# AGENTS.md — Tenacious

Notes for agentic assistants working in this repo. `CLAUDE.md` is a
symlink to this file, so the same rules apply to claude- and
codex-flavored agents alike.

## Git hygiene

- Every edit in this project must end up either committed or explicitly
  listed in `.gitignore`. No untracked-but-intended-to-keep files lying
  around.
- Never use wildcard git adds: no `git add .`, no `git add -A`, no
  `git add -u`, no globbed paths like `git add src/`.
- Always stage and commit files individually by explicit path
  (`git add path/to/file1 path/to/file2`).

## Auth bank — checking real status

The auth bank lives at `~/.tenacious/auth-bank/` with one subdir per
provider (`openai/`, `anthropic/`) and one account dir under each
(`default/`). Inside each account dir are credential slots:

```
~/.tenacious/auth-bank/openai/default/
    auth.json            # codex credential slot
    auth.json.lock       # persistent flock sentinel (openai only)
    codex1.json … codex9.json
    codex1.json.lock     # one .lock per slot that has ever been leased
~/.tenacious/auth-bank/anthropic/default/
    cc1.txt … cc5.txt    # claude credential slots (no .lock files)
    ccsecret.txt
```

Anthropic accounts no longer create `.lock` files because
anthropic is lockless: tokens are static (`writeback=False`), so
there is no rotation race to guard against. `lease()` for
anthropic simply yields the first available `.txt` slot. The
flock-based mutual exclusion below applies to openai/codex only.

### `.lock` files DO NOT indicate active locks (openai/codex only)

Common mistake: assuming `ls` of the openai account dir tells you
which slots are currently leased. It does not.

Each `<slot>.lock` under `openai/` is a persistent sentinel file
created the first time that slot is ever leased (`authbank.py` opens
it with `"a+"` and calls `fcntl.flock(LOCK_EX | LOCK_NB)`). The file
stays on disk forever afterward. Its **existence** means "this slot
has been used at some point"; it tells you nothing about *current*
lock state. The actual flock is a kernel-side property of the open
fd inside the orchestrator process — invisible to `ls`, `stat`, or
mtime.

### How to see who actually holds a lock right now (openai/codex)

```sh
lsof 2>/dev/null | grep tenacious/auth-bank/openai
```

Each line is a real active flock. Columns: command, pid, user, fd,
type, ..., path. The pid is the orchestrator process holding the
lease (the lock is held for the duration of the `with
authbank.lease(...)` block in `orchestrator.py:run_codex`, which
wraps one subprocess invocation). Anthropic leases never appear in
this output because they never call `fcntl.flock`.

### How leases relate to the run lifecycle

The lease is scoped to **one agent subprocess invocation**, not the
whole step. In `orchestrator.py`:

```python
with authbank.lease("openai", account) as slot:
    ...
    result = _supervise(cmd, ..., outcome_path=step_dir/"outcome.txt", ...)
    ...
# lease released here, when the `with` exits
```

Consequences worth knowing:

- **During a Q&A pause the lease is released.** The agent exited with
  `outcome=question`, `_supervise` returned, the `with` ended. The
  orchestrator is now polling for `answer.txt`; no auth slot is held.
- **Between visits the lease is released.** Each visit is a fresh
  subprocess and a fresh lease.
- **A wedged agent process keeps its lease until the process is reaped.**
  If codex/claude hangs internally but is still alive, the orchestrator
  is still inside `_supervise`, still inside the `with`, still holding
  the flock. Killing the wedged child releases it.
- **Crashes are safe.** flock auto-releases when the holding process
  dies; no stale-lock sweeper is needed.

### Free slots vs busy slots — quick mental model (openai/codex)

Anthropic is lockless, so its slot count never bounds concurrency.
For openai/codex, to know whether a run can launch a new agent
invocation right now:

```sh
# codex/openai slots in use:
lsof 2>/dev/null | grep -c openai/default
```

Compare against the total slot count (`ls openai/default/*.json | wc -l`,
excluding `.lock` files). If in-use ≥ total, the next lease will
block until someone releases.

### Cross-check: which agent processes are alive

```sh
pgrep -fl "codex exec" | head
pgrep -fl "claude -p"  | head
```

For each pid, `ps -p <pid> -o ppid=` gives the parent orchestrator,
which lets you map an active flock back to a specific run.

## Other quick references

- Per-run logs: `~/.tenacious/runs/<slug>/run.log`
- Per-step working dirs: `~/.tenacious/runs/<slug>/<step>/<NNN>/`
- Each agent profile (codex CODEX_HOME / claude CLAUDE_CONFIG_DIR):
  `~/.tenacious/runs/<slug>/profiles/<step>/`
- Codex rollouts (the canonical "is the stream still flowing" signal
  for a live codex visit):
  `~/.tenacious/runs/<slug>/profiles/<step>/sessions/<YYYY>/<MM>/<DD>/rollout-*.jsonl`
