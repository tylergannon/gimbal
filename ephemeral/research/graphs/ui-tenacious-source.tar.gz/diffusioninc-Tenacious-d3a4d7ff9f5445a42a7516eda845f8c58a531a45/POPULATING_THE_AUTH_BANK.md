# Populating the auth bank

How to generate provider credentials and load them into
`~/.tenacious/auth-bank/` as leasable slots.

## Layout recap

```
~/.tenacious/auth-bank/
    openai/<account>/<name>.json     # codex auth artifacts
    anthropic/<account>/<name>.txt   # claude oauth tokens
```

`list_slots` treats **every** file with the provider's extension
(`.json` for openai, `.txt` for anthropic, excluding `.lock`) as a
slot. So:

- Names are free — `codex1.json`, `primary.json`, etc. — only the
  extension matters.
- More distinct files in one account dir = more concurrent calls
  allowed against that account.
- Each slot must hold a **unique** credential. Two slots with the same
  token let two concurrent calls hit the same real account at once.
- Do **not** copy non-credential `.json` files (codex's
  `version.json`, `models_cache.json`) into the bank — they'd become
  bogus slots.

## 1. Generate codex credentials

Codex writes its `auth.json` into `$CODEX_HOME`. Create one directory
per account up front, then log in into each:

```sh
mkdir -p ~/dev/authbanksetup/codex{1..9}
CODEX_HOME=~/dev/authbanksetup/codex9 codex   # log in, then quit; repeat per dir
```

Each `~/dev/authbanksetup/codexN/` ends up with `auth.json` (plus
`version.json` / `models_cache.json`, which we ignore).

## 2. Load codex slots into the bank

Copy only the `auth.json` from each, renamed so they're distinct slots
in one account (`default` here):

```sh
dest=~/.tenacious/auth-bank/openai/default
mkdir -p "$dest"
for n in 1 2 3 4 5 6 7 8 9; do
  cp ~/dev/authbanksetup/codex$n/auth.json "$dest/codex$n.json"
  chmod 600 "$dest/codex$n.json"
done
```

Verify all slots are unique:

```sh
shasum -a 256 "$dest"/*.json | sort
```

## 3. Generate and load anthropic credentials

`claude setup-token` runs an interactive (browser) login and prints an
oauth token to stdout. Point `CLAUDE_CONFIG_DIR` at a per-account dir
(create them up front, as with codex):

```sh
mkdir -p ~/dev/authbanksetup/claude{1..9}
CLAUDE_CONFIG_DIR=~/dev/authbanksetup/claude1 claude setup-token
```

Copy the printed token and save it as a `.txt` slot. The slot file's
entire contents are the token (the orchestrator does
`slot.read_text().strip()`), so no JSON, no surrounding text:

```sh
dest=~/.tenacious/auth-bank/anthropic/default
mkdir -p "$dest"
printf '%s' 'PASTE_TOKEN_HERE' > "$dest/claude1.txt"
chmod 600 "$dest/claude1.txt"
```

Repeat per account/slot (`claude2.txt`, …). Same rules as codex: names
are free, the `.txt` extension is what matters, and each slot must hold
a unique token.

> **Anthropic accounts are no longer flocked, and a single `.txt` slot
> is sufficient.** The anthropic token is static (`writeback=False`),
> so there is no rotation race to protect — `lease()` for anthropic
> simply yields the first `.txt` slot in the account without opening
> any `.lock` file. Extra slots remain harmless but unnecessary, and
> no `.lock` files are created for anthropic. Codex/openai still uses
> per-slot flock because codex mutates `auth.json` in place
> (`writeback=True`); each concurrent codex slot needs its own
> distinct, separately-generated credential. Multiple distinct
> anthropic tokens only matter when you deliberately want to spread
> load across separate accounts.

## Notes

- openai has `writeback=True`: codex rotates these tokens in place
  during runs, so bank slots diverge from the originals in
  `authbanksetup` over time. Don't re-copy expecting them to match.
- anthropic has `writeback=False`: these tokens are static and never
  written back, so the bank slot is the single source of truth.
