# Slack MCP → Tenacious How-To

How to authenticate the Slack MCP server inside Claude Code, extract the
resulting OAuth token, and use it in a Tenacious workflow over the new
HTTP MCP transport.

## TL;DR

1. Install the Slack plugin: `claude plugin install slack` (one-time).
2. In Claude Code, run the Slack MCP `authenticate` tool and complete
   the OAuth flow in your browser.
3. Extract the access token from the macOS Keychain
   (`Claude Code-credentials-*` entries) and save it under
   `~/.tenacious/secrets/slack-mcp-token`.
4. In your workflow YAML, declare the Slack server with `url` +
   `bearer_token_env_var: "SLACK_MCP_TOKEN"`.
5. `export SLACK_MCP_TOKEN=$(cat ~/.tenacious/secrets/slack-mcp-token)`
   before running `tenacious`.

The rest of this doc is the long form.

---

## Part 1 — Set up the Slack MCP in Claude Code

The Slack MCP is one of the official **cloud MCP plugins** shipped with
Claude Code. It is served from `https://mcp.slack.com/mcp` and uses
OAuth (not an `xoxb-` bot token) so each user authenticates as
themselves against the workspace they choose.

### 1.1 Install the Slack plugin (one-time)

The Slack MCP ships as a Claude Code plugin from the official
marketplace. Install it once per machine:

```sh
claude plugin install slack
```

This pulls the plugin from
`https://github.com/slackapi/slack-mcp-plugin.git` and registers the
`plugin:slack:slack` MCP server (you'll see it in `claude mcp list`
after this, in `! Needs authentication` state until you finish 1.2).

### 1.2 Trigger the OAuth flow

From inside a Claude Code session, ask the model to authenticate the
Slack MCP. Under the hood it invokes:

```
mcp__plugin_slack_slack__authenticate
```

You'll get back an OAuth authorization URL like:

```
https://slack.com/oauth/v2_user/authorize?response_type=code
  &client_id=1601185624273.8899143856786
  &code_challenge=...
  &code_challenge_method=S256
  &redirect_uri=http%3A%2F%2Flocalhost%3A3118%2Fcallback
  &state=...
  &scope=search%3Aread.public+search%3Aread.private+...+channels%3Ahistory+...
  &resource=https%3A%2F%2Fmcp.slack.com%2F
```

Open it in a browser.

### 1.3 Pick the right workspace

The OAuth page defaults to whichever Slack workspace your browser is
already signed in to. If that's wrong, click **"Sign in to a different
workspace"** at the bottom of the Slack consent page and enter the
workspace slug you actually want (e.g. `famtokash`).

Approve the requested scopes — they're broad (`search:read.*`,
`channels:history`, `chat:write`, `reactions:write`, `canvases:*`,
`users:read*`, …) because the MCP exposes the full Slack toolset.

### 1.4 Verify the connection

Back in your terminal:

```
$ claude mcp list
claude.ai Gmail:          ✓ Connected
claude.ai Google Drive:   ! Needs authentication
claude.ai Google Calendar:! Needs authentication
plugin:slack:slack:       https://mcp.slack.com/mcp (HTTP) - ✓ Connected
```

A `✓ Connected` line for `plugin:slack:slack` means Claude Code has a
valid access token cached. From inside Claude Code you can now call any
`mcp__plugin_slack_slack__*` tool (`slack_search_public`,
`slack_read_channel`, etc.).

---

## Part 2 — Why Tenacious needs extra wiring

Tenacious orchestrates `claude -p` and `codex exec` subprocesses, one
per step, each in its own profile dir. For MCP it writes a per-step
config file and launches the agent with `--strict-mcp-config` (claude)
or a freshly-scoped `$CODEX_HOME` (codex). Two consequences:

- **Strict mode replaces the user's MCP set.** The `plugin:slack:slack`
  server registered globally in Claude Code is *not* inherited; the
  workflow has to declare its own `slack` entry.
- **Tenacious must speak HTTP MCP.** The earlier round-1 schema only
  knew about stdio servers (`command` + `args` + `env`). The Slack MCP
  is HTTP, so the schema needed `url` + bearer-token support — see
  `tenacious/orchestrator.py` and the new tests in
  `tests/test_mcp_config.py`.

The cloud OAuth token isn't usable directly with `claude -p
--strict-mcp-config` either, because Claude Code's automatic
plugin-token injection only happens for the user-global MCP set, not
for servers we hand-write into `--mcp-config`. We have to put the
`Authorization: Bearer …` header in the per-step MCP config ourselves.

---

## Part 3 — Extract the OAuth token from Claude Code

Claude Code stores MCP OAuth tokens in the **macOS login keychain**
under service names like `Claude Code-credentials`, `Claude
Code-credentials-<hex>`. The blob in each entry is a JSON document of
the form:

```json
{
  "claudeAiOauth": { "accessToken": "sk-ant-oat01-…", … },
  "mcpOAuth": {
    "plugin:slack:slack|<short-hex>": {
      "serverName":  "plugin:slack:slack",
      "serverUrl":   "https://mcp.slack.com/mcp",
      "accessToken": "xoxe.xoxp-1-…",
      "refreshToken":"xoxe-1-…",
      "expiresAt":   1779613627270,
      "scope":       "channels:history,…"
    }
  }
}
```

The Slack token usually lives in one of the suffixed entries (not the
unsuffixed one). To find and extract it:

```sh
# List candidate entries
security dump-keychain ~/Library/Keychains/login.keychain-db \
  | grep -E '"svce".*Claude Code-credentials' | sort -u

# For each candidate, read it and check whether it contains a plugin:slack:slack token.
# Replace <SUFFIX> with what you saw above; macOS will prompt you to allow
# the security command to read the keychain item (Always Allow is fine).
security find-generic-password -s "Claude Code-credentials-<SUFFIX>" -g 2>&1 \
  | sed -n 's/^password: "\(.*\)"$/\1/p' \
  | python3 -c '
import json, sys
d = json.loads(sys.stdin.read())
for k, v in d.get("mcpOAuth", {}).items():
    if "slack" in k.lower():
        print(v["accessToken"])
        break
'
```

The result is a Slack user token (`xoxe.xoxp-…`).

### 3.1 Stash the token

Tenacious uses `~/.tenacious/secrets/` as a per-user secret dir. Save
the token there with restrictive permissions:

```sh
mkdir -p ~/.tenacious/secrets
umask 077
echo -n "$THE_TOKEN_YOU_JUST_EXTRACTED" > ~/.tenacious/secrets/slack-mcp-token
chmod 600 ~/.tenacious/secrets/slack-mcp-token
```

The token expires (the `expiresAt` field above is the millisecond
deadline). When that happens, re-authenticate in Claude Code and
re-extract.

---

## Part 4 — Declare the Slack MCP in a workflow

With HTTP MCP support, a workflow step can declare:

```yaml
mcp_servers:
  slack:
    url: https://mcp.slack.com/mcp
    bearer_token_env_var: SLACK_MCP_TOKEN
```

The legacy JSON shape is:

```json
"mcp_servers": {
  "slack": {
    "url": "https://mcp.slack.com/mcp",
    "bearer_token_env_var": "SLACK_MCP_TOKEN"
  }
}
```

Rules:

- `url` and `command` are mutually exclusive — exactly one must be
  present per server.
- `bearer_token_env_var` names an env var. **The token itself never
  goes in the workflow file.**
- An optional `headers` object can carry extra HTTP headers.

What the orchestrator does with that at step-execution time:

| Agent  | File written into profile dir | Bearer token handling |
|--------|-------------------------------|-----------------------|
| claude | `mcp-servers.json` with `type: "http"`, `url`, and merged `headers` | Token resolved from `$SLACK_MCP_TOKEN` in the orchestrator's env; injected as `Authorization: Bearer <token>` |
| codex  | `config.toml` with `url = "…"` and `bearer_token_env_var = "SLACK_MCP_TOKEN"` | Codex itself resolves the env var at connect time |

The `run.log` summary line looks like:

```
mcp_servers: 1 http (slack)
```

A worked example shipping in the repo is
`workflows/secret-word-slack.json` — Opus 4.7 and Codex each search the
famtokash `#general` channel for a "secret word", then a third Claude
step compares their answers.

---

## Part 5 — Run it

```sh
export SLACK_MCP_TOKEN=$(cat ~/.tenacious/secrets/slack-mcp-token)

PYTHONPATH=~/dev/Tenacious \
  ~/dev/Tenacious/.venv/bin/python -m tenacious \
  ~/dev/Tenacious/workflows/secret-word-slack.json
```

Watch the run directory:

```sh
ls -tr ~/.tenacious/runs/ | tail -1
tail -F ~/.tenacious/runs/<run-slug>/run.log
```

In each step's profile dir you can confirm what the orchestrator
actually wrote:

```sh
# Claude side
cat ~/.tenacious/runs/<run-slug>/profiles/opus-search/mcp-servers.json
# Codex side
cat ~/.tenacious/runs/<run-slug>/profiles/codex-search/config.toml
```

The claude JSON will contain a literal `Authorization: Bearer xoxe.xoxp-…`
in `headers`. That file is inside a per-step directory under
`~/.tenacious/runs/` whose parent is `chmod 700` by default; if you want
extra hygiene you can delete those run dirs after a successful run.

---

## Troubleshooting

- **`unknown mcp_servers field(s) for slack: ['bearer_token_env_var', 'url']`**
  You're running the pre-HTTP version of `orchestrator.py`. Make sure
  the `tenacious` package on `sys.path` (or wired up via the venv's
  editable install) is the worktree/branch that has HTTP MCP support.
  An editable install pinned to a different checkout will silently
  override `PYTHONPATH`.

- **`401` / "invalid_auth" from Slack inside the agent**
  Token expired or wrong workspace. Re-run the Claude Code
  authenticate flow (Part 1), re-extract the token (Part 3), and
  re-export `SLACK_MCP_TOKEN`.

- **`claude mcp list` shows the Slack server as `! Needs authentication`**
  The cached OAuth token has expired or been revoked. Same fix —
  re-authenticate in Claude Code.

- **`claude mcp get plugin:slack:slack` errors with "No MCP server found"**
  The Claude Code CLI's argument parser has a quirk around colons in
  MCP names; the server *is* registered (see `claude mcp list`), you
  just can't `get` it by name. Read it out of the keychain instead
  (Part 3).

- **Wrong workspace in OAuth UI**
  Use the "Sign in to a different workspace" link at the bottom of the
  Slack consent page before approving.
