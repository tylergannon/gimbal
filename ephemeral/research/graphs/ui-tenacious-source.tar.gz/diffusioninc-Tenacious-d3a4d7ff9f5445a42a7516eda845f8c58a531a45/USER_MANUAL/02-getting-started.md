# 2. Getting started

[← Overview](01-overview.md) · [Table of contents](TOC.md) · [Next: Running workflows →](03-running-workflows.md)

## Requirements

- **Python 3.11+**.
- The **Claude Code** CLI and/or the **Codex** CLI installed and on
  `PATH` — whichever agents your workflow uses.
- Credentials for those CLIs, loaded into the *auth bank* (below).

There is no `pip install`; you run it from the source tree as a module:

```sh
cd /Users/johntokash/dev/Tenacious
python -m tenacious --help
python -m tenacious.viewer --help
```

## Where Tenacious keeps its data

Everything lives under one home directory:

- Default: `~/.tenacious`
- Override: set `TENACIOUS_HOME`, or pass `--home PATH` to the viewer.

```
~/.tenacious/
  auth-bank/          # your credentials, as leasable slots (set up below)
  runs/               # one directory per run (created automatically)
```

## The auth bank (one-time setup)

Tenacious never reads your normal CLI login. Instead it borrows
credentials from a **bank** of slot files, leasing one slot at a time so
parallel agent calls don't fight over the same account. You must populate
the bank before your first run.

### Layout

```
~/.tenacious/auth-bank/
  openai/<account>/<name>.json     # Codex auth artifacts
  anthropic/<account>/<name>.txt   # Claude OAuth tokens
```

Rules that bite people:

- **Only the extension matters.** Any `.json` under `openai/` is a Codex
  slot; any `.txt` under `anthropic/` is a Claude slot. Names are free.
- **More files = more concurrency — for codex.** Codex/openai slots are
  flocked while in use, so N `.json` files in a codex account dir allow N
  concurrent codex calls against it. Anthropic slots are **lockless**
  (their tokens are static, so there is no rotation race to guard against
  and `fcntl.flock` is not called), which means a single `.txt` file in
  an anthropic account dir already serves any concurrency level — extra
  anthropic slots are harmless but unnecessary.
- **Every slot must be a *unique* credential.** Two slots holding the same
  token means two concurrent calls hammer one real account.
- **Don't copy junk in.** Codex also writes `version.json` and
  `models_cache.json` — keep those *out* of the bank or they become bogus
  slots.

### Codex slots

Codex writes `auth.json` into `$CODEX_HOME`. Make one dir per account,
log in to each, then copy just the `auth.json`:

```sh
mkdir -p ~/dev/authbanksetup/codex{1..9}
CODEX_HOME=~/dev/authbanksetup/codex1 codex      # log in, quit; repeat per dir

dest=~/.tenacious/auth-bank/openai/default
mkdir -p "$dest"
for n in 1 2 3 4 5 6 7 8 9; do
  cp ~/dev/authbanksetup/codex$n/auth.json "$dest/codex$n.json"
  chmod 600 "$dest/codex$n.json"
done
shasum -a 256 "$dest"/*.json | sort      # confirm all slots are unique
```

Codex rotates these tokens *in place* during runs (writeback), so each
concurrent slot needs its own separately-generated credential. Don't
re-copy from the setup dirs later expecting them to still match.

### Claude slots

`claude setup-token` does a browser login and prints an OAuth token. The
slot file's entire contents must be just that token — no JSON, no quotes,
no trailing text:

```sh
mkdir -p ~/dev/authbanksetup/claude1
CLAUDE_CONFIG_DIR=~/dev/authbanksetup/claude1 claude setup-token

dest=~/.tenacious/auth-bank/anthropic/default
mkdir -p "$dest"
printf '%s' 'PASTE_TOKEN_HERE' > "$dest/claude1.txt"
chmod 600 "$dest/claude1.txt"
```

The Claude token is static (no writeback) and the anthropic side of the
auth bank is **lockless**, so **one** `.txt` slot per anthropic account
is enough — it serves any concurrency level. Extra `.txt` files inside
the same account dir are harmless but add nothing; you only want multiple
slots when you deliberately want to spread load across *distinct*
anthropic accounts (e.g. `anthropic/work/claude1.txt`,
`anthropic/personal/claude1.txt`).

> The full reference is `POPULATING_THE_AUTH_BANK.md` in the repo root.

### Skipping the bank

If you'd rather bill a provider directly through its metered API instead
of populating the bank for it, Tenacious has two opt-in top-level flags:
`--costly-use-anthropic-api-key` and `--costly-use-codex-api-key`. They
tell the orchestrator to skip the auth-bank lease for that provider and
pass an API key from the orchestrator's own environment to the child
agent. They are called "costly" because each child invocation is **billed
per token** against that key. The anthropic flag reads `ANTHROPIC_API_KEY`
from the env; the codex flag reads `CODEX_API_KEY` (preferred) or falls
back to `OPENAI_API_KEY`. With a flag set and its env var present, the
run can launch with an empty/absent `auth-bank/<provider>/` tree —
nothing in that subtree needs to exist. See
[`03-running-workflows.md`](03-running-workflows.md) for the full
mechanics, including the exact run-log banners and the startup errors for
missing environment variables.

If you already have a normal Claude Code or Codex home directory with
working auth, you can use that directly instead of the bank:
`--claude-code-home DIR` sets `CLAUDE_CONFIG_DIR` for child Claude
processes, and `--codex-home DIR` sets `CODEX_HOME` for child Codex
processes. User-home mode writes sessions and auth state under the
directory you name, while Tenacious still writes run metadata under
`~/.tenacious/runs/`. See chapter 3 for the exact mutual-exclusion rules
between auth bank, API-key mode, and user-home mode.

## Your first run

```sh
python -m tenacious workflows/hello-claude.json
```

For a one-step YAML smoke test on Claude Fable 5, use:

```sh
python -m tenacious workflows/hello-claude-fable5.yaml \
  --project-dir /tmp/tenacious-hello \
  --claude-code-home ~/.claude
```

On success it prints the run directory:

```
Run directory: /Users/you/.tenacious/runs/20260518092345-001
```

Then look at it:

```sh
python -m tenacious.viewer        # interactive — see chapter 6
```

[← Overview](01-overview.md) · [Table of contents](TOC.md) · [Next: Running workflows →](03-running-workflows.md)
</content>
