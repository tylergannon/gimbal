# 4. The built-in 6-step workflow

[← Running workflows](03-running-workflows.md) · [Table of contents](TOC.md) · [Next: Answering questions →](05-answering-questions.md)

`workflows/6step.yaml` is a complete, reusable workflow that builds
software **one tightly-scoped round at a time**, with you steering scope
through Q&A. It is the flagship example — read it to learn the patterns.

`workflows/6step-goal-only.yaml` is the sibling for unattended or
already-specified work: the CLI `--goal` is treated as the round's
requirements, so the workflow starts at planning instead of interviewing
you.

## Running it

```sh
python -m tenacious workflows/6step.yaml --project-dir /Users/you/dev/myproject
```

You will be asked questions during the `requirements` step (chapter 5
explains the editor). Everything else runs unattended between your
answers.

To skip the requirements interview and drive the round entirely from a
goal string:

```sh
python -m tenacious workflows/6step-goal-only.yaml \
  --project-dir /Users/you/dev/myproject \
  --goal "Build the requested feature and verify it."
```

## The six steps

```
        ┌──────────────┐
        │ requirements │  Claude · asks you questions · one round's scope
        └──────┬───────┘
               ▼
        ┌──────────────┐
        │     plan     │  Claude · turns requirements into a concrete plan
        └──────┬───────┘
               ▼
        ┌──────────────┐
        │  plan_eval   │  Codex · critiques the plan vs. requirements
        └──────┬───────┘
               ▼
        ┌──────────────┐
        │ plan_update  │  Claude · revises the plan, may reject feedback
        └──────┬───────┘
               ▼
        ┌──────────────┐
        │     code     │◄────────┐  Claude · implements & actually runs it
        └──────┬───────┘         │
               ▼                 │ feedback
        ┌──────────────┐         │ (review failed)
        │ code_review  │─────────┘  Codex · runs the program, judges it
        └──────┬───────┘
               │ passed
               ▼
        back to requirements  ──►  next round (or you stop)
```

1. **requirements** (Claude, asks questions). Interviews you one
   multiple-choice question at a time, probing both what to build *and*
   what is explicitly out of scope this round. It keeps asking until your
   answer says you're done (e.g. contains "done with questions"). Then it
   writes `requirements-NNNN.md` and `requirements-current.md` as assets.

2. **plan** (Claude). Reads `requirements-current.md`, writes a concrete
   implementation plan (files, exact CLI contract, how it will be
   verified) to `plan-NNNN.md` / `plan-current.md`.

3. **plan_eval** (Codex). Critiques the plan against the requirements —
   gaps, risks, over-engineering, missing verification — into
   `plan-feedback-current.md`.

4. **plan_update** (Claude). Folds in the feedback it agrees with,
   explicitly records rejected feedback, and overwrites
   `plan-current.md`.

5. **code** (Claude). Implements exactly the in-scope work in
   `--project-dir`, then **actually runs the program** to verify it, and
   runs the project's full test suite before signaling completion. It
   records what it ran and observed in `code-notes-current.md`. Honors a
   git worktree if the requirements/plan mandate one. Runs fully
   unattended (it must never block on terminal input).

6. **code_review** (Codex). Runs the program itself and reviews the code.
   It also checks that the coder did not delete, skip, xfail, narrow, or
   loosen tests unless the current plan explicitly required that exact
   change.
   - **Critically wrong** → writes `code-feedback-current.md` and sends
     the run **back to `code`** (the loop arrow above).
   - **Meets requirements** → writes `status-update-current.md`, clears
     the feedback file, and advances **back to `requirements`** to start
     the next round.

## The round loop

The workflow never ends on its own. Each successful `code_review` returns
to `requirements`, which reads the previous round's
`status-update-current.md` to frame what to build next. You end it by
stopping the process (or answering in a way that wraps the engagement,
per the requirements prompt).

## Following along while it runs

Open a second terminal and watch with the viewer (chapter 6). Drill into
the run, then the `code` step, then its session, to watch Claude
implement in real time — the viewer re-reads disk every redraw, so it
updates live.

## Per-round asset naming

Each round `N` (zero-padded to 4 digits) leaves a permanent record *and* a
stable "current" handle the next step reads:

| Permanent | Stable handle |
|---|---|
| `requirements-0001.md` | `requirements-current.md` |
| `plan-0001.md` | `plan-current.md` |
| `plan-feedback-0001.md` | `plan-feedback-current.md` |
| `plan-revised-0001.md` | (overwrites `plan-current.md`) |
| `code-notes-0001.md` | `code-notes-current.md` |
| `code-feedback-0001.md` | `code-feedback-current.md` |
| `status-update-0001.md` | `status-update-current.md` |

All of these are in the run's `assets/` directory (chapter 8).

[← Running workflows](03-running-workflows.md) · [Table of contents](TOC.md) · [Next: Answering questions →](05-answering-questions.md)
</content>
