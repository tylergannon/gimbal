# 5. Answering agent questions

[← The 6-step workflow](04-six-step-workflow.md) · [Table of contents](TOC.md) · [Next: The session viewer →](06-viewer-tui.md)

When a step is allowed to ask questions (`"questions": true`) and the
agent writes a `question.txt`, an **attended** run pauses and opens a
multi-line editor right in your terminal.

## What you'll see

```
[Question from agent]
<the agent's question>

Enter inserts a newline.
Submit: press Esc then Enter.  (Ctrl-D also submits.)
Ctrl-C cancels.  Left/Right = char; Option/Alt+Left/Right = word.
(On some terminals Alt+Enter also submits; use Esc then Enter if unsure.)
--- type your answer below ---
```

## The one thing everyone gets wrong

**Enter does NOT submit. Enter inserts a newline.**

This is deliberate — answers are often multi-paragraph. To send your
answer:

| To do this | Press |
|---|---|
| **Submit the answer** | **`Esc` then `Enter`** (press Esc, release, then Enter) |
| Submit (alternative) | `Ctrl-D` |
| New line within the answer | `Enter` |
| Cancel the whole run | `Ctrl-C` |

If you press Enter expecting it to submit and nothing happens — that's
working as designed. Press **`Esc` then `Enter`**.

## Editing controls

The editor is a real multi-line editor with live cursor feedback:

| Key | Action |
|---|---|
| Left / Right arrow | Move one character |
| Up / Down arrow | Move one line (same column) |
| Home / End | Start / end of the current line |
| Option/Alt + Left / Right | Jump by word |
| Backspace | Delete the character before the cursor |
| Delete | Delete the character at the cursor |
| Tab | Inserts a literal tab |

**Pasting works.** Bracketed paste is enabled, so multi-line clipboard
content is inserted verbatim — pasting a block that contains newlines will
*not* accidentally submit it.

When you submit, only trailing blank lines are trimmed; newlines inside
your answer are preserved exactly.

## Unattended answers (`--answers`)

If you started the run with `--answers answers.txt`, the editor never
opens. Each question consumes the next line of that file in order. Useful
for replaying a run or for CI.

For the 6-step workflow's `requirements` step, the prompt asks
multiple-choice questions whose answers begin with a letter, and it keeps
asking until your answer indicates you're done — so an `--answers` file
for it is a list of letter choices ending with a "done with questions"
line.

## Edge case: no terminal

If the editor can't open a real terminal (`/dev/tty` unavailable, raw
mode fails), it falls back to reading your answer from standard input
until EOF. You lose live cursor editing but multi-line and paste still
work; finish with the terminal's EOF (`Ctrl-D`).

[← The 6-step workflow](04-six-step-workflow.md) · [Table of contents](TOC.md) · [Next: The session viewer →](06-viewer-tui.md)
</content>
