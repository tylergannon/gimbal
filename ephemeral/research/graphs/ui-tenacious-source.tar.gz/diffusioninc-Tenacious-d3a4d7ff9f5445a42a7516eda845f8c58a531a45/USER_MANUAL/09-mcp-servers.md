# 9. MCP servers per step

[← The run directory](08-run-directory.md) · [Table of contents](TOC.md)

A step can declare one or more **MCP (Model Context Protocol) servers**
in its workflow file. When the orchestrator visits the step, it
materializes the right per-agent config into the step's profile
directory and the spawned agent (claude or codex) exposes those
servers' tools alongside its built-ins.

For deeper detail see the design docs under `docs/mcp/`:
[`tenacious-mcp-design.md`](../docs/mcp/tenacious-mcp-design.md),
[`how-to-add-mcp-to-a-step.md`](../docs/mcp/how-to-add-mcp-to-a-step.md),
[`claude-mcp-config.md`](../docs/mcp/claude-mcp-config.md),
[`codex-mcp-config.md`](../docs/mcp/codex-mcp-config.md).

## Schema

Add an optional `mcp_servers` object to any step. YAML is preferred:

```yaml
mcp_servers:
  stdio_name:
    command: /abs/path/to/exe
    args:
    - --flag
    - value
    env:
      KEY: value
  http_name:
    url: https://example.com/mcp
    headers:
      X-Custom: value
    bearer_token_env_var: MCP_TOKEN
```

The same shape can appear in legacy JSON workflows:

```json
"mcp_servers": {
  "stdio_name": {
    "command": "/abs/path/to/exe",
    "args": ["--flag", "value"],
    "env": {"KEY": "value"}
  },
  "http_name": {
    "url": "https://example.com/mcp",
    "headers": {"X-Custom": "value"},
    "bearer_token_env_var": "MCP_TOKEN"
  }
}
```

Rules, enforced at workflow load:

- A server must declare exactly one transport:
  - stdio: `command` is required (string, non-empty); `args` defaults to
    `[]`; `env` defaults to `{}`.
  - HTTP: `url` is required (string, non-empty); `headers` defaults to
    `{}`; `bearer_token_env_var`, when present, names an environment
    variable whose value is injected as `Authorization: Bearer <value>`
    for Claude and passed through for Codex.
- Server names must match `^[A-Za-z0-9_-]{1,64}$`.
- Unknown keys under a server entry (including `cwd`) are rejected.
- Explicit `null` for `mcp_servers` is rejected — omit the key if you
  mean "no servers".
- Supported transports are stdio and HTTP. SSE / WebSocket / SDK
  transports, per-server `cwd`, OAuth flows, and timeouts are deferred.

## Four worked examples

### Filesystem reference server (off-the-shelf, via npx)

```json
"mcp_servers": {
  "fs": {
    "command": "/opt/homebrew/bin/npx",
    "args": ["-y",
             "@modelcontextprotocol/server-filesystem",
             "/tmp/tenacious-mcp-sandbox"]
  }
}
```

No credentials, no network beyond the initial `npx` fetch. A full
working snippet lives at `docs/mcp/example-step-with-mcp.json`.

### In-repo echo fixture (stdio, stdlib Python only)

```json
"mcp_servers": {
  "echo": {
    "command": "/usr/bin/python3",
    "args": ["/abs/path/to/tenacious/tests/_mcp_servers/echo_server.py"],
    "env": {"ECHO_PREFIX": "X:"}
  }
}
```

Useful for tests and quick demos. `ECHO_PREFIX` proves the `env`
plumbing reaches the spawned server.

### `uvx`-launched stdio server (e.g. mcp-server-time)

```json
"mcp_servers": {
  "time": {
    "command": "/opt/homebrew/bin/uvx",
    "args": ["mcp-server-time", "--local-timezone", "America/Los_Angeles"]
  }
}
```

`uvx` fetches + caches on first use, then spawns directly.

### HTTP server with a bearer token

```json
"mcp_servers": {
  "slack": {
    "url": "https://mcp.slack.com/mcp",
    "bearer_token_env_var": "SLACK_MCP_TOKEN"
  }
}
```

Set `SLACK_MCP_TOKEN` in the orchestrator environment before launching
the run. Tenacious does not store token values in the workflow file.

## What happens at runtime

1. The orchestrator validates `mcp_servers` at workflow load.
2. On each visit, it writes one file into
   `<run_root>/profiles/<step>/`:
   - claude → `mcp-servers.json`
   - codex  → `config.toml`
3. For claude, the rendered command line gains
   `--mcp-config <abs-path> --strict-mcp-config`. For codex, no extra
   flag is needed — codex auto-loads via `$CODEX_HOME`.
4. `run.log` gets one summary line per visit, e.g.
   `mcp_servers: 1 stdio (fs), 1 http (slack)` (or
   `mcp_servers: none`).
5. The agent talks to each declared server using the selected transport.

## Replacement-only semantics

For claude, `--strict-mcp-config` makes step-declared servers the
**only** MCP sources the agent sees for that invocation. User,
project, local, enterprise, and claudeai sources are ignored. Codex
gets the same effect via the per-step `CODEX_HOME` containing only
what the orchestrator wrote. This makes steps reproducible across
machines: the tool surface can't silently vary by developer.

## Tips

- Always use an absolute path in `command`. The agent's `cwd` is the
  project dir, not the orchestrator's cwd.
- Keep server names short and stable — they show up in `run.log` and
  in the agent's tool listing.

## Verifying it worked

After a run, inspect:

- `~/.tenacious/runs/<run-slug>/profiles/<step>/mcp-servers.json`
  (claude) or `…/config.toml` (codex).
- `~/.tenacious/runs/<run-slug>/run.log` for the
  `mcp_servers: N stdio (...), M http (...)` line.
- `~/.tenacious/runs/<run-slug>/<step>/<visit>/stdout.txt` for tool
  calls whose names match your declared servers.

[← The run directory](08-run-directory.md) · [Table of contents](TOC.md)
