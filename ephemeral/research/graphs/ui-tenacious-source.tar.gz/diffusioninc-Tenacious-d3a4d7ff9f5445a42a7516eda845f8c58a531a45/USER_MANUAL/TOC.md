# Tenacious — User Manual

Tenacious orchestrates multi-step workflows of AI coding agents (Claude Code
and Codex). It runs each step as a separate agent invocation, passes files
between steps, pauses for your answers when an agent asks a question, and
records every byte so you can replay what happened.

## Table of contents

1. [Overview & core concepts](01-overview.md)
   What a workflow, run, step, visit, session, and asset are — and how they
   relate.

2. [Getting started](02-getting-started.md)
   Requirements, the auth bank, and your first run.

3. [Running workflows](03-running-workflows.md)
   The `python -m tenacious` command, its flags, and the YAML workflow
   format. JSON workflows are legacy compatibility.

4. [The built-in 6-step workflow](04-six-step-workflow.md)
   The included `workflows/6step.yaml` and `6step-goal-only.yaml`:
   iterative requirements/goal → plan → code → review loops.

5. [Answering agent questions](05-answering-questions.md)
   The multi-line answer editor: when it appears, how to type, and — the
   part that trips everyone up — **how to submit**.

6. [The session viewer (TUI)](06-viewer-tui.md)
   **Read this if the viewer confuses you.** A full walkthrough of the
   four-screen terminal UI, the runs → steps → sessions → transcript
   hierarchy, and every key.

7. [The viewer command line](07-viewer-cli.md)
   Non-interactive ways to list runs and dump transcripts (scripting,
   piping, CI).

8. [The run directory](08-run-directory.md)
   Where every artifact is written on disk, so you can read it without any
   tool at all.

9. [MCP servers per step](09-mcp-servers.md)
   Declare MCP servers in a workflow step; how the orchestrator
   materializes them for claude and codex.

## The 30-second version

```sh
# 1. Load credentials into ~/.tenacious/auth-bank/  (one-time; see ch. 2)
# 2. Run a workflow:
python -m tenacious workflows/hello-claude-fable5.yaml --project-dir /tmp/hello

# 3. Look at what happened:
python -m tenacious.viewer            # interactive TUI
python -m tenacious.viewer --list     # plain list, for scripts
```
</content>
</invoke>
