# Running the AI-Player sessions through the orchestrator — options

Date: 2026-05-14
Updated: 2026-05-14 — the 600 s `subprocess.run` timeout has since
been removed from `run_codex`/`run_claude` (and the now-dead
`TimeoutExpired` handler dropped). Agent invocations are no longer
time-bounded. Sections below are revised to reflect that.

## TLDR

The AI-player work is a long-running, fully-autonomous, single-prompt
loop ("read the latest handoff and keep iterating, never ask, pushover
only"). The orchestrator (`tenacious/orchestrator.py`) can drive
it. The old hard blocker — a 600 s per-invocation `subprocess.run`
timeout that no bench could fit inside (a single game is ~24 min) —
**has been removed**, so an agent step may now run for hours. What
remains is an *operational* concern, not a wall: a single blocking
`subprocess.run` for the whole campaign has no checkpointing, so a
crash loses the run. The viable shapes are: (A) one long step that
runs the whole session in the foreground (now fully viable), (B) a
kickoff→poll→evaluate loop where benches run as backgrounded `nohup`
jobs and each step is short (best for checkpointing/resumability), or
(D) only use the orchestrator for the bounded analysis/decision/
handoff-writing phase and leave benching as the user's background
jobs. Everything else (bypass permissions, cwd, auth-bank,
autonomous = no questions) already lines up.

---

## What an AI-player session actually is

Confirmed from `~/.claudeHome/projects/-Users-johntokash-Dropbox-original-ExtremeOnslaught2026-Asteroids-ai-player/*.jsonl`
(19 sessions, 0.3–8 MB, ~1000–1600 records each) and the
`Asteroids/ai_player/handoffs/` directory (`handoff_recipe.md`,
`variant_ledger.md`, `ai_player_session3..14.md`,
`20260514-v11s-report.md`).

The opening user message is always a one-liner of the same shape:

- "Read this and get started — handoffs/ai_player_session6.md"
- "read handoffs/ai_player_session9.md and get to work. NEVER wait
  for my feedback or ask me questions. Only update me via pushover.
  Get to work!"
- "Get to work: handoffs/ai_player_session13.md"

From there the session is autonomous for its entire length:

1. Read `ai_player_session<N>.md` → `handoff_recipe.md` →
   `variant_ledger.md`.
2. Pick the next variant idea from the handoff frontier.
3. Edit `ai_player_5.py` (never `ai_player.py`), inject `[TIMING]`
   via `add_timing.py`.
4. **Restart the game server** (`pkill -9 -f server.py`, relaunch
   `nohup python server.py` on port 62600) — mandatory before
   every bench.
5. Launch `nohup python bench_variant.py <tag> <n> <c>` in the
   background.
6. Lightly monitor (120 s polls — `game_log.jsonl` is 100 MB+),
   read the per-game `[TIMING]` line, interpret avg/med/stdev vs
   HEAD.
7. Update `variant_ledger.md`, decide BANK/REV/TIE, pick the next
   variant, repeat.
8. When stuck or out of frontier: write the next
   `ai_player_session<N+1>.md` handoff and keep going.
9. Status to the user is **pushover only** — never asks, never waits.

Key properties for orchestration:

- **Duration**: hours. One game ≈ 1448 s wall. A bench of n=10 c=10
  is hours; n=50 c=10 is 2–3 h (per `handoff_recipe.md`).
- **Autonomous**: explicitly "never ask". No question flow needed.
- **Durable state lives in the repo, not the session**: handoffs,
  ledger, `game_log.jsonl`, `sessions.jsonl`, `death_replays/`. The
  Claude session itself is disposable; the campaign state is on
  disk in the Dropbox tree. Consecutive sessions chain purely
  through the handoff files.
- **Background processes outlive the agent**: the server and the
  bench are `nohup … & disown`. They keep running after the
  `claude -p` process that launched them exits.

---

## How the orchestrator works (relevant facts)

From `tenacious/orchestrator.py` and `tenacious/authbank.py`:

- A workflow is JSON: `goal`, `start_step`, and `steps{}` with
  `agent` (`claude`/`codex`), `model`, `prompt` (templated with
  `{goal} {run_slug} {assets_dir} {outcome_path} {step_dir}`),
  `asset_slugs`, `next_steps`, `context` (`empty`|`continue`),
  `questions`.
- Each step visit renders a prompt + an **ORCHESTRATOR CONTRACT**
  block telling the agent to write the next-step slug to
  `outcome.txt`. The returned slug must be in `next_steps`
  (or `question`/`end`).
- **`next_steps` may cycle** (a step can list itself or an earlier
  step). The only loop bound is `max_steps = 100` total step
  executions per run (`execute_workflow`).
- `context: "continue"` adds `--continue` from visit 2 on, so the
  agent keeps its reasoning context across loop iterations
  (per-step profile dir → per-step session store).
- Claude is launched (`run_claude`) as:
  `claude -p <prompt> --output-format json
  --permission-mode bypassPermissions --add-dir <run.root>
  [--model …] [--continue]`, with `cwd = run.root`,
  `CLAUDE_CONFIG_DIR = <run>/profiles/<step>/`,
  `ANTHROPIC_API_KEY` removed, `CLAUDE_CODE_OAUTH_TOKEN` from a
  leased auth-bank slot, `stdin = DEVNULL`, **no subprocess
  timeout** (a step may run arbitrarily long).
- Auth-bank: each run is *magnetized* to one Anthropic account
  (deterministic by run-slug) for cache friendliness; each
  invocation leases one slot for the duration of the subprocess
  and releases on exit. Multiple accounts/slots → long campaigns
  can spread load and survive a quota wall by re-running under a
  different slug.
- A non-zero exit **or** a missing `outcome.txt` **or** a
  `TimeoutExpired` aborts the whole run with `RuntimeError`.

### Where orchestrator and AI-player already agree

- **`bypassPermissions`** is already set → the agent can `pkill`/
  relaunch `server.py`, run `git`, `nohup` benches, read the
  ai_player `.env` for the pushover token, with no prompts.
- **Autonomous** → `questions: false`, no `AnswerSource` needed.
  The "never ask, pushover only" directive maps cleanly onto the
  non-interactive contract.
- **Disposable session, durable repo state** → the run dir under
  `$TENACIOUS_HOME/runs/<slug>/` being ephemeral is fine; the
  handoff/ledger chain is the real state. One orchestrator run ≈
  one "session"; the next run just reads the latest handoff.
- **cwd mismatch is not fatal**: cwd is `run.root` and only
  `--add-dir run.root` is passed, but under `bypassPermissions`
  the agent can operate on
  `/Users/johntokash/Dropbox/original/ExtremeOnslaught2026/Asteroids/ai_player`
  by absolute path anyway. (Cleaner: also pass `--add-dir` for the
  Asteroids tree — see "Required changes".)

### The former hard blocker (now removed)

`run_claude` / `run_codex` previously called
`subprocess.run(..., timeout=600)` — ten minutes — so any
foreground bench step was killed mid-game (`TimeoutExpired` → run
abort). **That timeout has been removed**; an agent step can now run
for the full multi-hour campaign. What is left is operational, not a
hard wall: one blocking `subprocess.run` for hours means no
intra-run checkpoint — an orchestrator/agent crash loses the run
(though campaign state on disk makes a fresh run resumable from the
last handoff). The options below now differ on
checkpointing/legibility, not on whether a bench can fit.

---

## Options

### Option A — One long foreground step

One `claude` step, `context: empty`, `next_steps: ["end"]`, prompt =
the standing kickoff line ("read the latest handoff, get to work,
never ask, pushover only, write `end` to outcome.txt when truly
done"). With the timeout removed this needs **no code change** — the
step simply runs for the whole campaign.

- **Pros**: 1:1 with how sessions run manually today; trivial
  workflow; the agent's own internal loop does all the work;
  `--continue` not even needed; no orchestrator change required.
- **Cons**: orchestrator blocks for the entire campaign in one
  `subprocess.run`; no checkpointing — a crash loses the run with a
  `RuntimeError` and no partial credit (recovery = start a fresh run
  that reads the latest handoff); this single long `claude -p` is
  almost exactly what a bare CLI invocation already does, so the
  orchestrator mainly adds auth-bank leasing + run logging.
- **Verdict**: now fully viable and simplest. Good for "kick one
  unattended session and walk away"; the trade vs B is
  resumability/legibility, not feasibility.

### Option B — Kickoff → poll → evaluate loop (recommended)

Model the iteration loop as cycling steps; benches run as
backgrounded `nohup` jobs so every step returns well under 600 s.

```
start: kickoff
  kickoff  (claude, context=continue, next=[poll])
     read latest handoff/recipe/ledger; pick next variant;
     edit ai_player_5.py; add_timing.py; restart server;
     nohup bench_variant.py <tag> <n> <c> &  ; disown
     write the tag + expected game count to {assets_dir}/inflight.txt
     -> outcome: poll                         (returns fast)
  poll     (claude, context=continue, next=[poll, evaluate])
     read inflight.txt; grep -c <tag> sessions.jsonl; check
     [TIMING]. If complete -> evaluate. Else: short bounded
     in-step sleep (e.g. sleep 540) then -> poll
  evaluate (claude, context=continue, next=[kickoff, end])
     interpret avg/med/stdev vs HEAD; update variant_ledger.md;
     BANK/REV/TIE; pushover the user. More frontier and
     step-budget left -> kickoff. Else write next handoff -> end
```

- **Pros**: natural checkpoints (each step writes `outcome.txt`,
  ledger, and `assets/`) so a crash loses at most one iteration, not
  the run; `context: continue` preserves the agent's reasoning
  across the loop; `max_steps=100` is a clean campaign budget
  (≈33 kickoff/poll/evaluate triples); the run directory is
  self-documenting (you can see which phase/variant it's on); this
  is also exactly the discipline `handoff_recipe.md` already
  prescribes (background bench + light polling).
- **Cons**: needs a real workflow JSON authored; the orchestrator
  has **no inter-step delay**, so the poll cadence must come from an
  in-step `sleep` (now unbounded — pick a sane interval, e.g. 120 s
  per the recipe) rather than a tight spin that burns step budget /
  auth leases. Long campaigns may exceed `max_steps=100` and need
  either a higher bound or a fresh run that re-reads the handoff.
- **Verdict**: best fit when resumability/legibility matter. It
  mirrors the existing manual discipline and gives the orchestrator
  real checkpoints to log and resume from; the cost over A is having
  to author and maintain the workflow.

### Option C — Many short foreground steps

Originally ruled out because a single game (~24 min) blew the 600 s
timeout. With the timeout gone this is no longer infeasible, but it
also loses its reason to exist: if a foreground step can run for
hours, there is no need to chop the campaign into sub-600 s pieces —
that is just Option A with extra structure, or Option B without the
background-bench benefit. Subsumed by A/B/D; not worth pursuing on
its own.

### Option D — Orchestrator for the bounded phase only

Leave real-time benching as the user's own `nohup` background jobs
(as today). Use the orchestrator for the parts that *are* bounded and
benefit from structure and parallel subagents:

- harvest a finished bench's results from `game_log.jsonl` /
  `sessions.jsonl`,
- fan out death-replay analysis (`handoff_recipe.md` already
  prescribes `isolation: "worktree"` subagents, 2–3 test games,
  kill-after-first-death),
- compute the avg/med/stdev verdict and update `variant_ledger.md`,
- write the next `ai_player_session<N+1>.md` and pushover the user.

A "harvest-and-handoff" workflow triggered after each bench
completes.

- **Pros**: every step is naturally short anyway; plays to the
  orchestrator's strengths (deterministic multi-step, parallel
  worktree subagents, frozen logs); zero changes to
  `orchestrator.py`.
- **Cons**: does not actually run the sessions end-to-end — the
  user (or a separate scheduler) still launches and babysits the
  benches; two systems to operate.
- **Verdict**: lowest-risk, highest-leverage *if* the goal is "make
  the analysis/decision phase reproducible" rather than "fully
  unattend the whole campaign".

### Option E — Self-looping single step + background bench

Option B collapsed to one step: `next_steps: ["self", "end"]`,
`context: continue`, prompt = "do one bounded unit of the campaign
(advance one variant: kick or poll-once or evaluate-one), then write
`self` to loop or `end` when out of frontier/budget." Benches still
run via background `nohup` (Option B's mechanism).

- **Pros**: minimal workflow (one step); `--continue` carries full
  context; `max_steps` still bounds it; the agent decides its own
  sub-phase each visit.
- **Cons**: less legible than B's explicit kickoff/poll/evaluate
  (one opaque step, harder to see "where" the campaign is from the
  run dir); same in-step poll-cadence caveat as B; one prompt has
  to encode all three sub-behaviors.
- **Verdict**: a terser B. Pick B if you want the run directory to
  be self-documenting; pick E if you want the smallest possible
  workflow file.

---

## Required / recommended changes

1. **Timeout — done.** The 600 s `subprocess.run` timeout in
   `run_codex`/`run_claude` (and the now-unreachable
   `TimeoutExpired` handler in `_run_step_visit`) has been removed.
   Agent steps are no longer time-bounded; no per-step timeout knob
   is needed. (If a guard is ever wanted again, reintroduce it as an
   opt-in env-configurable value, not a hard default.)
2. **Extra `--add-dir`** (`run_claude`, currently only
   `--add-dir str(run.root)`): add the Asteroids/ai_player tree so
   the agent isn't relying solely on `bypassPermissions` to reach
   it. Either hardcode via an asset/goal convention or add a
   workflow-level "extra dirs" field. Functionally optional under
   bypass; cleaner with it.
3. **Inter-step pacing**: there is no orchestrator-side delay. Decide
   the poll cadence via an in-step `sleep` in the poll prompt
   (e.g. 120 s per the recipe; now unbounded since the timeout is
   gone) rather than a busy spin that burns step budget / auth
   leases.
4. **Step budget**: `max_steps=100` caps a run. For a long campaign
   either raise it (workflow- or CLI-configurable) or rely on the
   handoff chain — end the run cleanly, start a fresh one that reads
   the new handoff (the natural "session N → N+1" boundary).
5. **Pushover token**: the agent reads it from the ai_player `.env`
   under `bypassPermissions`; no orchestrator env passthrough
   needed. Do **not** add it to the run dir or assets (the recipe
   forbids committing pushover tokens).
6. **Goal/handoff wiring**: put the standing directive in `goal`
   and the explicit handoff path in the step prompt (or pass the
   current handoff as an `asset_slug` snapshot). The agent should
   write the next handoff back into the **Dropbox tree** (durable),
   optionally copying it into `assets_dir` for the run record.

---

## Recommendation

- To **fully unattend a session with the least work**: Option A.
  With the timeout removed it runs end-to-end with no code change
  and a one-step workflow; the only real cost is no intra-run
  checkpoint (recover by starting a fresh run on the latest
  handoff).
- To **fully unattend with resumability and a legible run dir**:
  Option B. It reproduces the discipline `handoff_recipe.md` already
  mandates (background bench + light polling + ledger checkpoint) and
  loses at most one iteration on a crash. Changes 2–4 apply;
  2 and 5 are already covered by `bypassPermissions`. Choose B over
  A when a multi-hour campaign's resumability is worth authoring and
  maintaining the workflow.
- To **get value with near-zero risk and no code change**: Option D
  — orchestrate the harvest/analysis/handoff phase, keep benching as
  background jobs.
- Option C is subsumed by A/B/D — not worth pursuing on its own.
