## TLDR

Launch Claude Code non-interactively with `claude -p "<prompt>"`, piping or supplying the prompt via argv or stdin. Pick `--output-format text|json|stream-json` (stream-json requires `--verbose` and emits NDJSON `SDKMessage` lines on stdout; everything else, including warnings and errors, goes to stderr). For scripting, combine `-p` with `--permission-mode acceptEdits` (or `--dangerously-skip-permissions`), `--allowed-tools`, `--model`, `--max-turns`/`--max-budget-usd`, `--resume <uuid>` / `--continue`, and `--mcp-config`; exit code is `0` on success or `1` on validation errors or when the final `result` has `is_error: true`.

---
## Executive Summary

- `-p` / `--print` is the master switch for headless / non-interactive use; nearly every other scripting flag is gated by it. Dispatches to `runHeadless` in `src/cli/print.ts` (lazy-imported from `main.tsx:2825`).
- Prompts come from argv (positional), stdin, or both — in text mode the CLI concatenates argv+stdin with a newline; in `--input-format=stream-json` it consumes stdin as an NDJSON message stream. Add `< /dev/null` to silence the 3-second "no stdin" warning when stdin is piped but empty.
- `--output-format`: `text` (default; final result text), `json` (single result object, or full message array with `--verbose`), `stream-json` (NDJSON of every `SDKMessage`; requires `--verbose`).
- `--input-format`: `text` (default) or `stream-json` (which requires `--output-format=stream-json`). Stream-json is the canonical SDK / bridge protocol.
- Result envelope (`SDKResultSuccessSchema` in `entrypoints/sdk/coreSchemas.ts:1407`) carries `session_id`, `result`, `is_error`, `num_turns`, `duration_ms`, `total_cost_usd`, `usage`, `modelUsage`, `permission_denials`, optional `structured_output`. Error variants carry `errors: string[]` and a typed subtype (`error_max_turns`, etc.).
- Exit codes: `0` on success unless the final result has `is_error: true` (then `1`); explicit `1` for argument validation, missing prompt, sandbox failures, stream-json without `--verbose`, `--resume-session-at`/`--rewind-files` without `--resume`. `gracefulShutdownSync` sets `process.exitCode` then enforces a 5s failsafe `forceExit`.
- stdout = response; stderr = warnings, errors, debug. In stream-json mode `installStreamJsonStdoutGuard()` reroutes stray non-JSON stdout to stderr to keep the line-by-line parser clean.
- Permission modes (`src/types/permissions.ts`): `default`, `acceptEdits`, `bypassPermissions`, `plan`, `dontAsk`, plus `auto` on ant builds. `--dangerously-skip-permissions` == `bypassPermissions`. `--permission-prompt-tool <mcpTool>` routes asks to a named MCP tool. `--allowed-tools` / `--disallowedTools` / `--tools` accept space-separated tool names with argument patterns (`Bash(git:*)`).
- Session continuity: `-c, --continue`, `-r, --resume [uuid|path.jsonl|search]`, `--fork-session`, `--session-id <uuid>`, `--resume-session-at <msg-id>`, `--rewind-files <msg-id>`, `--no-session-persistence` (print-only), `--from-pr`.
- Model selection: `--model <alias|id>`, `--fallback-model`, `--effort`, `--thinking`, `--max-turns`, `--max-budget-usd`, `--task-budget`, `--betas`.
- Context: `--mcp-config` (files or JSON), `--strict-mcp-config`, `--add-dir`, `--settings`, `--setting-sources`, `--plugin-dir` (repeatable), `--agents`, `--agent`, `--system-prompt[-file]`, `--append-system-prompt[-file]`, `--bare` (minimal mode with strict env-var auth).
- Extras for stream-json: `--include-partial-messages`, `--include-hook-events`, `--replay-user-messages`, `--json-schema`, `--workload`, `--sdk-url`.
- Canonical SDK child spawn (from `src/bridge/sessionRunner.ts:289`):  
  `claude --print --session-id <uuid> --input-format stream-json --output-format stream-json [--permission-mode <mode>]` (always with `--verbose`).
- Useful non-REPL subcommands: `claude mcp serve|add|list|remove|add-json`, `claude server` (HTTP/Unix socket session host), `claude open <cc-url>`, `claude auth status --json`, `claude agents`, `claude completion <shell>`, `claude ssh <host>`.

---
## Detailed Summary

Claude Code's non-interactive surface area is gated entirely behind `-p` / `--print`. When that flag is present, `main.tsx` skips the Ink TUI, sets the session to non-interactive (`getIsNonInteractiveSession()` returns true), bypasses the workspace-trust dialog, and lazy-imports `src/cli/print.ts:runHeadless`. Every other "headless" flag in the help text is annotated "only works with --print" and validated either inside `main.tsx`'s action body (using `console.error` + `process.exit(1)`) or at the top of `runHeadless` (using `process.stderr.write` + `gracefulShutdownSync(1)`).

Prompts can arrive two ways: a positional argv argument or stdin. `getInputPrompt` (main.tsx:857) checks `process.stdin.isTTY`; if stdin is piped, it either returns `process.stdin` directly (when `--input-format=stream-json`, the SDK NDJSON protocol) or buffers all of stdin as a string and concatenates it after the argv prompt with a newline. A 3-second peek timer prints a stderr warning if no stdin data arrives, so subprocess callers that don't intend to use stdin should redirect `< /dev/null`. With no prompt and no resume target, `runHeadless` aborts with exit 1.

`--output-format` is one of `text` (default, last assistant `result` text), `json` (single `result` object — or, with `--verbose`, the full message array), or `stream-json` (NDJSON of every `SDKMessage` as it streams). The stream format requires `--verbose` and installs a stdout guard that diverts stray non-JSON writes to stderr. The final `SDKResult{Success,Error}Schema` payload (`/Users/johntokash/Downloads/src/entrypoints/sdk/coreSchemas.ts:1407+`) includes `session_id`, `num_turns`, `duration_ms`, `total_cost_usd`, `usage`, `modelUsage`, `permission_denials`, `is_error`, and either a `result` string (success) or an `errors` list with an error subtype (`error_during_execution`, `error_max_turns`, `error_max_budget_usd`, `error_max_structured_output_retries`). The exit code is `0` unless the final message is a result with `is_error: true`, in which case it's `1`.

`--input-format` accepts `text` (default; argv+stdin concatenation) or `stream-json` (NDJSON of inbound messages). Stream-json input requires stream-json output. Inbound messages include `user`, `control_request` (initialize, set_permission_mode, set_model, can_use_tool responses, mcp_set_servers, interrupt), `keep_alive` (ignored), and `update_environment_variables` (live mutation of `process.env`). The parser is `StructuredIO.processLine` at `src/cli/structuredIO.ts:333`.

Permissions: `--permission-mode` chooses from `default`, `acceptEdits`, `bypassPermissions`, `plan`, `dontAsk`, plus `auto` on ant builds (defined in `src/types/permissions.ts`). `--dangerously-skip-permissions` is equivalent to `bypassPermissions`. `--permission-prompt-tool <tool>` lets headless invocations route ask-prompts to a named MCP tool (the canonical mechanism for SDK consumers to handle approvals). `--allowed-tools` / `--disallowedTools` / `--tools` accept space-separated tool names with optional argument patterns (`Bash(git:*)`, `WebFetch(domain:example.com)`).

Session continuity: `-c, --continue` resumes the most recent session in the cwd. `-r, --resume [value]` takes a UUID, a `.jsonl` path, or in interactive mode an optional search term. `--fork-session` resumes but assigns a new session UUID. `--session-id <uuid>` predetermines the session ID for orchestrators. `--resume-session-at <message-id>` and `--rewind-files <user-message-id>` operate on resume targets and are subject to extra validation (both exit 1 if `--resume` is missing). `--no-session-persistence` (only with `-p`) disables disk persistence.

Model & budget: `--model <alias-or-id>`, `--fallback-model` (print-only auto-fallback on overload), `--effort <low|medium|high|max>`, `--thinking <enabled|adaptive|disabled>`, `--max-turns`, `--max-budget-usd`, `--task-budget`, `--betas`. Quota error messages adapt to non-interactive mode and suggest `--model` instead of `/model`.

Context & MCP: `--mcp-config <files-or-json...>` plus `--strict-mcp-config` to ignore all other sources; `--add-dir`, `--settings`, `--setting-sources`, `--plugin-dir` (repeatable), `--agents` (inline JSON), `--agent`, `--system-prompt[-file]`, `--append-system-prompt[-file]`, `--disable-slash-commands`, `--bare` for a stripped-down deterministic environment. `--bare` is the cleanest setting for CI: no hooks, no plugin sync, no keychain reads, no CLAUDE.md auto-discovery, strict env-var-based auth.

Streams output channel discipline: stdout is reserved for the response (text / JSON / NDJSON). stderr carries validation errors, warnings (stdin peek timeout), and runHeadless aborts. Debug logging never touches stdout unless `-d2e, --debug-to-stderr` is explicitly used (and even then, it goes to stderr). `installStreamJsonStdoutGuard()` (print.ts:594) further protects stdout when streaming JSON.

Concrete SDK-shaped invocation (mirrored by the bridge child spawn in `src/bridge/sessionRunner.ts:289`):

```
claude -p --session-id <uuid> \
       --input-format stream-json --output-format stream-json --verbose \
       [--permission-mode acceptEdits] \
       [--permission-prompt-tool mcp__custom__approve]
```

Other useful subcommands: `claude mcp serve|add|list|remove|add-json|add-from-claude-desktop`, `claude server` (long-running session server over HTTP or Unix socket), `claude open <cc-url>` (supports `-p` and `--output-format`), `claude auth status --json|--text`, `claude agents`, `claude completion <shell>`, `claude ssh <host> [dir]` (forwards `--permission-mode`/`--dangerously-skip-permissions` to the remote child).

---
# Extensive: Launching Claude Code Non-Interactively

Reference source tree: `/Users/johntokash/Downloads/src` (Claude Code internal sources). All file paths below are absolute into that tree unless noted.

## 1. Print mode is the entry to all headless behavior

Print mode is selected with `-p` / `--print`. Almost every other non-interactive flag (`--output-format`, `--input-format`, `--max-turns`, `--max-budget-usd`, `--json-schema`, `--include-partial-messages`, `--include-hook-events`, `--permission-prompt-tool`, `--replay-user-messages`, `--workload`, `--no-session-persistence`, `--fallback-model`) is documented as "only works with --print".

From `/Users/johntokash/Downloads/src/main.tsx` line 976 (single chained `program.option(...)` call):

> `.option('-p, --print', 'Print response and exit (useful for pipes). Note: The workspace trust dialog is skipped when Claude is run with the -p mode. Only use this flag in directories you trust.', () => true)`

> `.addOption(new Option('--output-format <format>', 'Output format (only works with --print): "text" (default), "json" (single result), or "stream-json" (realtime streaming)').choices(['text', 'json', 'stream-json']))`

> `.addOption(new Option('--input-format <format>', 'Input format (only works with --print): "text" (default), or "stream-json" (realtime streaming input)').choices(['text', 'stream-json']))`

Print mode bypasses the workspace-trust dialog and renders no Ink/React TUI. The function dispatched into is `runHeadless` (see `/Users/johntokash/Downloads/src/cli/print.ts:455`):

```
export async function runHeadless(
  inputPrompt: string | AsyncIterable<string>,
  getAppState, setAppState, commands, tools, sdkMcpConfigs, agents,
  options: { continue, resume, resumeSessionAt, verbose,
    outputFormat, jsonSchema, permissionPromptToolName,
    allowedTools, thinkingConfig, maxTurns, maxBudgetUsd,
    taskBudget, systemPrompt, appendSystemPrompt,
    userSpecifiedModel, fallbackModel, teleport, sdkUrl,
    replayUserMessages, includePartialMessages, forkSession,
    rewindFiles, enableAuthStatus, agent, workload,
    setupTrigger, sessionStartHooksPromise, setSDKStatus },
)
```

Invoked from `/Users/johntokash/Downloads/src/main.tsx:2826-2860` after `await import('src/cli/print.js')`. So print is lazy-loaded — startup cost for the TUI path is not paid.

Non-interactive detection (`getIsNonInteractiveSession()` in `/Users/johntokash/Downloads/src/bootstrap/state.ts:1057`) is just `!STATE.isInteractive`; `setIsInteractive(false)` is forced when `-p`/`--print` is present (set in main.tsx's `setup`/argv parse path; see `process.argv.includes('-p') || process.argv.includes('--print')` in main.tsx:602, 622, 786, 800, 3883 and analogous in `utils/gracefulShutdown.ts:262`, `utils/earlyInput.ts:37`, `services/api/logging.ts:454`).

## 2. How prompts are fed: argv vs stdin

The action handler accepts a `prompt` positional argument from Commander. It then calls `getInputPrompt(effectivePrompt, inputFormat)` (main.tsx:1861).

`getInputPrompt` at `/Users/johntokash/Downloads/src/main.tsx:857`:

```
async function getInputPrompt(prompt, inputFormat) {
  if (!process.stdin.isTTY && !process.argv.includes('mcp')) {
    if (inputFormat === 'stream-json') {
      return process.stdin;          // returns Readable used as AsyncIterable
    }
    process.stdin.setEncoding('utf8');
    let data = '';
    process.stdin.on('data', c => { data += c });
    const timedOut = await peekForStdinData(process.stdin, 3000);
    if (timedOut) {
      process.stderr.write('Warning: no stdin data received in 3s, ' +
        'proceeding without it. If piping from a slow command, ' +
        'redirect stdin explicitly: < /dev/null to skip, or wait longer.\n');
    }
    return [prompt, data].filter(Boolean).join('\n');
  }
  return prompt;
}
```

Key behaviors:

- If stdin is a TTY (no pipe), only the positional `prompt` arg is used.
- If stdin is piped and `--input-format` is `text` (default), the CLI reads all of stdin, then concatenates it after the argv prompt with a newline: `argv_prompt + "\n" + stdin_text`.
- If `--input-format=stream-json`, the CLI returns `process.stdin` itself as the async iterable; messages are read line-by-line as JSON envelopes.
- The 3-second stdin peek is a gotcha: when a parent process forwards stdin but writes nothing, the CLI will warn after 3s and continue. To avoid the warning when you want pure argv prompts in a subprocess, redirect: `claude -p "..." < /dev/null`.
- Stdin "hijacking" is skipped for `claude mcp ...` so MCP servers' own stdio is not consumed.

If no prompt is provided at all and no valid resume target is set, `runHeadless` aborts:

`/Users/johntokash/Downloads/src/cli/print.ts:779`:
> `Error: Input must be provided either through stdin or as a prompt argument when using --print`

## 3. Output formats: text / json / stream-json

Defined by `--output-format <format>` Option with `.choices(['text','json','stream-json'])`. The output dispatch is at `/Users/johntokash/Downloads/src/cli/print.ts:917`:

```
switch (options.outputFormat) {
  case 'json':
    if (!lastMessage || lastMessage.type !== 'result') throw ...
    if (options.verbose) { writeToStdout(jsonStringify(messages) + '\n'); break }
    writeToStdout(jsonStringify(lastMessage) + '\n'); break
  case 'stream-json':
    // already logged above (streaming as messages arrived)
    break
  default:  // text
    if (!lastMessage || lastMessage.type !== 'result') throw ...
    switch (lastMessage.subtype) {
      case 'success':
        writeToStdout(lastMessage.result.endsWith('\n')
          ? lastMessage.result : lastMessage.result + '\n'); break
      case 'error_during_execution':           writeToStdout('Execution error'); break
      case 'error_max_turns':                  writeToStdout(`Error: Reached max turns (${options.maxTurns})`); break
      case 'error_max_budget_usd':             writeToStdout(`Error: Exceeded USD budget (${options.maxBudgetUsd})`); break
      case 'error_max_structured_output_retries':
        writeToStdout('Error: Failed to provide valid structured output after maximum retries')
    }
}
```

### text (default)
- Single string written to stdout. Just the final assistant `result` text. Newline-terminated.
- Error subtypes get terse text strings (no JSON).

### json (single result)
- Without `--verbose`: emits one JSON object — the final SDK `result` message.
- With `--verbose`: emits a JSON array of every retained SDK message.
- Shape of the result message (see `/Users/johntokash/Downloads/src/entrypoints/sdk/coreSchemas.ts:1407`, `SDKResultSuccessSchema`):
  ```
  { type: "result", subtype: "success",
    duration_ms, duration_api_ms, is_error, num_turns,
    result, stop_reason, total_cost_usd, usage, modelUsage,
    permission_denials, structured_output?, fast_mode_state?,
    uuid, session_id }
  ```
- Error variant (`SDKResultErrorSchema` line 1428) has the same shape but `subtype` ∈ {`error_during_execution`,`error_max_turns`,`error_max_budget_usd`,`error_max_structured_output_retries`}, no `result`, has `errors: string[]`.

### stream-json (NDJSON realtime)
- One JSON object per line ("newline-delimited JSON"). Each line is an `SDKMessage`.
- Requires `--verbose` — print.ts:787:
  > `Error: When using --print, --output-format=stream-json requires --verbose`
- Stdout is locked down: `installStreamJsonStdoutGuard()` (print.ts:594) diverts any stray non-JSON writes (debug prints, library banners) to stderr so the line-by-line parser never sees garbage. NDJSON-safe encoding lives at `/Users/johntokash/Downloads/src/cli/ndjsonSafeStringify.ts`.
- Streamed message types include `system`, `user`, `assistant`, `result`, plus optional `stream_event` (when `--include-partial-messages`), `control_request`/`control_response` (SDK bidirectional channel), and `hook_*` system subtypes (when `--include-hook-events`).
- The final `result` line is the canonical end-of-stream marker.

Extra knobs:
- `--include-partial-messages` — emits `stream_event` chunks as they arrive. main.tsx:1847: requires `--print` and `--output-format=stream-json`.
- `--include-hook-events` — emits `system` messages with `subtype: hook_started|hook_progress|hook_completed` (see print.ts:628-666).
- `--json-schema <schema>` — JSON Schema for structured output validation. Failures surface as `error_max_structured_output_retries`.
- `--replay-user-messages` — re-emits user-message inputs back on stdout for acknowledgment. Only with `--input-format=stream-json` AND `--output-format=stream-json` (main.tsx:1839-1845).
- `CLAUDE_CODE_STREAMLINED_OUTPUT=true` (with feature flag and stream-json) collapses thinking/tool_use into `streamlined_text`/`streamlined_tool_use_summary` messages (print.ts:854-861).

## 4. Input format: stream-json (bidirectional protocol)

`--input-format` accepts `text` (default) or `stream-json`. Validation:
- main.tsx:1823: `--input-format=stream-json` requires `--output-format=stream-json`.
- main.tsx:1818: any other value rejects with `Invalid input format`.

In stream-json mode, stdin is parsed as NDJSON `StdinMessage | SDKMessage` objects. The parser is in `/Users/johntokash/Downloads/src/cli/structuredIO.ts:333` (`processLine`). Handled inbound types include:

- `user` — a queued user-message turn (`SDKUserMessage`).
- `control_request` — bidirectional control (initialize, set_permission_mode, set_model, can_use_tool response, mcp_set_servers, interrupt, etc.).
- `keep_alive` — silently ignored.
- `update_environment_variables` — mutates `process.env` live (used by the bridge for auth token refresh) (structuredIO.ts:348).

The control-channel schema is in `/Users/johntokash/Downloads/src/entrypoints/sdk/controlSchemas.ts`. Initialize/permission-mode handlers live in print.ts:4336 (`handleInitializeRequest`) and print.ts:4568 (`handleSetPermissionMode`).

This is the protocol the Anthropic Agent SDK speaks to a child `claude -p --input-format stream-json --output-format stream-json --verbose` process.

## 5. Permission modes and bypass

`PERMISSION_MODES` are defined in `/Users/johntokash/Downloads/src/types/permissions.ts`:

```
export const EXTERNAL_PERMISSION_MODES = [
  'acceptEdits', 'bypassPermissions', 'default', 'dontAsk', 'plan',
] as const

export const INTERNAL_PERMISSION_MODES = [
  ...EXTERNAL_PERMISSION_MODES,
  ...(feature('TRANSCRIPT_CLASSIFIER') ? (['auto'] as const) : []),
]
export const PERMISSION_MODES = INTERNAL_PERMISSION_MODES
```

CLI option:
> `.addOption(new Option('--permission-mode <mode>', 'Permission mode to use for the session').argParser(String).choices(PERMISSION_MODES))`

Semantics:
- `default` — prompt for each tool needing approval. In headless mode, prompts route to the SDK consumer via `control_request` (`can_use_tool`) or to a `--permission-prompt-tool` MCP tool. Without either, prompts have nothing to display and tools that need approval will deny.
- `acceptEdits` — auto-accept file edits (Edit, Write, NotebookEdit) without prompting; still gates non-edit risky ops.
- `plan` — plan mode; tools that write are blocked; the model is constrained to produce a plan.
- `bypassPermissions` — equivalent to `--dangerously-skip-permissions`. Skips all permission checks.
- `dontAsk` — auto-deny instead of asking.
- `auto` (ant build) — classifier-driven.

Bypass flags (main.tsx:976):
> `.option('--dangerously-skip-permissions', 'Bypass all permission checks. Recommended only for sandboxes with no internet access.', () => true)`
> `.option('--allow-dangerously-skip-permissions', 'Enable bypassing all permission checks as an option, without it being enabled by default. ...')`

`--dangerously-skip-permissions` is detected very early (main.tsx:621, 720) and sets `sessionBypassPermissionsMode`. Aliases: ant builds map `--delegate-permissions`, `--dangerously-skip-permissions-with-classifiers`, `--afk` → `--permission-mode auto` (main.tsx:3817-3823).

`--permission-prompt-tool <tool>` (main.tsx:976; hidden) lets a headless invocation route ask-prompts to a specific MCP tool. Result-decision mapping is in `/Users/johntokash/Downloads/src/utils/permissions/PermissionPromptToolResultSchema.ts` and consumed in print.ts via `createCanUseToolWithPermissionPrompt` (print.ts:4149) and `getCanUseToolFn` (print.ts:4267).

`--allowed-tools` / `--disallowedTools` / `--tools` (main.tsx:988):
> `.option('--allowedTools, --allowed-tools <tools...>', 'Comma or space-separated list of tool names to allow (e.g. "Bash(git:*) Edit")')`
> `.option('--tools <tools...>', 'Specify the list of available tools from the built-in set. Use "" to disable all tools, "default" to use all tools, or specify tool names (e.g. "Bash,Edit,Read").')`
> `.option('--disallowedTools, --disallowed-tools <tools...>', 'Comma or space-separated list of tool names to deny (e.g. "Bash(git:*) Edit")')`

These accept space-separated values; commander's variadic `<tools...>`. Rule syntax includes tool name with optional argument patterns: `Bash(git:*)`, `Edit`, `Read`, `WebFetch(domain:example.com)`. Source: `/Users/johntokash/Downloads/src/utils/permissions/permissionSetup.ts`.

## 6. Session resumption: --continue, --resume, --fork-session, --session-id

From main.tsx:988:

> `.option('-c, --continue', 'Continue the most recent conversation in the current directory', () => true)`
> `.option('-r, --resume [value]', 'Resume a conversation by session ID, or open interactive picker with optional search term', value => value || true)`
> `.option('--fork-session', 'When resuming, create a new session ID instead of reusing the original (use with --resume or --continue)', () => true)`
> `.option('--no-session-persistence', 'Disable session persistence - sessions will not be saved to disk and cannot be resumed (only works with --print)')`
> `.option('--session-id <uuid>', 'Use a specific session ID for the conversation (must be a valid UUID)')`
> `.addOption(new Option('--resume-session-at <message id>', 'When resuming, only messages up to and including the assistant message with <message.id> (use with --resume in print mode)').argParser(String).hideHelp())`
> `.addOption(new Option('--rewind-files <user-message-id>', 'Restore files to state at the specified user message and exit (requires --resume)').hideHelp())`

Inside `runHeadless`:
- `--resume-session-at` without `--resume` exits 1 (print.ts:567).
- `--rewind-files` without `--resume` exits 1 (print.ts:573).
- `--rewind-files` with a prompt is rejected (print.ts:579).
- If `--resume` provides a UUID or `.jsonl` file path, the CLI accepts a missing prompt (treats as no new turn) (print.ts:773-776):
  ```
  const hasValidResumeSessionId =
    typeof options.resume === 'string' &&
    (Boolean(validateUuid(options.resume)) || options.resume.endsWith('.jsonl'))
  ```
- `-r` (interactive picker) is not useful in `-p` mode unless you give it a value.
- `--from-pr [value]` resumes a session linked to a PR (main.tsx:991).
- `--session-id <uuid>` lets you predetermine the new session UUID — useful for orchestrators that need to track sessions before launch.

## 7. Model selection

main.tsx:993:

> `.option('--model <model>', "Model for the current session. Provide an alias for the latest model (e.g. 'sonnet' or 'opus') or a model's full name (e.g. 'claude-sonnet-4-6').")`

> `.option('--fallback-model <model>', 'Enable automatic fallback to specified model when default model is overloaded (only works with --print)')`

> `.addOption(new Option('--effort <level>', 'Effort level for the current session (low, medium, high, max)'))`

> `.option('--betas <betas...>', 'Beta headers to include in API requests (API key users only)')`

> `.addOption(new Option('--thinking <mode>', 'Thinking mode: enabled (equivalent to adaptive), disabled').choices(['enabled','adaptive','disabled']).hideHelp())`

> `.addOption(new Option('--max-thinking-tokens <tokens>', '[DEPRECATED. Use --thinking instead for newer models] Maximum number of thinking tokens (only works with --print)').argParser(Number).hideHelp())`

Inside the running session, the model can also be changed via stream-json `control_request` `set_model`. Non-interactive error messages for model-quota events suggest `--model` (see `/Users/johntokash/Downloads/src/services/api/errors.ts:892`):
```
const switchCmd = getIsNonInteractiveSession() ? '--model' : '/model'
```

## 8. MCP & context flags relevant to scripting

From main.tsx:988-1006:

> `.option('--mcp-config <configs...>', 'Load MCP servers from JSON files or strings (space-separated)')`
> `.option('--strict-mcp-config', 'Only use MCP servers from --mcp-config, ignoring all other MCP configurations', () => true)`
> `.option('--add-dir <directories...>', 'Additional directories to allow tool access to')`
> `.option('--settings <file-or-json>', 'Path to a settings JSON file or a JSON string to load additional settings from')`
> `.option('--setting-sources <sources>', 'Comma-separated list of setting sources to load (user, project, local).')`
> `.option('--plugin-dir <path>', 'Load plugins from a directory for this session only (repeatable: --plugin-dir A --plugin-dir B)', (val, prev) => [...prev, val], [])`
> `.option('--agents <json>', 'JSON object defining custom agents (e.g. \'{"reviewer": {...}}\')')`
> `.option('--agent <agent>', 'Agent for the current session. Overrides the \'agent\' setting.')`
> `.option('--ide', 'Automatically connect to IDE on startup if exactly one valid IDE is available', () => true)`
> `.option('--disable-slash-commands', 'Disable all skills', () => true)`

`--mcp-config` accepts either file paths or inline JSON strings; values are space-separated (commander variadic). `--strict-mcp-config` ignores user-level MCP config and uses only the values from `--mcp-config`.

`--bare` (main.tsx:976) is an opinionated minimal mode for scripting:
> `Minimal mode: skip hooks, LSP, plugin sync, attribution, auto-memory, background prefetches, keychain reads, and CLAUDE.md auto-discovery. Sets CLAUDE_CODE_SIMPLE=1. Anthropic auth is strictly ANTHROPIC_API_KEY or apiKeyHelper via --settings (OAuth and keychain are never read). 3P providers (Bedrock/Vertex/Foundry) use their own credentials. Skills still resolve via /skill-name. Explicitly provide context via: --system-prompt[-file], --append-system-prompt[-file], --add-dir (CLAUDE.md dirs), --mcp-config, --settings, --agents, --plugin-dir.`

## 9. System prompt control

> `--system-prompt <prompt>`              — replace default system prompt entirely.
> `--system-prompt-file <file>` (hidden)  — read from file.
> `--append-system-prompt <prompt>`       — append to default.
> `--append-system-prompt-file <file>` (hidden).

These map into `runHeadless` options `systemPrompt` / `appendSystemPrompt` (print.ts:476-477).

## 10. Budget/turn caps

> `--max-turns <turns>` (hidden) — early-exit after N agentic turns. Surfaces as a final `result` with `subtype: error_max_turns`.
> `--max-budget-usd <amount>` — surfaces as `error_max_budget_usd`.
> `--task-budget <tokens>` (hidden) — API-side total task budget.

All listed as "only works with --print".

## 11. Exit codes

`gracefulShutdownSync` in `/Users/johntokash/Downloads/src/utils/gracefulShutdown.ts:336-355` sets `process.exitCode = exitCode` and triggers async cleanup, falling back to a 5s failsafe via `forceExit(exitCode)`.

Concrete exit-code call sites in `runHeadless`:

- 0 success: `gracefulShutdownSync(lastMessage?.type === 'result' && lastMessage?.is_error ? 1 : 0)` (print.ts:971).
- 1: `--resume-session-at` without `--resume` (print.ts:569).
- 1: `--rewind-files` without `--resume` (print.ts:575).
- 1: `--rewind-files` with a prompt (print.ts:583).
- 1: stream-json output without `--verbose` (print.ts:791).
- 1: no prompt and no resume (print.ts:783).
- 1: sandbox required but unavailable (print.ts:608).
- 1: sandbox initialization failed (print.ts:623).
- 1 (`process.exit(1)`): bad `--input-format` value, or `--input-format=stream-json` without `--output-format=stream-json` (main.tsx:1820-1827, 1832-1834, 1841-1844, 1850-1852, 1857-1858).
- Result errors propagate via `is_error: true` on the final SDK result, which maps to exit 1.

## 12. stdout vs stderr separation

- stdout carries the response payload (text, JSON, or NDJSON stream-json messages) and nothing else.
- stderr carries:
  - Validation errors prior to entering `runHeadless` (`console.error(...)` then `process.exit(1)`).
  - Diagnostic warnings, e.g. the 3s stdin peek timeout warning (main.tsx:878).
  - Errors during runHeadless are written to stderr (`process.stderr.write(...)`) prior to `gracefulShutdownSync(1)`.
  - In stream-json mode, any stray non-JSON stdout write is redirected to stderr by `installStreamJsonStdoutGuard()` (print.ts:594).
- `emitLoadError` (print.ts:4841) routes initial-message load errors to stdout as a JSON error envelope when `outputFormat === 'stream-json'`, but to stderr otherwise:

  ```
  function emitLoadError(message, outputFormat) {
    if (outputFormat === 'stream-json') {
      process.stdout.write(jsonStringify(errorResult) + '\n')
    } else {
      // plain text to stderr
    }
  }
  ```

- Debug logging: `-d` / `--debug [filter]` goes to a debug file by default; `-d2e, --debug-to-stderr` (hidden) emits to stderr. `--debug-file <path>` writes elsewhere. None of these touch stdout.

## 13. Concrete examples and call sites

Single-shot text:
```
claude -p "Summarize CHANGELOG.md"
```

Single-shot JSON:
```
claude -p "What is 2+2?" --output-format json
```
Stdout is one `{type:"result",subtype:"success",result:"4", ...}`.

Verbose JSON (full message array):
```
claude -p "build the project" --output-format json --verbose
```

NDJSON realtime stream (the SDK protocol):
```
claude -p --input-format stream-json --output-format stream-json --verbose
```
Stdin: NDJSON of `SDKUserMessage` and `control_request` objects. Stdout: NDJSON of `SDKMessage` events ending with a `result`.

CI-friendly, scripted, no prompts:
```
claude -p "$(cat task.md)" \
  --output-format json \
  --permission-mode acceptEdits \
  --allowed-tools "Read Write Edit Bash(git:*)" \
  --max-turns 30 \
  --max-budget-usd 5 \
  --model sonnet \
  --add-dir ./src ./tests \
  < /dev/null
```

Resume + new turn:
```
claude -p "Now run the tests" --resume 8d8c2e3a-... --output-format json
```

Headless one-shot via stdin pipe:
```
echo "Refactor foo to bar" | claude -p --output-format json
```

Spawn a child SDK-style:
```
claude -p --input-format stream-json --output-format stream-json --verbose \
       --session-id $(uuidgen) \
       --permission-prompt-tool mcp__custom__approve
```

Sandboxed, dangerous skip:
```
claude -p "..." --dangerously-skip-permissions    # equivalent to --permission-mode bypassPermissions
```

Bridge child spawn example, from `/Users/johntokash/Downloads/src/bridge/sessionRunner.ts:289`:
```
'--print',
'--session-id', sessionId,
'--input-format', 'stream-json',
'--output-format', 'stream-json',
... ['--permission-mode', deps.permissionMode]
```
Confirms the canonical scripting recipe.

Subprocess sub-agents (`/Users/johntokash/Downloads/src/tools/shared/spawnMultiAgent.ts:223`) push `--dangerously-skip-permissions` for child agent processes; they also filter out `--model` from the parent argv so the child can pick a different model.

## 14. Subcommands relevant to scripting

- `claude mcp serve` — start an MCP server exposing Claude's tools as MCP. (main.tsx:3895)
- `claude mcp add|remove|list|add-json|add-from-claude-desktop` — manage MCP server configs without entering the REPL. (main.tsx:3916-3945)
- `claude open <cc-url>` — connect to a Claude Code server. Supports `-p, --print [prompt]` and `--output-format <format>` (main.tsx:4059).
- `claude agents` — list configured agents non-interactively.
- `claude server` — long-running session server (HTTP/Unix socket; `--port`, `--unix`, `--auth-token`, `--workspace`, `--max-sessions`, `--idle-timeout`). (main.tsx:3962)
- `claude completion <shell>` — emit shell completion script. (main.tsx:4494)
- `claude auth login|status` — non-interactive auth with `--json`/`--text`. (main.tsx:4101)
- `claude doctor`, `claude install`, `claude rollback` — env management.
- `claude ssh <host> [dir]` — bootstraps a remote Claude over SSH, supports `--permission-mode` and `--dangerously-skip-permissions` for the remote child (main.tsx:4046).

## 15. Gotchas

- `--output-format=stream-json` requires `--verbose` — without it, you get `Error: When using --print, --output-format=stream-json requires --verbose` and exit 1.
- `--input-format=stream-json` requires `--output-format=stream-json`.
- `--include-partial-messages`, `--replay-user-messages`, `--sdk-url`, `--workload`, `--no-session-persistence` all require print mode and may require stream-json formats.
- Piped stdin with no data → 3s warning then proceeds. To suppress, redirect `< /dev/null`.
- `--print` mode skips the workspace-trust dialog. Don't aim it at untrusted directories.
- `--dangerously-skip-permissions` is parsed *before* the trust dialog evaluation — it disables every permission gate.
- `--resume` accepts either a UUID or a `.jsonl` file path; a bare value that is neither is treated as an interactive search term (but in `-p` mode that's effectively useless).
- Without a configured `--permission-prompt-tool` or SDK control channel, any tool that needs `ask` will deny in headless mode unless you pre-allow it (`--allowed-tools`) or set a mode (`acceptEdits` / `bypassPermissions`).
- The CLI lazy-imports `src/cli/print.js` only when `-p` is set, so the cold-start path is faster than a TUI launch (main.tsx:2825).
- In `stream-json` output mode, stray library/console writes will be diverted to stderr by `installStreamJsonStdoutGuard()`. If you depend on seeing those, redirect stderr too.
- `--bare` strips automatic context (CLAUDE.md autodiscovery, hooks, plugin sync, OAuth/keychain). Pair with explicit `--mcp-config`, `--system-prompt`, `--add-dir`, `--agents` and a literal `ANTHROPIC_API_KEY` or `apiKeyHelper` in settings.
- The `result.is_error` flag determines exit code 0 vs 1 for the success path. Don't assume `subtype: success` ⇒ exit 0 without checking `is_error`.
- For long-running headless sessions, `gracefulShutdownSync` has a 5s failsafe before `forceExit` — MCP servers and other resources have at most ~5s to clean up after a result is produced.
- `--max-turns`/`--max-budget-usd` produce `result` messages with `is_error: true` and `errors: string[]` — handle these distinctly from success.
- `--include-hook-events` adds `system` messages with `hook_started`/`hook_progress`/`hook_completed` subtypes (print.ts:628-666); consumers parsing stream-json must accept unknown system subtypes gracefully.
