# Claude Code profile directory layout

## TLDR

Claude Code roots every disk path through `getClaudeConfigHomeDir()`, which
returns `process.env.CLAUDE_CONFIG_DIR ?? ~/.claude`, and forwards
`CLAUDE_CONFIG_DIR` to spawned teammates — so a per-run dir cleanly isolates
the entire profile. To boot a fresh dir with existing auth, copy
`.credentials.json` (chmod 600) and `~/.claude.json` into it; the macOS
Keychain is *not* usable across fresh dirs because the keychain service
name embeds a sha256 of the config-dir path. No SQLite is used anywhere
under the profile dir; the only mutex is `~/.claude/.update.lock`, and
everything else (`projects/`, `sessions/`, `shell-snapshots/`, `ide/`,
`file-history/`) is session-id- or PID-namespaced and safe under
concurrent runs.

---

## Executive summary

- **Single chokepoint:** `getClaudeConfigHomeDir()` in `utils/envUtils.ts`
  resolves to `process.env.CLAUDE_CONFIG_DIR ?? ~/.claude`. Set the env var
  and the *entire* profile tree (settings, projects, sessions, plugins,
  shell-snapshots, ide locks, debug, file-history, …) re-roots cleanly.
- **Auto-forwarded to subagents:** the swarm/tmux spawner explicitly
  forwards `CLAUDE_CONFIG_DIR` (`utils/swarm/spawnUtils.ts:105`), so
  teammates inherit the per-run dir without extra plumbing.
- **Global config sits next to, not inside, the dir:** `~/.claude.json`
  (or `$CLAUDE_CONFIG_DIR/.claude.json`) holds OAuth account info,
  project trust, MCP servers, telemetry consent, and cached Statsig
  gates. Must be seeded for non-prompted boot.
- **Credentials live in `~/.claude/.credentials.json`** (chmod 600) as a
  fallback; macOS Keychain is preferred, but the keychain *service name
  includes a sha256 hash of the config dir* when non-default — so a fresh
  `CLAUDE_CONFIG_DIR` will not find existing OS-keychain creds unless you
  drop the plaintext file in (recommended for concurrent orchestration).
- **`projects/<sanitized-cwd>/`** holds session JSONL transcripts and
  the auto-memory dir. Cwd mangling is character substitution
  (`[^a-zA-Z0-9] -> '-'`, max 200 chars, hash suffix only beyond that) —
  not a hash. Canonicalised via `realpath` + NFC.
- **No `todos/` or `statsig/` dirs in this build.** Todos live in
  `AppStateStore` memory and the transcript JSONL; Statsig cache lives
  inside `~/.claude.json`. Anything you see on disk under those names is
  from older releases.
- **`plugins/`** is the heaviest sub-tree (marketplaces / cache /
  installed / data) and has its own env levers:
  `CLAUDE_CODE_PLUGIN_CACHE_DIR` (full override) and
  `CLAUDE_CODE_PLUGIN_SEED_DIR` (PATH-style read-only seed layer). Use
  these to share a pre-baked plugin tree across runs.
- **No SQLite anywhere.** Only meaningful lock is `~/.claude/.update.lock`.
  `ide/*.lock` and `sessions/<pid>.json` are PID-keyed; transcripts are
  session-id-keyed → concurrent runs in the same dir don't collide on
  filenames, but per-run dirs are still cleaner.
- **Minimum seed for fresh dir + existing auth:** copy
  `.credentials.json` (chmod 600) and `~/.claude.json` into
  `$CLAUDE_CONFIG_DIR`. Optionally symlink user-content dirs
  (`commands/`, `agents/`, `skills/`, `CLAUDE.md`, `rules/`,
  `settings.json`, `keybindings.json`). Everything else (`projects/`,
  `sessions/`, `shell-snapshots/`, `debug/`, `file-history/`, etc.) is
  regenerated.

---

## Detailed summary

The Claude Code CLI resolves its profile root through a single memoized
helper, `getClaudeConfigHomeDir()` in
`/Users/johntokash/Downloads/src/utils/envUtils.ts:7-14`, which returns
`process.env.CLAUDE_CONFIG_DIR ?? join(homedir(), '.claude')`, NFC-normalized.
Every disk path the CLI touches (settings, projects, sessions, ide locks,
shell snapshots, plugins, file-history, debug, statsCache, …) is rooted
here, so setting `CLAUDE_CONFIG_DIR` per run cleanly isolates the entire
profile. The teammate/swarm spawner forwards `CLAUDE_CONFIG_DIR`
explicitly through tmux so subagents inherit the same dir
(`/Users/johntokash/Downloads/src/utils/swarm/spawnUtils.ts:105`).

The legacy "global config" file lives **outside** `~/.claude` by default:
`getGlobalClaudeFile()` in `/Users/johntokash/Downloads/src/utils/env.ts:14-26`
returns `~/.claude<oauthSuffix>.json` when `CLAUDE_CONFIG_DIR` is unset, or
`$CLAUDE_CONFIG_DIR/.claude<oauthSuffix>.json` when it is set. This file
holds OAuth account state, project trust dialogs, MCP server registrations,
cached Statsig gates/dynamic-configs, and telemetry consent.

Inside `~/.claude/` the inventory is:

- `settings.json` — user-scope settings; merges in order
  `userSettings -> projectSettings -> localSettings -> policySettings`
  (`/Users/johntokash/Downloads/src/utils/settings/settings.ts:239-307,801`).
  Cowork mode renames to `cowork_settings.json`. Optional.
- `managed-settings.json` + `managed-settings.d/*.json` — admin policy.
  Optional.
- `.credentials.json` — plaintext OAuth token storage, chmod 0600
  (`/Users/johntokash/Downloads/src/utils/secureStorage/plainTextStorage.ts:13-17,61`).
  macOS Keychain is preferred; its **service name embeds a sha256 hash of
  the config dir** when `CLAUDE_CONFIG_DIR` is non-default
  (`/Users/johntokash/Downloads/src/utils/secureStorage/macOsKeychainHelpers.ts:29-41`).
  That hashing means each fresh per-run dir gets its own keychain
  namespace — convenient for isolation but it forces you to seed the
  plain file if you want to reuse existing OAuth credentials.
- `projects/<sanitized-cwd>/<sessionId>.jsonl` — full session transcript.
  Path mangling is **character substitution, not hashing**:
  `sanitizePath` replaces every `[^a-zA-Z0-9]` with `-` (max 200 chars,
  hash suffix only beyond that limit) —
  `/Users/johntokash/Downloads/src/utils/sessionStoragePortable.ts:311-319`.
  Cwd is canonicalized via `realpath` + NFC so symlinks collapse to one
  dir (`canonicalizePath` at line 339). Subagent transcripts live at
  `projects/<sanitized-cwd>/<sessionId>/subagents/agent-<id>.jsonl`
  (`/Users/johntokash/Downloads/src/utils/sessionStorage.ts:247-262`).
  Auto-memory lives at `projects/<sanitized-git-root>/memory/MEMORY.md`
  (`/Users/johntokash/Downloads/src/memdir/paths.ts:223-235`), with
  overrides `CLAUDE_CODE_REMOTE_MEMORY_DIR` (memory base) and
  `CLAUDE_COWORK_MEMORY_PATH_OVERRIDE` (full path) at lines 85-90 and
  209-228.
- `todos/` — **does not exist** in this build. Todos are kept in
  `AppStateStore.todos` in memory
  (`/Users/johntokash/Downloads/src/state/AppStateStore.ts:220,530`) and
  rehydrated from the transcript on `--resume`
  (`/Users/johntokash/Downloads/src/utils/sessionRestore.ts:73-89,139-146`).
- `statsig/` — **does not exist** in this build. Gate / dynamic-config
  values are cached inside `~/.claude.json` under `cachedStatsigGates` /
  `cachedStatsigDynamicConfigs`
  (`/Users/johntokash/Downloads/src/utils/config.ts:440-445`,
  `services/analytics/growthbook.ts:876-878`).
- `shell-snapshots/snapshot-<shell>-<timestamp>-<rand>.sh` —
  per-Bash-tool shell-env capture; randomly suffixed → concurrency-safe
  (`/Users/johntokash/Downloads/src/utils/bash/ShellSnapshot.ts:437-447`).
- `plugins/` (or `cowork_plugins/`) — plugin marketplace cache, installed
  plugins, persistent per-plugin data, and tracking caches. Layout:
  `marketplaces/<name>/`, `cache/<marketplace>/<plugin>/<version>/`,
  `installed/<marketplace>/<plugin>/`, `data/<sanitizedId>/`,
  `known_marketplaces.json`, `install-counts-cache.json`,
  `flagged-plugins.json`
  (`/Users/johntokash/Downloads/src/utils/plugins/pluginDirectories.ts:53-123`,
  `installedPluginsManager.ts:187-288`, `installCounts.ts:8`,
  `pluginFlagging.ts:5`). Overridable via `CLAUDE_CODE_PLUGIN_CACHE_DIR`
  (full override) and `CLAUDE_CODE_PLUGIN_SEED_DIR` (PATH-style read-only
  layer for container images).
- `commands/`, `agents/`, `output-styles/`, `skills/`, `workflows/`,
  optionally `templates/` — markdown-defined user config, also discovered
  in `<cwd>/.claude/<subdir>/` for project scope
  (`/Users/johntokash/Downloads/src/utils/markdownConfigLoader.ts:29-38,300-310`).
- `ide/<port>.lock` — written by JetBrains/VSCode Claude extensions, read
  by CC to discover an editor port
  (`/Users/johntokash/Downloads/src/utils/ide.ts:294-339,456-512`). On
  WSL the search also probes Windows-side `~/.claude/ide` dirs. Stale
  cleanup keys off PID liveness; safe to share between concurrent runs.
- `memory/` — there is **no top-level `~/.claude/memory/`**. User-level
  memory hooks are `~/.claude/CLAUDE.md` and `~/.claude/rules/`
  (`/Users/johntokash/Downloads/src/utils/config.ts:1784,1806`). Auto
  memory lives under `projects/` (see above).
- Other lazily-created paths: `history.jsonl`, `keybindings.json`,
  `uploads/<sessionId>/`, `teams/`, `cache/changelog.md`, `pasteStore/`,
  `plans/`, `debug/<sessionId>.txt` (+ `latest` symlink),
  `.update.lock`, `local/` (managed local install: `local/claude`,
  `local/node_modules/`), `backups/`, `sessions/<pid>.json` (PID
  registry, mode 0o700, cleaned on exit),
  `startup-perf/<sessionId>.txt`, `file-history/<sessionId>/<hash>@v<n>`,
  `session-env/`, `.npm-cache-cleanup`, `.version-cleanup`, and the
  stats-cache file.

Concurrency hazards: there is **no SQLite** anywhere under the profile
dir. The only true mutex is `~/.claude/.update.lock`
(`/Users/johntokash/Downloads/src/utils/autoUpdater.ts:169`). `ide/*.lock`
and `sessions/<pid>.json` are PID-namespaced and safe across concurrent
runs in the same dir. JSONL transcripts are session-id-scoped so even
shared `projects/` is non-colliding. The keychain `security` CLI
serializes via a 30s in-process cache
(`macOsKeychainHelpers.ts:69`) but per-run dir-hash service-name routing
means different runs touch different keychain items.

Minimum seed for a fresh `CLAUDE_CONFIG_DIR=$RUN_DIR` to run authenticated:

1. `$RUN_DIR/.credentials.json` copied from `~/.claude/.credentials.json`,
   chmod 600 (sidesteps the macOS keychain dir-hash mismatch).
2. `$RUN_DIR/.claude<oauthSuffix>.json` copied from `~/.claude.json`
   (project trust, MCP servers, telemetry consent).
3. Optionally symlink read-only artefacts: `settings.json`, `commands/`,
   `agents/`, `skills/`, `output-styles/`, `workflows/`, `CLAUDE.md`,
   `rules/`, `keybindings.json`.
4. Optionally point `CLAUDE_CODE_PLUGIN_CACHE_DIR` /
   `CLAUDE_CODE_PLUGIN_SEED_DIR` at a shared plugins tree to avoid
   re-cloning marketplaces per run.

Do **not** seed: `projects/`, `sessions/`, `shell-snapshots/`,
`file-history/`, `debug/`, `startup-perf/`, `uploads/`, `ide/`,
`.update.lock`, `local/`, `backups/`, `session-env/`, stats-cache.

---

## Extensive notes

Source root for all citations: `/Users/johntokash/Downloads/src/` (a checkout
of the Claude Code CLI). All file references are absolute to that tree.

### 1. The root resolver and the `CLAUDE_CONFIG_DIR` env var

Single chokepoint for every path the CLI puts under `~/.claude`:

`/Users/johntokash/Downloads/src/utils/envUtils.ts:7-14`

```ts
export const getClaudeConfigHomeDir = memoize(
  (): string => {
    return (
      process.env.CLAUDE_CONFIG_DIR ?? join(homedir(), '.claude')
    ).normalize('NFC')
  },
  () => process.env.CLAUDE_CONFIG_DIR,
)
```

Notes:

- `CLAUDE_CONFIG_DIR`, when set, **completely replaces** `~/.claude`. It is not
  merged: every consumer (settings, projects, sessions, ide locks, shell
  snapshots, plugins, file-history, debug, statsig-like caches, todos via
  projects, credentials, history, statsCache, …) re-roots through this one
  function.
- It is memoized but keyed on the env var, so changing `CLAUDE_CONFIG_DIR`
  *after* the process has touched the cache will flip everything (used by
  tests; in production the env var is session-stable per the comment).
- 150+ callers ride this hot path (comment in the same file).
- The teammate/swarm spawner explicitly forwards `CLAUDE_CONFIG_DIR` to
  spawned children so subagents share the same profile dir
  (`/Users/johntokash/Downloads/src/utils/swarm/spawnUtils.ts:96-128`,
  list includes `'CLAUDE_CONFIG_DIR'` at line 105). That means if you launch
  with a per-run profile dir, teammates inherit it automatically.

The legacy "global config" JSON sits **outside** `~/.claude` by default:

`/Users/johntokash/Downloads/src/utils/env.ts:14-26`

```ts
export const getGlobalClaudeFile = memoize((): string => {
  if (getFsImplementation().existsSync(join(getClaudeConfigHomeDir(), '.config.json'))) {
    return join(getClaudeConfigHomeDir(), '.config.json')
  }
  const filename = `.claude${fileSuffixForOauthConfig()}.json`
  return join(process.env.CLAUDE_CONFIG_DIR || homedir(), filename)
})
```

That is: `~/.claude.json` (or `~/.claude-*.json` for staging/dev OAuth
profiles) when `CLAUDE_CONFIG_DIR` is unset, or `$CLAUDE_CONFIG_DIR/.claude*.json`
when it is set. Legacy fallback `$CLAUDE_CONFIG_DIR/.config.json` is used if
present. This file holds OAuth state, project list/metadata, MCP servers,
trust dialogs, theme/UI, telemetry flags, etc. It is the single most
important file to seed for "fresh dir, existing auth".

### 2. Everything that lives under `getClaudeConfigHomeDir()` (≈ `~/.claude`)

Each entry: path, defining file, role, whether it is required.

#### 2.1 Settings

- `~/.claude/settings.json` — user-scope settings, the "userSettings"
  source.
  `/Users/johntokash/Downloads/src/utils/settings/settings.ts:239-253`:

  ```ts
  case 'userSettings':
    return resolve(getClaudeConfigHomeDir())
  ```

  Filename can become `cowork_settings.json` in cowork mode
  (`getUserSettingsFilePath`, settings.ts:264-272). Optional — the
  defaults work fine without it.

- `~/.claude/managed-settings.json` and `~/.claude/managed-settings.d/*.json`
  — `policySettings`, requires admin in normal installs. Optional.
  `/Users/johntokash/Downloads/src/utils/settings/settings.ts:59` resolves
  it via `getManagedFilePath()` (platform-specific).

- Project-local equivalents (NOT under `~/.claude`, but under the cwd):
  `<projectRoot>/.claude/settings.json` (`projectSettings`) and
  `<projectRoot>/.claude/settings.local.json` (`localSettings`).
  `/Users/johntokash/Downloads/src/utils/settings/settings.ts:298-307`:

  ```ts
  case 'projectSettings':
    return join('.claude', 'settings.json')
  case 'localSettings':
    return join('.claude', 'settings.local.json')
  ```

  Merge order: `userSettings -> projectSettings -> localSettings -> policySettings`
  (settings.ts:801).

#### 2.2 Credentials

- `~/.claude/.credentials.json` — plaintext fallback for OAuth/API tokens.
  `/Users/johntokash/Downloads/src/utils/secureStorage/plainTextStorage.ts:13-17`:

  ```ts
  function getStoragePath(): { storageDir: string; storagePath: string } {
    const storageDir = getClaudeConfigHomeDir()
    const storageFileName = '.credentials.json'
    return { storageDir, storagePath: join(storageDir, storageFileName) }
  }
  ```

  Permissions chmod'd to `0o600` (plainTextStorage.ts:61).
- On macOS the preferred backend is Keychain. Service name encodes the
  config-dir hash so different `CLAUDE_CONFIG_DIR` values get distinct
  keychain entries:
  `/Users/johntokash/Downloads/src/utils/secureStorage/macOsKeychainHelpers.ts:29-41`:

  ```ts
  const isDefaultDir = !process.env.CLAUDE_CONFIG_DIR
  const dirHash = isDefaultDir
    ? ''
    : `-${createHash('sha256').update(configDir).digest('hex').substring(0, 8)}`
  return `Claude Code${getOauthConfig().OAUTH_FILE_SUFFIX}${serviceSuffix}${dirHash}`
  ```

  Implication: a fresh `CLAUDE_CONFIG_DIR` per run on macOS will **not**
  find existing keychain credentials unless you also seed
  `~/.claude/.credentials.json` (plain), or copy/share the per-dir-hash
  keychain item. Easiest path for concurrent orchestration is to drop a
  pre-populated `.credentials.json` into each fresh dir (and accept the
  "plaintext credentials" warning) or symlink it from a shared source.
- See also `/Users/johntokash/Downloads/src/utils/auth.ts:1323` which
  joins `getClaudeConfigHomeDir(), '.credentials.json'` directly when
  migrating.

#### 2.3 `projects/` — per-cwd session JSONL transcripts

- `~/.claude/projects/<sanitized-cwd>/<sessionId>.jsonl` — full session
  transcript.
  `/Users/johntokash/Downloads/src/utils/sessionStorage.ts:198-205`:

  ```ts
  export function getProjectsDir(): string {
    return join(getClaudeConfigHomeDir(), 'projects')
  }
  export function getTranscriptPath(): string {
    const projectDir = getSessionProjectDir() ?? getProjectDir(getOriginalCwd())
    return join(projectDir, `${getSessionId()}.jsonl`)
  }
  ```

- Subagent transcripts: `<projectDir>/<sessionId>/subagents/agent-<id>.jsonl`
  (`sessionStorage.ts:247-258`), with optional grouping subdir.
- Sidecar metadata: `agent-<id>.meta.json` (`sessionStorage.ts:260-262`).
- The cwd→subdir mapping is *not* a hash; it's a character substitution:
  `/Users/johntokash/Downloads/src/utils/sessionStoragePortable.ts:288-319`:

  ```ts
  export const MAX_SANITIZED_LENGTH = 200
  export function sanitizePath(name: string): string {
    const sanitized = name.replace(/[^a-zA-Z0-9]/g, '-')
    if (sanitized.length <= MAX_SANITIZED_LENGTH) return sanitized
    const hash = typeof Bun !== 'undefined' ? Bun.hash(name).toString(36) : simpleHash(name)
    return `${sanitized.slice(0, MAX_SANITIZED_LENGTH)}-${hash}`
  }
  ```

  So `/Users/jt/dev/Tenacious` becomes `-Users-jt-dev-Tenacious`.
  Only paths exceeding 200 chars get a hash suffix, and CLI (Bun.hash) vs
  SDK (djb2) can disagree on the hash — `findProjectDir` handles that with
  prefix scan (sessionStoragePortable.ts:354-380).
- Canonicalization: `canonicalizePath` calls `realpath` + NFC; symlinks
  collapse to one project dir (sessionStoragePortable.ts:339-345).
- Also under here: `~/.claude/projects/<sanitized-cwd>/memory/` —
  auto-memory (memdir).
  `/Users/johntokash/Downloads/src/memdir/paths.ts:223-235`:

  ```ts
  const projectsDir = join(getMemoryBaseDir(), 'projects')
  return (join(projectsDir, sanitizePath(getAutoMemBase()), AUTO_MEM_DIRNAME) + sep).normalize('NFC')
  ```

  `AUTO_MEM_DIRNAME = 'memory'` and the entrypoint is `MEMORY.md`
  (memdir/paths.ts:92-93). Auto-memory base resolves to the canonical git
  root so all worktrees share one memory dir (memdir/paths.ts:200-205).
  `CLAUDE_CODE_REMOTE_MEMORY_DIR` overrides the memory base
  (memdir/paths.ts:85-90) and `CLAUDE_COWORK_MEMORY_PATH_OVERRIDE` is a
  full-path override (memdir/paths.ts:209-228).
- Asciicast recordings: `~/.claude/projects/<sanitized-cwd>/...`
  (`/Users/johntokash/Downloads/src/utils/asciicast.ts:36,57,87`).

#### 2.4 `todos/` — NOT present in this source tree

Despite the question listing `todos/`, the current source stores TodoWrite
state **in the AppStateStore in memory**, keyed by agentId
(`/Users/johntokash/Downloads/src/state/AppStateStore.ts:220` —
`todos: { [agentId: string]: TodoList }`, default `{}` at line 530), and
hydrates from the transcript on `--resume`
(`/Users/johntokash/Downloads/src/utils/sessionRestore.ts:73-89, 139-146`).
There is no `~/.claude/todos/` directory in this build. The TodoWriteTool
(`/Users/johntokash/Downloads/src/tools/TodoWriteTool/TodoWriteTool.ts`)
only reads/writes `appState.todos[todoKey]`. If older Claude Code releases
wrote a `todos/` dir on disk, this build no longer does — todos are
implicitly persisted via the JSONL transcript in `projects/`.

#### 2.5 `statsig/` — NOT present in this source tree

There is no Statsig SDK on-disk cache directory created by this build.
Statsig gate / dynamic-config values are cached **inside the global config
file** (`~/.claude.json`) under
`cachedStatsigGates` / `cachedStatsigDynamicConfigs`
(`/Users/johntokash/Downloads/src/utils/config.ts:440-445` comments,
`/Users/johntokash/Downloads/src/services/analytics/growthbook.ts:876-878`).
Telemetry events go through `firstPartyEventLoggingExporter.ts` which
stores failed-event spool files under a config-dir-relative path
(`/Users/johntokash/Downloads/src/services/analytics/firstPartyEventLoggingExporter.ts:43`
comments "evaluated at runtime to respect CLAUDE_CONFIG_DIR in tests").
If your existing `~/.claude/statsig/` is from an older release, it is safe
to omit when seeding a fresh dir.

#### 2.6 `shell-snapshots/`

- `~/.claude/shell-snapshots/snapshot-<shell>-<timestamp>-<rand>.sh`
- Created by the Bash tool to capture user shell env/functions/aliases
  for replay in tool calls.
  `/Users/johntokash/Downloads/src/utils/bash/ShellSnapshot.ts:437-447`:

  ```ts
  const timestamp = Date.now()
  const randomId = Math.random().toString(36).substring(2, 8)
  const snapshotsDir = join(getClaudeConfigHomeDir(), 'shell-snapshots')
  const shellSnapshotPath = join(
    snapshotsDir,
    `snapshot-${shellType}-${timestamp}-${randomId}.sh`,
  )
  await mkdir(snapshotsDir, { recursive: true })
  ```

- Filename includes a random component → safe under concurrent runs.
  Optional; auto-created on demand.

#### 2.7 `plugins/` (or `cowork_plugins/`) — plugin cache + state

- `/Users/johntokash/Downloads/src/utils/plugins/pluginDirectories.ts:53-63`:

  ```ts
  export function getPluginsDirectory(): string {
    const envOverride = process.env.CLAUDE_CODE_PLUGIN_CACHE_DIR
    if (envOverride) return expandTilde(envOverride)
    return join(getClaudeConfigHomeDir(), getPluginsDirectoryName())
  }
  ```

- Two env-var levers:
  - `CLAUDE_CODE_PLUGIN_CACHE_DIR` — full path override, bypasses the
    config-home.
  - `CLAUDE_CODE_USE_COWORK_PLUGINS` — flips name to `cowork_plugins`.
  - `CLAUDE_CODE_PLUGIN_SEED_DIR` — PATH-style list of read-only seed
    layers (`pluginDirectories.ts:85-90`), used to pre-bake plugin
    contents into container images.
- Internal subtree (from comments + `installedPluginsManager.ts:187-288`,
  `pluginLoader.ts:166,242`):

  - `plugins/known_marketplaces.json`
  - `plugins/marketplaces/<name>/...`
  - `plugins/cache/<marketplace>/<plugin>/<version>/...`  (V2 versioned)
  - `plugins/cache/<plugin-name>/...`  (V1 legacy)
  - `plugins/installed/<marketplace>/<plugin>/...`
    (`pluginLoader.ts` doc-comment / `schemas.ts:1443`)
  - `plugins/data/<sanitizedPluginId>/`  — persistent per-plugin user
    data, survives plugin updates
    (`pluginDirectories.ts:98-123`, exposed as `${CLAUDE_PLUGIN_DATA}`).
  - `plugins/install-counts-cache.json`
    (`installCounts.ts:8`).
  - `plugins/flagged-plugins.json` (`pluginFlagging.ts:5`).
- Plugin data dirs use `sanitizePluginId` (`pluginDirectories.ts:92-95`,
  replaces non-`[a-zA-Z0-9_-]` with `-`).

#### 2.8 `commands/`, `agents/`, `output-styles/`, `skills/`, `workflows/`, (`templates/`)

User-level markdown config sources. Globally enumerated:
`/Users/johntokash/Downloads/src/utils/markdownConfigLoader.ts:29-38`:

```ts
export const CLAUDE_CONFIG_DIRECTORIES = [
  'commands',
  'agents',
  'output-styles',
  'skills',
  'workflows',
  ...(feature('TEMPLATES') ? (['templates'] as const) : []),
] as const
```

Each is read from `~/.claude/<subdir>/` and from `<projectRoot>/.claude/<subdir>/`
(markdownConfigLoader.ts:300-310; fileSuggestions.ts:447). All optional.

#### 2.9 `ide/` — IDE lockfiles

- `~/.claude/ide/<port>.lock` JSON files written by the JetBrains/VSCode
  Claude extensions; read by CC to discover an editor IPC port.
  `/Users/johntokash/Downloads/src/utils/ide.ts:462-463`:

  ```ts
  export async function getIdeLockfilesPaths(): Promise<string[]> {
    const paths: string[] = [join(getClaudeConfigHomeDir(), 'ide')]
  ```

  On WSL the function additionally probes Windows-side `~/.claude/ide`
  paths (ide.ts:474-503).
- Read-only from CC's perspective; stale entries are GC'd by
  `cleanupStaleIdeLockfiles` (ide.ts:518-548), which calls
  `isProcessRunning(lockfileInfo.pid)`. A shared `ide/` dir between
  concurrent runs is **safe** but they will race on stale-cleanup; per-run
  isolation is cleaner if you don't need IDE integration.

#### 2.10 `memory/` (the project-scoped one)

Already covered in 2.3 — the user-visible "memory" is
`~/.claude/projects/<sanitized-cwd>/memory/MEMORY.md`. There is **no
top-level `~/.claude/memory/`** in this build; the only top-level "memory"
hooks are `~/.claude/CLAUDE.md` (user-level system prompt include) and
`~/.claude/rules/` — see `config.ts:1784,1806`:

```ts
return join(getClaudeConfigHomeDir(), 'CLAUDE.md')
…
return join(getClaudeConfigHomeDir(), 'rules')
```

#### 2.11 Other files/dirs created lazily under `getClaudeConfigHomeDir()`

From a sweep of every `join(getClaudeConfigHomeDir(), …)` call:

| Path | Defined at | Role | Required? |
|---|---|---|---|
| `history.jsonl` | `history.ts:115,299` | Prompt history (REPL up-arrow) | No |
| `keybindings.json` | `keybindings/loadUserBindings.ts:116` | Custom key bindings | No |
| `uploads/<sessionId>/` | `bridge/inboundAttachments.ts:61` | Inbound paste / drag-drop files | No |
| `teams/` | `envUtils.ts:16-18` (`getTeamsDir`) | Teams feature data | No |
| `cache/changelog.md` | `releaseNotes.ts:38` | Cached release notes | No |
| `pasteStore/` (`PASTE_STORE_DIR`) | `pasteStore.ts:14` | Pasted image/text store | No |
| `plans/` | `plans.ts:94,100`; `cleanup.ts:301` | `/plan` file storage | No |
| `debug/<sessionId>.txt` | `debug.ts:234`; `cleanup.ts:400` | Debug logs (+ `latest` symlink) | No |
| `.update.lock` | `autoUpdater.ts:169` | Auto-update mutex | No |
| `local/` | `localInstaller.ts:19-23` | Managed local install (`local/claude`, `local/node_modules/`) | No |
| `backups/` | `config.ts:1363` | Config backup snapshots | No |
| `CLAUDE.md` | `config.ts:1784` | User-level system prompt include | No |
| `rules/` | `config.ts:1806` | User-level rule files | No |
| `sessions/<pid>.json` | `concurrentSessions.ts:21-22, 60-80` | PID registry for `claude ps` (mode 0o700) | No |
| `startup-perf/<sessionId>.txt` | `startupProfiler.ts:152` | Startup profile traces | No |
| `<STATS_CACHE_FILENAME>` | `statsCache.ts:78` | Token/usage stats cache | No |
| `file-history/<sessionId>/<hash>@v<n>` | `fileHistory.ts:733-740, 951-954` | Edit/Write rollback snapshots | No |
| `session-env/` | `cleanup.ts:356-357`; `sessionEnvironment.ts:17` | Per-session env state | No |
| `.npm-cache-cleanup`, `.version-cleanup` | `cleanup.ts:439,544` | Cleanup markers | No |
| `<STATS_CACHE_FILENAME>` / various caches under `cache/` | `releaseNotes.ts`, `model/modelCapabilities.ts:60` | Misc cache | No |

#### 2.12 Sub-process spawn forwarding

Teammates/subagents spawned via tmux strip env by default; the explicit
forward list is at
`/Users/johntokash/Downloads/src/utils/swarm/spawnUtils.ts:96-128` and
includes `CLAUDE_CONFIG_DIR`, `CLAUDE_CODE_REMOTE_MEMORY_DIR`,
`CLAUDE_CODE_REMOTE`, provider env, and proxy env. For concurrent
orchestration this is the right list to set per child if you want each
subagent in its own profile dir; if you set them in the *parent*
environment, they propagate.

### 3. Locks, sockets, sqlite — concurrency hazards

- **No SQLite anywhere** under the profile dir. A repo-wide grep for
  `sqlite`/`better-sqlite`/`.db` under `~/.claude` paths returned no hits.
- **Lockfiles**:
  - `~/.claude/.update.lock` (`autoUpdater.ts:169`) — exclusive lock during
    self-update. Should not conflict between concurrent runs that aren't
    updating, but two updates at once would race.
  - `~/.claude/ide/*.lock` — written by editors, consumed by CC. Multiple
    CC instances can read concurrently; stale-cleanup races on `unlink`
    are best-effort (already caught).
- **`sessions/<pid>.json`** is created with `mode 0o700`
  (`concurrentSessions.ts:75-76`) and removed on exit
  (registerCleanup at line 66). Concurrent runs in the same dir are fine
  because filenames are PID-unique. Cross-runtime caveat: on WSL the code
  refuses to sweep PID files because Windows PIDs aren't probeable
  (concurrentSessions.ts:194-200), so cross-OS shared dirs accumulate
  stale entries — irrelevant for pure-darwin orchestration.
- **`projects/<sanitized-cwd>/<sessionId>.jsonl`** is per-session; multiple
  runs in the same cwd write to distinct files. JSONL append is line-safe
  but two writers to the *same* file would interleave — never happens
  because session IDs differ.
- **macOS Keychain**: a single `security` CLI shells out per read/write
  with a 30s in-process cache (macOsKeychainHelpers.ts:69). Cross-process
  contention is possible (a parallel `/login` could refresh a token);
  the cache TTL bounds staleness rather than fully serialising. For
  per-run profile dirs the service-name dir-hash (sec. 2.2) means each
  run looks up *different* keychain entries → no contention, but also no
  pre-existing creds.
- **Memory dir**: per-project, keyed on canonical git root — if two runs
  share the cwd they share the memory dir. Writes go through
  `extractMemories` background agents; concurrent writers could clobber.
  If isolation is required, set `CLAUDE_COWORK_MEMORY_PATH_OVERRIDE` per
  run (memdir/paths.ts:209-228).

### 4. Project-local `<cwd>/.claude/`

Distinct from the home profile dir. Created by CC under the user's repo:

- `<cwd>/.claude/settings.json` — `projectSettings` (checked in).
- `<cwd>/.claude/settings.local.json` — `localSettings` (gitignored).
- `<cwd>/.claude/{commands,agents,output-styles,skills,workflows}/` —
  project-scoped markdown config (markdownConfigLoader.ts pairing with
  the user-scope ones).
- Sandbox notes show `<cwd>/.claude/` is treated as project-trust scope
  (`/Users/johntokash/Downloads/src/utils/sandbox/sandbox-adapter.ts:434`
  region of `.claude-projects` carve-outs).

These are governed by cwd, not by `CLAUDE_CONFIG_DIR`. Per-run isolation
of *home* profile does not affect them.

### 5. Minimum seed for a fresh `CLAUDE_CONFIG_DIR` to run authenticated

Goal: `CLAUDE_CONFIG_DIR=/tmp/cc-run-XYZ claude …` starts headless without
re-login.

Required:

1. **Credentials**, one of:
   - `$CLAUDE_CONFIG_DIR/.credentials.json` (chmod 600) — copied from the
     source dir. This bypasses the macOS keychain service-name dir-hash
     mismatch entirely because plain-text storage is tried by
     `getSecureStorage()` as a fallback (see
     `/Users/johntokash/Downloads/src/utils/secureStorage/index.ts` /
     auth.ts:1209-1290).
   - Or `ANTHROPIC_API_KEY` in env (for `--bare`-style API-key auth;
     bypasses keychain entirely, see `envUtils.ts:60-65` for `isBareMode`).

2. **Global config JSON** — `~/.claude.json` (or
   `$CLAUDE_CONFIG_DIR/.claude.json` when the env var is set, per
   `env.ts:24-25`). Holds OAuth account info, telemetry consent,
   project trust dialogs, MCP server registrations. Without it, OAuth
   may still work (creds in `.credentials.json` are independent), but
   the user will see trust prompts and lose MCP servers / first-run
   defaults. Copy this from the source profile.

3. **macOS-only consideration**: if you skip step 1 (plain creds file) and
   rely on Keychain, you must also seed a keychain entry whose service
   name matches the new dir's hash (see
   `macOsKeychainHelpers.ts:32-41`). Easier: ship `.credentials.json`.

Optional (preserve UX continuity):

- `$CLAUDE_CONFIG_DIR/settings.json` — user prefs (theme, model, hooks).
- `$CLAUDE_CONFIG_DIR/commands/`, `agents/`, `skills/`, `output-styles/`,
  `workflows/` — copy or symlink user content.
- `$CLAUDE_CONFIG_DIR/CLAUDE.md`, `rules/` — user-scope memory/rules.
- `$CLAUDE_CONFIG_DIR/plugins/` — or, much cheaper, set
  `CLAUDE_CODE_PLUGIN_CACHE_DIR` to a shared read-only path, or
  `CLAUDE_CODE_PLUGIN_SEED_DIR` to layer a pre-baked plugin cache.
- `$CLAUDE_CONFIG_DIR/keybindings.json` if customised.

Should NOT be seeded (per-run state, will be recreated):

- `projects/`, `sessions/`, `shell-snapshots/`, `file-history/`,
  `debug/`, `startup-perf/`, `uploads/`, `ide/`, `.update.lock`,
  `local/`, `backups/`, `session-env/`, statsCache file.

### 6. Concurrency recipe summary

For clean per-run profile dirs:

1. For each run, pick `RUN_DIR=$(mktemp -d -t cc-run)`. Seed:
   - `cp ~/.claude/.credentials.json $RUN_DIR/` (chmod 600).
   - `cp ~/.claude.json $RUN_DIR/.claude.json`.
   - Optionally symlink the read-only stuff: `commands/`, `agents/`,
     `skills/`, `output-styles/`, `CLAUDE.md`, `rules/`,
     `keybindings.json`, `settings.json`.
2. `export CLAUDE_CONFIG_DIR=$RUN_DIR`. (Also forwards to teammates by
   default — `spawnUtils.ts:105`.)
3. Optional: `export CLAUDE_CODE_PLUGIN_CACHE_DIR=/shared/plugins` (read
   only) or `CLAUDE_CODE_PLUGIN_SEED_DIR=/shared/plugins`.
4. Optional but recommended: `export CLAUDE_COWORK_MEMORY_PATH_OVERRIDE`
   per run if you want isolated memory; otherwise memory will be shared
   among runs against the same git root.
5. Nothing else collides: every other path the CLI writes is either
   session-id-scoped, PID-scoped, or randomly suffixed.

---

## Appendix A — Empirical verification of keychain service-name hashing (2026-05-12)

The hashing rule in §2.2 was confirmed against this machine's actual keychain.

**Algorithm** (`macOsKeychainHelpers.ts:29-41`): the service name is
`Claude Code${OAUTH_FILE_SUFFIX}-credentials${dirHash}`, where `dirHash`
is empty when `CLAUDE_CONFIG_DIR` is unset (back-compat with the legacy
default-dir entry) and otherwise `-` + the first 8 hex chars of
`sha256(<absolute config dir path>)`. `OAUTH_FILE_SUFFIX` is empty in
production builds.

**Computed vs observed.** Three CLAUDE_CONFIG_DIR profiles are aliased
in this user's `~/.zshrc` (`claudeHome`, `claudeGuilde`, `claudeVoice`).
Computed service names:

| Config dir | sha256 prefix | Expected service name |
|---|---|---|
| `/Users/johntokash/.claudeHome` | `b05ca9fb` | `Claude Code-credentials-b05ca9fb` |
| `/Users/johntokash/.claudeGuilde` | `4c1244b7` | `Claude Code-credentials-4c1244b7` |
| `/Users/johntokash/.claudeVoice` | `64258b8a` | `Claude Code-credentials-64258b8a` |

`security dump-keychain | grep "Claude Code-credentials"` on the same
machine returned exactly three entries:

- `Claude Code-credentials`           ← legacy default-dir entry (CLAUDE_CONFIG_DIR unset)
- `Claude Code-credentials-4c1244b7`  ← matches `~/.claudeGuilde`
- `Claude Code-credentials-b05ca9fb`  ← matches `~/.claudeHome`

`~/.claudeVoice` (`64258b8a`) is absent because the user has never
logged into that profile yet — confirming entries are created lazily on
first login.

**Implications for the orchestrator.**

- Per-run `CLAUDE_CONFIG_DIR`s *do* get isolated auth on macOS (each dir
  hashes to a distinct keychain slot) — earlier guidance that "every
  profile shares one credential on macOS" was wrong.
- On macOS, seeding a fresh per-run profile with existing auth means
  either (a) compute the dir-hash service name and write to Keychain
  via `security add-generic-password -U -a $USER -s "Claude Code-credentials-$DIRHASH" -w "$JSON"`,
  or (b) drop `.credentials.json` (mode 0600) into the new dir — the
  plain-text fallback works on macOS too.
- Reproducing the hash from a path: `printf %s "$ABS_DIR" |
  shasum -a 256 | cut -c1-8`. The input must be the absolute path
  exactly as `getClaudeConfigHomeDir()` returns it (tilde expanded; no
  trailing slash; not realpath-resolved).
