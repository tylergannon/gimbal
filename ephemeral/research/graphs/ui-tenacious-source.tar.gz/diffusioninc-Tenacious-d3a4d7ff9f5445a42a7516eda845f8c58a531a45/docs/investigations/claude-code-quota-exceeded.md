# TLDR

In `claude -p --output-format stream-json --verbose`, a Pro/Max quota hit surfaces as a stdout `{type:"rate_limit_event", rate_limit_info:{status:"rejected", rateLimitType:"five_hour"|"seven_day"|…, resetsAt:<unix-seconds>, overageStatus, overageDisabledReason}}` event followed by a terminal `{type:"result", subtype:"success", is_error:true, result:"You've hit your weekly limit · resets …"}` and **exit code 1**. Subscription 429s are not auto-retried (only Enterprise/API-key 429s are), so the rejection appears immediately; transient capacity errors (529 / non-subscriber 429) are distinguishable by interleaved `{type:"system", subtype:"api_retry", error_status, retry_delay_ms}` events. Pattern-match on `rate_limit_event.status==='rejected'` plus `rateLimitType` and back off the account until `resetsAt`.

---

## Executive summary

- All inference, including OAuth Pro/Max, goes to `api.anthropic.com`; the `claude.ai` / `claude.com` host is only used for OAuth authorize — there is **no separate OAuth quota channel**.
- Subscription quota rejections arrive as **HTTP 429** carrying `anthropic-ratelimit-unified-*` headers — chief among them `-representative-claim` (`five_hour` = 5-hour cap, `seven_day` = weekly cap, `seven_day_opus`, `seven_day_sonnet`, `overage`), `-status` (`allowed | allowed_warning | rejected`), and `-reset` (Unix-seconds reset time).
- A bare 429 without those headers is treated as **capacity / entitlement**, not quota; message is `API Error: Request rejected (429) · …`.
- Pro/Max OAuth subscribers' 429s are **not retried** (`withRetry.shouldRetry` returns false for them); API-key and Enterprise users retry up to `DEFAULT_MAX_RETRIES = 10` honoring `Retry-After`. `CLAUDE_CODE_UNATTENDED_RETRY=1` enables persistent retry that schedules resume from `anthropic-ratelimit-unified-reset` (capped at 6 h).
- The SDK error-tag enum on stream-json is `'authentication_failed' | 'billing_error' | 'rate_limit' | 'invalid_request' | 'server_error'`. Both 429 and 529/overloaded collapse to `'rate_limit'`.
- Stream-JSON events to pattern-match (in priority order):
  1. `{type:"rate_limit_event", rate_limit_info:{status:"rejected", resetsAt, rateLimitType, overageStatus, overageDisabledReason, …}}` — definitive quota signal.
  2. `{type:"system", subtype:"api_retry", error_status:429, error:"rate_limit", retry_delay_ms, attempt, max_retries}` — visible during retried 429/529.
  3. `{type:"assistant", error:"rate_limit", message:{content:[{text:"You've hit your weekly limit · resets …"}]}}` — synthetic in-turn error.
  4. Terminal `{type:"result", subtype:"success", is_error:true, result:"You've hit your …"}` (quota) **or** `subtype:"error_during_execution"` (uncaught throw, exit-code-1).
- Exit code: **0** only if final `result.is_error === false`; **1** otherwise. Set by `gracefulShutdownSync` (`cli/print.ts:971-973`, `2451`).
- The user-facing text always begins with one of: `"You've hit your"`, `"You've used"`, `"You're now using extra usage"`, `"You're close to"`, `"You're out of extra usage"` (`rateLimitMessages.ts:21-27`).
- `overageDisabledReason === 'out_of_credits'` means the account has used all extra usage and is fully locked out until reset; other reasons (`org_level_disabled`, `member_zero_credit_limit`, …) indicate config/billing problems an admin must fix.
- Recommended orchestrator policy: on `rate_limit_event.status === 'rejected'`, mark the account quota-exhausted until `max(resetsAt, overageResetsAt ?? 0)`; on transient `api_retry` events let the CLI keep working; on auth errors (`error:"authentication_failed"`, `OAuth token has been revoked`, `Please run /login`) the account is broken, not quota-limited.

---

## Detailed summary

**How a 429 reaches stdout in `claude -p`.** All inference goes through `api.anthropic.com` regardless of OAuth vs API key. The SDK throws `APIError`; `services/api/withRetry.ts` decides whether to retry. For **Pro/Max OAuth subscribers a 429 is deliberately *not* retried** (`shouldRetry`, lines 765-769): the loop throws `CannotRetryError`. For API-key / Enterprise users it retries up to `DEFAULT_MAX_RETRIES = 10` honoring the `Retry-After` header (`getRetryDelay`, 530-548). An opt-in `CLAUDE_CODE_UNATTENDED_RETRY` enables persistent retry that waits up to 6 hours using `anthropic-ratelimit-unified-reset` to schedule resume (`getRateLimitResetDelayMs`, 814-822).

**The unified header family.** `services/claudeAiLimits.ts` parses these on every response: `anthropic-ratelimit-unified-status` (`allowed | allowed_warning | rejected`), `-reset` (epoch s), `-representative-claim` (`five_hour | seven_day | seven_day_opus | seven_day_sonnet | overage`), `-overage-status`, `-overage-reset`, `-overage-disabled-reason` (13 enum values including `out_of_credits`, `org_level_disabled`, `member_zero_credit_limit`), and per-window `-5h-utilization` / `-5h-reset` / `-7d-utilization` / `-7d-reset` / `-{5h,7d}-surpassed-threshold`. Updates fire `emitStatusChange` which fans out to `statusListeners`.

**Stream-JSON events an orchestrator can match on.**

- `{type:"rate_limit_event", rate_limit_info:{status, resetsAt, rateLimitType, utilization, overageStatus, overageResetsAt, overageDisabledReason, isUsingOverage, surpassedThreshold}}` — emitted on every quota state change from `cli/print.ts:1126-1140`. Schema: `entrypoints/sdk/coreSchemas.ts:1358-1367` + `SDKRateLimitInfoSchema` ~1300-1345.
- `{type:"system", subtype:"api_retry", attempt, max_retries, retry_delay_ms, error_status, error}` — emitted per retry attempt from `QueryEngine.ts:943-955`. `error` is one of `'rate_limit' | 'authentication_failed' | 'server_error' | 'unknown'` from `categorizeRetryableAPIError` (`errors.ts:1163-1182`).
- `{type:"assistant", error:"rate_limit", message:{content:[{text:"You've hit your weekly limit · resets …"}]}}` — synthetic message produced by `getAssistantMessageFromError` (`errors.ts:466-557`). Text-prefix set in `services/rateLimitMessages.ts:21-27`.
- Terminal `{type:"result", subtype:"success", is_error:true, result:"You've hit your …"}` — `QueryEngine.ts:1132-1155`. Note the gotcha: a quota rejection comes through as `subtype:'success'` with `is_error:true`, **not** `error_during_execution`. The latter is reserved for thrown exceptions caught at `cli/print.ts:2424-2452` (`gracefulShutdownSync(1)`).
- Exit code: `gracefulShutdownSync(lastMessage?.is_error ? 1 : 0)` at `cli/print.ts:971-973`. Quota → **exit 1**.

**Subscription vs API key.** `errors.ts:466-557` forks on `isClaudeAISubscriber()` AND the presence of `anthropic-ratelimit-unified-representative-claim`. With those headers → subscription quota message ("You've hit your weekly limit · resets …"). Without → generic "API Error: Request rejected (429) · …". `RateLimitType` display names (`claudeAiLimits.ts:79-85`): `five_hour='session limit'`, `seven_day='weekly limit'`. Subscription 429s are also force-tagged `error:'rate_limit'` regardless.

**Overage / extra usage.** When subscription is `rejected` but overage is `allowed`, `isUsingOverage=true` and execution continues silently. When overage also rejects, `overageDisabledReason` carries the precise cause (`out_of_credits` etc.). The earliest of `resetsAt` and `overageResetsAt` is shown to the user.

**Retry-After / x-should-retry semantics.** `Retry-After` header (seconds) honored verbatim, bypassing `maxDelayMs`. `x-should-retry: true` honored for non-subscribers and Enterprise; ignored for Pro/Max because the API reports `true` with "in several hours" (`withRetry.ts:736-742`). `x-should-retry: false` honored except Ants on 5xx (744-751).

**529 / overloaded_error.** Detected by status or message-substring `"type":"overloaded_error"` (`is529Error`, 610-621). Foreground sources retry up to 3 times; non-foreground (summaries/titles/classifiers) bail immediately to avoid amplification (`FOREGROUND_529_RETRY_SOURCES`, 62-82). After 3 consecutive 529s, optionally falls back to a configured fallback model via `FallbackTriggeredError`.

**OAuth host vs API host.** `constants/oauth.ts:85-93`: `BASE_API_URL='https://api.anthropic.com'`, `CLAUDE_AI_AUTHORIZE_URL='https://claude.com/cai/oauth/authorize'`. No quota signaling at the OAuth host — everything comes back on the inference response from `api.anthropic.com`.

**Detection recipe.** Prefer the `rate_limit_event.rate_limit_info.status==='rejected'` signal with `resetsAt` for the back-off deadline. Fall back to terminal-result `is_error===true && result startsWith "You've hit your"`. Distinguish transient capacity (`api_retry` with `error_status:529` or non-subscriber 429) from hard quota (no retries, immediate rejection with unified headers). For API-key 429s without unified headers, treat as transient capacity, not quota.

---

# Claude Code CLI: Detecting Quota / Rate-Limit Exhaustion from an Orchestrator (Extensive)

Source tree: `/Users/johntokash/Downloads/src` (Claude Code CLI bundle, TypeScript).

This pass enumerates the entire signaling surface: HTTP status codes, response headers, internal error wrappers, what gets emitted on the `stream-json` stdout channel in `claude -p` / print mode, retry/backoff behavior, and the resulting exit codes — with verbatim citations.

---

## 1. HTTP status codes Claude Code recognizes

The CLI uses the official `@anthropic-ai/sdk` `APIError` class. All status-based branching lives mainly in:

- `/Users/johntokash/Downloads/src/services/api/errors.ts`
- `/Users/johntokash/Downloads/src/services/api/withRetry.ts`
- `/Users/johntokash/Downloads/src/services/claudeAiLimits.ts`

Status codes and their classification (`classifyAPIError`, `errors.ts:965-1161`):

- **429** — `rate_limit` (always, regardless of body). Special branch for subscribers checks for the `anthropic-ratelimit-unified-*` headers; if present, it's treated as a Pro/Max **quota** rejection; otherwise it's surfaced as a generic 429 (capacity / entitlement). See `errors.ts:466-557`.
- **529** or message containing `"type":"overloaded_error"` — `server_overload` / `is529Error` → retried up to `MAX_529_RETRIES = 3` for non-foreground; foreground/persistent paths retry more (`withRetry.ts:54, 610-621, 327-364`).
- **401 / 403** — auth errors. 403 with `OAuth token has been revoked` triggers re-login. Generic 401/403 → `auth_error` (`errors.ts:837-883`, `1109-1133`).
- **400** — many sub-flavors: prompt_too_long, invalid_model, tool_use mismatch, image_exceeds, credit balance, organization disabled, etc.
- **404** — model not available.
- **408 / 409** — retried (request timeout / lock timeout) (`withRetry.ts:760-763`).
- **413** — request too large (`errors.ts:659`).
- **500+** — `server_error`, retried (`withRetry.ts:784`).

`categorizeRetryableAPIError` (`errors.ts:1163-1182`) collapses these into the SDK-facing error tag set used in stream-json:

```ts
if (error.status === 529 || error.message?.includes('"type":"overloaded_error"')) return 'rate_limit'
if (error.status === 429) return 'rate_limit'
if (error.status === 401 || error.status === 403) return 'authentication_failed'
if (error.status !== undefined && error.status >= 408) return 'server_error'
return 'unknown'
```

The full SDK-facing error enum (`entrypoints/sdk/coreSchemas.ts:1256-1263`):

```ts
export const SDKAssistantMessageErrorSchema = lazySchema(() =>
  z.enum([
    'authentication_failed',
    'billing_error',
    'rate_limit',
    'invalid_request',
    'server_error',
    ...
  ])
)
```

## 2. Subscription quota vs API-key 429

The fork happens in `getAssistantMessageFromError` (`errors.ts:465-558`):

```ts
if (
  error instanceof APIError &&
  error.status === 429 &&
  shouldProcessRateLimits(isClaudeAISubscriber())
) {
  // Check if this is the new API with multiple rate limit headers
  const rateLimitType = error.headers?.get?.(
    'anthropic-ratelimit-unified-representative-claim',
  ) as 'five_hour' | 'seven_day' | 'seven_day_opus' | null
  const overageStatus = error.headers?.get?.(
    'anthropic-ratelimit-unified-overage-status',
  ) as 'allowed' | 'allowed_warning' | 'rejected' | null
  // If we have the new headers, use the new message generation
  if (rateLimitType || overageStatus) { ... }
  // No quota headers — this is NOT a quota limit. Surface what the API actually
  // said instead of a generic "Rate limit reached". Entitlement rejections
  // (e.g. 1M context without Extra Usage) and infra capacity 429s land here.
  ...
  return createAssistantAPIErrorMessage({
    content: `${API_ERROR_MESSAGE_PREFIX}: Request rejected (429) · ${detail || 'this may be a temporary capacity issue — check status.anthropic.com'}`,
    error: 'rate_limit',
  })
}
```

So:

- A **Claude.ai (Pro/Max) subscription quota rejection** is identified by a 429 whose response carries `anthropic-ratelimit-unified-representative-claim` and/or `anthropic-ratelimit-unified-overage-status`.
- A **plain API-key 429** (or a 429 missing those headers, e.g. infra capacity, entitlement rejection) becomes the generic `API Error: Request rejected (429) · …` text but is still tagged `error: 'rate_limit'`.
- `shouldProcessRateLimits(isClaudeAISubscriber())` (in `services/rateLimitMocking.ts`) gates the subscription-specific code path: API-key users skip the entire Pro/Max quota machinery.

`withRetry.shouldRetry` (`withRetry.ts:696-787`) further codifies the distinction:

```ts
// Retry on rate limits, but not for ClaudeAI Subscription users
// Enterprise users can retry because they typically use PAYG instead of rate limits
if (error.status === 429) {
  return !isClaudeAISubscriber() || isEnterpriseSubscriber()
}
```

→ For Pro/Max OAuth subscribers, a 429 is **not retried** by `withRetry` — it propagates straight to a user-visible error. For API-key users and Enterprise OAuth, a 429 is retried with exponential backoff up to `DEFAULT_MAX_RETRIES = 10` (`withRetry.ts:52`), honoring `Retry-After` (`withRetry.ts:519-548`).

Also:

```ts
// If the server explicitly says whether or not to retry, obey.
// For Max and Pro users, should-retry is true, but in several hours, so we shouldn't.
const shouldRetryHeader = error.headers?.get('x-should-retry')
if (shouldRetryHeader === 'true' && (!isClaudeAISubscriber() || isEnterpriseSubscriber())) {
  return true
}
```

## 3. The `anthropic-ratelimit-unified-*` header family

Defined and parsed in `services/claudeAiLimits.ts`. Headers consumed:

- `anthropic-ratelimit-unified-status` — `'allowed' | 'allowed_warning' | 'rejected'` (`claudeAiLimits.ts:380`).
- `anthropic-ratelimit-unified-reset` — Unix epoch seconds for window reset (`claudeAiLimits.ts:382`).
- `anthropic-ratelimit-unified-fallback` — `'available'` indicates Opus→Sonnet downgrade option (`claudeAiLimits.ts:385`).
- `anthropic-ratelimit-unified-representative-claim` — the rate-limit type that caused rejection: `'five_hour' | 'seven_day' | 'seven_day_opus' | 'seven_day_sonnet' | 'overage'` (`claudeAiLimits.ts:388, 29-35`).
- `anthropic-ratelimit-unified-overage-status` — same enum as unified-status, for extra-usage (overage) window.
- `anthropic-ratelimit-unified-overage-reset` — Unix epoch for overage window reset.
- `anthropic-ratelimit-unified-overage-disabled-reason` — one of the 13 `OverageDisabledReason` values (`claudeAiLimits.ts:107-120`) e.g. `out_of_credits`, `org_level_disabled`, `member_zero_credit_limit`.
- `anthropic-ratelimit-unified-5h-utilization`, `anthropic-ratelimit-unified-7d-utilization` — float 0..1.
- `anthropic-ratelimit-unified-5h-reset`, `anthropic-ratelimit-unified-7d-reset` — epoch seconds (`claudeAiLimits.ts:164-179`).
- `anthropic-ratelimit-unified-5h-surpassed-threshold`, `anthropic-ratelimit-unified-7d-surpassed-threshold` — numeric warning threshold crossed (`claudeAiLimits.ts:263-289`).
- `anthropic-ratelimit-unified-overage-utilization`, `anthropic-ratelimit-unified-overage-reset`, `anthropic-ratelimit-unified-overage-surpassed-threshold`.

These headers are read on **every** API response (success or 429), so `currentLimits` and `rawUtilization` are continuously updated. On a 429, `extractQuotaStatusFromError` (`claudeAiLimits.ts:487-515`) forces `status = 'rejected'` even if headers are absent.

The display-name mapping (`claudeAiLimits.ts:79-85`):

```ts
const RATE_LIMIT_DISPLAY_NAMES: Record<RateLimitType, string> = {
  five_hour: 'session limit',
  seven_day: 'weekly limit',
  seven_day_opus: 'Opus limit',
  seven_day_sonnet: 'Sonnet limit',
  overage: 'extra usage limit',
}
```

The user-visible message format ("You've hit your weekly limit · resets …") is built in `services/rateLimitMessages.ts:143-197`:

```ts
function getLimitReachedText(limits: ClaudeAILimits, model: string): string {
  const resetsAt = limits.resetsAt
  const resetTime = resetsAt ? formatResetTime(resetsAt, true) : undefined
  const resetMessage = resetTime ? ` · resets ${resetTime}` : ''
  ...
  if (limits.rateLimitType === 'seven_day') return formatLimitReachedText('weekly limit', resetMessage, model)
  if (limits.rateLimitType === 'five_hour') return formatLimitReachedText('session limit', resetMessage, model)
  return formatLimitReachedText('usage limit', resetMessage, model)
}
```

```ts
// rateLimitMessages.ts:333
return `You've hit your ${limit}${resetMessage}`
```

The error-message prefix set (`rateLimitMessages.ts:21-27`) — useful for orchestrator pattern matching against the text result:

```ts
export const RATE_LIMIT_ERROR_PREFIXES = [
  "You've hit your",
  "You've used",
  "You're now using extra usage",
  "You're close to",
  "You're out of extra usage",
] as const
```

## 4. `Retry-After` and reset-time propagation

`withRetry.ts:519-548`:

```ts
function getRetryAfter(error: unknown): string | null {
  return (
    (error as {...}).headers?.['retry-after'] ||
    (error as APIError).headers as Headers)?.get?.('retry-after')) ?? null
  )
}

export function getRetryDelay(attempt, retryAfterHeader, maxDelayMs = 32000): number {
  if (retryAfterHeader) {
    const seconds = parseInt(retryAfterHeader, 10)
    if (!isNaN(seconds)) return seconds * 1000
  }
  const baseDelay = Math.min(BASE_DELAY_MS * Math.pow(2, attempt - 1), maxDelayMs)
  const jitter = Math.random() * 0.25 * baseDelay
  return baseDelay + jitter
}
```

For window-based limits (5h/7d) the unified-reset header is used instead in persistent-retry mode (`withRetry.ts:814-822`):

```ts
function getRateLimitResetDelayMs(error: APIError): number | null {
  const resetHeader = error.headers?.get?.('anthropic-ratelimit-unified-reset')
  if (!resetHeader) return null
  const resetUnixSec = Number(resetHeader)
  if (!Number.isFinite(resetUnixSec)) return null
  const delayMs = resetUnixSec * 1000 - Date.now()
  if (delayMs <= 0) return null
  return Math.min(delayMs, PERSISTENT_RESET_CAP_MS) // 6h cap
}
```

`x-should-retry` header is checked but **deliberately ignored for Pro/Max subscribers** (comment in `withRetry.ts:736-742`):

```ts
// For Max and Pro users, should-retry is true, but in several hours, so we shouldn't.
if (shouldRetryHeader === 'true' && (!isClaudeAISubscriber() || isEnterpriseSubscriber())) return true
```

## 5. Internal retry/backoff policy

`withRetry.withRetry` (`withRetry.ts:170-517`) is the central retry loop. Constants:

- `DEFAULT_MAX_RETRIES = 10`
- `MAX_529_RETRIES = 3`
- `BASE_DELAY_MS = 500`, default `maxDelayMs = 32000` (32s)
- Exponential backoff with up to 25% jitter
- `Retry-After` header always honored verbatim if present
- Env override: `CLAUDE_CODE_MAX_RETRIES`
- Env opt-in for unattended sessions: `CLAUDE_CODE_UNATTENDED_RETRY=1` enables **persistent retry**:
  - 429/529 retry indefinitely (foreground sources)
  - `PERSISTENT_MAX_BACKOFF_MS = 5 min`
  - `PERSISTENT_RESET_CAP_MS = 6 hr` (waits until `anthropic-ratelimit-unified-reset` rather than polling)
  - Heartbeat every 30s: emits `system / api_retry` events on stdout so the host doesn't kill the session as idle

Decision matrix for whether a 429 retries at all (`shouldRetry`, `withRetry.ts:696-787`):

| Mode | Status | Retry? |
|------|--------|--------|
| Persistent (`CLAUDE_CODE_UNATTENDED_RETRY`) | 429/529 | Yes — capped at 6h reset |
| CCR (`CLAUDE_CODE_REMOTE`) | 401/403/429/529 | Yes |
| Pro/Max OAuth (non-Enterprise) | 429 | **No** |
| API key, Enterprise OAuth | 429 | Yes (up to 10×) |
| Any | 408/409 | Yes |
| Any | 5xx | Yes |
| Any | overloaded_error / 529 | Yes (3× by default, more in foreground) |

When retries are exhausted `withRetry` throws `CannotRetryError` (`withRetry.ts:144-158`) wrapping the original error; if a fallback model is configured it instead throws `FallbackTriggeredError` (`withRetry.ts:160-168`).

## 6. Stream-JSON output: what an orchestrator sees

In `claude -p --output-format stream-json --verbose` the SDK message stream is what stdout carries. Schemas live in `entrypoints/sdk/coreSchemas.ts`. Key events:

### 6.1 `rate_limit_event` — emitted whenever quota status changes

`coreSchemas.ts:1358-1367`:

```ts
export const SDKRateLimitEventSchema = lazySchema(() =>
  z.object({
    type: z.literal('rate_limit_event'),
    rate_limit_info: SDKRateLimitInfoSchema(),
    uuid: ...,
    session_id: z.string(),
  })
)
```

`SDKRateLimitInfoSchema` (`coreSchemas.ts` ~1300-1345, with `claudeAiLimits.ts` source):

```ts
{
  status: 'allowed' | 'allowed_warning' | 'rejected',
  resetsAt?: number,                  // unix seconds
  rateLimitType?: 'five_hour' | 'seven_day' | 'seven_day_opus' | 'seven_day_sonnet' | 'overage',
  utilization?: number,
  overageStatus?: 'allowed' | 'allowed_warning' | 'rejected',
  overageResetsAt?: number,
  overageDisabledReason?: 'overage_not_provisioned' | 'org_level_disabled' | 'org_level_disabled_until'
                        | 'out_of_credits' | 'seat_tier_level_disabled' | 'member_level_disabled'
                        | 'seat_tier_zero_credit_limit' | 'group_zero_credit_limit'
                        | 'member_zero_credit_limit' | 'org_service_level_disabled'
                        | 'org_service_zero_credit_limit' | 'no_limits_configured' | 'unknown',
  isUsingOverage?: boolean,
  surpassedThreshold?: number,
}
```

Emission site `cli/print.ts:1126-1140`:

```ts
const rateLimitListener = (limits: ClaudeAILimits) => {
  const rateLimitInfo = toSDKRateLimitInfo(limits)
  if (rateLimitInfo) {
    output.enqueue({
      type: 'rate_limit_event',
      rate_limit_info: rateLimitInfo,
      uuid: randomUUID(),
      session_id: getSessionId(),
    })
  }
}
statusListeners.add(rateLimitListener)
```

These are fired on **every status change** (header-driven `emitStatusChange`, `claudeAiLimits.ts:184-197`), including the warning→rejected transition that signals exhaustion.

### 6.2 `system / api_retry` — emitted on every retry attempt

`QueryEngine.ts:943-955`:

```ts
if (message.subtype === 'api_error') {
  yield {
    type: 'system',
    subtype: 'api_retry' as const,
    attempt: message.retryAttempt,
    max_retries: message.maxRetries,
    retry_delay_ms: message.retryInMs,
    error_status: message.error.status ?? null,   // <-- HTTP code (429, 529, etc.)
    error: categorizeRetryableAPIError(message.error),  // <-- 'rate_limit' | 'authentication_failed' | 'server_error' | 'unknown'
    session_id: getSessionId(),
    uuid: message.uuid,
  }
}
```

So even mid-turn, an orchestrator observing stream-json sees `{type:'system', subtype:'api_retry', error_status:429, error:'rate_limit', retry_delay_ms:…, attempt:N, max_retries:10}` for each backoff cycle.

### 6.3 `assistant` message with `error` field — terminal API error inside a turn

`coreSchemas.ts:1347-1356`:

```ts
SDKAssistantMessageSchema:
  type: 'assistant'
  message: APIAssistantMessage...
  error: SDKAssistantMessageError | undefined   // 'rate_limit' | 'authentication_failed' | ...
```

When `withRetry` gives up, the synthetic assistant message produced by `getAssistantMessageFromError` (`errors.ts:425+`) carries `error: 'rate_limit'` and its `content` is the user-visible "You've hit your weekly limit · resets …" or "API Error: Request rejected (429) · …" string.

### 6.4 `result` — the terminal message in print mode

Two flavors (`coreSchemas.ts:1407-1454`):

- **Success**: `{type:'result', subtype:'success', is_error: boolean, result: string, stop_reason, total_cost_usd, usage, ...}`. Note `is_error: true` is possible on subtype `success` when the turn ended on an assistant API-error message (`QueryEngine.ts:1132-1138`: `isApiError = Boolean(result.isApiErrorMessage)`).
- **Error**: `{type:'result', subtype: 'error_during_execution' | 'error_max_turns' | 'error_max_budget_usd' | 'error_max_structured_output_retries', is_error: true, errors: string[]}`.

When `CannotRetryError` propagates out of the main loop (e.g. Pro/Max 429), execution reaches `print.ts:2424-2452`:

```ts
} catch (error) {
  // Emit error result message before shutting down
  try {
    await structuredIO.write({
      type: 'result',
      subtype: 'error_during_execution',
      duration_ms: 0,
      ...
      errors: [errorMessage(error), ...getInMemoryErrors().map(_ => _.error)],
    })
  } catch {}
  gracefulShutdownSync(1)
  return
}
```

So `errors[0]` will contain the underlying APIError message (which for a quota hit includes the JSON body like `{"type":"error","error":{"type":"rate_limit_error","message":"..."}}`).

### 6.5 `result.is_error` and exit code

`print.ts:971-973` (the non-streaming text/json path):

```ts
gracefulShutdownSync(
  lastMessage?.type === 'result' && lastMessage?.is_error ? 1 : 0,
)
```

→ Exit code **0** for a `result/success` with `is_error: false`; **1** for any `result/error_*` or a `result/success` whose `is_error: true` (turn ended in API error message). Same convention applies in stream-json mode via the `gracefulShutdownSync(1)` in the catch block above.

Other exit-code-1 paths in print.ts startup (`print.ts:569, 575, 583, 608, 783, 791`) cover auth-init failures, JSON parsing failures, and unrecoverable boot errors.

## 7. The `subtype: 'success'` with `is_error: true` gotcha

A quota-rejected turn that produces a synthetic assistant error message is still wrapped in `result/success` (because the agent completed its turn — by emitting the error). Look at both:

```ts
// QueryEngine.ts:1132
isApiError = Boolean(result.isApiErrorMessage)
...
yield {
  type: 'result',
  subtype: 'success',
  is_error: isApiError,    // <-- TRUE for quota rejection
  ...
  result: textResult,      // <-- contains "You've hit your weekly limit · resets …"
}
```

So orchestrators should **not** rely on `subtype === 'error_during_execution'` alone to detect quota; they must also handle `subtype === 'success' && is_error === true` and look at the preceding `rate_limit_event` or the `assistant.error === 'rate_limit'` field.

## 8. Persistent / unattended mode behavior

`withRetry.ts:96-104`:

```ts
const PERSISTENT_MAX_BACKOFF_MS = 5 * 60 * 1000
const PERSISTENT_RESET_CAP_MS = 6 * 60 * 60 * 1000
const HEARTBEAT_INTERVAL_MS = 30_000

function isPersistentRetryEnabled(): boolean {
  return feature('UNATTENDED_RETRY')
    ? isEnvTruthy(process.env.CLAUDE_CODE_UNATTENDED_RETRY)
    : false
}
```

In persistent mode the orchestrator will see a stream of `system/api_retry` events with growing `retry_delay_ms` (up to 5 min / chunked at 30s heartbeats) and `error_status: 429` until the reset epoch; the CLI process **does not exit** while waiting. This is gated behind a build feature (`UNATTENDED_RETRY`) so it may not be present in all builds.

## 9. OAuth (claude.ai) vs API (api.anthropic.com)

`constants/oauth.ts:85-93`:

```ts
BASE_API_URL: 'https://api.anthropic.com',
CLAUDE_AI_AUTHORIZE_URL: 'https://claude.com/cai/oauth/authorize',
CLAUDE_AI_ORIGIN: 'https://claude.ai',
API_KEY_URL: 'https://api.anthropic.com/api/oauth/claude_cli/create_api_key',
ROLES_URL: 'https://api.anthropic.com/api/oauth/claude_cli/roles',
```

Inference traffic — including for OAuth-authenticated Pro/Max subscribers — goes to **`api.anthropic.com`**. The `claude.ai` host is only used for the OAuth authorize redirect. Therefore: all quota signaling (the `anthropic-ratelimit-unified-*` headers and 429s) originates from `api.anthropic.com`, regardless of subscription auth vs API-key auth. There is no separate `claude.ai/oauth`-side quota channel. The CLI distinguishes Pro/Max from API-key purely via `isClaudeAISubscriber()` (which inspects the locally stored OAuth tokens / account info).

## 10. Mock / test rate-limit machinery

`services/mockRateLimits.ts` and `services/rateLimitMocking.ts` provide the `/mock-limits` slash-command path for Ants — they inject synthetic `anthropic-ratelimit-unified-*` headers and synthetic 429s. `shouldProcessRateLimits` returns true for both real subscribers and active mocks. Mock errors are tagged via `isMockRateLimitError` and **never retried** (`withRetry.ts:698`):

```ts
if (isMockRateLimitError(error)) return false
```

So during normal operation an orchestrator can ignore this — it's developer-only.

## 11. Special error strings and constants worth pattern-matching

From `services/api/errors.ts`:

```ts
export const API_ERROR_MESSAGE_PREFIX = 'API Error'
export const CREDIT_BALANCE_TOO_LOW_ERROR_MESSAGE = 'Credit balance is too low'
export const REPEATED_529_ERROR_MESSAGE = 'Repeated 529 Overloaded errors'
export const CUSTOM_OFF_SWITCH_MESSAGE = 'Opus is experiencing high load, please use /model to switch to Sonnet'
export const API_TIMEOUT_ERROR_MESSAGE = 'Request timed out'
```

From `services/rateLimitMessages.ts`:

```ts
RATE_LIMIT_ERROR_PREFIXES = [
  "You've hit your",       // limit reached (hard)
  "You've used",           // early warning (% used)
  "You're now using extra usage",
  "You're close to",       // approaching limit
  "You're out of extra usage",
]
```

## 12. Orchestrator detection recipe (derived)

For a Pro/Max subscriber running `claude -p --output-format stream-json --verbose`, the highest-fidelity signal is:

1. Watch every line for `{"type":"rate_limit_event", "rate_limit_info":{...}}`. When `rate_limit_info.status === 'rejected'` (and either `overageStatus` absent or also `rejected`), this account is currently locked out. Use `rate_limit_info.resetsAt` (Unix seconds) for the back-off deadline; if `rateLimitType === 'seven_day'` (or `seven_day_opus` / `seven_day_sonnet`), this is the **weekly cap**; if `five_hour` it's the **5-hour cap**; if `overage` rejected and `overageDisabledReason === 'out_of_credits'`, the account is out of extra-usage credits.
2. Watch for `{"type":"system","subtype":"api_retry","error_status":429,"error":"rate_limit"}` — only emitted if the CLI is actually retrying (i.e. **not** Pro/Max default, but Enterprise / API-key / persistent mode). For Pro/Max the 429 short-circuits and you'll instead see steps 3-4 directly.
3. Watch for `{"type":"assistant", ..., "error":"rate_limit"}` with content starting `"You've hit your "` — synthetic error message inside the turn.
4. Terminal: `{"type":"result", "subtype":"success", "is_error":true, "result":"You've hit your weekly limit · resets …"}` OR `{"type":"result", "subtype":"error_during_execution", "is_error":true, "errors":[...]}` for harder failures.
5. Process exit code: **1** in all rejection cases.

Transient vs hard distinction:
- **Transient** (will auto-recover, do NOT mark account as quota-exhausted): `system/api_retry` with `error_status` in {408, 409, 529} or `error: 'server_overload'` / `error: 'rate_limit'` for *non-subscriber*. CLI retries internally — orchestrator only sees the `api_retry` events if `verbose` is on; the final `result` may still be `success/is_error:false`.
- **Hard quota** (back off this account until `resetsAt`): `rate_limit_event` with `status:'rejected'` AND `rateLimitType` in `{five_hour, seven_day, seven_day_opus, seven_day_sonnet}` AND (`overageStatus !== 'allowed'`).
- **Out of credits**: `rate_limit_event` with `overageStatus:'rejected'`, `overageDisabledReason:'out_of_credits'`.
- **Auth/token**: `assistant.error === 'authentication_failed'` or `result.errors[*]` containing `OAuth token has been revoked` / `Please run /login`.
- **Capacity** (not quota): plain 429 without the unified headers — content reads `API Error: Request rejected (429) · …` — retry after backoff; do not assume quota is exhausted.

Header-based detection (only useful if the orchestrator owns its own HTTP transport — Claude Code does not expose raw headers to stdout, but the `rate_limit_event.rate_limit_info` is the post-processed equivalent).

## 13. File-by-file reference index

- HTTP error classification: `/Users/johntokash/Downloads/src/services/api/errors.ts` (lines 425-934 build assistant error messages; 965-1161 `classifyAPIError`; 1163-1182 `categorizeRetryableAPIError`).
- Retry loop: `/Users/johntokash/Downloads/src/services/api/withRetry.ts` (52-104 constants, 170-517 main loop, 696-787 `shouldRetry`, 803-822 reset-time helpers).
- Subscription quota state: `/Users/johntokash/Downloads/src/services/claudeAiLimits.ts` (29-35 RateLimitType, 79-85 display names, 107-120 OverageDisabledReason, 164-179 header parsing, 376-436 `computeNewLimitsFromHeaders`, 487-515 `extractQuotaStatusFromError`).
- User-facing message text: `/Users/johntokash/Downloads/src/services/rateLimitMessages.ts` (21-27 prefixes, 143-197 limit-reached text, 333-344 formatter).
- Stream-json schemas: `/Users/johntokash/Downloads/src/entrypoints/sdk/coreSchemas.ts` (1256-1263 error enum, 1300-1345 rate-limit info, 1358-1367 rate-limit event, 1407-1454 result success/error, 1457-1494 system init).
- Mapper internal→SDK: `/Users/johntokash/Downloads/src/utils/messages/mappers.ts` (221-252 `toSDKRateLimitInfo`).
- Emission in non-interactive runner: `/Users/johntokash/Downloads/src/cli/print.ts` (1126-1140 rate-limit listener, 2424-2452 catch→`error_during_execution`, 971-973 exit-code mapping).
- Per-retry stream event: `/Users/johntokash/Downloads/src/QueryEngine.ts` (943-955 `system/api_retry`; 1082-1116 `error_during_execution`; 1132-1155 `result/success` with `is_error`).
- OAuth vs API URLs: `/Users/johntokash/Downloads/src/constants/oauth.ts` (85-93).
- `createSystemAPIErrorMessage` (internal): `/Users/johntokash/Downloads/src/utils/messages.ts:4585-4603`.
