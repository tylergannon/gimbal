# TLDR

Claude Code persists each session as an append-only NDJSON transcript at `~/.claude/projects/<cwd-with-nonalnum-replaced-by-dashes>/<sessionId>.jsonl`, with subagent sidechains under `<projectDir>/<sessionId>/subagents/agent-<agentId>.jsonl` and TodoV2 tasks (one file per task) at `~/.claude/tasks/<sessionId>/<taskId>.json` — there is no `~/.claude/todos/` in this build. An orchestrator can tail those files, register from 27 hook events (every payload carries `session_id`+`transcript_path`+`cwd`), consume the separate NDJSON `stream-json` stdout protocol when launching with `--print --output-format=stream-json --verbose`, and/or ingest OTel `claude_code.<event>` logs joined to JSONL rows via `prompt.id`. The on-disk JSONL and the wire SDK messages are related but not identical: the on-disk `Entry` union is richer (parent UUIDs, sidechain flags, internal metadata like `summary`/`task-summary`/`marble-origami-commit`), and at exit Claude re-appends title/tag/agent/PR metadata so the 64 KB tail-window resume picker can still find them.

---

## Executive Summary

- **Canonical store**: `~/.claude/projects/<sanitizePath(cwd)>/<sessionId>.jsonl` — append-only NDJSON, mode `0o600`, parent dir `0o700`. `sanitizePath` is `cwd.replace(/[^a-zA-Z0-9]/g,'-')`, truncated + hashed past 200 chars (`sessionStoragePortable.ts:311`).
- **Subagents**: each runs into its own `<projectDir>/<sessionId>/subagents/[<group>/]agent-<agentId>.jsonl` with a `.meta.json` sidecar (`agentType`, `worktreePath?`, `description?`). Remote agents have parallel `remote-agents/remote-agent-<taskId>.meta.json` sidecars.
- **Line format**: one `Entry` per line, discriminated by `type`. Conversation lines are `TranscriptMessage` (`type:'user'|'assistant'|'attachment'|'system'`) carrying `uuid`, `parentUuid`, `sessionId`, `cwd`, `userType`, `entrypoint`, `version`, `gitBranch?`, `isSidechain`, `timestamp`, `promptId?`, and the inner Anthropic API `message`. Tool calls/results are content blocks inside `message.content`, not separate lines.
- **Bookkeeping lines** alongside conversation: `summary`, `custom-title`, `ai-title`, `last-prompt`, `task-summary` (periodic agent self-report every min(5 steps, 2 min)), `tag`, `agent-name`/`-color`/`-setting`, `mode`, `worktree-state`, `pr-link`, `file-history-snapshot`, `attribution-snapshot`, `queue-operation`, `content-replacement`, `speculation-accept`, `marble-origami-commit`/`marble-origami-snapshot` (context-collapse). Ephemeral `*_progress` ticks are not persisted.
- **Append plumbing**: `appendEntryToFile` (`sessionStorage.ts:2572`) is the single writer (sync appendFile + mkdir-on-ENOENT). Writes funnel through a `Project` async queue (line 549). At exit, `reAppendSessionMetadata` re-writes title/tag/agent/PR/mode/worktree entries so they stay in the 64 KB tail window the resume picker scans.
- **Resume / continue**: CLI flags `-c/--continue`, `-r/--resume [id]`, `--fork-session`, `--from-pr`, `--resume-session-at`, `--no-session-persistence`, `--session-id`. Picker uses `fetchLogs` → stat `<projectDir>/*.jsonl` sorted by mtime, lite-enriched from head 16 KB + tail 64 KB. SDK side has portable `resolveSessionFilePath` with realpath/NFC, Bun-vs-Node hash prefix-scan fallback, and git-worktree fallback (`sessionStoragePortable.ts:403`).
- **Hooks (27 events)**: `PreToolUse`, `PostToolUse(Failure)`, `Notification`, `UserPromptSubmit`, `SessionStart`/`End`, `Stop`/`Failure`, `SubagentStart`/`Stop`, `PreCompact`/`PostCompact`, `PermissionRequest`/`Denied`, `Setup`, `TeammateIdle`, `TaskCreated`/`Completed`, `Elicitation`/`Result`, `ConfigChange`, `WorktreeCreate`/`Remove`, `InstructionsLoaded`, `CwdChanged`, `FileChanged`. Every payload starts with `{session_id, transcript_path, cwd, permission_mode?, agent_id?, agent_type?}` (`utils/hooks.ts:301`); subagent hooks also carry `agent_transcript_path`. Hooks are the primary out-of-process control + observe channel.
- **Stream-JSON wire (distinct from on-disk)**: under `--print --output-format=stream-json --verbose`, stdout is NDJSON of `SDKMessage`s — opening `SDKSystemMessage{subtype:'init', ...}`, body of `SDKUser`/`SDKAssistant`/`SDKRateLimitEvent`/streamlined variants, closing `SDKResultMessage{type:'result', ...}`. `streamJsonStdoutGuard` diverts non-JSON stdout writes to stderr tagged `[stdout-guard]`. Flags `--include-hook-events` and `--include-partial-messages` widen the stream.
- **Todos**: `TodoWriteTool` is **in-memory only** in this build (`AppState.todos[agentId|sessionId]`); there is no `~/.claude/todos/` directory. TodoV2 / Task tools persist one file per task at `~/.claude/tasks/<sanitizePathComponent(taskListId)>/<taskId>.json` (`utils/tasks.ts:221`), where `taskListId` defaults to the sessionId. Watchable with `fs.watch` (Claude's own UI does this in `hooks/useTaskListWatcher.ts:137-156`).
- **OpenTelemetry**: standard `OTEL_*` (plus `ANT_OTEL_*` aliases) for exporter selection (`console`/`otlp`/`prometheus`); events emit `claude_code.<eventName>` log records with `event.sequence`, `event.timestamp`, `prompt.id`. Prompt content redacted unless `OTEL_LOG_USER_PROMPTS=1`. `TranscriptMessage.promptId` joins OTel events back to specific JSONL rows.
- **For an orchestrator monitoring a live session, in priority**: (1) tail `<projectDir>/<sessionId>.jsonl`; (2) `fs.watch ~/.claude/tasks/<sessionId>/`; (3) consume stream-json stdout if you control launch; (4) register hooks for tool-use/turn boundaries; (5) ingest OTel logs/metrics for cross-session views. Plus the subagent JSONLs under `<projectDir>/<sessionId>/subagents/`.

---

## Detailed Summary

**Where state lives.** Claude Code persists each conversation as an append-only NDJSON file at `~/.claude/projects/<sanitizePath(cwd)>/<sessionId>.jsonl`. `sanitizePath` replaces every non-alphanumeric character in the absolute cwd with `-`, truncating to 200 chars + djb2/Bun hash suffix when longer (`utils/sessionStoragePortable.ts:311`, `utils/sessionStorage.ts:202`). Subagents get their own sidechain files under `<projectDir>/<sessionId>/subagents/[<group>/]agent-<agentId>.jsonl` plus a `.meta.json` sidecar recording `agentType`, `worktreePath?`, and `description?` (`utils/sessionStorage.ts:247-303`). Remote (CCR) agents have `remote-agents/remote-agent-<taskId>.meta.json` sidecars. File mode is `0o600`, parent dir `0o700`.

**Line schema.** Every line is one JSON object with a `type` discriminator. The Entry union is in `types/logs.ts:297-317`. Conversational lines are `TranscriptMessage`s: `{type:'user'|'assistant'|'attachment'|'system', uuid, parentUuid, isSidechain, cwd, userType, entrypoint?, sessionId, timestamp(ISO), version, gitBranch?, slug?, agentId?, promptId?, message:<Anthropic API message>}`. Tool calls and results are **content blocks inside** the `message.content` array (`type:'tool_use'`/`type:'tool_result'`), not their own line-level entries. Bookkeeping lines that share the file: `summary` (compaction stub keyed by `leafUuid`), `custom-title`, `ai-title`, `last-prompt`, `task-summary` (periodic agent self-report — `min(5 steps, 2min)`, see `types/logs.ts:88-97`), `tag`, `agent-name`, `agent-color`, `agent-setting`, `mode`, `worktree-state`, `pr-link`, `file-history-snapshot`, `attribution-snapshot`, `queue-operation`, `content-replacement`, `speculation-accept`, `marble-origami-commit`/`marble-origami-snapshot` (context-collapse), plus `System*` variants including `compact-boundary`/`microcompact-boundary`. Ephemeral `bash_progress`/`mcp_progress`/`sleep_progress` ticks are UI-only and **not persisted** (`sessionStorage.ts:186`).

**Live append behavior.** `appendEntryToFile` (`sessionStorage.ts:2572`) is the single writer; it does `appendFileSync(json + '\n')` and mkdirs the parent on ENOENT. The `Project` singleton (line 549) buffers entries until `materializeSessionFile` runs on the first persistable message (line 976), then dispatches each entry through an async write queue. The file grows monotonically; the only mutation is `removeMessageByUuid` (tombstone for orphaned streaming attempts, line 871-950), which positionally truncates the tail. At exit, `reAppendSessionMetadata` (line 722-839) re-writes `last-prompt`, `custom-title`, `tag`, `agent-name`, `agent-color`, `agent-setting`, `mode`, `worktree-state`, `pr-link` so they stay inside the 64 KB tail window that the resume picker scans. Persistence is suppressed under `NODE_ENV=test`, `cleanupPeriodDays=0`, `--no-session-persistence`, or `CLAUDE_CODE_SKIP_PROMPT_HISTORY=1` (line 960).

**Resume / continue.** `-c/--continue` resumes the most-recent session in cwd; `-r/--resume [id]` either resumes by UUID or opens a picker; `--fork-session` keeps history but mints a new sessionId; `--from-pr` resumes by PR number; `--resume-session-at <msg>` truncates resume to a given assistant message; `--no-session-persistence` disables writes (`main.tsx:976-991`). The picker is fed by `fetchLogs` (`sessionStorage.ts:2559`) which stats `<projectDir>/*.jsonl` and sorts by mtime, then enriches each via `readLiteMetadata` (head 16 KB + tail 64 KB only). The SDK has a portable parallel implementation (`utils/sessionStoragePortable.ts:403 resolveSessionFilePath`, `utils/listSessionsImpl.ts`) that handles realpath/NFC normalization, Bun-vs-Node hash mismatches for long paths (prefix scan), and git-worktree fallback so a session created in worktree A is findable from worktree B. `sessionIdExists` is just `stat(<projectDir>/<id>.jsonl)` (line 401).

**Hook surface.** 27 events in `entrypoints/sdk/coreTypes.ts:25-53`: `PreToolUse`, `PostToolUse`, `PostToolUseFailure`, `Notification`, `UserPromptSubmit`, `SessionStart`, `SessionEnd`, `Stop`, `StopFailure`, `SubagentStart`, `SubagentStop`, `PreCompact`, `PostCompact`, `PermissionRequest`, `PermissionDenied`, `Setup`, `TeammateIdle`, `TaskCreated`, `TaskCompleted`, `Elicitation`, `ElicitationResult`, `ConfigChange`, `WorktreeCreate`, `WorktreeRemove`, `InstructionsLoaded`, `CwdChanged`, `FileChanged`. Every hook receives a JSON payload starting with `{session_id, transcript_path, cwd, permission_mode?, agent_id?, agent_type?}` (`utils/hooks.ts:301-328`). Subagent hooks additionally include `agent_transcript_path` (line 3676). Hooks can be CLI commands or in-process callbacks; the return shape (`syncHookResponseSchema`, `types/hooks.ts:50-166`) supports `permissionDecision`, `updatedInput`, `additionalContext`, `initialUserMessage`, `watchPaths`, `updatedMCPToolOutput`, and event-specific decision objects.

**Stream-JSON wire format (distinct from on-disk JSONL).** `--print --output-format=stream-json --verbose` emits NDJSON to stdout using SDK shapes from `entrypoints/sdk/coreSchemas.ts:1240-1480`: an opening `SDKSystemMessage{subtype:'init', session_id, cwd, tools[], mcp_servers[], model, permissionMode, slash_commands[], output_style, skills[], plugins[], claude_code_version}`, then a stream of `SDKUserMessage`/`SDKAssistantMessage`/`SDKRateLimitEvent`/streamlined variants, terminated by `SDKResultMessage{type:'result', subtype, duration_ms, duration_api_ms, num_turns, total_cost_usd, usage, modelUsage, permission_denials[], session_id, uuid}`. `utils/streamJsonStdoutGuard.ts` intercepts `process.stdout.write` and diverts any non-JSON line to stderr tagged `[stdout-guard]` to keep the NDJSON contract intact. Flags `--include-hook-events`, `--include-partial-messages`, `--input-format stream-json`, `--replay-user-messages` extend the stream. The wire SDK messages are NOT byte-identical to the on-disk `Entry` shapes — they overlap on user/assistant content but the JSONL is richer (`parentUuid`, `isSidechain`, internal metadata kinds).

**Todos vs. tasks.** `TodoWriteTool` writes **only to in-memory `AppState.todos[agentId|sessionId]`** (`tools/TodoWriteTool/TodoWriteTool.ts:88-94`, `state/AppStateStore.ts:220`) — there is **no `~/.claude/todos/` directory in this build**. The newer TodoV2 family (`TaskGetTool`, `TaskCreateTool`, `TaskUpdateTool`, `TaskListTool`) persists one JSON file per task at `~/.claude/tasks/<sanitizePathComponent(taskListId)>/<taskId>.json` (`utils/tasks.ts:221-231`). `taskListId` defaults to `CLAUDE_CODE_TASK_LIST_ID` → team name → leader team name → **sessionId** (`utils/tasks.ts:199-210`), so single-process sessions get `~/.claude/tasks/<sessionId>/`. The in-process UI watches that directory with `fs.watch` (`hooks/useTaskListWatcher.ts:137-156`); an external watcher should do the same.

**OpenTelemetry signals.** Full OTel wiring at `utils/telemetry/instrumentation.ts` (825 lines). Honored env vars include all standard `OTEL_*` plus `ANT_OTEL_*` aliases. Exporter types: `console`, `otlp` (http/grpc), `prometheus`. `utils/telemetry/events.ts:21-75` emits `claude_code.<eventName>` log records with global attributes, monotonic `event.sequence`, ISO `event.timestamp`, and `prompt.id`. Prompt content is `<REDACTED>` unless `OTEL_LOG_USER_PROMPTS=1`. `TranscriptMessage.promptId` joins the OTel events back to specific assistant rows in the JSONL. Auxiliary tracing surfaces: `betaSessionTracing.ts`, `sessionTracing.ts`, `perfettoTracing.ts`, `bigqueryExporter.ts`. Internal analytics fire `tengu_session_*` events (`tengu_session_renamed`, `tengu_session_tagged`, `tengu_session_linked_to_pr`, `tengu_session_persistence_failed`, `tengu_session_forked_branches_fetched`).

**What an external orchestrator should tail.** (1) The transcript JSONL itself — most informative, byte-stream of every turn. (2) `~/.claude/tasks/<sessionId>/*.json` via `fs.watch` for live todo state. (3) Stream-JSON stdout if you launched with `--print --output-format=stream-json --verbose --include-hook-events`. (4) Hooks registered via settings.json — the primary out-of-process control + observe channel (hook input always contains `session_id` + `transcript_path` + `cwd` so the orchestrator can correlate). (5) OTel logs/metrics/traces for cross-session aggregate views, with `prompt.id` joining back to specific JSONL rows. Subagents: additionally tail `<projectDir>/<sessionId>/subagents/**/agent-*.jsonl`. Tail-window caveats: `readLiteMetadata` only inspects the first 16 KB and last 64 KB; metadata is re-appended at exit to stay inside that window.

---

# Extensive Findings: Claude Code Session / Conversation Storage

All paths below are relative to `/Users/johntokash/Downloads/src/` unless otherwise noted. Line numbers reference that source tree.

## 1. On-disk layout

Claude Code persists per-session conversation state under the user's Claude config home directory (default `~/.claude/`). The relevant subtrees:

```
~/.claude/
├── projects/<sanitized-cwd>/
│   ├── <sessionId>.jsonl                              # main transcript (append-only NDJSON)
│   ├── <sessionId>/
│   │   ├── subagents/[<subdir>/]agent-<agentId>.jsonl # subagent sidechain transcripts
│   │   ├── subagents/.../agent-<agentId>.meta.json    # subagent type / worktree / description
│   │   └── remote-agents/remote-agent-<taskId>.meta.json
│   └── bridge-pointer.json                            # bridge transport (CCR) pointer
├── tasks/<sanitized-taskListId>/<taskId>.json         # TodoV2 / Task tools per-task records
└── (no `todos/` directory in this build — see Section 6)
```

### 1.1 Project directory derivation (`sanitizePath`)

`utils/sessionStoragePortable.ts:311`:

```ts
export function sanitizePath(name: string): string {
  const sanitized = name.replace(/[^a-zA-Z0-9]/g, '-')
  if (sanitized.length <= MAX_SANITIZED_LENGTH) {       // 200
    return sanitized
  }
  const hash =
    typeof Bun !== 'undefined' ? Bun.hash(name).toString(36) : simpleHash(name)
  return `${sanitized.slice(0, MAX_SANITIZED_LENGTH)}-${hash}`
}
```

Every non-alphanumeric character in the absolute cwd is replaced with `-`. So `/Users/jt/dev/Tenacious` becomes the directory name `-Users-jt-dev-Tenacious`. For long paths (>200 chars), it is truncated and a djb2 / Bun.hash suffix is appended.

`getProjectsDir()` is `join(getClaudeConfigHomeDir(), 'projects')` (`sessionStoragePortable.ts:325`, mirrored at `utils/sessionStorage.ts:198`).

`getProjectDir(cwd)` is `join(getProjectsDir(), sanitizePath(cwd))` (`sessionStorage.ts:436`, memoized — note in code at line 431: "called 12+ times per turn via hooks.ts createBaseHookInput").

### 1.2 Transcript path for the running session

`utils/sessionStorage.ts:202`:

```ts
export function getTranscriptPath(): string {
  const projectDir = getSessionProjectDir() ?? getProjectDir(getOriginalCwd())
  return join(projectDir, `${getSessionId()}.jsonl`)
}

export function getTranscriptPathForSession(sessionId: string): string {
  if (sessionId === getSessionId()) {
    return getTranscriptPath()
  }
  const projectDir = getProjectDir(getOriginalCwd())
  return join(projectDir, `${sessionId}.jsonl`)
}
```

`getSessionProjectDir()` is consulted first so that worktree-switched sessions (set by `switchActiveSession`) still resolve to the directory the file was originally written to (the in-line comment cites gh-30217 and CC-34 — sessionId + projectDir are atomic).

### 1.3 Subagent sidechain transcripts

`utils/sessionStorage.ts:247`:

```ts
export function getAgentTranscriptPath(agentId: AgentId): string {
  const projectDir = getSessionProjectDir() ?? getProjectDir(getOriginalCwd())
  const sessionId = getSessionId()
  const subdir = agentTranscriptSubdirs.get(agentId)
  const base = subdir
    ? join(projectDir, sessionId, 'subagents', subdir)
    : join(projectDir, sessionId, 'subagents')
  return join(base, `agent-${agentId}.jsonl`)
}
```

Each subagent gets its own `agent-<agentId>.jsonl` plus an `agent-<agentId>.meta.json` sidecar (`writeAgentMetadata`, `sessionStorage.ts:283`). The sidecar persists `agentType`, optional `worktreePath`, and the original `description` so the subagent can be resumed. Remote (CCR) agents have a parallel `remote-agents/remote-agent-<taskId>.meta.json` sidecar (`sessionStorage.ts:337`).

## 2. JSONL transcript file format

The file is **append-only NDJSON** (one JSON object per line, terminated by `\n`). The writer is `appendEntryToFile` at `utils/sessionStorage.ts:2572`:

```ts
function appendEntryToFile(fullPath: string, entry: Record<string, unknown>): void {
  const fs = getFsImplementation()
  const line = jsonStringify(entry) + '\n'
  try {
    fs.appendFileSync(fullPath, line, { mode: 0o600 })
  } catch {
    fs.mkdirSync(dirname(fullPath), { mode: 0o700 })
    fs.appendFileSync(fullPath, line, { mode: 0o600 })
  }
}
```

Entries are POSIX-mode `0o600`, parent dir `0o700`. Writes are queued and drained by the `Project` class (`sessionStorage.ts:549`); see Section 4.

Transcripts can grow to multiple GB (comment at `sessionStorage.ts:227-229`: "session JSONL can grow to multiple GB (inc-3930). Callers ... must bail out above this threshold to avoid OOM"). `MAX_TRANSCRIPT_READ_BYTES = 50 * 1024 * 1024`.

### 2.1 Entry types (the discriminator field is `type`)

All persisted entry types are defined in `types/logs.ts` as the union `Entry` (lines 297–317):

```ts
export type Entry =
  | TranscriptMessage         // conversational messages (user/assistant/attachment/system/etc.)
  | SummaryMessage            // {type:'summary', leafUuid, summary}
  | CustomTitleMessage        // {type:'custom-title', sessionId, customTitle}
  | AiTitleMessage            // {type:'ai-title', sessionId, aiTitle}
  | LastPromptMessage         // {type:'last-prompt', sessionId, lastPrompt}
  | TaskSummaryMessage        // {type:'task-summary', sessionId, summary, timestamp}
  | TagMessage                // {type:'tag', sessionId, tag}
  | AgentNameMessage          // {type:'agent-name', sessionId, agentName}
  | AgentColorMessage         // {type:'agent-color', sessionId, agentColor}
  | AgentSettingMessage       // {type:'agent-setting', sessionId, agentSetting}
  | PRLinkMessage             // {type:'pr-link', sessionId, prNumber, prUrl, prRepository, timestamp}
  | FileHistorySnapshotMessage// {type:'file-history-snapshot', messageId, snapshot, isSnapshotUpdate}
  | AttributionSnapshotMessage// {type:'attribution-snapshot', messageId, surface, fileStates, ...}
  | QueueOperationMessage     // {type:'queue-operation', ...}
  | SpeculationAcceptMessage  // {type:'speculation-accept', timestamp, timeSavedMs}
  | ModeEntry                 // {type:'mode', sessionId, mode:'coordinator'|'normal'}
  | WorktreeStateEntry        // {type:'worktree-state', sessionId, worktreeSession|null}
  | ContentReplacementEntry   // {type:'content-replacement', sessionId, agentId?, replacements}
  | ContextCollapseCommitEntry// {type:'marble-origami-commit', ...}
  | ContextCollapseSnapshotEntry// {type:'marble-origami-snapshot', ...}
```

Plus the catch-all `TranscriptMessage` (the actual conversation), defined at `types/logs.ts:221`:

```ts
export type TranscriptMessage = SerializedMessage & {
  parentUuid: UUID | null
  logicalParentUuid?: UUID | null
  isSidechain: boolean
  gitBranch?: string
  agentId?: string
  teamName?: string
  agentName?: string
  agentColor?: string
  promptId?: string      // correlates with OTel prompt.id
}
```

`SerializedMessage = Message & {cwd, userType, entrypoint?, sessionId, timestamp, version, gitBranch?, slug?}` (`types/logs.ts:8`).

`Message` itself is a discriminated union (defined in `src/types/message.ts` — referenced via `import type { Message } from 'src/types/message.js'` at `types/logs.ts:5`; not present in this extracted source dump but referenced everywhere). Variants imported in `utils/messages.ts:42-72`:

- `UserMessage` — `type:'user'`, content is Anthropic-API content blocks; tool results from the assistant come back as `user` messages whose content is `tool_result` blocks.
- `AssistantMessage` — `type:'assistant'`, content is API content blocks: `text`, `thinking`, `redacted_thinking`, `tool_use`. Carries `message.id`, `apiError?`, etc.
- `AttachmentMessage` — system-injected attachments (memory headers, hook attachments, etc.).
- `ProgressMessage<P>` — high-frequency in-flight ticks (NOT persisted, see `EPHEMERAL_PROGRESS_TYPES`, `sessionStorage.ts:186`).
- `SystemMessage` and its variants: `SystemAPIErrorMessage`, `SystemApiMetricsMessage`, `SystemCompactBoundaryMessage`, `SystemMicrocompactBoundaryMessage`, `SystemInformationalMessage`, `SystemPermissionRetryMessage`, `SystemBridgeStatusMessage`, `SystemLocalCommandMessage`, `SystemAgentsKilledMessage`, `SystemAwaySummaryMessage`, `SystemMemorySavedMessage`, `SystemScheduledTaskFireMessage`, `SystemStopHookSummaryMessage`, `SystemTurnDurationMessage`, `TombstoneMessage`, `ToolUseSummaryMessage`.

`tool_use` and `tool_result` are **content blocks inside** assistant/user messages — not their own line-level entry types. So when you tail the JSONL, look at `entry.message.content[*].type` to find tool calls and their results. An external watcher will see something like:

```
{"type":"user","cwd":"/Users/jt/dev/foo","userType":"external","sessionId":"<uuid>","timestamp":"2026-05-11T...","version":"1.x.x","gitBranch":"main","parentUuid":null,"isSidechain":false,"uuid":"<uuid>","message":{"role":"user","content":[{"type":"text","text":"hello"}]}}
{"type":"assistant","cwd":"...","sessionId":"...","parentUuid":"<prev>","isSidechain":false,"uuid":"<uuid>","message":{"id":"msg_...","role":"assistant","content":[{"type":"thinking","thinking":"..."},{"type":"tool_use","id":"toolu_...","name":"Read","input":{...}}],"model":"...","usage":{...}}}
{"type":"user","sessionId":"...","parentUuid":"<assistant uuid>","uuid":"<uuid>","message":{"role":"user","content":[{"type":"tool_result","tool_use_id":"toolu_...","content":"..."}]}}
```

### 2.2 Message chain

Each `TranscriptMessage` carries `uuid` and `parentUuid`. Building the conversation chain walks `parentUuid` backwards from the most recent leaf (`sessionStorage.ts:3227-3270` describes a byte-level pre-filter that excises dead fork branches before `parseJSONL` because forks leave many orphan branches).

`isSidechain: boolean` distinguishes subagent transcripts written into the main file from main-thread ones. `agentId` is set on sidechain rows.

`SummaryMessage` (`type:'summary'`) is inserted by the compaction flow; its `leafUuid` points to the last archived message it stands in for. Multiple summaries can accumulate over a long session.

### 2.3 Compact / context-collapse boundaries

The transcript also stores compaction markers as `SystemCompactBoundaryMessage` and `SystemMicrocompactBoundaryMessage` entries (system message variants). `marble-origami-commit` / `marble-origami-snapshot` are persisted context-collapse instructions — they record splice boundaries (`firstArchivedUuid`, `lastArchivedUuid`) and a summary placeholder; the archived messages themselves remain in the JSONL as ordinary user/assistant entries (see `types/logs.ts:239-294`).

### 2.4 Metadata entries that get re-appended at exit

`reAppendSessionMetadata` (`sessionStorage.ts:722-839`) reads the tail of the file at shutdown and re-writes selected metadata entries (`last-prompt`, `custom-title`, `tag`, `agent-name`, `agent-color`, `agent-setting`, `mode`, `worktree-state`, `pr-link`) so they stay inside the 64 KB tail window that `readLiteMetadata` scans on `--resume`. This is why an external watcher will see duplicates of these fields at EOF.

### 2.5 Append plumbing

The `Project` singleton (`sessionStorage.ts:549`) buffers entries until `materializeSessionFile` runs (lazily on the first persistable user/assistant message; `sessionStorage.ts:976`). Once `sessionFile` is set, `appendEntry` dispatches by entry type and most append paths go through `enqueueWrite`, which serializes writes via an async queue. The Project class also handles tombstone removal (`removeMessageByUuid`, `sessionStorage.ts:871`).

Persistence is skipped if (`sessionStorage.ts:960`):
- `NODE_ENV=test` and `TEST_ENABLE_SESSION_PERSISTENCE` unset
- `settings.cleanupPeriodDays === 0`
- `--no-session-persistence` (`isSessionPersistenceDisabled()`)
- `CLAUDE_CODE_SKIP_PROMPT_HISTORY=1` (set by tmuxSocket.ts for Tungsten test sessions)

## 3. `--resume` / `--continue` resolution

CLI flags (`main.tsx:976-991`, summarized):

- `-c, --continue` — "Continue the most recent conversation in the current directory"
- `-r, --resume [value]` — "Resume a conversation by session ID, or open interactive picker with optional search term"
- `--fork-session` — when resuming, mint a new session ID instead of reusing the original
- `--resume-session-at <message id>` — only resume up to a given assistant message
- `--from-pr [value]` — resume a session linked to a PR
- `--session-id <uuid>` — only valid in combination with `--continue`/`--resume` if `--fork-session` is also given (`main.tsx:1281`)
- `--no-session-persistence` — disables writing, hence resuming

The picker / list is fed by `fetchLogs(limit?)` (`sessionStorage.ts:2559`):

```ts
export async function fetchLogs(limit?: number): Promise<LogOption[]> {
  const projectDir = getProjectDir(getOriginalCwd())
  const logs = await getSessionFilesLite(projectDir, limit, getOriginalCwd())
  await trackSessionBranchingAnalytics(logs)
  return logs
}
```

`getSessionFilesLite` (`sessionStorage.ts:4975`) just stats `<projectDir>/*.jsonl` and sorts by `mtime` descending. Lite logs are enriched on demand by `enrichLog` (`sessionStorage.ts:5023`) which reads only the first ~16 KB and last ~64 KB of each file (`readLiteMetadata`, called from line 5029) — never the full file — to extract `firstPrompt`, `customTitle`, `summary`, `tag`, `gitBranch`, `agentSetting`, `prNumber`, `prUrl`, `prRepository`, `isSidechain`, `teamName`, `projectPath`. Sidechain and team-spawned sessions are filtered out of the picker (`sessionStorage.ts:5056-5067`).

For SDK / external callers there is a parallel **portable** implementation (`utils/listSessionsImpl.ts`, `utils/sessionStoragePortable.ts:403 resolveSessionFilePath`) that:

- canonicalizes the directory (`realpath` + NFC) to handle symlinks like `/tmp` → `/private/tmp`,
- looks up `<projectsDir>/<sanitizePath(canonical)>/<sessionId>.jsonl`,
- falls back to **prefix-based scanning** when the sanitized path was hash-truncated (CLI uses `Bun.hash`, SDK uses `simpleHash` → different suffixes), and
- falls back further to sibling **git worktrees** of the given directory via `getWorktreePathsPortable` so a session created in worktree `A` can still be resolved from worktree `B`.

`sessionIdExists(sessionId)` (`sessionStorage.ts:401`) is the fast existence check — `stat(<projectDir>/<sessionId>.jsonl)`.

## 4. Live append semantics — what an external watcher will see

The single file `<projectDir>/<sessionId>.jsonl` is the canonical live ledger. While a session runs:

1. The first user message lazily creates the file (mode 0o600), parent dir `0o700` (`appendEntryToFile`).
2. Buffered startup entries (e.g. `agent-name`, `agent-color`, `agent-setting`, `mode`, the first user prompt, etc.) are flushed in order.
3. Each turn appends: a `user` `TranscriptMessage`, then one or more `assistant` `TranscriptMessage`s (each is a full API message containing `text`/`thinking`/`tool_use` content blocks), then `user` rows with `tool_result` content blocks, then more assistants, etc. Each row has `uuid`, `parentUuid`, `timestamp` (ISO-8601), `sessionId`, `cwd`, `version`, `gitBranch?`, `userType` ("external"/"ant"/etc.), `entrypoint` (from `CLAUDE_CODE_ENTRYPOINT`).
4. Periodic markers between turns: `task-summary` (every min(5 steps, 2 min) — written by forking the main thread mid-turn; comment at `types/logs.ts:88-97` — so `claude ps` can show something useful), `file-history-snapshot`, `attribution-snapshot`, `last-prompt` (overwritten each turn), `queue-operation`, `content-replacement`, `speculation-accept`.
5. Compaction events insert a `summary` entry plus `SystemCompactBoundaryMessage` / `marble-origami-commit` rows.
6. At exit cleanup the project flushes all queued writes and re-appends the metadata block (Section 2.4).

`isEphemeralToolProgress(dataType)` (`sessionStorage.ts:194`) — the `bash_progress`, `powershell_progress`, `mcp_progress`, and `sleep_progress` entry types are UI-only ticks; they're **not persisted** in current builds and `loadTranscriptFile` skips them if encountered in legacy transcripts.

Removals are rare but exist: `removeMessageByUuid` (tombstone for orphaned streaming attempts) does a positional truncate-then-rewrite of the tail (lines 871-950). It will only rewrite files smaller than `MAX_TOMBSTONE_REWRITE_BYTES`.

A tailer reading `<sessionId>.jsonl` will see strictly monotonic appends except for the rare tombstone rewrite of the last line(s).

## 5. Stream-JSON output format (the wire protocol, distinct from the on-disk JSONL)

When invoked with `--print --output-format=stream-json --verbose`, Claude Code emits **NDJSON to stdout** using the SDK message shapes (not the on-disk `Entry` types). Schemas live in `entrypoints/sdk/coreSchemas.ts`:

- `SDKSystemMessage` (`coreSchemas.ts:1457`) — `{type:'system', subtype:'init', agents?, apiKeySource, betas?, claude_code_version, cwd, tools[], mcp_servers[{name,status}], model, permissionMode, slash_commands[], output_style, skills[], plugins[...]}`
- `SDKUserMessage` (`coreSchemas.ts:1290`) — `{type:'user', message:<APIUserMessage>, parent_tool_use_id, isSynthetic?, tool_use_result?, priority?, timestamp?, uuid?, session_id?}`
- `SDKUserMessageReplay` (`coreSchemas.ts:1297`) — same plus `isReplay:true`, used when `--replay-user-messages`
- `SDKAssistantMessage` (`coreSchemas.ts:1347`) — `{type:'assistant', message:<APIAssistantMessage>, parent_tool_use_id, error?, uuid, session_id}`
- `SDKRateLimitEvent` (`coreSchemas.ts:1360`) — `{type:'rate_limit_event', rate_limit_info, uuid, session_id}`
- `SDKStreamlinedTextMessage` / `SDKStreamlinedToolUseSummaryMessage` — `--streamlined-output` variants
- `SDKResultMessage` (`coreSchemas.ts:1453`) — union of success / error result envelope: `{type:'result', subtype:'success'|'error_during_execution'|'error_max_turns'|'error_max_budget_usd'|'error_max_structured_output_retries', duration_ms, duration_api_ms, is_error, num_turns, result?, stop_reason, total_cost_usd, usage, modelUsage, permission_denials[], structured_output?, fast_mode_state?, errors?, uuid, session_id}`

Validation prologue in `cli/print.ts`:

- Line 787-789: "Error: When using --print, --output-format=stream-json requires --verbose"
- Line 594, 628, 884, 923, 926, 928-953 — the stream-json branch emits each `SDKMessage` followed by `\n`; otherwise text/json mode emits only the last message.

To protect the NDJSON contract, `utils/streamJsonStdoutGuard.ts` installs a `process.stdout.write` interceptor that buffers per-line, JSON-parses every line, and diverts anything that doesn't parse to stderr tagged `[stdout-guard]`:

```ts
// utils/streamJsonStdoutGuard.ts:49-91
process.stdout.write = function (chunk, encodingOrCb, cb) {
  ...
  if (isJsonLine(line)) {
    wrote = originalWrite!(line + '\n')
  } else {
    process.stderr.write(`${STDOUT_GUARD_MARKER} ${line}\n`)
    ...
  }
}
```

Extra CLI flags affecting the wire stream:
- `--include-hook-events` — emit all hook lifecycle events into the stream-json stdout
- `--include-partial-messages` — emit partial message chunks as they arrive
- `--input-format stream-json` — accept NDJSON `SDKUserMessage` on stdin
- `--replay-user-messages` — re-emit consumed user messages as `SDKUserMessageReplay`

The streaming `SDKMessage`s are **not** byte-identical to the on-disk JSONL `Entry`s — on-disk entries are richer (they carry `parentUuid`, `isSidechain`, `cwd`, `gitBranch`, `version`, internal metadata kinds like `agent-color`, `marble-origami-snapshot`, etc.). The two streams overlap on `user`/`assistant` content but should not be confused.

## 6. TodoWrite / TaskV2 storage

The classic `TodoWriteTool` (`tools/TodoWriteTool/TodoWriteTool.ts`) writes **only to in-memory app state** keyed by `todoKey = context.agentId ?? sessionId`:

```ts
// TodoWriteTool.ts:88-94
context.setAppState(prev => ({
  ...prev,
  todos: {
    ...prev.todos,
    [todoKey]: newTodos,
  },
}))
```

That state lives in `state/AppStateStore.ts:220` (`todos: { [agentId: string]: TodoList }`, initial `{}` at line 530). There is **no `~/.claude/todos/` directory written by this codebase**. The todo list is reconstructable from the JSONL by replaying `TodoWrite` tool_use blocks; on resume the AppState is rebuilt via `sessionRestore.ts` (which special-cases `if (!isTodoV2Enabled() && result.messages && result.messages.length > 0)` at `sessionRestore.ts:140`).

The newer **TodoV2 / Task family** (`TaskGetTool`, `TaskCreateTool`, `TaskUpdateTool`, `TaskListTool`) persists each task as a separate file:

```ts
// utils/tasks.ts:221
export function getTasksDir(taskListId: string): string {
  return join(getClaudeConfigHomeDir(), 'tasks', sanitizePathComponent(taskListId))
}
export function getTaskPath(taskListId: string, taskId: string): string {
  return join(getTasksDir(taskListId), `${sanitizePathComponent(taskId)}.json`)
}
```

`taskListId` (`utils/tasks.ts:199`) is resolved with priority: `CLAUDE_CODE_TASK_LIST_ID` env > in-process teammate's leader team name > `CLAUDE_CODE_TEAM_NAME` > leader team name > **sessionId**. So for a stand-alone session, tasks live at `~/.claude/tasks/<sessionId>/<taskId>.json`.

`hooks/useTaskListWatcher.ts:137-156` shows that the in-process UI watches this directory directly with `fs.watch`:

```ts
const tasksDir = getTasksDir(taskListId)
...
watcher = watch(tasksDir, debouncedCheck)
```

An external watcher can do the same — tail the directory with inotify/FSEvents and reload changed JSON files.

`isTodoV2Enabled()` (`utils/tasks.ts:133`) returns `true` whenever the session is non-interactive (i.e. SDK / `--print`) or when `CLAUDE_CODE_ENABLE_TASKS` is set.

> Note: the user's question mentioned `~/.claude/todos/`. That path does **not** appear in this build. The closest equivalents are the in-memory `appState.todos[agentId]` map (visible only via the TodoWrite tool_use blocks in the JSONL) and the file-backed `~/.claude/tasks/<taskListId>/<taskId>.json` directory used by TodoV2.

## 7. Hook events — what an orchestrator can hook into

`HOOK_EVENTS` (`entrypoints/sdk/coreTypes.ts:25`):

```ts
export const HOOK_EVENTS = [
  'PreToolUse', 'PostToolUse', 'PostToolUseFailure',
  'Notification',
  'UserPromptSubmit',
  'SessionStart', 'SessionEnd',
  'Stop', 'StopFailure',
  'SubagentStart', 'SubagentStop',
  'PreCompact', 'PostCompact',
  'PermissionRequest', 'PermissionDenied',
  'Setup',
  'TeammateIdle',
  'TaskCreated', 'TaskCompleted',
  'Elicitation', 'ElicitationResult',
  'ConfigChange',
  'WorktreeCreate', 'WorktreeRemove',
  'InstructionsLoaded',
  'CwdChanged', 'FileChanged',
] as const
```

Every hook invocation receives a base input from `createBaseHookInput` (`utils/hooks.ts:301-328`):

```ts
{
  session_id: string,
  transcript_path: string,        // <projectDir>/<sessionId>.jsonl
  cwd: string,
  permission_mode?: string,
  agent_id?: string,
  agent_type?: string,
}
```

Hooks are executed by `executeSessionEndHooks` / per-event runners (`utils/hooks.ts`) and can be CLI commands or in-process callbacks (`types/hooks.ts:202-226`). They return a `HookJSONOutput` whose `hookSpecificOutput` discriminates on `hookEventName` (`types/hooks.ts:70-163`): `PreToolUse` can return `permissionDecision`, `updatedInput`, `additionalContext`; `UserPromptSubmit` returns `additionalContext`; `SessionStart` returns `additionalContext`, `initialUserMessage`, `watchPaths`; `PostToolUse` returns `additionalContext`, `updatedMCPToolOutput`; `PermissionRequest` returns a decision object; etc.

Subagent hooks additionally carry `agent_transcript_path` (`utils/hooks.ts:3676`), pointing at the subagent's sidechain `agent-<agentId>.jsonl`.

`SessionEnd` hooks are budgeted (`gracefulShutdown.ts:406-479`) and run in `executeSessionEndHooks`. Plugin hooks pre-load before `processSessionStartHooks` (`setup.ts:326`).

## 8. OpenTelemetry / event signals

OTel is fully wired (`utils/telemetry/instrumentation.ts`, 825 lines). Honored env vars (lines 90-115):

- `OTEL_METRICS_EXPORTER` / `OTEL_LOGS_EXPORTER` / `OTEL_TRACES_EXPORTER` (also `ANT_*` aliases)
- `OTEL_EXPORTER_OTLP_PROTOCOL`, `OTEL_EXPORTER_OTLP_ENDPOINT`, `OTEL_EXPORTER_OTLP_HEADERS`
- `OTEL_METRIC_EXPORT_INTERVAL`
- `OTEL_EXPORTER_OTLP_METRICS_TEMPORALITY_PREFERENCE` (forced to `delta` if unset)
- `OTEL_LOG_USER_PROMPTS` — opt-in to log user prompt content (otherwise replaced with `<REDACTED>`, see `utils/telemetry/events.ts:13-19`).

Exporters supported: `console`, `otlp` (http or grpc), `prometheus` — dynamically imported.

Event logger (`utils/telemetry/events.ts:21-75`) emits `claude_code.<eventName>` log records with attributes including the global telemetry attributes, monotonic `event.sequence`, ISO `event.timestamp`, and `prompt.id` (from `getPromptId()`). `CLAUDE_CODE_WORKSPACE_HOST_PATHS` (set by the desktop wrapper) is attached as `workspace.host_paths` for events only (not metrics, to avoid cardinality blowup).

`TranscriptMessage.promptId` is the same value, so an orchestrator with both the OTel log and the JSONL can join turn-level events back to specific assistant rows.

Additional analytics: `tengu_session_*` events fired throughout `sessionStorage.ts` (e.g. `tengu_session_renamed`, `tengu_session_tagged`, `tengu_session_linked_to_pr`, `tengu_session_persistence_failed`, `tengu_session_forked_branches_fetched`, `tengu_teleport_resume_session`). These flow through `logEvent` to the analytics pipeline.

There is also `betaSessionTracing.ts`, `sessionTracing.ts`, `perfettoTracing.ts`, and a `bigqueryExporter.ts` — three independent tracing surfaces on top of OTel.

## 9. What an external orchestrator/watcher can tail

For monitoring a running Claude Code session out of process, in priority order:

1. **The transcript JSONL itself.** `<~/.claude/projects/<sanitizePath(cwd)>/<sessionId>.jsonl`. Stat-stream with inotify/FSEvents and parse new lines. Each `assistant` row gives you tool calls (`message.content[*].type === 'tool_use'`) and reasoning. Watch for `summary` rows (compaction), `task-summary` (periodic agent-state snapshot), `last-prompt` (rolling), `tombstone` writes (rare — line removed).
   - Resolve the cwd → directory mapping via `sanitizePath`; for path lengths >200, expect a truncated-plus-hash suffix and use a directory prefix scan (the SDK's own `findProjectDir` falls back to this on Bun/Node hash mismatch).
   - For subagents, additionally tail `<projectDir>/<sessionId>/subagents/**/agent-<agentId>.jsonl` plus the `*.meta.json` sidecars.
   - File mode is `0o600` and parent dir `0o700` — the watcher needs to run as the same user.

2. **Task files (TodoV2).** Tail `~/.claude/tasks/<sessionId-or-teamName>/*.json` with `fs.watch` (Claude Code does the same in `hooks/useTaskListWatcher.ts`). Each file is a single-task JSON document.

3. **Stream-JSON stdout.** When the session was launched with `--print --output-format=stream-json --verbose [--include-hook-events] [--include-partial-messages]`, every `SDKMessage` is one NDJSON line on the orchestrator-side stdout. Validation is enforced by `streamJsonStdoutGuard`. The first line is always an `SDKSystemMessage` with `subtype:'init'` carrying `session_id`, `cwd`, `tools[]`, `mcp_servers[]`, `model`, `permissionMode`, `slash_commands[]`, `output_style`, `skills[]`, `plugins[]`, `claude_code_version`. The last line is an `SDKResultMessage` with cost/usage totals.

4. **Hooks.** Register a CLI command for any of the 27 `HOOK_EVENTS`. The hook gets a JSON-on-stdin payload containing `session_id`, `transcript_path`, `cwd`, `permission_mode?`, `agent_id?`, `agent_type?`, and event-specific extras (tool inputs/outputs, user prompts, compaction reasons, file change paths, etc.). For subagent hooks the payload also carries `agent_transcript_path`. Hooks can be configured via settings.json or `--settings`; they're the primary out-of-process control channel.

5. **OTel logs / metrics / traces.** Set `OTEL_LOGS_EXPORTER=otlp` (or `prometheus` for metrics) and an OTLP endpoint; you'll receive `claude_code.*` log records with `prompt.id`, `event.sequence`, `session.id`, plus standard metrics from `sdk-metrics`. Opt into prompt-text capture with `OTEL_LOG_USER_PROMPTS=1`.

6. **Auxiliary sidecars** (read-only on demand, not tailed):
   - `agent-<agentId>.meta.json` — subagent agent type + worktree + description
   - `remote-agent-<taskId>.meta.json` — CCR remote-agent identity (status fetched live)
   - `bridge-pointer.json` — bridge transport pointer (CCR-mediated remote sessions; `bridge/bridgePointer.ts:53`)

### 9.1 Tail-window quirks worth knowing

- `readLiteMetadata` only inspects the **first ~16 KB and last ~64 KB** of a JSONL. Long metadata-only sessions or messages bigger than the head window can blank out `firstPrompt`; the code falls back to `'(session)'` (`sessionStorage.ts:5052`).
- The author re-appends metadata entries at exit precisely so that within the 64 KB tail window the latest `custom-title`, `tag`, etc. are always reachable (`sessionStorage.ts:722` — see the long comment about why titles "scroll out of the window" on a long post-compact session).
- Compact-boundary chunked reads (`sessionStoragePortable.ts:469`) — readers can begin parsing from the most recent compaction boundary rather than the file start; for >5 MB sessions, precompact filtering is skipped because they almost certainly have compact boundaries.
- The transcript path used for hook `transcript_path` is computed atomically with `session_id` (see `getTranscriptPathForSession`, `sessionStorage.ts:207`) so it always points to where the file *is*, not where `originalCwd` would suggest.

### 9.2 Sanity for a watcher implementation

Pseudocode:

```text
projectDir = ~/.claude/projects/<replace_nonalnum(cwd, '-')>   # add hash suffix if >200 chars
mainFile   = projectDir / <sessionId>.jsonl
tail -F mainFile, parse each line as JSON
  if entry.type in ('user','assistant','attachment','system'): record the turn
    for block in entry.message.content:
      if block.type == 'tool_use':  emit "agent started <name>"
      if block.type == 'tool_result': pair with prior tool_use_id
  if entry.type == 'summary':        emit "compaction happened"
  if entry.type == 'task-summary':   emit "agent self-report: <summary>"
  if entry.type == 'pr-link':        emit "linked to PR <prNumber>"
also watch projectDir/<sessionId>/subagents/  for new agent-*.jsonl files
also watch ~/.claude/tasks/<sessionId>/       for *.json create/update/delete
```

End of extensive findings.
