## TLDR

Claude Code subscription auth is OAuth 2.0 authorization-code + PKCE (no device-code) with the token stored in macOS Keychain (`Claude Code-credentials`) or `$CLAUDE_CONFIG_DIR/.credentials.json` (mode 0600) on other platforms; the refresh-token grant rotates, supports scope expansion, and is serialized per-machine by a `proper-lockfile` on `~/.claude`. You **can** auth once and ship to N machines/containers by copying `.credentials.json`, exporting a `claude setup-token`-issued 1-year `CLAUDE_CODE_OAUTH_TOKEN` (inference-only, no MCP/sessions/upload), or using `CLAUDE_CODE_OAUTH_REFRESH_TOKEN` + `CLAUDE_CODE_OAUTH_SCOPES` — but concurrent refreshes can race-rotate the refresh token (no cross-host lock), and the 5-hour and 7-day rate limits are account-scoped (one quota across all containers, surfaced via `anthropic-ratelimit-unified-*` headers with no client-side backoff).

---

## Executive summary

- **OAuth flow is browser-PKCE with localhost callback + manual paste fallback** — no RFC 8628 device-code. Entry is `claude /login` or `claude auth login`. Token endpoint `https://platform.claude.com/v1/oauth/token`; subscriber scopes `user:profile user:inference user:sessions:claude_code user:mcp_servers user:file_upload`; subscriber wire header is `Authorization: Bearer …` + `anthropic-beta: oauth-2025-04-20`.
- **Storage is keychain-first with file fallback on macOS, file-only on Linux/Windows.** File path is `$CLAUDE_CONFIG_DIR/.credentials.json` (default `~/.claude/.credentials.json`, mode 0600). Keychain entry is `security`-managed generic-password `Claude Code-credentials`. Blob is `{accessToken, refreshToken, expiresAt(ms), scopes, subscriptionType, rateLimitTier}`. Profile metadata (email, orgUuid, billingType) is in `~/.claude/.claude.json`.
- **Refresh is rotating and lock-protected per machine.** `grant_type=refresh_token` returns a new `refresh_token` and supports scope expansion. Cross-process: `proper-lockfile` on `$CLAUDE_CONFIG_DIR`, mtime-watch invalidates the in-memory cache, 5-minute expiry skew buffer, dedup of concurrent 401 handlers. **No cross-machine lock.**
- **Auth-once-ship-to-many is supported three ways, with caveats**:
  1. Copy `~/.claude/.credentials.json` (explicitly designed for host↔container sharing per `fallbackStorage.ts` comment referencing GH#1414).
  2. `CLAUDE_CODE_OAUTH_TOKEN` env var holding a `claude setup-token`-issued 1-year inference-only access token — no refresh ever, but **gates off MCP, file upload, Remote Control, sessions** (inference-only).
  3. `CLAUDE_CODE_OAUTH_REFRESH_TOKEN` + `CLAUDE_CODE_OAUTH_SCOPES` for headless re-login that runs `refreshOAuthToken()` at start.
- **Primary fanout risk: refresh-token rotation race.** With N containers sharing one refresh token, the per-machine `proper-lockfile` cannot serialize them; the server can rotate and orphan all but one host. Mitigations: use the 1-year setup-token (option 2), or have a single host refresh and broadcast the resulting blob, or run inference-only.
- **Secondary fanout risk: account-level rate limits.** Server returns unified headers `anthropic-ratelimit-unified-representative-claim ∈ {five_hour, seven_day, seven_day_opus}`, `-unified-reset`, `-unified-overage-status ∈ {allowed, allowed_warning, rejected}`, `-unified-overage-reset`, `-unified-overage-disabled-reason`. All N containers share one Claude.ai account's 5-hour and 7-day quotas. No client-side exponential backoff for 429 on subscription path — CLI surfaces "session limit / weekly limit · resets …" with upsell.
- **No client-side device binding.** No fingerprint, MAC, or device ID sent. Only User-Agent `claude-code/<v>` and the fixed `client_id=9d1c250a-e61b-44d9-88ed-5944d1962f5e`.
- **API-key fallback precedence**: `--bare` → `apiKeyHelper`; otherwise `ANTHROPIC_AUTH_TOKEN` → `CLAUDE_CODE_OAUTH_TOKEN` → `CLAUDE_CODE_OAUTH_TOKEN_FILE_DESCRIPTOR` → settings `apiKeyHelper` → keychain/file OAuth → `ANTHROPIC_API_KEY` (with managed-OAuth-context override that forces OAuth even when `ANTHROPIC_API_KEY` is set, for CCR / Claude Desktop). 3P providers (`CLAUDE_CODE_USE_BEDROCK|_USE_VERTEX|_USE_FOUNDRY`) bypass entirely.
- **Key env vars**: `CLAUDE_CONFIG_DIR`, `CLAUDE_CODE_OAUTH_TOKEN`, `CLAUDE_CODE_OAUTH_REFRESH_TOKEN`, `CLAUDE_CODE_OAUTH_SCOPES`, `CLAUDE_CODE_OAUTH_TOKEN_FILE_DESCRIPTOR`, `CLAUDE_CODE_OAUTH_CLIENT_ID`, `CLAUDE_CODE_CUSTOM_OAUTH_URL`, `CLAUDE_CODE_REMOTE`, `CLAUDE_CODE_ENTRYPOINT`, `ANTHROPIC_API_KEY`, `ANTHROPIC_AUTH_TOKEN`.

---

## Detailed summary

**UX flow.** OAuth 2.0 authorization-code with PKCE, no device-code flow. `claude /login` or `claude auth login` spins up an ephemeral localhost listener (`AuthCodeListener`, `services/oauth/index.ts:51-52`), generates `code_verifier`/`code_challenge` + `state`, opens `https://claude.com/cai/oauth/authorize?...redirect_uri=http://localhost:<port>/callback&scope=user:profile user:inference user:sessions:claude_code user:mcp_servers user:file_upload&code_challenge_method=S256&...` in the browser, and also prints a manual URL (`MANUAL_REDIRECT_URL = https://platform.claude.com/oauth/code/callback`) for paste-back. Auth code is POSTed to `https://platform.claude.com/v1/oauth/token` (`grant_type=authorization_code`, `code_verifier`, `client_id=9d1c250a-…`). Response yields `access_token`, `refresh_token`, `expires_in`, `scope`, `account: {uuid, email_address}`, `organization: {uuid}`. `installOAuthTokens()` then wipes prior state via `performLogout({clearOnboarding:false})`, fetches `/api/oauth/profile` for subscription type and rate-limit tier, and writes secure storage. `claude setup-token` is a separate inference-only path issuing a 1-year `access_token` (`expiresIn: 365*24*60*60`, `inferenceOnly: true`) printed to the user for export as `CLAUDE_CODE_OAUTH_TOKEN`.

**Storage.** `getSecureStorage()` returns `createFallbackStorage(macOsKeychainStorage, plainTextStorage)` on darwin, plain text on all others (`utils/secureStorage/index.ts:9-17`; TODO comment for libsecret on Linux). File path is `$CLAUDE_CONFIG_DIR/.credentials.json` (default `~/.claude/.credentials.json`), mode 0600. Keychain entry: generic-password under service `Claude Code-credentials` (with `sha256(dir)[:8]` suffix when `$CLAUDE_CONFIG_DIR` is non-default); read via `security find-generic-password -w`, written via hex-encoded JSON piped through `security -i` to keep payload out of `ps`. Blob shape: `{accessToken, refreshToken, expiresAt (ms), scopes[], subscriptionType, rateLimitTier}`. Profile (email, orgUuid, billingType) lives separately in `~/.claude/.claude.json`'s `oauthAccount`. 30 s keychain read TTL with stale-while-error semantics and a generation counter to prevent stale subprocess results from overwriting fresh writes.

**Refresh.** `refreshOAuthToken()` POSTs `grant_type=refresh_token` to `TOKEN_URL` with `scope` defaulting to `CLAUDE_AI_OAUTH_SCOPES`, allowing **scope expansion on refresh** ("ALLOWED_SCOPE_EXPANSIONS … safe even for tokens issued before scopes were added"). Server **rotates the refresh token** (response `refresh_token` is stored if present; falls back to the previous on omission). Expiry uses a 5-minute skew buffer. Refresh is gated by an in-process promise dedup *and* a `proper-lockfile` on `$CLAUDE_CONFIG_DIR` (5 retries × 1-2 s jitter); after lock acquisition the code re-reads to detect "another tab already refreshed". 401s are handled out-of-band: a `pending401Handlers` map dedupes by failed token, then either picks up a new token from keychain or force-refreshes. The `.credentials.json` mtime is checked to invalidate the in-memory memoize when another process writes.

**Multi-machine portability.** Three viable transports:

1. **Copy `~/.claude/.credentials.json`** — explicitly supported. Fallback storage comment: *"Delete secondary when migrating to primary for the first time. This preserves credentials when sharing .claude between host and containers. See: https://github.com/anthropics/claude-code/issues/1414"* (`fallbackStorage.ts:36-39`). On Linux/containers the file is the only store.
2. **`CLAUDE_CODE_OAUTH_TOKEN` env var** — inference-only path; `refreshToken: null, expiresAt: null, scopes: ['user:inference']`. Refresh is *skipped entirely* (`auth.ts:1404`). Designed for the 1-year `setup-token`. Side effect: Remote Control / MCP / file upload features are gated off — *"Long-lived tokens (from `claude setup-token` or `CLAUDE_CODE_OAUTH_TOKEN`) are limited to inference-only for security reasons"* (`bridge/bridgeEnabled.ts:76`).
3. **`CLAUDE_CODE_OAUTH_REFRESH_TOKEN` + `CLAUDE_CODE_OAUTH_SCOPES`** — headless re-login that exchanges the refresh token via `refreshOAuthToken()`, installs the result like normal `auth login`.

**What breaks at fanout.**
- *Refresh-token rotation race* across machines: the per-machine `proper-lockfile` does **not** serialize across containers, so two hosts refreshing the same token can leave N-1 hosts with a stale refresh token. Mitigation: pin to env-var token (option 2) or have one machine refresh and re-distribute, or use the 1-year `setup-token`.
- *Account-level rate limits*: Anthropic's unified rate-limit headers (`anthropic-ratelimit-unified-representative-claim` ∈ `five_hour | seven_day | seven_day_opus`, `-unified-reset`, `-unified-overage-status` ∈ `allowed | allowed_warning | rejected`, `-unified-overage-reset`, `-unified-overage-disabled-reason`) are scoped to the *Claude.ai account*. Every container shares one 5-hour session quota and 7-day weekly quota. On 429 the CLI surfaces "You've hit your session limit · resets <time>" with `/upgrade` (Pro/Max) or `/extra-usage` (Team/Ent) upsell; **there is no automatic backoff** — the message is rendered and the session pauses until reset. Early-warning banner fires at high utilization.
- *Device binding*: nothing client-side. No fingerprint, MAC, device id sent. Only `User-Agent: claude-code/<v>` + `client_id`. Server could enforce concurrent-IP heuristics but the client does not participate.

**API-key fallback & precedence.** `isAnthropicAuthEnabled()` returns false (forcing API-key path) when 3P provider env is set, when `ANTHROPIC_AUTH_TOKEN`/`apiKeyHelper`/`CLAUDE_CODE_API_KEY_FILE_DESCRIPTOR` exists outside managed context, or when `ANTHROPIC_API_KEY` exists outside managed context. `getAuthTokenSource()` precedence: bare→apiKeyHelper, `ANTHROPIC_AUTH_TOKEN`, `CLAUDE_CODE_OAUTH_TOKEN`, FD token, settings `apiKeyHelper`, then keychain/file OAuth. Wire header is `Authorization: Bearer …` + `anthropic-beta: oauth-2025-04-20` for subscribers, `x-api-key: …` otherwise (`utils/http.ts:69-99`).

**Env vars / files controlling auth.** `CLAUDE_CONFIG_DIR` (relocate `~/.claude`), `CLAUDE_CODE_OAUTH_TOKEN`, `CLAUDE_CODE_OAUTH_REFRESH_TOKEN`+`CLAUDE_CODE_OAUTH_SCOPES`, `CLAUDE_CODE_OAUTH_TOKEN_FILE_DESCRIPTOR` (+ disk fallback `/home/claude/.claude/remote/.oauth_token`), `ANTHROPIC_API_KEY`, `ANTHROPIC_AUTH_TOKEN`, `CLAUDE_CODE_API_KEY_FILE_DESCRIPTOR`, `CLAUDE_CODE_OAUTH_CLIENT_ID`, `CLAUDE_CODE_CUSTOM_OAUTH_URL` (allowlisted FedStart endpoints), `CLAUDE_CODE_REMOTE`/`CLAUDE_CODE_ENTRYPOINT=claude-desktop` (managed-OAuth context), `CLAUDE_CODE_USE_BEDROCK|_USE_VERTEX|_USE_FOUNDRY`, `CLAUDE_CODE_ACCOUNT_UUID|_USER_EMAIL|_ORGANIZATION_UUID` (SDK profile override). Files: `$CLAUDE_CONFIG_DIR/.credentials.json` (tokens), `$CLAUDE_CONFIG_DIR/.claude.json` (`oauthAccount` profile), Keychain `Claude Code-credentials[-<suffix>]`, CCR `/home/claude/.claude/remote/.oauth_token` and `.api_key`.

---

# Extensive

Source root: `/Users/johntokash/Downloads/src` (Claude Code CLI; not a git repo).

## 1. UX flow: browser-PKCE OAuth (no device-code flow)

Claude Code's "Pro/Max login" is a standard OAuth 2.0 **authorization-code + PKCE** flow with a localhost callback listener, plus a manual-paste fallback. There is **no RFC 8628 device-code flow** — `device_code` does not appear anywhere in the source.

Entry points:

- `claude /login` (interactive) → `components/ConsoleOAuthFlow.tsx`
- `claude auth login [--claudeai | --console] [--email …] [--sso]` (non-interactive subcommand) → `cli/handlers/auth.ts:112` `authLogin()`
- `claude setup-token` → `cli/handlers/util.tsx:43`, `main.tsx:4267` — long-lived (1-year) inference-only token, intended for headless/CI use, returned to the user instead of stored.

Core service: `services/oauth/index.ts` `OAuthService.startOAuthFlow()`.

Mechanism (`services/oauth/index.ts:32-132`):

1. Spin up a local HTTP listener (`AuthCodeListener`) on an ephemeral port.
2. Generate PKCE `code_verifier`/`code_challenge` + `state` (`services/oauth/crypto.ts`).
3. Build two URLs — automatic (`redirect_uri=http://localhost:<port>/callback`) and manual (`redirect_uri=https://platform.claude.com/oauth/code/callback`):

   ```ts
   // services/oauth/client.ts:46-105
   authUrl.searchParams.append('code', 'true') // tells login page to show Claude Max upsell
   authUrl.searchParams.append('client_id', getOauthConfig().CLIENT_ID)
   authUrl.searchParams.append('response_type', 'code')
   authUrl.searchParams.append('redirect_uri',
     isManual ? getOauthConfig().MANUAL_REDIRECT_URL : `http://localhost:${port}/callback`)
   authUrl.searchParams.append('scope', scopesToUse.join(' '))
   authUrl.searchParams.append('code_challenge', codeChallenge)
   authUrl.searchParams.append('code_challenge_method', 'S256')
   authUrl.searchParams.append('state', state)
   ```

4. `openBrowser(automaticFlowUrl)` and simultaneously print the manual URL. Whichever returns first wins:

   ```ts
   // services/oauth/index.ts:81-85
   await authURLHandler(manualFlowUrl) // Show manual option to user
   await openBrowser(automaticFlowUrl) // Try automatic flow
   ```

5. Auth code is POSTed to `TOKEN_URL` with `grant_type=authorization_code`, `code_verifier`, `redirect_uri`, `client_id`, `state` (`services/oauth/client.ts:107-144`). Response shape:

   ```ts
   // services/oauth/types.ts (inferred from client.ts usage)
   { access_token, refresh_token, expires_in, scope, account: { uuid, email_address }, organization: { uuid } }
   ```

6. `fetchProfileInfo()` calls `/api/oauth/profile` to learn `subscriptionType` (`max | pro | enterprise | team`) and `rateLimitTier` (`services/oauth/client.ts:355-420`).
7. `installOAuthTokens()` runs `performLogout({ clearOnboarding: false })` first to wipe any prior state, then saves via `saveOAuthTokensIfNeeded()` (`cli/handlers/auth.ts:50-110`).

Endpoints (prod, `constants/oauth.ts:84-104`):

```ts
BASE_API_URL:           'https://api.anthropic.com',
CONSOLE_AUTHORIZE_URL:  'https://platform.claude.com/oauth/authorize',
CLAUDE_AI_AUTHORIZE_URL:'https://claude.com/cai/oauth/authorize',  // 307s to claude.ai/oauth/authorize
TOKEN_URL:              'https://platform.claude.com/v1/oauth/token',
API_KEY_URL:            'https://api.anthropic.com/api/oauth/claude_cli/create_api_key',
MANUAL_REDIRECT_URL:    'https://platform.claude.com/oauth/code/callback',
CLIENT_ID:              '9d1c250a-e61b-44d9-88ed-5944d1962f5e',
```

Scopes (`constants/oauth.ts:33-58`):

```ts
CONSOLE_OAUTH_SCOPES = ['org:create_api_key', 'user:profile']
CLAUDE_AI_OAUTH_SCOPES = ['user:profile', 'user:inference', 'user:sessions:claude_code', 'user:mcp_servers', 'user:file_upload']
OAUTH_BETA_HEADER = 'oauth-2025-04-20'
```

`shouldUseClaudeAIAuth()` keys off `user:inference` to decide subscriber vs API-key path (`services/oauth/client.ts:38-40`).

## 2. Token storage: macOS Keychain primary, `~/.claude/.credentials.json` fallback

Selection logic (`utils/secureStorage/index.ts:9-17`):

```ts
export function getSecureStorage(): SecureStorage {
  if (process.platform === 'darwin') {
    return createFallbackStorage(macOsKeychainStorage, plainTextStorage)
  }
  // TODO: add libsecret support for Linux
  return plainTextStorage
}
```

So **macOS → Keychain with file fallback**; **Linux/Windows → file only** (no libsecret yet).

File backend (`utils/secureStorage/plainTextStorage.ts:13-84`):

```ts
function getStoragePath(): { storageDir: string; storagePath: string } {
  const storageDir = getClaudeConfigHomeDir()        // $CLAUDE_CONFIG_DIR or ~/.claude
  const storageFileName = '.credentials.json'
  return { storageDir, storagePath: join(storageDir, storageFileName) }
}
// ...
chmodSync(storagePath, 0o600)
return { success: true, warning: 'Warning: Storing credentials in plaintext.' }
```

Config dir resolution (`utils/envUtils.ts:7-13`):

```ts
export const getClaudeConfigHomeDir = memoize(() =>
  process.env.CLAUDE_CONFIG_DIR ?? join(homedir(), '.claude')
)
```

Keychain backend (`utils/secureStorage/macOsKeychainStorage.ts` + `macOsKeychainHelpers.ts`):

- Service name: `Claude Code-credentials` for the default config dir; `Claude Code-credentials-<sha256(dir)[:8]>` if `$CLAUDE_CONFIG_DIR` is set (`macOsKeychainHelpers.ts:29-41`). `OAUTH_FILE_SUFFIX` (e.g. `-staging-oauth`, `-local-oauth`, `-custom-oauth`) is interpolated for non-prod.
- Username = `process.env.USER` or `userInfo().username`.
- Read: `security find-generic-password -a "$USER" -w -s "Claude Code-credentials"`. Write: `security add-generic-password -U` with the JSON blob hex-encoded and piped on stdin (`-i`) to keep the payload out of `ps`/process monitors:

  ```ts
  // macOsKeychainStorage.ts:113-118
  // Prefer stdin (`security -i`) so process monitors (CrowdStrike et al.)
  // see only "security -i", not the payload (INC-3028).
  const command = `add-generic-password -U -a "${username}" -s "${storageServiceName}" -X "${hexValue}"\n`
  ```
- In-process 30 s TTL cache to avoid `security` spawn storms; stale-while-error semantics on read failure (`macOsKeychainHelpers.ts:69` `KEYCHAIN_CACHE_TTL_MS = 30_000`).
- Locked-keychain detection (`isMacOsKeychainLocked()`): `security show-keychain-info` exit 36 → keychain locked (SSH session case).

Fallback semantics (`utils/secureStorage/fallbackStorage.ts`):

- `read()`: prefer primary (keychain); if null, read secondary (file).
- `update()`: write to primary; on first successful primary write, delete the secondary "to preserve credentials when sharing .claude between host and containers" (line 36-38). On primary write failure, write to secondary AND `primary.delete()` to avoid serving stale keychain entries (#30337 fix).

Persisted blob shape (`utils/auth.ts:1217-1229`):

```ts
storageData.claudeAiOauth = {
  accessToken: tokens.accessToken,
  refreshToken: tokens.refreshToken,
  expiresAt: tokens.expiresAt,          // ms epoch
  scopes: tokens.scopes,
  subscriptionType: tokens.subscriptionType ?? existingOauth?.subscriptionType ?? null,
  rateLimitTier:   tokens.rateLimitTier   ?? existingOauth?.rateLimitTier   ?? null,
}
```

Profile metadata (email, org UUID, display name, billing type, account-created-at, subscription-created-at) lives separately in `~/.claude/.claude.json` (global config) under `oauthAccount` (`services/oauth/client.ts:517-566` `storeOAuthAccountInfo`).

## 3. Refresh semantics

Implementation: `services/oauth/client.ts:146-274` `refreshOAuthToken()`. POST to `TOKEN_URL` with `grant_type=refresh_token`, `refresh_token`, `client_id`, `scope` (default `CLAUDE_AI_OAUTH_SCOPES`).

Key behavior:

- **Refresh token rotation**: `refresh_token: newRefreshToken = refreshToken` (line 178) — falls back to old refresh token if server omits a new one, but the server typically returns a new one (the comment at `auth.ts:1316` references "another CC instance's /login or refresh" rotating tokens).
- **Scope expansion on refresh** (line 154-162):

  ```ts
  // The backend's refresh-token grant allows scope expansion beyond what the
  // initial authorize granted (see ALLOWED_SCOPE_EXPANSIONS), so this is
  // safe even for tokens issued before scopes were added to the app's
  // registered oauth_scope.
  ```
- **Expiry check buffer**: 5 min skew (`client.ts:344-353`):

  ```ts
  export function isOAuthTokenExpired(expiresAt: number | null): boolean {
    if (expiresAt === null) return false
    const bufferTime = 5 * 60 * 1000
    return Date.now() + bufferTime >= expiresAt
  }
  ```
- **Refresh orchestration** (`utils/auth.ts:1427-1562` `checkAndRefreshOAuthTokenIfNeeded`):
  - In-process dedup via `pendingRefreshCheck` promise.
  - Cross-process: takes `proper-lockfile` lock on `$CLAUDE_CONFIG_DIR` (`lockfile.lock(claudeDir)`). On `ELOCKED` retries up to 5× with 1-2 s jitter (lines 1494-1502).
  - Detects "another tab refreshed already" by re-reading after lock acquire (lines 1517-1527, event `tengu_oauth_token_refresh_race_resolved`).
- **401 handler** (`utils/auth.ts:1360-1392`): on a 401 from API, compares failed token vs current keychain; if different, treat as recovered ("another tab already refreshed"); else force-refresh ignoring local `expiresAt`. Dedup map `pending401Handlers` collapses concurrent 401s on the same token.
- **Disk mtime invalidation** (`auth.ts:1320-1336`): if `.credentials.json` mtime changed, blow the memoize so terminal 2's refresh is picked up by terminal 1.
- **Wire header** when subscriber: `Authorization: Bearer <accessToken>` plus `anthropic-beta: oauth-2025-04-20` (`utils/http.ts:69-99`). API-key path uses `x-api-key`.

## 4. Multi-machine portability — can we ship one auth to many containers?

**Yes — directly supported.** Three independent mechanisms, with caveats.

### 4a. Copy `~/.claude/.credentials.json`

Fallback storage explicitly preserves this for container sharing (`utils/secureStorage/fallbackStorage.ts:36-39`):

```
// Delete secondary when migrating to primary for the first time
// This preserves credentials when sharing .claude between host and containers
// See: https://github.com/anthropics/claude-code/issues/1414
```

On Linux containers there's no keychain — `plainTextStorage` is sole backend, so dropping a copy of `.credentials.json` (mode 0600) in `$CLAUDE_CONFIG_DIR` is sufficient. The blob has `accessToken`, `refreshToken`, `expiresAt`, `scopes`, `subscriptionType`, `rateLimitTier` — everything needed for refresh.

### 4b. `CLAUDE_CODE_OAUTH_TOKEN` env var (inference-only)

`utils/auth.ts:1259-1270`:

```ts
if (process.env.CLAUDE_CODE_OAUTH_TOKEN) {
  // Return an inference-only token (unknown refresh and expiry)
  return {
    accessToken: process.env.CLAUDE_CODE_OAUTH_TOKEN,
    refreshToken: null,
    expiresAt: null,
    scopes: ['user:inference'],
    subscriptionType: null,
    rateLimitTier: null,
  }
}
```

Designed to be set to the output of `claude setup-token` (1-year expiry, inference-only). Pros: simple, ship-as-env, no refresh dance. Cons: **inference-only scope** — `user:sessions:claude_code`, `user:mcp_servers`, `user:file_upload`, `user:profile` are absent. From `bridge/bridgeEnabled.ts:76`:

```
Remote Control requires a full-scope login token. Long-lived tokens (from `claude setup-token` or CLAUDE_CODE_OAUTH_TOKEN) are limited to inference-only for security reasons. Run `claude auth login` to use Remote Control.
```

`auth.ts:1404` skips refresh entirely for env-var tokens. When the token expires (1 year), every process using it breaks until you re-run `setup-token`.

### 4c. `CLAUDE_CODE_OAUTH_REFRESH_TOKEN` + `CLAUDE_CODE_OAUTH_SCOPES`

Headless re-login path in `cli/handlers/auth.ts:140-186`:

```ts
const envRefreshToken = process.env.CLAUDE_CODE_OAUTH_REFRESH_TOKEN
if (envRefreshToken) {
  const envScopes = process.env.CLAUDE_CODE_OAUTH_SCOPES
  if (!envScopes) {
    process.stderr.write(
      'CLAUDE_CODE_OAUTH_SCOPES is required when using CLAUDE_CODE_OAUTH_REFRESH_TOKEN.\n' +
      'Set it to the space-separated scopes the refresh token was issued with\n' +
      '(e.g. "user:inference" or "user:profile user:inference user:sessions:claude_code user:mcp_servers").\n')
    process.exit(1)
  }
  const tokens = await refreshOAuthToken(envRefreshToken, { scopes: envScopes.split(/\s+/).filter(Boolean) })
  await installOAuthTokens(tokens)
```

So a single `auth login` on a workstation produces a `refresh_token` which can be exported into N machines/containers. Each will run `refreshOAuthToken` on first launch, **which can rotate the refresh token server-side**. That is the load-bearing risk for fanout.

### 4d. CCR / file-descriptor injection

`utils/authFileDescriptor.ts:168-181` — CCR (Claude Code Remote) and Claude Desktop pipe a token through `CLAUDE_CODE_OAUTH_TOKEN_FILE_DESCRIPTOR` (numeric FD) and fall back to a well-known disk file `/home/claude/.claude/remote/.oauth_token` for subprocesses that can't inherit the pipe. `services/remoteManagedSettings/syncCache.ts:77` notes "CLAUDE_CODE_OAUTH_TOKEN_FILE_DESCRIPTOR, Agent SDK, CI carry no…".

### 4e. What breaks at scale

1. **Refresh-token rotation race.** `refreshOAuthToken` returns `newRefreshToken` (`services/oauth/client.ts:178`). If host A and host B both spin up with the same refresh token, both call `/v1/oauth/token`, and the server can rotate. Within one machine this is serialized by the `proper-lockfile` on `$CLAUDE_CONFIG_DIR` (`auth.ts:1485-1516`). **Across machines/containers there is no shared lock.** One container will hold the new refresh token; the other(s) will have a stale one. The stored access token is still valid until ~5 min before its `expires_in` — but the *next* refresh on the loser hosts will 4xx and the auth blob is broken.
   - The `.credentials.json` blob's `expiresAt` is process-local-clock based (`Date.now() + expires_in * 1000` at line 182), so machine clock skew matters too.
2. **Account-level rate limits.** The 5-hour rolling subscription quota and 7-day quotas are scoped to *the Claude.ai account*, not the device. Concurrent runs on N machines share one quota.
   - Headers from server (`services/api/errors.ts:471-516`):
     ```
     anthropic-ratelimit-unified-representative-claim  → 'five_hour' | 'seven_day' | 'seven_day_opus'
     anthropic-ratelimit-unified-overage-status        → 'allowed' | 'allowed_warning' | 'rejected'
     anthropic-ratelimit-unified-reset                 → epoch seconds
     anthropic-ratelimit-unified-overage-reset
     anthropic-ratelimit-unified-overage-disabled-reason
     ```
   - 429 message: `You've hit your session limit · resets <time>` for `five_hour`; `weekly limit` for `seven_day` (`rateLimitMessages.ts:181-196`).
   - Pro/Max upsell: `'/upgrade to keep using Claude Code'`; Team/Ent: `'/extra-usage to request more'` (`rateLimitMessages.ts:268-294`).
3. **Device binding.** Nothing in the code emits any hardware fingerprint, MAC address, or device ID into the token request. The User-Agent (`claude-code/<version> (entrypoint, agent-sdk/…)` — `utils/http.ts:36-50`) and `CLIENT_ID` are the only identifiers. So **no client-side device-binding** — server-side could still flag concurrent IPs, but the code shows no such enforcement client-side.

## 5. API-key fallback / precedence

`isAnthropicAuthEnabled()` (`utils/auth.ts:100-149`) — OAuth path is *disabled* when:

```ts
const shouldDisableAuth =
  is3P ||                                       // CLAUDE_CODE_USE_BEDROCK / _USE_VERTEX / _USE_FOUNDRY
  (hasExternalAuthToken && !isManagedOAuthContext()) ||
  (hasExternalApiKey && !isManagedOAuthContext())
```

Where `hasExternalAuthToken` = `ANTHROPIC_AUTH_TOKEN || apiKeyHelper || CLAUDE_CODE_API_KEY_FILE_DESCRIPTOR`.

`getAuthTokenSource()` (`utils/auth.ts:153-206`) precedence (top wins):

1. `--bare` mode → `apiKeyHelper` only (no OAuth).
2. `ANTHROPIC_AUTH_TOKEN` (unless managed-OAuth context).
3. `CLAUDE_CODE_OAUTH_TOKEN` env var.
4. `CLAUDE_CODE_OAUTH_TOKEN_FILE_DESCRIPTOR` (or CCR well-known file fallback).
5. `apiKeyHelper` (settings.json, unless managed-OAuth).
6. `claude.ai` OAuth from secure storage (`getClaudeAIOAuthTokens`).
7. `none`.

`getAnthropicApiKeyWithSource()` (`utils/auth.ts:226-348`) precedence for API-key auth:

1. `--bare`: `ANTHROPIC_API_KEY` env or `apiKeyHelper`.
2. `preferThirdPartyAuthentication() && ANTHROPIC_API_KEY` (when `claude --print`).
3. CI/test mode: `CLAUDE_CODE_API_KEY_FILE_DESCRIPTOR` then `ANTHROPIC_API_KEY` (errors out if neither + no oauth token).
4. `ANTHROPIC_API_KEY` if approved in `customApiKeyResponses.approved`.
5. `CLAUDE_CODE_API_KEY_FILE_DESCRIPTOR`.
6. `apiKeyHelper` (cached, async helper command).
7. `getApiKeyFromConfigOrMacOSKeychain()` — legacy `/login`-managed Console key.

Wire header dispatch (`utils/http.ts:69-98`):

```ts
if (isClaudeAISubscriber()) {
  return { headers: { Authorization: `Bearer ${oauthTokens.accessToken}`, 'anthropic-beta': OAUTH_BETA_HEADER } }
}
const apiKey = getAnthropicApiKey()
return { headers: { 'x-api-key': apiKey } }
```

`isClaudeAISubscriber()` = `isAnthropicAuthEnabled() && shouldUseClaudeAIAuth(scopes)` (`auth.ts:1564-1570`), i.e. `user:inference` scope present and OAuth not disabled.

Special-case: on homespace (`isRunningOnHomespace()`), `ANTHROPIC_API_KEY` is suppressed in favor of the Console-managed key (`auth.ts:250-254`).

## 6. Env vars / files that control auth selection

Env vars:

| Var | Effect |
|---|---|
| `CLAUDE_CONFIG_DIR` | Overrides `~/.claude` (also derives keychain service-name suffix). |
| `ANTHROPIC_API_KEY` | Direct API-key auth; disables OAuth path (unless `isManagedOAuthContext`). |
| `ANTHROPIC_AUTH_TOKEN` | Bearer-token API-key alternative; disables OAuth path. |
| `CLAUDE_CODE_OAUTH_TOKEN` | Inject inference-only OAuth access token; **no refresh attempted**. |
| `CLAUDE_CODE_OAUTH_TOKEN_FILE_DESCRIPTOR` | FD with OAuth token (CCR/Desktop); fallback `/home/claude/.claude/remote/.oauth_token`. |
| `CLAUDE_CODE_API_KEY_FILE_DESCRIPTOR` | FD with API key. |
| `CLAUDE_CODE_OAUTH_REFRESH_TOKEN` | One-shot login via refresh-token grant; requires `CLAUDE_CODE_OAUTH_SCOPES`. |
| `CLAUDE_CODE_OAUTH_SCOPES` | Space-separated scopes for above. |
| `CLAUDE_CODE_OAUTH_CLIENT_ID` | Override OAuth client_id. |
| `CLAUDE_CODE_CUSTOM_OAUTH_URL` | FedStart endpoint override (allowlisted). |
| `CLAUDE_CODE_REMOTE`, `CLAUDE_CODE_ENTRYPOINT=claude-desktop` | Managed-OAuth context: ignore user's `apiKeyHelper`/`ANTHROPIC_API_KEY`. |
| `CLAUDE_CODE_USE_BEDROCK` / `_USE_VERTEX` / `_USE_FOUNDRY` | 3P provider; bypass Anthropic auth. |
| `CLAUDE_CODE_ACCOUNT_UUID`, `CLAUDE_CODE_USER_EMAIL`, `CLAUDE_CODE_ORGANIZATION_UUID` | SDK callers (Cowork) supply account info to skip profile fetch (`client.ts:457-471`). |
| `ANTHROPIC_UNIX_SOCKET` | `claude ssh` proxy mode; `CLAUDE_CODE_OAUTH_TOKEN` becomes a subscriber-marker placeholder. |
| `USE_LOCAL_OAUTH`, `USE_STAGING_OAUTH`, `CLAUDE_LOCAL_OAUTH_*_BASE` | Ant-only test config. |

Files:

- `$CLAUDE_CONFIG_DIR/.credentials.json` — OAuth blob (`claudeAiOauth: {accessToken, refreshToken, expiresAt, scopes, subscriptionType, rateLimitTier}`), 0600. On non-macOS this is the only store.
- `$CLAUDE_CONFIG_DIR/.claude.json` (global config) — `oauthAccount` profile (email, orgUuid, billingType, etc.) and onboarding flags.
- macOS Keychain entry `Claude Code-credentials` (suffix `<sha256(dir)[:8]>` if custom config dir; `-staging-oauth`/`-local-oauth`/`-custom-oauth` for non-prod).
- `/home/claude/.claude/remote/.oauth_token`, `.api_key` — CCR well-known fallback files.

## 7. Rate-limit & backoff signals (account-level)

`services/api/errors.ts:465-558` — 429 handling only triggers when `isClaudeAISubscriber()` and `shouldProcessRateLimits()` (mock-aware). It reads the unified rate-limit headers above, builds a `ClaudeAILimits` object, and calls `getRateLimitErrorMessage()`:

- `five_hour` → "session limit"
- `seven_day` → "weekly limit"
- `seven_day_opus` → "Opus limit"
- `seven_day_sonnet` → "weekly limit" / "Sonnet limit"
- overage → `allowed | allowed_warning | rejected` plus `overageResetsAt`, `overageDisabledReason`.

No exponential backoff for 429s on subscription path — surface limit to user and stop. Capacity 429s (no quota headers) fall to a generic "Request rejected (429) · this may be a temporary capacity issue" (`errors.ts:553-557`).

Early-warning UX (banner) at `rateLimitMessages.ts:199-254`: `"You've used <pct>% of your session limit · resets <time> · /upgrade to keep using Claude Code"` for Pro/Max.

## 8. Cross-instance race protection summary

- 30 s keychain read cache (`KEYCHAIN_CACHE_TTL_MS`) with generation counter + in-flight dedup.
- `.credentials.json` mtime watcher → cache invalidate.
- `proper-lockfile` on `$CLAUDE_CONFIG_DIR` around refresh.
- `pending401Handlers: Map<string, Promise>` keyed by failed access token.
- "Stale-while-error" read: serve last good cache on `security` spawn failure.

Net: a single machine with many CC processes is *well* serialized. Many machines sharing one refresh token are *not* — that is the fundamental obstacle to the user's "auth once, ship to N containers" goal.
