# TLDR

Use `codex exec [--json] [-o FINAL.txt] [--output-schema SCHEMA.json] --sandbox <mode> --skip-git-repo-check "PROMPT"`; the prompt may also come from stdin (`-` or piped). In `--json` mode, stdout is one `ThreadEvent` per line (watch for `turn.completed` / `turn.failed` to know it's done); in default mode, stdout receives only the final assistant message. Everything else — progress, tool output, errors, tracing — goes to stderr. Exit code is `0` on success and `1` on any failure (including failed/interrupted turns); approvals are auto-rejected so pick the sandbox up front. Resume sessions with `codex exec resume [UUID|name|--last] "PROMPT"` after capturing `thread_id` from the first run's `thread.started` event.

---

## Executive Summary

- The non-interactive surface is `codex exec` (alias `codex e`), implemented in `codex-rs/exec/`. Two sub-modes: `codex exec resume` (continue a session) and `codex exec review` (code review). `codex mcp-server` / `codex app-server` exist for long-lived JSON-RPC scenarios but are a different protocol.
- Prompt input: positional `[PROMPT]`, or stdin (auto-detected when piped, forced with `-`). With both, stdin is appended as a `<stdin>` block. Images via `--image`/`-i`.
- Output contract is enforced (`#![deny(clippy::print_stdout)]` at `codex-rs/exec/src/lib.rs:5`): default mode puts only the final assistant message on stdout; `--json` mode puts one JSON event per line on stdout; everything else (config summary, progress, tool output, reasoning, errors, tokens-used, tracing logs) goes to stderr.
- Final answer capture: `--output-last-message FILE` / `-o FILE` writes the last assistant message when the turn succeeds. Combine with `--output-schema FILE` to constrain the final message to a JSON Schema for parseable structured output.
- `--json` (alias `--experimental-json`) emits typed `ThreadEvent`s: `thread.started`, `turn.started`, `turn.completed`, `turn.failed`, `item.started/updated/completed`, `error`. Items are tagged: `agent_message`, `reasoning`, `command_execution`, `file_change`, `mcp_tool_call`, `collab_tool_call`, `web_search`, `todo_list`, `error`. `turn.completed` carries token `usage`.
- Wait-for-completion = loop until you see `turn.completed` (status `completed`, `failed`, or `interrupted`); the process exits shortly after. SIGINT triggers a `turn/interrupt` server call.
- Exit codes are binary: `0` success, `1` for any failure (config, schema, missing prompt, no-git-repo, login restriction, fatal server error, failed/interrupted turn, rejected approval). The Node shim `codex-cli/bin/codex.js` forwards SIGINT/SIGTERM/SIGHUP and re-emits signals for shell 128+n semantics.
- Scripting-critical flags: `--skip-git-repo-check` (required outside a git repo), `--sandbox {read-only|workspace-write|danger-full-access}`, `--add-dir DIR`, `--dangerously-bypass-approvals-and-sandbox` / `--yolo` (also implies skip-git). Approvals are always rejected in exec mode, so you must choose a sandbox that lets the model's tools succeed.
- Session continuation: `codex exec resume [UUID|name|--last] [PROMPT]` — for scripts, capture `thread_id` from the `thread.started` JSON event on call N and pass it to call N+1. `--ephemeral` opts out of session persistence (and out of the `thread/read` backfill safety net).
- Other useful globals: `--profile`/`-p`, `--cd`/`-C`, `--model`/`-m`, `--oss`, `--local-provider`, `--ignore-user-config`, `--ignore-rules`, `--color`, and arbitrary `-c key=value` config overrides. `RUST_LOG` controls stderr tracing verbosity (default `error,...otel=off`).
- The only documentation file in-tree (`docs/exec.md`) is a stub pointing at `https://developers.openai.com/codex/noninteractive`; the canonical source is the code in `codex-rs/exec/src/{cli,lib,exec_events,event_processor*}.rs`.

---

## Detailed Summary

The headless surface of the Codex CLI is `codex exec` (alias `codex e`), defined in `codex-rs/exec/src/cli.rs` and driven by `codex-rs/exec/src/lib.rs`. It uses an in-process app-server client to start a thread, fire a single turn with the supplied prompt, stream notifications back, and exit when the turn reaches a terminal state. There is also `codex exec resume` for session continuation and `codex exec review` (mirrored at top level as `codex review`) for repo reviews. Longer-lived JSON-RPC services exist (`codex mcp-server`, `codex app-server`, `codex exec-server`) but use different protocols; this doc focuses on `codex exec`.

Prompt input. The positional `[PROMPT]` is the prompt. If it is `-`, or omitted while stdin is piped, the prompt is read from stdin (UTF-8 with BOM handling; UTF-16 BE/LE supported; UTF-32 rejected). If both a positional prompt and piped stdin are present, stdin is appended as a `<stdin>...</stdin>` block — see `prompt_with_stdin_context` in `codex-rs/exec/src/lib.rs:1810-1817`. With no prompt arg and stdin attached to a TTY, exec exits with code 1 and prints "No prompt provided...". Images can be attached with `--image`/`-i`.

I/O contract. The crate enforces `#![deny(clippy::print_stdout)]` and the file comment at `codex-rs/exec/src/lib.rs:1-5` says: default mode writes only the final assistant message to stdout; `--json` mode writes one JSON event per line to stdout; everything else goes to stderr. Tracing logs go to stderr via an `EnvFilter` that defaults to `error,opentelemetry_sdk=off,opentelemetry_otlp=off` and respects `RUST_LOG`. In human mode, whether the final message lands on stdout depends on TTY detection of both fds (`should_print_final_message_to_stdout` / `_to_tty`): if either fd is non-TTY, stdout gets it; if both are TTYs, the message only appears in the stderr-rendered stream.

JSON event stream. `--json` (alias `--experimental-json`) emits a typed `ThreadEvent` per line. The variants are tagged by `type`: `thread.started`, `turn.started`, `turn.completed`, `turn.failed`, `item.started`, `item.updated`, `item.completed`, `error` (see `codex-rs/exec/src/exec_events.rs:9-37`). `item.*` events carry a `ThreadItem` whose `details` is flattened and tagged with snake_case `type`: `agent_message`, `reasoning`, `command_execution`, `file_change`, `mcp_tool_call`, `collab_tool_call`, `web_search`, `todo_list`, `error`. `turn.completed` also carries a `usage` object (`input_tokens`, `cached_input_tokens`, `output_tokens`, `reasoning_output_tokens`). `AgentMessage` and `Reasoning` are emitted only as `item.completed`; tool calls stream `started` and `completed`; `todo_list` streams `started`, `updated`s, then `completed` at turn end.

Final message. `--output-last-message FILE` / `-o FILE` writes the last agent message to a file via `handle_last_message`. It is only written when the turn completes successfully; failed/interrupted turns log a stderr warning and write empty content. With `--output-schema FILE`, the agent's final message is constrained to a JSON string matching the supplied JSON Schema (the schema file is validated at startup; bad files exit 1). This pairs well with `-o` to capture parseable structured output.

Run loop and waiting. `codex-rs/exec/src/lib.rs:558-937` boots an `InProcessAppServerClient`, sends `thread/start` (or `thread/resume`), then `turn/start`, then loops on `client.next_event()` interleaved with a `tokio::signal::ctrl_c` interrupt channel. The loop ends when `process_server_notification` returns `CodexStatus::InitiateShutdown` — currently emitted on `TurnCompleted` with status `Completed | Failed | Interrupted`. After the loop, `client.shutdown()` runs, `print_final_output` writes the `-o` file and (in human mode) emits the final message to stdout where appropriate. There is a `thread/read` backfill for non-ephemeral runs when `turn.completed` arrives with empty `turn.items` due to in-process backpressure (`lib.rs:1226-1267`).

Exit codes. Only two are meaningful: `0` on success, `1` on any of: config load error, output schema error, missing/invalid stdin prompt, "not inside a trusted directory" without `--skip-git-repo-check`, login restriction error, fatal server `Error` notification (`will_retry == false`), `TurnCompleted` with `Failed` or `Interrupted` status, or any rejected server-side approval request. Signals propagate via the Node shim: `codex-cli/bin/codex.js` forwards SIGINT/SIGTERM/SIGHUP and re-emits the signal so shells see 128+n. The cli's `handle_exit_status` helper (`codex-rs/cli/src/exit_status.rs`) mirrors the same convention for sub-processes.

Sandbox and approvals. In exec mode the approval policy is forced to `AskForApproval::Never` (`lib.rs:399-410`), and every approval-style `ServerRequest` is rejected (`handle_server_request` at `lib.rs:1530-1656`). So you must pre-pick the sandbox: `--sandbox read-only`, `--sandbox workspace-write` (combine with `--add-dir DIR` for extra writable roots), or `--sandbox danger-full-access`. `--dangerously-bypass-approvals-and-sandbox` / `--yolo` forces `DangerFullAccess` and implicitly skips the git repo check. `--full-auto` is hidden/deprecated and maps to `workspace-write`. By default, `codex exec` refuses to run outside a git repo unless `--skip-git-repo-check` (or `--yolo`) is given.

Session continuation. `codex exec resume [SESSION_ID] [PROMPT]` resolves the thread to resume in this order (`resolve_resume_thread_id` at `lib.rs:1338-1449`): `--last` picks the newest `thread/list` entry filtered by current model provider and cwd (use `--all` to ignore cwd); otherwise a UUID arg wins; otherwise a thread name is looked up in the state DB and then via `thread/list` with `search_term`. If nothing matches, a new `thread/start` happens silently. To chain calls from scripts, capture the `thread_id` from the `thread.started` event of the first `--json` run and pass it as a UUID to subsequent `resume` calls. `--ephemeral` disables rollout persistence (and disables the `thread/read` backfill safety net).

Other global flags. `--profile`/`-p` selects a config profile; `--cd`/`-C DIR` overrides cwd; `--ignore-user-config` skips `$CODEX_HOME/config.toml`; `--ignore-rules` skips execpolicy `.rules`; `--color {auto|always|never}` controls ANSI on stderr (irrelevant in `--json`); `--model`/`-m`, `--oss`, `--local-provider {lmstudio|ollama}` pick model/provider. Arbitrary config keys can be overridden via `-c key=value` (handled by `config_overrides.parse_overrides()`; bad overrides exit 1).

Scripting summary. Use `codex exec --json -o final.txt --sandbox <mode> --skip-git-repo-check [--add-dir ...] "PROMPT" >events.jsonl 2>codex.err`. Read `events.jsonl` line by line (parse as JSON, dispatch on `type`), watch for `turn.completed`/`turn.failed`/`error` to know when to stop, capture `thread_id` from `thread.started` for resume, and read `final.txt` for the assistant's final answer (which is a JSON document when `--output-schema` is set). Treat exit codes as binary success/failure; rely on event payloads for granularity.

---

# Codex CLI: Non-Interactive Launch — Extensive Summary

Source workspace inspected: `/Users/johntokash/Downloads/codex` (Rust workspace under `codex-rs/`, Node shim under `codex-cli/`, docs under `docs/`).

The single doc page on this topic is essentially a stub:

> `docs/exec.md`:
> ```
> # Non-interactive mode
>
> For information about non-interactive mode, see [this documentation](https://developers.openai.com/codex/noninteractive).
> ```

Everything below was derived from reading the actual code in the workspace.

---

## 1. Entry points and subcommand shape

The `codex` binary is dispatched through `codex-rs/cli/src/main.rs`. Relevant subcommands (from `enum Subcommand`):

```rust
// codex-rs/cli/src/main.rs:105-182
#[derive(Debug, clap::Subcommand)]
enum Subcommand {
    /// Run Codex non-interactively.
    #[clap(visible_alias = "e")]
    Exec(ExecCli),

    /// Run a code review non-interactively.
    Review(ReviewArgs),
    ...
    /// Start Codex as an MCP server (stdio).
    McpServer,

    /// [experimental] Run the app server or related tooling.
    AppServer(AppServerCommand),
    ...
    /// [EXPERIMENTAL] Run the standalone exec-server service.
    ExecServer(ExecServerCommand),
}
```

So the headless entry points are:

- `codex exec` (alias `codex e`) — one-shot non-interactive run. This is the primary thing to script against.
- `codex review` — non-interactive code review wrapper (same exec engine).
- `codex mcp-server` — JSON-RPC over stdio (MCP). Not a one-shot prompt runner; different I/O contract.
- `codex app-server` / `codex exec-server` — experimental, longer-lived JSON-RPC services.

The non-interactive CLI is defined in `codex-rs/exec/src/cli.rs`. Its usage line says it all:

```rust
// codex-rs/exec/src/cli.rs:9-13
#[derive(Parser, Debug)]
#[command(
    version,
    override_usage = "codex exec [OPTIONS] [PROMPT]\n       codex exec [OPTIONS] <COMMAND> [ARGS]"
)]
pub struct Cli {
```

Subcommands underneath `exec`:

```rust
// codex-rs/exec/src/cli.rs:160-167
#[derive(Debug, clap::Subcommand)]
pub enum Command {
    /// Resume a previous session by id or pick the most recent with --last.
    Resume(ResumeArgs),

    /// Run a code review against the current repository.
    Review(ReviewArgs),
}
```

So `codex exec` is `codex exec [PROMPT]`, `codex exec resume ...`, or `codex exec review ...`.

## 2. Top-level `codex exec` flags

From `codex-rs/exec/src/cli.rs:14-82` and the shared options in `codex-rs/utils/cli/src/shared_options.rs`:

- Positional `[PROMPT]` — initial prompt. If omitted, or set to `-`, the prompt comes from stdin. If both a positional prompt and piped stdin exist, stdin is appended as a `<stdin>` block.
- `--json` (alias `--experimental-json`) — emit one JSON event per line on stdout. Global.
- `--output-last-message FILE` / `-o FILE` — write the final assistant message to a file. Global.
- `--output-schema FILE` — JSON Schema file constraining the model's final reply. Loaded via `load_output_schema` (process exits 1 if the file is missing or invalid JSON).
- `--color {auto|always|never}` — color for the human renderer; controls ANSI on stderr.
- `--skip-git-repo-check` — allow running outside a git repo (default: refuses, see below).
- `--ephemeral` — do not persist session files to disk.
- `--ignore-user-config` — do not load `$CODEX_HOME/config.toml` (auth still uses `CODEX_HOME`).
- `--ignore-rules` — do not load user or project execpolicy `.rules` files.
- `--full-auto` — hidden, deprecated; warns and maps to `--sandbox workspace-write`.
- Shared with TUI (via `SharedCliOptions`):
  - `--image`/`-i FILE,...` — attach image(s) to the initial prompt.
  - `--model`/`-m`.
  - `--oss`, `--local-provider` (lmstudio|ollama).
  - `--profile`/`-p` — config profile.
  - `--sandbox`/`-s {read-only|workspace-write|danger-full-access}` — see `codex-rs/utils/cli/src/sandbox_mode_cli_arg.rs`.
  - `--dangerously-bypass-approvals-and-sandbox` (alias `--yolo`) — full bypass.
  - `--cd`/`-C DIR` — working dir.
  - `--add-dir DIR` — extra writable roots.

`Resume` subcommand args (`codex-rs/exec/src/cli.rs:169-237`):

- `[SESSION_ID]` positional — UUID or thread name.
- `--last` — resume newest session matching cwd (or all with `--all`).
- `--all` — disable cwd filtering when picking sessions.
- `--image`/`-i FILE,...`.
- `[PROMPT]` positional after session_id — prompt to send after resume; `-` reads stdin.
- Note: `--last <prompt>` is treated as a prompt (no session id), via:
  ```rust
  // codex-rs/exec/src/cli.rs:220-237
  let (session_id, prompt) = if raw.last && raw.prompt.is_none() {
      (None, raw.session_id)
  } else {
      (raw.session_id, raw.prompt)
  };
  ```

`Review` subcommand (`codex-rs/exec/src/cli.rs:260-293`):

- `--uncommitted`
- `--base BRANCH`
- `--commit SHA` (+ optional `--title TITLE`)
- `[PROMPT]` for custom review instructions (mutually exclusive with the above).

## 3. I/O model and TTY behavior

The top of `codex-rs/exec/src/lib.rs` states the contract explicitly:

```rust
// codex-rs/exec/src/lib.rs:1-5
// - In the default output mode, it is paramount that the only thing written to
//   stdout is the final message (if any).
// - In --json mode, stdout must be valid JSONL, one event per line.
// For both modes, any other output must be written to stderr.
#![deny(clippy::print_stdout)]
```

So:

- `stdout` carries either (a) the final assistant message text in default mode, or (b) one JSON event per line in `--json` mode.
- Everything else — config summary, progress, tool/command output, reasoning, warnings, tokens-used line, diffs, plan ticks, errors — is on `stderr`.
- Tracing logs are routed to stderr with a default `EnvFilter`:
  ```rust
  // codex-rs/exec/src/lib.rs:225-231
  fn exec_stderr_env_filter() -> EnvFilter {
      EnvFilter::try_from_default_env()
          .or_else(|_| EnvFilter::try_new(EXEC_DEFAULT_LOG_FILTER))
          .unwrap_or_else(|_| EnvFilter::new("error"))
  }
  // EXEC_DEFAULT_LOG_FILTER = "error,opentelemetry_sdk=off,opentelemetry_otlp=off"
  ```
  Override via `RUST_LOG=...`.

### Stdin prompt resolution

`codex-rs/exec/src/lib.rs:170-180` defines three behaviors:

```rust
enum StdinPromptBehavior {
    /// Read stdin only when there is no positional prompt, which is the legacy
    /// `codex exec` behavior for `codex exec` with piped input.
    RequiredIfPiped,
    /// Always treat stdin as the prompt, used for the explicit `codex exec -`
    /// sentinel and similar forced-stdin call sites.
    Forced,
    /// If stdin is piped alongside a positional prompt, treat stdin as
    /// additional context to append rather than as the primary prompt.
    OptionalAppend,
}
```

And the rules in `read_prompt_from_stdin` / `resolve_root_prompt` (`codex-rs/exec/src/lib.rs:1763-1847`):

- No positional prompt + stdin is a TTY → exits 1 with "No prompt provided. Either specify one as an argument or pipe the prompt into stdin."
- No positional prompt + stdin is piped → prints "Reading prompt from stdin..." to stderr, reads stdin to EOF, decodes UTF-8 (handles BOMs, UTF-16LE/BE; rejects UTF-32).
- Positional prompt and stdin piped → wraps stdin as a tagged block:
  ```rust
  // codex-rs/exec/src/lib.rs:1810-1817
  fn prompt_with_stdin_context(prompt: &str, stdin_text: &str) -> String {
      let mut combined = format!("{prompt}\n\n<stdin>\n{stdin_text}");
      if !stdin_text.ends_with('\n') { combined.push('\n'); }
      combined.push_str("</stdin>");
      combined
  }
  ```
- Positional prompt `-` forces stdin read.

### Final-message-to-stdout heuristic (human mode)

`codex-rs/exec/src/event_processor_with_human_output.rs:584-599`:

```rust
fn should_print_final_message_to_stdout(
    final_message: Option<&str>,
    stdout_is_terminal: bool,
    stderr_is_terminal: bool,
) -> bool {
    final_message.is_some() && !(stdout_is_terminal && stderr_is_terminal)
}

fn should_print_final_message_to_tty(
    final_message: Option<&str>,
    final_message_rendered: bool,
    stdout_is_terminal: bool,
    stderr_is_terminal: bool,
) -> bool {
    final_message.is_some() && !final_message_rendered && stdout_is_terminal && stderr_is_terminal
}
```

So when both stdout and stderr are TTYs, the final message is printed only as part of the human stream on stderr. When stdout is redirected (script case), the final message is `println!`'d to stdout. The streaming agent messages along the way are written via `eprintln!` (stderr). This means in a pipe `codex exec "..." | tee file.txt`, `file.txt` ends up with just the final assistant message.

## 4. JSON event stream (`--json`)

Emit happens in `codex-rs/exec/src/event_processor_with_jsonl_output.rs:103-115`:

```rust
#[allow(clippy::print_stdout)]
fn emit(&self, event: ThreadEvent) {
    println!(
        "{}",
        serde_json::to_string(&event).unwrap_or_else(|err| {
            json!({
                "type": "error",
                "message": format!("failed to serialize exec json event: {err}"),
            })
            .to_string()
        })
    );
}
```

Top-level event tags (`codex-rs/exec/src/exec_events.rs:9-37`):

```rust
#[serde(tag = "type")]
pub enum ThreadEvent {
    #[serde(rename = "thread.started")]    ThreadStarted(ThreadStartedEvent),
    #[serde(rename = "turn.started")]      TurnStarted(TurnStartedEvent),
    #[serde(rename = "turn.completed")]    TurnCompleted(TurnCompletedEvent),
    #[serde(rename = "turn.failed")]       TurnFailed(TurnFailedEvent),
    #[serde(rename = "item.started")]      ItemStarted(ItemStartedEvent),
    #[serde(rename = "item.updated")]      ItemUpdated(ItemUpdatedEvent),
    #[serde(rename = "item.completed")]    ItemCompleted(ItemCompletedEvent),
    #[serde(rename = "error")]             Error(ThreadErrorEvent),
}
```

Items in `item.*` events are tagged by `ThreadItemDetails` (snake_case `type` field, flattened) — `codex-rs/exec/src/exec_events.rs:94-130`:

```rust
pub struct ThreadItem {
    pub id: String,
    #[serde(flatten)]
    pub details: ThreadItemDetails,
}

#[serde(tag = "type", rename_all = "snake_case")]
pub enum ThreadItemDetails {
    AgentMessage(AgentMessageItem),       // .text (final answer or JSON if --output-schema)
    Reasoning(ReasoningItem),             // .text
    CommandExecution(CommandExecutionItem), // .command, .aggregated_output, .exit_code, .status
    FileChange(FileChangeItem),           // .changes[].path/.kind, .status
    McpToolCall(McpToolCallItem),         // .server, .tool, .arguments, .result, .error, .status
    CollabToolCall(CollabToolCallItem),
    WebSearch(WebSearchItem),
    TodoList(TodoListItem),               // running plan/todo list
    Error(ErrorItem),                     // non-fatal error surfaced as an item
}
```

Status enums (snake_case):

- `CommandExecutionStatus`: `in_progress | completed | failed | declined`
- `PatchApplyStatus`: `in_progress | completed | failed`
- `PatchChangeKind`: `add | delete | update`
- `McpToolCallStatus`, `CollabToolCallStatus`: `in_progress | completed | failed`

`TurnCompletedEvent` carries usage:

```rust
// codex-rs/exec/src/exec_events.rs:60-70
pub struct Usage {
    pub input_tokens: i64,
    pub cached_input_tokens: i64,
    pub output_tokens: i64,
    pub reasoning_output_tokens: i64,
}
```

Notes on what is and isn't streamed:

- `AgentMessage` and `Reasoning` arrive as `item.completed` (the JSON processor returns `None` for their `item.started` mapping, see `map_started_item` at `event_processor_with_jsonl_output.rs:333-341`). Tool calls (`command_execution`, `mcp_tool_call`, etc.) are streamed as `item.started` → `item.completed`.
- `TodoList` is `item.started`, repeated `item.updated`, then `item.completed` when the turn completes.
- Reasoning items with empty summaries are dropped.
- `Error` event vs `error` item: the typed `ThreadEvent::Error` is unrecoverable stream-level error; `ErrorItem` is a non-fatal error surfaced inline.
- `thread.started` is emitted from the synchronous `thread/start` response (no waiting for a server-pushed `SessionConfigured`), avoiding the ~10s startup delay called out at `lib.rs:738-742`.

## 5. The run loop and how it waits for completion

`codex-rs/exec/src/lib.rs:558-937` drives the in-process app-server. Sequence:

1. Build `Config` (overrides + profiles + cwd + sandbox + auth).
2. `check_execpolicy_for_warnings` — non-zero exits if rules fail to load.
3. `enforce_login_restrictions` — non-zero exit on auth misconfig.
4. `InProcessAppServerClient::start(...)`.
5. Resolve resume target if `Resume(...)`, else `ClientRequest::ThreadStart`.
6. `ClientRequest::TurnStart` with input items (text + images), `output_schema`, cwd, approval policy, sandbox/permissions, etc.
7. Event loop:

```rust
// codex-rs/exec/src/lib.rs:835-926 (excerpted)
loop {
    let server_event = tokio::select! {
        maybe_interrupt = interrupt_rx.recv(), if interrupt_channel_open => {
            // send turn/interrupt, continue
        }
        maybe_event = client.next_event() => maybe_event,
    };
    let Some(server_event) = server_event else { break; };
    match server_event {
        InProcessServerEvent::ServerRequest(request) => {
            handle_server_request(&client, request, &mut error_seen).await;
        }
        InProcessServerEvent::ServerNotification(mut notification) => {
            // mark error_seen for fatal Error and Failed/Interrupted TurnCompleted
            maybe_backfill_turn_completed_items(...).await;
            if should_process_notification(...) {
                match event_processor.process_server_notification(notification) {
                    CodexStatus::Running => {}
                    CodexStatus::InitiateShutdown => { request_shutdown(...).await; break; }
                }
            }
        }
        InProcessServerEvent::Lagged { skipped } => { /* warn */ }
    }
}
client.shutdown().await;
event_processor.print_final_output();
if error_seen { std::process::exit(1); }
```

So "wait for completion" is "loop until `TurnCompleted` (or `Failed`/`Interrupted`) flips status to `InitiateShutdown`". After that, the client is shut down and `print_final_output` writes `--output-last-message` and (in human mode) the final message to stdout if appropriate.

Interruption: a `tokio::spawn` listens for SIGINT/Ctrl-C and sends a `turn/interrupt` to the server (`lib.rs:757-763`). Subsequent `TurnCompleted` with `TurnStatus::Interrupted` triggers shutdown and `error_seen = true`.

Backfill: in non-ephemeral mode, when `TurnCompleted` arrives with empty `turn.items` (in-process delivery can drop intermediate notifications under backpressure), exec calls `thread/read` to fill items so the final message is still recovered (`lib.rs:1226-1267`).

## 6. Exit codes

There are very few distinct codes:

- `0` — turn completed successfully (no fatal errors and no failed/interrupted turn).
- `1` — emitted via `std::process::exit(1)` for: config load errors, output-schema file errors, OSS provider not set, login restriction failure, missing prompt (no stdin and no positional), missing/invalid stdin, "Not inside a trusted directory and --skip-git-repo-check was not specified", and at the end of the loop if any of:
  - a `ServerNotification::Error` with `will_retry == false` matching the current turn,
  - a `TurnCompleted` with status `Failed` or `Interrupted`,
  - a rejected/erroring server-side approval request was processed.

Excerpts:

```rust
// codex-rs/exec/src/lib.rs:668-674
if !skip_git_repo_check
    && !dangerously_bypass_approvals_and_sandbox
    && get_git_repo_root(&default_cwd).is_none()
{
    eprintln!("Not inside a trusted directory and --skip-git-repo-check was not specified.");
    std::process::exit(1);
}
```

```rust
// codex-rs/exec/src/lib.rs:866-888
ServerNotification::Error(payload) => {
    if payload.thread_id == primary_thread_id_for_requests
        && payload.turn_id == task_id
        && !payload.will_retry
    { error_seen = true; }
}
ServerNotification::TurnCompleted(payload) if ... &&
    matches!(payload.turn.status, TurnStatus::Failed | TurnStatus::Interrupted)
=> { error_seen = true; }
```

```rust
// codex-rs/exec/src/lib.rs:932-935
if error_seen {
    std::process::exit(1);
}
```

The Node shim faithfully forwards both exit codes and signals (`codex-cli/bin/codex.js:204-229`):

```js
["SIGINT", "SIGTERM", "SIGHUP"].forEach((sig) => {
  process.on(sig, () => forwardSignal(sig));
});
...
if (childResult.type === "signal") {
  process.kill(process.pid, childResult.signal); // 128 + n
} else {
  process.exit(childResult.exitCode);
}
```

And the unix exit-status helper used elsewhere in the CLI:

```rust
// codex-rs/cli/src/exit_status.rs:1-13
#[cfg(unix)]
pub(crate) fn handle_exit_status(status: std::process::ExitStatus) -> ! {
    if let Some(code) = status.code() { std::process::exit(code); }
    else if let Some(signal) = status.signal() { std::process::exit(128 + signal); }
    else { std::process::exit(1); }
}
```

## 7. Sandbox / approval flags that matter when scripting

From `codex-rs/exec/src/lib.rs:399-410`:

```rust
let overrides = ConfigOverrides {
    ...
    // Default to never ask for approvals in headless mode. Feature flags can override.
    approval_policy: Some(AskForApproval::Never),
    ...
    sandbox_mode,
    ...
};
```

So under `codex exec`, the approval policy is forced to `Never`. Any server-side approval request is treated as an automatic rejection. From `handle_server_request` (`lib.rs:1530-1656`):

```rust
ServerRequest::ExecCommandApproval { request_id, params } => {
    reject_server_request(
        client, request_id, &method,
        format!("exec command approval is not supported in exec mode for thread `{}`", params.conversation_id),
    ).await
}
// ditto for: ApplyPatchApproval, FileChangeRequestApproval, CommandExecutionRequestApproval,
// PermissionsRequestApproval, ToolRequestUserInput, DynamicToolCall, ChatgptAuthTokensRefresh,
// AttestationGenerate, McpServerElicitationRequest (auto-cancel)
```

So when scripting, you must pre-decide the sandbox so the agent doesn't need approvals. The effective options:

- `--sandbox read-only` — safest. No file writes by the agent.
- `--sandbox workspace-write` — writes restricted to cwd; combine with `--add-dir` for additional roots.
- `--sandbox danger-full-access` — full disk + network.
- `--dangerously-bypass-approvals-and-sandbox` (alias `--yolo`) — overrides sandbox to `DangerFullAccess` and also implicitly skips the git repo check:
  ```rust
  // codex-rs/exec/src/lib.rs:285-290
  let sandbox_mode = if removed_full_auto { Some(SandboxMode::WorkspaceWrite) }
      else if dangerously_bypass_approvals_and_sandbox { Some(SandboxMode::DangerFullAccess) }
      else { sandbox_mode_cli_arg.map(Into::into) };
  ```

If you intend to script writes/exec, pick `workspace-write` plus optionally `--add-dir` rather than `--yolo`.

## 8. Resume / session continuation flags

`codex exec resume` flow (`codex-rs/exec/src/lib.rs:683-720`, `resolve_resume_thread_id` `lib.rs:1338-1449`):

- With `--last`: pages `thread/list` sorted by `UpdatedAt`, filters by `model_providers = [current]`, and matches cwd unless `--all`. First hit wins.
- Without `--last`: if `SESSION_ID` parses as a UUID, that wins. Otherwise it looks up by exact thread name via `state_db.find_thread_by_exact_title`, then by paging `thread/list` with `search_term = session_id`, again filtered by cwd unless `--all`.
- If nothing is found, a fresh `thread/start` is issued (silent fallback) — note the prompt is sent regardless.
- After resolution, `ClientRequest::ThreadResume` issues with the same params as `ThreadStart`. The returned `thread.id` becomes the working thread for the new turn.

For one-shot scripting you typically want either:

- New session every time (no `resume`).
- Or capture the `thread_id` from `thread.started` (in `--json`) on the first call and pass it to `codex exec resume <UUID> "next prompt"`.

`--ephemeral` skips rollout persistence entirely — useful if you don't want sessions to be picked up by `--last`. But it disables the `thread/read` backfill mentioned earlier, so under heavy backpressure intermediate `item.*` notifications may be dropped without recovery (`turn.completed` still fires).

## 9. Output schema (structured output)

`--output-schema FILE` loads a JSON Schema. From `lib.rs:1664-1688`:

```rust
fn load_output_schema(path: Option<PathBuf>) -> Option<Value> {
    let path = path?;
    let schema_str = match std::fs::read_to_string(&path) { ... };
    match serde_json::from_str::<Value>(&schema_str) { Ok(value) => Some(value), Err(err) => { exit(1) } }
}
```

It is attached to `TurnStartParams.output_schema` and constrains the final assistant message text. Per the `AgentMessageItem` doc:

> `AgentMessageItem` is "either a natural-language response or a JSON string when structured output is requested."

So with `--output-schema`, the final assistant message text will be a JSON string conforming to your schema; `--output-last-message FILE` then yields a parseable JSON file.

## 10. `--output-last-message`

Implemented in `event_processor.rs:31-48`:

```rust
pub(crate) fn handle_last_message(last_agent_message: Option<&str>, output_file: &Path) {
    let message = last_agent_message.unwrap_or_default();
    write_last_message_file(message, Some(output_file));
    if last_agent_message.is_none() {
        eprintln!("Warning: no last agent message; wrote empty content to {}", output_file.display());
    }
}
```

Called from `print_final_output` only when a turn actually `Completed`. Failed/interrupted turns leave the file unwritten (or empty) and stderr carries a warning. Both `--json` and human-output modes honor it.

## 11. Useful invocation recipes

Single shot, default human output:

```sh
codex exec "Refactor foo()" --sandbox read-only --skip-git-repo-check
```

Pipe a long prompt:

```sh
cat task.md | codex exec --sandbox read-only --skip-git-repo-check
# stderr says "Reading prompt from stdin..."
```

Force-stdin even when a prompt arg looks present:

```sh
codex exec --sandbox read-only --skip-git-repo-check -
```

Append context but keep a positional prompt:

```sh
cat context.md | codex exec "Use this context" --skip-git-repo-check
# Stdin becomes a <stdin>...</stdin> block appended to the prompt
```

Structured automation (capture all events, capture final answer):

```sh
codex exec --json -o final.txt \
  --sandbox workspace-write --add-dir vendor/ \
  --skip-git-repo-check \
  "Run the migration plan" \
  >events.jsonl 2>codex.err
```

- `events.jsonl` — JSONL stream; parse line by line.
- `final.txt` — last assistant message (or JSON if `--output-schema` was used).
- `codex.err` — progress, warnings, tracing logs.

Continue a session:

```sh
codex exec resume --last "Now add tests for it"
# or by UUID/name:
codex exec resume 4e1f...uuid "Now add tests"
```

Review:

```sh
codex exec review --base main --json -o review.txt
```

## 12. Caveats observed in the code

- `codex exec` exits 1 by default outside a git repo. You must pass `--skip-git-repo-check` (or `--yolo`, which implies it) for scripts run from arbitrary dirs.
- In `--json` mode, `--color` doesn't matter; stdout is JSON.
- The "final message" decision for human mode depends on TTY detection of both stdout and stderr — if you redirect stderr but not stdout, you'll still get the final message on stdout; if both go to a TTY, the message is only on stderr.
- Approvals are always rejected in exec mode. If your sandbox is too restrictive, the model's tool calls will fail rather than escalate.
- `--ephemeral` disables the backfill safety net; under backpressure you may miss `item.*` events in `--json` mode but still get the `turn.completed`.
- Stdin is decoded as UTF-8 (BOM stripped) or UTF-16 BE/LE (BOM detected). UTF-32 is rejected with a clear error.
- `RUST_LOG` controls stderr tracing verbosity; the default filter is `error,opentelemetry_sdk=off,opentelemetry_otlp=off`.
- The Node shim `codex-cli/bin/codex.js` is `stdio: "inherit"` and forwards SIGINT/SIGTERM/SIGHUP and re-emits signals via `process.kill(process.pid, signal)` so shell semantics (128+n) are preserved.
- For very long-running automation that needs request/response shape, `codex exec` is a one-shot; `codex mcp-server` or `codex app-server` give you JSON-RPC streams over stdio for multi-turn programmatic use, but with a different protocol (out of scope here).
