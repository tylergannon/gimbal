# Codex CLI profile/home directory — TLDR

Codex resolves its profile dir via `find_codex_home()` (`codex-rs/utils/home-dir/src/lib.rs:14`): the `$CODEX_HOME` env var if set (must pre-exist as a directory), else `~/.codex`. For each concurrent run, `mkdir -p` a fresh dir, copy in `auth.json` (and optionally `config.toml`), and point `CODEX_HOME` there — everything else (`installation_id`, `state_5.sqlite`/`logs_2.sqlite`, `sessions/...`, `log/`, `history.jsonl`, `memories/`, `app-server-control.sock`) is auto-created on first use. Do **not** share a `$CODEX_HOME` between concurrent processes: the app-server Unix socket refuses second binders with `AddrInUse`, the SQLite DBs serialise writers, and `history.jsonl` uses an advisory `try_lock` with only ~10 × 100 ms retries.

---

# Codex CLI profile/home directory — executive summary

- **Location resolver:** `find_codex_home()` in `codex-rs/utils/home-dir/src/lib.rs:14` honors `$CODEX_HOME` (must already exist as a directory, canonicalised), else defaults to `~/.codex`. **No XDG support.**
- **Granular overrides:** `CODEX_SQLITE_HOME` (redirects `state_5.sqlite`/`logs_2.sqlite` only), `log_dir` in `config.toml` or `-c log_dir=...`, and `--listen unix://PATH | stdio:// | off` for the app-server socket. Auth credential storage is selectable: `auth_credentials_store_mode = "file" | "keyring" | "auto"`.
- **Required vs auto-created:** for non-interactive runs reusing an existing identity, only **`auth.json`** must be seeded (schema in `codex-rs/login/src/auth/storage.rs:31-49`). `config.toml` is optional. Everything else is auto-created: `installation_id`, `state_5.sqlite`, `logs_2.sqlite`, `sessions/YYYY/MM/DD/rollout-*.jsonl`, `log/`, `history.jsonl`, `memories/`, `plugins/`, `app-server-control/app-server-control.sock`, etc.
- **Global vs per-project:** `$CODEX_HOME` is global. Per-project config layers (`<repo>/.codex/config.toml`) are loaded but **disabled until the project is trusted** via the global `[projects]` table (`codex-rs/core/src/config/mod.rs:1547-1614`). Per-session state lives in `sessions/...` rollouts plus rows in `state_5.sqlite` and one line in `history.jsonl`.
- **Concurrency hazards (why two processes cannot share one dir):**
  1. `$CODEX_HOME/app-server-control/app-server-control.sock` is a Unix domain socket; a second app-server-mode process refuses to start with `AddrInUse` (`codex-rs/app-server-transport/src/transport/unix_socket.rs:92-131`).
  2. `state_5.sqlite` / `logs_2.sqlite` writers serialise across processes (`codex-rs/state/src/lib.rs:69-70`).
  3. `history.jsonl` uses advisory `File::try_lock` with only 10 × 100 ms retries; under contention entries may be dropped (`codex-rs/message-history/src/lib.rs:152-170`).
- **Recipe for many concurrent agent runs with a clean profile each:** `mkdir -p $TMP_CODEX_HOME`, copy in `auth.json` (and optionally `config.toml` with `auth_credentials_store_mode = "file"`), set `CODEX_HOME=$TMP_CODEX_HOME`, give every run its own directory. Don't share.
- **Gotcha:** when `$CODEX_HOME` is set, the directory **must already exist** — Codex won't create the root for you, only sub-paths.

---

# Codex CLI profile/home directory — detailed summary

## Discovery

- Resolver: `codex-rs/utils/home-dir/src/lib.rs:14` `find_codex_home()`. Reads `CODEX_HOME` env var; if set, the path **must already exist and be a directory** (it's canonicalised), otherwise falls back to `dirs::home_dir() + ".codex"`. No XDG support.
- Sibling override: `CODEX_SQLITE_HOME` (`codex-rs/state/src/lib.rs:67`) redirects only the SQLite DBs; `log_dir` config key (or `-c log_dir=...`) redirects the log directory (`codex-rs/core/src/config/mod.rs:2864-2868`).

## Layout under `$CODEX_HOME`

Top-level files (all under `$CODEX_HOME`):

- `config.toml` — main user config (`codex-rs/config/src/lib.rs:28`). Optional.
- `auth.json` — `AuthDotJson` struct: `auth_mode`, `OPENAI_API_KEY`, `tokens`, `last_refresh`, `agent_identity` (`codex-rs/login/src/auth/storage.rs:31-85`). The minimum required artifact for non-interactive auth in file mode.
- `installation_id` — single UUID line, auto-generated on first use (`codex-rs/core/src/installation_id.rs:17-61`). Concurrency-safe via `create_new(true)` race + fallback read.
- `history.jsonl` — global cross-session input history; append-only, `0o600`, advisory `File::try_lock` with up to 10 × 100 ms retries (`codex-rs/message-history/src/lib.rs:45,78,138-170`).
- `state_5.sqlite`, `logs_2.sqlite` — versioned SQLite DBs (`codex-rs/state/src/lib.rs:69-70`, `state/src/runtime.rs:287-301`). Used for thread/agent state, remote control enrollment, log buffering.
- `managed_config.toml` — enterprise overlay (`codex-rs/config/src/loader/layer_io.rs:135`).
- `.personality_migration` marker (`codex-rs/core/src/personality_migration.rs:15`).
- `models_cache.json` (`codex-rs/models-manager/src/manager.rs:22`), `cloud-requirements-cache.json` (`codex-rs/cloud-requirements/src/lib.rs:47`), `version.json` (`codex-rs/tui/src/updates.rs:63`), `setup_error.json` (transient).
- `hooks.json`, `skills-role.toml`, `AGENTS.md` (optional user files).

Subdirectories:

- `sessions/YYYY/MM/DD/rollout-YYYY-MM-DDThh-mm-ss-<uuid>.jsonl` — per-thread rollouts (`codex-rs/rollout/src/lib.rs:22`, `recorder.rs:1404-1448`). `archived_sessions/` is the archive counterpart (`lib.rs:23`).
- `log/` — default trace logs; e.g. `~/.codex/log/codex-tui.log` (`docs/install.md:56`).
- `memories/`, `memories_extensions/` — persistent memory roots, both cleared together by `clear_memory_roots_contents` (`memories/write/src/control.rs:3-8`). `memory_root` returns `codex_home.join("memories")` (`memories/read/src/lib.rs:18-20`). Added to sandbox writable roots (`core/src/config/mod.rs:2294-2300`).
- `plugins/cache/`, `plugins/data/`, `plugins/.remote-plugin-install-staging/`, `plugins/.marketplace-plugin-source-staging/` (`core-plugins/src/store.rs:15-16`, `remote_bundle.rs:27`, `loader.rs:1103`).
- `.tmp/plugins/`, `.tmp/marketplaces/`, `.tmp/plugin-share-local-paths-v1.json` (curated/installed marketplace mirroring).
- `proxy/` — managed MITM CA artifacts (`network-proxy/src/certs.rs:95-102`).
- `shell_snapshots/` (`core/src/shell_snapshot.rs:35`).
- `rules/` for exec policy (`core/src/exec_policy.rs:49,769`).
- `skills/` (`core-skills/src/loader.rs:110`), `themes/`, `agents/`, `marketplaces/`, `source/`.
- `tmp/arg0/` — sandbox exec helper area (`core/src/config/permissions.rs:321`).
- `app-server-control/app-server-control.sock` — Unix domain socket for the app-server control plane (`app-server-transport/src/transport/mod.rs:38-46`, `unix_socket.rs:92-131`).

## Override knobs

| Knob | Env / Config | Source |
| --- | --- | --- |
| Root | `CODEX_HOME=/path` | `utils/home-dir/src/lib.rs:14-44` |
| SQLite home | `CODEX_SQLITE_HOME` or `sqlite_home` in TOML | `state/src/lib.rs:67`, `core/src/config/mod.rs:185-197, 2869-2874` |
| Log dir | `log_dir` TOML key or `-c log_dir=...` | `core/src/config/mod.rs:2864-2868` |
| App server listen URL | `--listen unix://PATH | stdio:// | off` | `app-server-transport/src/transport/mod.rs:83-95` |
| Credential storage | `auth_credentials_store_mode = "file"/"keyring"/"auto"` | `core/src/config/mod.rs:199-209` |
| Per-project gate | `[projects."<abs path>"] trust_level = "trusted"` | `core/src/config/mod.rs:1547-1614` |

Important: when `CODEX_HOME` is set, the path **must exist** — Codex won't create the root itself (only its sub-paths). `mkdir -p $CODEX_HOME` before launch.

## Global vs per-project vs per-session

- **Global (in `$CODEX_HOME`):** `config.toml`, `auth.json`, `installation_id`, `history.jsonl`, both `.sqlite` DBs, `sessions/`, `memories/`, `plugins/`, `skills/`, `themes/`, `models_cache.json`, `version.json`, `proxy/`, `app-server-control/`, `log/`.
- **Per-project:** `<repo>/.codex/config.toml` (loaded but **disabled until trusted** via the `[projects]` table in the global config; loader walks parent dirs up to git root — `config/src/loader/mod.rs:89-90`). System layers: `/etc/codex/config.toml`, `/etc/codex/managed_config.toml` (`config/src/loader/mod.rs:45`, `layer_io.rs:16`), plus Windows variants under `OpenAI/Codex/` (`loader/mod.rs:516, 1250`).
- **Per-session:** rollout JSONL inside `sessions/YYYY/MM/DD/`; a row per session in `state_5.sqlite`; one line in `history.jsonl`.

## Concurrency hazards for sharing one `$CODEX_HOME`

1. **`app-server-control/app-server-control.sock`** — `prepare_control_socket_path` attempts to connect; if it gets a response it bails with `AddrInUse` ("app-server control socket is already in use at ..."). `Drop` guard removes the socket on exit (`app-server-transport/src/transport/unix_socket.rs:92-165`). Two app-server-mode processes per dir is **not allowed** unless `--listen` is per-process.
2. **`state_5.sqlite` / `logs_2.sqlite`** — SQLite pools with `max_connections=5`; cross-process writes serialise. Override via `CODEX_SQLITE_HOME` to fan out per run.
3. **`history.jsonl`** — Advisory `try_lock` with 10-retry budget; concurrent writers may drop entries after contention.
4. **`installation_id`** — Race-safe (`create_new(true)` + read-fallback).
5. **Rollouts** — Per-session UUID files; no inter-session collisions on the files themselves, but the SQLite state DB is touched.

## Minimum seed for a fresh, clean profile per run that reuses an existing auth

1. `mkdir -p $TMP_CODEX_HOME && CODEX_HOME=$TMP_CODEX_HOME ...`.
2. Copy `auth.json` from the canonical profile into `$TMP_CODEX_HOME`.
3. Optionally copy `config.toml` (model defaults, trust list, MCP servers).
4. (Recommended) Force `auth_credentials_store_mode = "file"` in `config.toml` to avoid the OS keyring path entirely.
5. Everything else (sessions, history, sqlite, log, installation_id, memories, etc.) auto-generates inside the new dir.
6. Use a **distinct `$CODEX_HOME` per concurrent run** — don't try to share; the control socket and SQLite writes are the practical blockers.

---

## Codex CLI profile/home directory — extensive analysis

Source tree: `/Users/johntokash/Downloads/codex` (specifically the Rust workspace at `codex-rs/`).

This pass documents, with file:line citations and verbatim excerpts, how Codex CLI locates and lays out its profile directory, what files/subdirs it creates, which knobs override its location, what state is global vs per-project, and what side effects (sockets, sqlite, file locks) constrain concurrent processes sharing the same directory.

---

## 1. Discovery: `find_codex_home` and the `CODEX_HOME` env var

The canonical resolver lives in `codex-rs/utils/home-dir/src/lib.rs`:

```rust
// utils/home-dir/src/lib.rs:5-13
/// Returns the path to the Codex configuration directory, which can be
/// specified by the `CODEX_HOME` environment variable. If not set, defaults to
/// `~/.codex`.
///
/// - If `CODEX_HOME` is set, the value must exist and be a directory. The
///   value will be canonicalized and this function will Err otherwise.
/// - If `CODEX_HOME` is not set, this function does not verify that the
///   directory exists.
pub fn find_codex_home() -> std::io::Result<AbsolutePathBuf> {
    let codex_home_env = std::env::var("CODEX_HOME")
        .ok()
        .filter(|val| !val.is_empty());
    find_codex_home_from_env(codex_home_env.as_deref())
}
```

Behaviour:

- If `CODEX_HOME` is set and non-empty: the path **must already exist and be a directory**. It is then `canonicalize()`-ed; non-existence is fatal with `NotFound`, and a file path is fatal with `InvalidInput` (see `find_codex_home_from_env` body at `utils/home-dir/src/lib.rs:20-65`). Tests at lines 78–129 of the same file pin these semantics.
- If `CODEX_HOME` is unset/empty: it falls back to `dirs::home_dir()` + `.codex` and does **not** verify existence (`utils/home-dir/src/lib.rs:55-64`).

Excerpt (default branch):

```rust
// utils/home-dir/src/lib.rs:55-64
None => {
    let mut p = home_dir().ok_or_else(|| {
        std::io::Error::new(
            std::io::ErrorKind::NotFound,
            "Could not find home directory",
        )
    })?;
    p.push(".codex");
    AbsolutePathBuf::from_absolute_path(p)
}
```

There is no XDG (`XDG_CONFIG_HOME`) support — only `CODEX_HOME` and `~/.codex`. The crate is re-exported from many places, e.g.:

- `codex-rs/core/src/config/mod.rs` uses it (via `pub use codex_utils_home_dir::find_codex_home;` family).
- `codex-rs/rmcp-client/src/oauth.rs:531` — `Ok(find_codex_home()?.join(FALLBACK_FILENAME).to_path_buf())`.
- `codex-rs/network-proxy/src/certs.rs:100-102` — `find_codex_home().context("failed to resolve CODEX_HOME for managed MITM CA")?; let proxy_dir = codex_home.join(MANAGED_MITM_CA_DIR);`.
- `codex-rs/thread-manager-sample/src/main.rs:153` — `let codex_home = find_codex_home().context("find Codex home")?;`.

### Related env vars

`codex-rs/state/src/lib.rs:67`:
```rust
pub const SQLITE_HOME_ENV: &str = "CODEX_SQLITE_HOME";
```
Lets the SQLite databases (`state_*.sqlite`, `logs_*.sqlite`) be redirected away from `CODEX_HOME` per-run. Wired in `core/src/config/mod.rs:185-197` (`resolve_sqlite_home_env`) and applied at `core/src/config/mod.rs:2869-2874`:

```rust
let sqlite_home = cfg
    .sqlite_home
    .as_ref()
    .map(AbsolutePathBuf::to_path_buf)
    .or_else(|| resolve_sqlite_home_env(&resolved_cwd))
    .unwrap_or_else(|| codex_home.to_path_buf());
```

`log_dir` is similarly overridable (also configurable in `config.toml` and via `-c log_dir=...` per `docs/install.md:56`):

```rust
// core/src/config/mod.rs:2864-2868
let log_dir = cfg
    .log_dir
    .as_ref()
    .map(AbsolutePathBuf::to_path_buf)
    .unwrap_or_else(|| codex_home.join("log").to_path_buf());
```

## 2. Files and subdirectories created under `$CODEX_HOME`

Aggregated from `grep -E 'codex_home\.join'` across the workspace (see notes section for the unique-set):

### Top-level files

| Path | Source | Required? | Notes |
| --- | --- | --- | --- |
| `config.toml` | `config/src/lib.rs:28` (`pub const CONFIG_TOML_FILE: &str = "config.toml";`) and consumers across `core/src/config`, `core-plugins/`, `config/src/plugin_edit.rs` etc. | Optional (Codex runs with defaults if missing; `tui/src/app/config_persistence.rs` even handles `[broken` cases) | Main config; can be patched at runtime (e.g. `set_project_trust_level` at `core/src/config/mod.rs:1547+`). |
| `auth.json` | `login/src/auth/storage.rs:85` — `pub(super) fn get_auth_file(codex_home: &Path) -> PathBuf { codex_home.join("auth.json") }` | Required for non-interactive auth (unless keyring mode used; see `AuthCredentialsStoreMode`) | Holds `auth_mode`, `OPENAI_API_KEY`, `tokens`, `last_refresh`, `agent_identity`. Schema: `AuthDotJson` struct at `login/src/auth/storage.rs:32-49`. |
| `installation_id` | `core/src/installation_id.rs:17` — `pub(crate) const INSTALLATION_ID_FILENAME: &str = "installation_id";` | Auto-created if missing | Single line UUID. `resolve_installation_id` at `core/src/installation_id.rs:19-61` generates and writes one with `O_CREAT` if absent or unparseable. |
| `history.jsonl` | `message-history/src/lib.rs:45` — `const HISTORY_FILENAME: &str = "history.jsonl";` and `config.codex_home.join(HISTORY_FILENAME)` at line 78. | Optional (gated by `history.persistence`; `HistoryPersistence::None` skips writes — see `lib.rs:101-108`) | **Global cross-session input history** — append-only JSONL. Uses **advisory file locking** (`File::try_lock`, `lib.rs:152-170`) with 10 retries × 100 ms. Mode `0o600` on Unix (`lib.rs:138-142`). |
| `state_5.sqlite` | `state/src/lib.rs:70` — `pub const STATE_DB_FILENAME: &str = "state_5.sqlite";`; resolved by `state/src/runtime.rs:291-293`: `codex_home.join(state_db_filename())` | Created on demand by SQLite pool | Versioned filename (currently `_5`). Used for thread/agent state, remote-control enrollment cache, etc. |
| `logs_2.sqlite` | `state/src/lib.rs:69` — `pub const LOGS_DB_FILENAME: &str = "logs_2.sqlite";`; resolved at `state/src/runtime.rs:299-301`. | Created on demand | Versioned logs DB. |
| `managed_config.toml` | `config/src/loader/layer_io.rs:135` — `codex_home.join("managed_config.toml")` (system-managed config layer, in addition to `/etc/codex/managed_config.toml` and `/etc/codex/config.toml` at `loader/layer_io.rs:16` and `loader/mod.rs:45`). | Optional | Enterprise-managed overrides. |
| `.personality_migration` | `core/src/personality_migration.rs:15` — `pub const PERSONALITY_MIGRATION_FILENAME: &str = ".personality_migration";` | Marker file | One-shot migration sentinel. |
| `models_cache.json` | `models-manager/src/manager.rs:22` — `const MODEL_CACHE_FILE: &str = "models_cache.json";` | Cache, recreated as needed | |
| `cloud-requirements-cache.json` | `cloud-requirements/src/lib.rs:47` — `const CLOUD_REQUIREMENTS_CACHE_FILENAME: &str = "cloud-requirements-cache.json";` | Cache | HMAC-signed (see lines 63-65). |
| `setup_error.json` | `join("setup_error.json")` (transient; written when login/setup errors must be surfaced to TUI). | Transient | |
| `version.json` | `tui/src/updates.rs:63` — `const VERSION_FILENAME: &str = "version.json";` | Cache for update checks | |
| `AGENTS.md` / `LOCAL_AGENTS_MD_FILENAME` | `DEFAULT_AGENTS_MD_FILENAME`, `LOCAL_AGENTS_MD_FILENAME` joined under codex_home in some flows. | Optional | User-supplied prompt fragments. |
| `hooks.json` | `join("hooks.json")` | Optional | Hook configuration. |
| `skills-role.toml` | `join("skills-role.toml")` | Optional | |

### Subdirectories (relative to `$CODEX_HOME`)

| Subdir | Source | Purpose |
| --- | --- | --- |
| `sessions/YYYY/MM/DD/rollout-YYYY-MM-DDThh-mm-ss-<uuid>.jsonl` | `rollout/src/lib.rs:22` `pub const SESSIONS_SUBDIR: &str = "sessions";` and `rollout/src/recorder.rs:1404-1434` (`precompute_log_file_info`) | Per-thread rollout JSONL files. Filename derives from local timestamp + thread UUID. Dir auto-created via `fs::create_dir_all(parent)` at `recorder.rs:1443`. |
| `archived_sessions/...` | `rollout/src/lib.rs:23` `pub const ARCHIVED_SESSIONS_SUBDIR: &str = "archived_sessions";` | Where archived rollouts live. |
| `log/` | `core/src/config/mod.rs:2868` and `docs/install.md:56` (`~/.codex/log/codex-tui.log`) | Default trace log destination; override via `log_dir` config or `-c log_dir=...`. |
| `memories/` | `memories/read/src/lib.rs:18-20` — `pub fn memory_root(codex_home: &AbsolutePathBuf) -> AbsolutePathBuf { codex_home.join("memories") }`. Also `memories/write/src/control.rs:5`. | Persistent memory files. Added to sandbox writable roots at `core/src/config/mod.rs:2294-2300`. |
| `memories_extensions/` | `memories/write/src/control.rs:6` — `codex_home.join("memories_extensions")` | Sibling root cleared together with `memories/`. |
| `plugins/cache/` | `core-plugins/src/store.rs:15` — `pub const PLUGINS_CACHE_DIR: &str = "plugins/cache";` | Marketplace plugin cache. |
| `plugins/data/` | `core-plugins/src/store.rs:16` — `pub const PLUGINS_DATA_DIR: &str = "plugins/data";` | Plugin data. |
| `plugins/.remote-plugin-install-staging/` | `core-plugins/src/remote_bundle.rs:27` | Staging during remote plugin install. |
| `plugins/.marketplace-plugin-source-staging/` | `core-plugins/src/loader.rs:1103` | Marketplace source staging. |
| `.tmp/plugins/` (curated) | `core-plugins/src/startup_sync.rs:25` — `const CURATED_PLUGINS_RELATIVE_DIR: &str = ".tmp/plugins";` | Curated plugin sync output. |
| `.tmp/marketplaces/` | `core-plugins/src/installed_marketplaces.rs:11` — `pub const INSTALLED_MARKETPLACES_DIR: &str = ".tmp/marketplaces";` | Installed marketplaces. |
| `.tmp/plugin-share-local-paths-v1.json` | `core-plugins/src/remote/share/local_paths.rs:123` | Plugin sharing local paths. |
| `proxy/` | `network-proxy/src/certs.rs:95` — `const MANAGED_MITM_CA_DIR: &str = "proxy";` then `codex_home.join(MANAGED_MITM_CA_DIR)` | Managed MITM CA artifacts. |
| `shell_snapshots/` | `core/src/shell_snapshot.rs:35` — `const SNAPSHOT_DIR: &str = "shell_snapshots";` then `codex_home.join(SNAPSHOT_DIR)` (line 505) | Shell state snapshots used during exec. |
| `rules/` | `core/src/exec_policy.rs:49` — `const RULES_DIR_NAME: &str = "rules";`; `codex_home.join(RULES_DIR_NAME).join(DEFAULT_POLICY_FILE)` (line 769) | Exec policy rules. |
| `skills/` | `core-plugins/src/loader.rs:47` `const DEFAULT_SKILLS_DIR_NAME: &str = "skills";` and `core-skills/src/loader.rs:110`, `skills/src/lib.rs:13`. `.system/` subfolder for system skills (`skills/src/lib.rs:12`). | Custom skills loaded into Codex. |
| `themes/` | `join(format!("{name}.tmTheme"))` under `themes/` — `tui/src/render/highlight.rs` and `tui/src/theme_picker.rs`. | User TextMate themes. |
| `tmp/arg0/` | `core/src/config/permissions.rs:321` — `let arg0_root = AbsolutePathBuf::from_absolute_path(codex_home.join("tmp").join("arg0")).ok();` | Working tmp for `arg0`-based exec sandbox helpers. |
| `agents/` | `join("agents")` | Per-agent definitions. |
| `marketplaces/`, `source/` | `core-plugins/src/marketplace_add/metadata.rs:266, 292-293` | Marketplace install roots. |
| `app-server-control/` | `app-server-transport/src/transport/mod.rs:38-46` — `APP_SERVER_CONTROL_SOCKET_DIR_NAME = "app-server-control"`, file `app-server-control.sock` inside it. | **Unix domain socket** for app-server control plane. Created in a "private socket directory" (`prepare_private_socket_directory`). |

### Session index, repair, etc.

`rollout/src/session_index.rs:17`: `const SESSION_INDEX_FILE: &str = "session_index.jsonl";` and `SESSION_IMPORT_LEDGER_FILE` — both joined onto `codex_home` (see grep listing).

### Project / config layering

`config/src/loader/mod.rs:89-90` shows the trust/discovery order:

```text
- tree      parent directories up to root looking for `./.codex/config.toml` (loaded but disabled when untrusted)
- repo      `$(git rev-parse --show-toplevel)/.codex/config.toml` (loaded but disabled when untrusted)
```

System-wide:
- `config/src/loader/mod.rs:45` — `const SYSTEM_CONFIG_TOML_FILE_UNIX: &str = "/etc/codex/config.toml";`
- `config/src/loader/layer_io.rs:16` — `/etc/codex/managed_config.toml`
- Windows variant: `loader/mod.rs:516` uses `windows_codex_system_dir().join("config.toml")`; tests confirm the path ends with `OpenAI/Codex/config.toml` (line 1250).

`project.<path>.trust_level` is stored in `~/.codex/config.toml` under the `[projects]` table — see `core/src/config/mod.rs:1547-1614` (`set_project_trust_level_inner`) and the example at line 1561: `"/path/to/project" = { trust_level = "trusted" }`.

## 3. What's global vs. per-project

- **Global, lives in `$CODEX_HOME`:** `config.toml`, `auth.json`, `installation_id`, `history.jsonl`, `state_5.sqlite`, `logs_2.sqlite`, `sessions/`, `archived_sessions/`, `memories/`, `plugins/`, `skills/`, `themes/`, `models_cache.json`, `version.json`, `proxy/`, `shell_snapshots/`, `rules/`, `app-server-control/`, `log/`.
- **Per-project:** discovered config layers in `<repo>/.codex/config.toml` (loaded but disabled until the project is marked trusted via the `[projects]` table in the global config). Also `.codex/` is checked when explicit and via parent-directory walk (`config/src/loader/mod.rs:89-90`).
- **Per-thread / per-session:** the rollout JSONL inside `sessions/YYYY/MM/DD/rollout-...-<uuid>.jsonl`; conversation history line in the global `history.jsonl`; rows in `state_5.sqlite` (`StateDbHandle` operations including `find_rollout_path_by_id`, `state_db.rs:442-449`).

## 4. Auth specifics — `auth.json` layout and storage modes

`login/src/auth/storage.rs:31-49`:

```rust
/// Expected structure for $CODEX_HOME/auth.json.
#[derive(Deserialize, Serialize, Clone, Debug, PartialEq)]
pub struct AuthDotJson {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub auth_mode: Option<AuthMode>,

    #[serde(rename = "OPENAI_API_KEY")]
    pub openai_api_key: Option<String>,

    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub tokens: Option<TokenData>,

    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub last_refresh: Option<DateTime<Utc>>,

    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub agent_identity: Option<String>,
}
```

`AuthCredentialsStoreMode` (re-exported in `login/src/lib.rs:10`) selects `File`, `Keyring`, or `Auto`. On `LOCAL_DEV_BUILD_VERSION = "0.0.0"`, keyring/auto degrade to `File` (`core/src/config/mod.rs:199-209`). For a clean-room reproducible profile, **`auth.json` is the minimum** — copy it into a freshly seeded `$CODEX_HOME` and Codex will authenticate without a keyring round-trip.

Mode bits on writes are constrained (`0o600` for history file, similar handling for auth via `OpenOptionsExt::mode`).

## 5. Concurrency hazards when sharing one `$CODEX_HOME` between processes

These are the explicit blockers we found:

1. **App-server control socket** (`app-server-transport/src/transport/unix_socket.rs:92-131`): `prepare_control_socket_path` first attempts to *connect* to `$CODEX_HOME/app-server-control/app-server-control.sock`; if a peer answers, it errors with `AddrInUse` and refuses to start ("app-server control socket is already in use at {path}"). If it's a stale socket file, it deletes and rebinds. The `Drop` guard `ControlSocketFileGuard` removes the file on exit (`unix_socket.rs:149-165`). Two app-server-mode processes pointing at the same `CODEX_HOME` **cannot coexist** unless they are configured for a different listen URL (see `AppServerTransport::Stdio | UnixSocket { socket_path }` at `transport/mod.rs:49-53`).

2. **SQLite databases** (`state_5.sqlite`, `logs_2.sqlite`): opened via `SqlitePoolOptions::new().max_connections(5).connect_with(options)` (`state/src/runtime.rs:243-247`) with `auto_vacuum=Incremental` and migrations run (`runtime.rs:257`). SQLite supports concurrent access across processes, but writers serialise; this is the part most likely to cause noisy contention. `CODEX_SQLITE_HOME` (`state/src/lib.rs:67`) is the supported override for per-run isolation if you want to keep `CODEX_HOME` shared.

3. **`history.jsonl` advisory locking** (`message-history/src/lib.rs:152-170`): uses `File::try_lock` with up to 10 retries (100 ms each). Concurrent writers degrade gracefully but can drop entries after 10 contested retries. Mode `0o600`.

4. **Installation ID generation race** (`core/src/installation_id.rs:30-61`): file is created with `OpenOptions::new().write(true).create_new(true)` and falls back to reading the existing file if `AlreadyExists` is returned — concurrency-safe.

5. **Plugins / marketplaces / rollouts**: rollout recorder opens with `append(true).create(true)` (`rollout/src/recorder.rs:1444-1448`). Each session writes to its own UUID-named file, so there is no inherent collision between distinct sessions — but the sqlite state DB updates are shared.

6. **OAuth state file** (`rmcp-client/src/oauth.rs:531`) — `$CODEX_HOME/<FALLBACK_FILENAME>` for MCP OAuth fallback storage; shared across processes.

7. **MITM CA** at `$CODEX_HOME/proxy/` (`network-proxy/src/certs.rs:100-102`) is generated once and reused; it would not block concurrency but should be regenerated if isolating proxy state.

## 6. Minimum seed for a clean per-run `$CODEX_HOME` that reuses existing auth

Empirically (from the code paths above):

- **Mandatory if you don't want a fresh login flow:** copy `auth.json` from the master profile into the new directory. Set `auth_credentials_store_mode = "file"` (`config/src/types.rs`) to avoid keyring lookups, or set `OPENAI_API_KEY` via env.
- **Optional but recommended:** copy `config.toml` (for model defaults, trust list, MCP servers, hooks, etc.). Without it Codex uses built-in defaults.
- **Auto-created on first use:** `installation_id`, `sessions/...`, `state_5.sqlite`, `logs_2.sqlite`, `log/`, `history.jsonl`, `models_cache.json`, `app-server-control/app-server-control.sock`, `memories/`, `proxy/`, `shell_snapshots/`, `plugins/cache`+`plugins/data` (only when plugins are touched), `tmp/arg0/`.

Important: `CODEX_HOME` itself **must already exist as a directory when the env var is set** — Codex will not auto-create the root path you pointed it at (`utils/home-dir/src/lib.rs:25-44`). So your spawn script should `mkdir -p $CODEX_HOME` before launch.

## 7. Override mechanisms summary

| Override | Mechanism | Source |
| --- | --- | --- |
| Root profile directory | `CODEX_HOME=/path` (must pre-exist as directory) | `utils/home-dir/src/lib.rs:14-44` |
| SQLite location | `CODEX_SQLITE_HOME=/path` OR `sqlite_home = "..."` in config | `state/src/lib.rs:67`, `core/src/config/mod.rs:185-197, 2869-2874` |
| Log dir | `log_dir` in config or `-c log_dir=...` CLI override | `core/src/config/mod.rs:2864-2868`, `docs/install.md:56` |
| Listen socket (app server) | `--listen unix://PATH` or `stdio://` or `off` | `app-server-transport/src/transport/mod.rs:83-95` |
| Auth credentials store | `auth_credentials_store_mode = "file" | "keyring" | "auto"` | `config/src/types.rs`, `core/src/config/mod.rs:199-209` |
| Project trust (per-project config gating) | `[projects."<abs path>"] trust_level = "trusted"` in global config.toml | `core/src/config/mod.rs:1547-1614` |

No XDG support; no per-user override for `auth.json` location (always `$CODEX_HOME/auth.json`).

## 8. Concrete plan for many concurrent runs each with a clean profile

Given the above, the safe recipe is:

1. For each run, `mktemp -d` (or `mkdir -p`) a fresh directory; export `CODEX_HOME=<that dir>`.
2. Copy `auth.json` from the canonical profile into the new `$CODEX_HOME`. Also copy `config.toml` if you depend on its settings (model defaults, trust list, MCP servers). Optionally copy `installation_id` for stable telemetry identity (else a new one is minted).
3. (Optional) Set `auth_credentials_store_mode = "file"` in `config.toml` to force file-based credentials and dodge the keyring entirely.
4. Do **not** point multiple runs at the same `$CODEX_HOME`; the `app-server-control/app-server-control.sock` binding and `state_5.sqlite` writes will collide.
5. Avoid passing `CODEX_SQLITE_HOME` unless you have a deliberate reason to fan SQLite into a different location; for clean-profile-per-run you want it co-located with the rest of the throwaway state.
6. Set `log_dir` to somewhere inside (or alongside) the throwaway `$CODEX_HOME` so logs don't bleed back into the user profile.
7. `tmp/arg0/` and `shell_snapshots/` are populated by sandbox exec helpers; they're safe to discard between runs.

## 9. Notes / unique join-target listing

The full unique set of relative paths joined onto `codex_home` (from non-test code) is:

```
.env, .sandbox-bin, .sandbox-secrets, .sandbox, .tmp/plugin-share-local-paths-v1.json,
AGENTS.md, agents, arg0, auth.json, cap_sid, config.toml, hooks.json, log,
managed_config.toml, marketplaces, memories, memories_extensions, sandbox.log,
secrets, setup_error.json, skills, skills-role.toml, source, themes, tmp,
ARCHIVED_SESSIONS_SUBDIR ("archived_sessions"), CONFIG_TOML_FILE,
CURATED_PLUGINS_RELATIVE_DIR (".tmp/plugins"), CURATED_PLUGINS_SHA_FILE,
HISTORY_FILENAME ("history.jsonl"), INSTALLATION_ID_FILENAME ("installation_id"),
INSTALLED_MARKETPLACES_DIR (".tmp/marketplaces"),
MANAGED_MITM_CA_DIR ("proxy"), MODEL_CACHE_FILE ("models_cache.json"),
PERSONALITY_MIGRATION_FILENAME (".personality_migration"),
PLUGIN_SHARE_LOCAL_PATHS_FILE, PLUGINS_CACHE_DIR ("plugins/cache"),
PLUGINS_DATA_DIR ("plugins/data"),
REMOTE_PLUGIN_INSTALL_STAGING_DIR ("plugins/.remote-plugin-install-staging"),
RULES_DIR_NAME ("rules"), SESSION_IMPORT_LEDGER_FILE, SESSION_INDEX_FILE ("session_index.jsonl"),
SESSIONS_SUBDIR ("sessions"), SKILLS_DIR_NAME ("skills"), SNAPSHOT_DIR ("shell_snapshots"),
STARTUP_REMOTE_PLUGIN_SYNC_MARKER_FILE, state_db_filename ("state_5.sqlite"),
logs_db_filename ("logs_2.sqlite"), plugins/.marketplace-plugin-source-staging,
app-server-control/app-server-control.sock
```

This list was produced from:

```
grep -rn "codex_home\.join" codex-rs --include="*.rs" \
  | grep -v "tests/\|_test\|tests::" \
  | grep -oE 'join\([^)]+\)' | sort -u
```

(See section 2 for canonical sources of each constant.)
