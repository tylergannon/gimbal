# TLDR

ChatGPT-subscription quota exhaustion arrives as HTTP 429 with body `{"error":{"type":"usage_limit_reached","plan_type":...,"resets_at":<epoch>}}` and `x-codex-{primary,secondary}-*` headers; codex returns it immediately (non-retryable) and `codex exec` exits **1** after emitting a JSONL `{"type":"turn.failed","error":{"message":"..."}}` event on stdout whose message starts with **`You've hit your usage limit`** and embeds `Try again at <time>` (or `Try again later.` if `resets_at` was absent). Orchestrators driving `codex exec --json` should pattern-match that prefix (and the siblings `Quota exceeded.`, `To use Codex with your ChatGPT plan, upgrade to Plus`, `exceeded retry limit, last status: 429`) since the structured `codex_error_info: "usage_limit_exceeded"` discriminator and the raw `resets_at` epoch never reach JSONL — they exist only on the in-process / app-server protocol. No `Retry-After` HTTP header is honored; cooldown comes solely from the parsed reset time, and internal retry uses 200ms·2^n exponential backoff with ±10% jitter.

---

# Executive summary

- A ChatGPT-subscription quota exhaustion arrives as HTTP **429** with a JSON body whose `error.type` is `usage_limit_reached`, an epoch `resets_at`, a `plan_type`, and a family of `x-codex-*` rate-limit headers (`x-codex-primary-*` = 5-hour cap, `x-codex-secondary-*` = weekly cap, plus `x-codex-active-limit`, `x-codex-limit-name`, `x-codex-promo-message`). Decoded in `codex-rs/codex-api/src/api_bridge.rs:80–106`.
- Codex maps three distinct conditions into the same wire-level discriminator `CodexErrorInfo::UsageLimitExceeded`: `UsageLimitReached` (429 + `usage_limit_reached`), `QuotaExceeded` (SSE `insufficient_quota`), `UsageNotIncluded` (429 / SSE `usage_not_included`). See `codex-rs/protocol/src/error.rs:219–221`. Distinguishing them requires looking at the message text.
- A bare 429 with no `usage_limit_reached` body becomes `CodexErr::RetryLimit { status: 429 }` after the transport's `request_max_retries` (default 4) are exhausted — wire discriminator `ResponseTooManyFailedAttempts { http_status_code: 429 }`. This is the typical API-key 429 path.
- All quota/usage variants are **non-retryable inside core** (`is_retryable()` returns false, `error.rs:170–206`); the agent loop bails immediately on the first hit. The only retried 429-ish case is SSE `rate_limit_exceeded` with an embedded `"try again in N s|ms"` hint (`codex-rs/codex-api/src/sse/responses.rs:521–545`).
- **No `Retry-After` HTTP header is parsed.** The only authoritative cooldown is `resets_at` (epoch seconds) from the 429 body, also reflected in `RateLimitSnapshot.primary/secondary.resets_at`. Internal retry uses exponential `200ms × 2^(attempt-1)` with ±10% jitter (`codex-rs/core/src/util.rs:11–12,88–93`).
- `codex exec --json` emits JSONL events on stdout (`{"type":"thread.started"|"turn.started"|"turn.completed"|"turn.failed"|"item.*"|"error"}`, schema in `codex-rs/exec/src/exec_events.rs`). On quota the orchestrator sees `{"type":"error","message":"..."}` followed by `{"type":"turn.failed","error":{"message":"..."}}`. **The JSONL drops the structured `codex_error_info` and `resets_at` epoch** — only the human Display string survives. Process exit code is **1** for any failed turn; not specific to quota.
- The canonical message patterns are produced by `UsageLimitReachedError::Display` (`codex-rs/protocol/src/error.rs:453–517`). The most reliable substring is `"You've hit your usage limit"` (case-insensitive); reset time is embedded as `"Try again at <HH:MM AM/PM>"` (same day) / `"Try again at <Mon Dth, YYYY HH:MM AM/PM>"` (later) or `"Try again later."` if `resets_at` was missing. Plan-specific suffixes mention Pro/Plus upgrade URLs or "send a request to your admin" (Team/Business/Enterprise CBP).
- Account-level vs key-level is determined by which auth path is in use. Subscription requests carry `ChatGPT-Account-Id: <uuid>` (set in `codex-rs/backend-client/src/client.rs:213–218`, value from cached id-token `tokens.id_token.chatgpt_account_id`). Workspace-aware quotas come back with `RateLimitReachedType` = `WorkspaceOwnerUsageLimitReached` / `WorkspaceMemberUsageLimitReached` / `WorkspaceOwner|MemberCreditsDepleted` / `RateLimitReached` (`codex-rs/protocol/src/protocol.rs:2083–2089`). API-key auth never sends `ChatGPT-Account-Id`; quotas are org/key-scoped and arrive as generic 429s or SSE `insufficient_quota`.
- Recommended orchestrator detection (against `codex exec --json` stdout): on `turn.failed`, regex the message — `/^You've hit your usage limit\b/` ⇒ this account is cooked until the parsed `Try again at <time>` (or default ~1h if "Try again later."); `/^Quota exceeded\./` ⇒ API-key billing exhausted; `/^To use Codex with your ChatGPT plan, upgrade to Plus/` ⇒ plan doesn't entitle Codex (permanent); `/^exceeded retry limit, last status: 429/` ⇒ generic 429 cooldown (conservative ~60s); `/^Selected model is at capacity\./` ⇒ transient; `/^We're currently experiencing high demand/` ⇒ transient.
- If you can switch off `codex exec` to the app-server / MCP server protocol, you get structured `ErrorEvent { codex_error_info: "usage_limit_exceeded", ... }` and `TokenCountEvent { rate_limits: { primary: { resets_at: <epoch> }, secondary: {...}, plan_type, rate_limit_reached_type } }` — significantly cleaner than scraping prose.

---

# Detailed summary

When the ChatGPT-subscription user runs out of quota, the OpenAI/ChatGPT backend returns HTTP **429** with body `{"error":{"type":"usage_limit_reached","plan_type":"...","resets_at":<epoch>}}` plus a family of `x-codex-*` rate-limit headers (`x-codex-primary-used-percent`, `x-codex-primary-window-minutes`, `x-codex-primary-reset-at`, the `secondary-*` counterparts, `x-codex-limit-name`, `x-codex-active-limit`, `x-codex-promo-message`). The "5-hour" cap is `primary` and the "weekly" cap is `secondary`. Codex decodes this in `codex-rs/codex-api/src/api_bridge.rs:80–106` and turns it into `CodexErr::UsageLimitReached(UsageLimitReachedError { plan_type, resets_at, rate_limits, promo_message })`. Adjacent body types `"usage_not_included"` (plan doesn't entitle Codex) and the SSE-stream `response.failed` codes `insufficient_quota`, `rate_limit_exceeded`, `server_is_overloaded`/`slow_down`, `context_length_exceeded`, `cyber_policy` produce sibling `CodexErr` variants (`UsageNotIncluded`, `QuotaExceeded`, `Stream{delay}`, `ServerOverloaded`, etc.). A 429 with a body that does *not* match `usage_limit_reached` / `usage_not_included` falls through to `CodexErr::RetryLimit { status: 429 }` only after the transport has exhausted `request_max_retries` (default 4, `codex-rs/model-provider-info/src/lib.rs:28`).

Internal retry behavior: `is_retryable()` in `codex-rs/protocol/src/error.rs:170–206` marks all of `UsageLimitReached`, `QuotaExceeded`, `UsageNotIncluded`, `ServerOverloaded`, `RetryLimit`, `CyberPolicy` as **non-retryable** — codex returns immediately to the caller. Only `Stream`, `Timeout`, `UnexpectedStatus`, `ResponseStreamFailed`, `ConnectionFailed`, `InternalServerError`, IO/JSON errors are retried. The retry loop (`codex-rs/core/src/session/turn.rs:1075–1142`) honors a server-supplied delay when present (parsed from SSE `"try again in N s|ms"` text by `try_parse_retry_after` in `codex-rs/codex-api/src/sse/responses.rs:521–545`, requires `error.code == "rate_limit_exceeded"`); otherwise it uses `backoff(attempt) = 200ms × 2^(attempt-1) × jitter[0.9,1.1)` (`codex-rs/core/src/util.rs:11–12,88–93`). **The HTTP `Retry-After` header is not parsed anywhere.** The only authoritative reset timestamp is `resets_at` (unix epoch seconds) from the JSON body for usage-limit errors.

At the wire/protocol layer (`codex-rs/protocol/src/protocol.rs:1700–1731`), all three of `UsageLimitReached`, `QuotaExceeded`, `UsageNotIncluded` collapse into `CodexErrorInfo::UsageLimitExceeded` (`error.rs:219–221`). A generic 429 becomes `ResponseTooManyFailedAttempts { http_status_code: 429 }`. `ServerOverloaded` and `InternalServerError` are their own discriminators. `ErrorEvent` (`protocol.rs:1905`) carries `codex_error_info: Option<CodexErrorInfo>` alongside the message; `TokenCountEvent` (`protocol.rs:2066`) carries the structured `RateLimitSnapshot` with `primary`/`secondary` windows (each with `used_percent`, `window_minutes`, `resets_at` epoch), `credits`, `plan_type`, and `rate_limit_reached_type` (`RateLimitReached` / `WorkspaceOwner|MemberCreditsDepleted` / `WorkspaceOwner|MemberUsageLimitReached`).

**Inside `codex exec --json` the structured info is mostly thrown away.** The JSONL schema (`codex-rs/exec/src/exec_events.rs:9–91`) defines a `ThreadEvent` enum with type tags `thread.started`, `turn.started`, `turn.completed`, `turn.failed`, `item.started`, `item.updated`, `item.completed`, `error`. The `error` and `turn.failed` payloads contain only `{ "message": "<string>" }` — no `codex_error_info`, no `resets_at`, no `RateLimitSnapshot`. The conversion is at `event_processor_with_jsonl_output.rs:432–541`. So orchestrators driving `codex exec --json` must regex the message. The strings come from `UsageLimitReachedError::Display` (`error.rs:453–517`) and are plan-specific: `"You've hit your usage limit. Upgrade to Pro (https://chatgpt.com/explore/pro), visit https://chatgpt.com/codex/settings/usage to purchase more credits Try again at <time>."` (Plus), `"You've hit your usage limit. ... send a request to your admin Try again at <time>."` (Team/Business/EnterpriseCBP), `"You've hit your usage limit. Upgrade to Plus to continue using Codex ..."` (Free/Go), `"You've hit your usage limit. Visit https://chatgpt.com/codex/settings/usage to purchase more credits Try again at <time>."` (Pro/ProLite), `"You've hit your usage limit. Try again at <time>."` (Enterprise/Edu/Unknown), plus model-scoped `"You've hit your usage limit for <limit_name>. Switch to another model now, or try again at <time>."`. If `resets_at` was missing, the suffix is `"Try again later."` instead of `"Try again at <time>."`. The bare static variants are `"Quota exceeded. Check your plan and billing details."` (QuotaExceeded), `"To use Codex with your ChatGPT plan, upgrade to Plus: https://chatgpt.com/explore/plus."` (UsageNotIncluded), `"Selected model is at capacity. Please try a different model."` (ServerOverloaded), `"We're currently experiencing high demand, which may cause temporary errors."` (InternalServerError), and `"exceeded retry limit, last status: 429 ..."` (RetryLimit).

**Output channels and exit code**: JSONL events and human turn output go to **stdout** (`println!`, `event_processor_with_jsonl_output.rs:105`). Internal retry/connection messages go to **stderr** through `tracing` (`warn!` etc.), e.g. `"stream disconnected - retrying sampling request ({retries}/{max_retries} in {delay:?})..."` at `session/turn.rs:1120`. The non-interactive process **exits with `1`** on any `TurnStatus::Failed` or `TurnStatus::Interrupted` (`exec/src/lib.rs:832,878–887,931–934`); there is no dedicated exit code for quota. So **exit code 1 + a JSONL `turn.failed` whose message starts with `You've hit your usage limit` is the canonical detection pattern** for an account-level cooldown when using `codex exec --json`.

**Account- vs key-level**: The `ChatGPT-Account-Id` header (HTTP header name `ChatGPT-Account-Id`, lowercase `chatgpt-account-id`, sent by `codex-rs/backend-client/src/client.rs:213–218` and on the responses path via the model provider) ties subscription requests to a specific ChatGPT account/workspace. The account id comes from the cached login token (`tui/src/local_chatgpt_auth.rs:32–37`). Quotas under this header are workspace-scoped; the response's `RateLimitReachedType` (`WorkspaceOwner*` vs `WorkspaceMember*`) tells you whose pocket the depletion came from. API-key auth never sends this header; quotas are enforced per-org-key and come back either as generic 429s (→ `RetryLimit` after retries) or as mid-stream `insufficient_quota` / `rate_limit_exceeded`. There is no per-account `Retry-After` propagated through codex; the only reliable cooldown signal is the `resets_at` epoch in the 429 body — which, under `codex exec --json`, the orchestrator must scrape out of the human-formatted message ("Try again at 9:30 AM" or "Try again at May 12th, 2026 9:30 AM").

**Detection cookbook for an orchestrator on top of `codex exec --json`**:
1. Read JSONL events; trigger on `{"type":"turn.failed",...}` (and the preceding `{"type":"error",...}`).
2. Regex `message` field:
   - `/^You've hit your usage limit\b/` → account/plan/workspace cap. Extract reset with `/Try again at ([^.]+)\./` (HH:MM AM/PM same-day, or `Mon Dth, YYYY HH:MM AM/PM` later day) or fall through to `/Try again later\./` (no known reset; back off conservatively, e.g. 1h). When `for <limit_name>` is present, only that specific limit is exhausted — switching model may help.
   - `/^Quota exceeded\./` → API-key billing exhausted, no retry.
   - `/^To use Codex with your ChatGPT plan, upgrade to Plus/` → plan doesn't include Codex; permanent until upgrade.
   - `/^exceeded retry limit, last status: 429/` → generic 429 after retries exhausted; no `resets_at`; conservative backoff (e.g. 60s).
   - `/^Selected model is at capacity\./` → transient; switch model or wait short interval.
   - `/^We're currently experiencing high demand/` or `/^stream disconnected before completion:/` → transient.
3. Exit code is always 1 on failure; do not use it to distinguish.
4. If you can move off `codex exec` to the app-server / MCP server interface, use `ErrorEvent.codex_error_info == "usage_limit_exceeded"` and `TokenCountEvent.rate_limits.primary.resets_at` (epoch seconds) directly — much cleaner than message-regex.

---

## Extensive findings: how `codex exec` surfaces quota/rate-limit errors

All file paths are inside the Codex source tree at `/Users/johntokash/Downloads/codex/`. Line numbers are 1-based.

## 1. The Rust error variants (server-side classification)

File: `codex-rs/protocol/src/error.rs`

The `CodexErr` enum (the canonical core error) distinguishes several distinct flavors of "you are throttled/blocked":

```
69    pub enum CodexErr {
...
102      UnexpectedStatus(UnexpectedResponseError),
...
110      UsageLimitReached(UsageLimitReachedError),
111      #[error("Selected model is at capacity. Please try a different model.")]
112      ServerOverloaded,
...
119      #[error("Quota exceeded. Check your plan and billing details.")]
120      QuotaExceeded,
121      #[error(
122          "To use Codex with your ChatGPT plan, upgrade to Plus: https://chatgpt.com/explore/plus."
123      )]
124      UsageNotIncluded,
125      #[error("We're currently experiencing high demand, which may cause temporary errors.")]
126      InternalServerError,
127      /// Retry limit exceeded.
128      #[error("{0}")]
129      RetryLimit(RetryLimitReachedError),
```

The `UsageLimitReachedError` struct itself (`codex-rs/protocol/src/error.rs` lines 446–517) is the rich, structured payload:

```
446  pub struct UsageLimitReachedError {
447      pub plan_type: Option<PlanType>,
448      pub resets_at: Option<DateTime<Utc>>,
449      pub rate_limits: Option<Box<RateLimitSnapshot>>,
450      pub promo_message: Option<String>,
451  }
```

Its `Display` impl (lines 453–517) is what becomes the human-readable error string. Key user-visible strings produced (these are the patterns an orchestrator can match on if it only has stderr/log text):

- `You've hit your usage limit. Upgrade to Pro (https://chatgpt.com/explore/pro), visit https://chatgpt.com/codex/settings/usage to purchase more credits Try again at <time>.` (Plus plan, line 480)
- `You've hit your usage limit. To get more access now, send a request to your admin Try again at <time>.` (Team/Business/Enterprise CBP, line 490)
- `You've hit your usage limit. Upgrade to Plus to continue using Codex (https://chatgpt.com/explore/plus), Try again at <time>.` (Free/Go, line 496)
- `You've hit your usage limit. Visit https://chatgpt.com/codex/settings/usage to purchase more credits Try again at <time>.` (Pro/ProLite, line 501)
- `You've hit your usage limit. Try again at <time>.` (Enterprise/Edu/Unknown, lines 506–512)
- When a specific limit name is present (not just "codex"): `You've hit your usage limit for <limit_name>. Switch to another model now, or try again at <time>.` (lines 463–467)
- When `resets_at` is missing the suffix is just `Try again later.` (line 524) instead of `Try again at <time>.`.

The static fallback strings on the other variants:

- `QuotaExceeded`  →  `"Quota exceeded. Check your plan and billing details."` (line 119)
- `UsageNotIncluded`  →  `"To use Codex with your ChatGPT plan, upgrade to Plus: https://chatgpt.com/explore/plus."` (line 121)
- `ServerOverloaded`  →  `"Selected model is at capacity. Please try a different model."` (line 111)
- `InternalServerError`  →  `"We're currently experiencing high demand, which may cause temporary errors."` (line 125)

### `is_retryable()`

`codex-rs/protocol/src/error.rs` lines 169–206 classifies every variant. Important: **none of the quota/usage variants are retryable**:

```
170      pub fn is_retryable(&self) -> bool {
171          match self {
...
176              | CodexErr::UsageNotIncluded
177              | CodexErr::QuotaExceeded
...
190              | CodexErr::UsageLimitReached(_)
191              | CodexErr::ServerOverloaded
192              | CodexErr::CyberPolicy { .. } => false,
193              CodexErr::Stream(..)
194              | CodexErr::Timeout
195              | CodexErr::UnexpectedStatus(_)
...                                          => true,
```

That is: `Stream`, `Timeout`, `UnexpectedStatus`, `ResponseStreamFailed`, `ConnectionFailed`, `InternalServerError`, IO/JSON/tokio-join errors are auto-retried; usage-limit and quota errors are surfaced immediately and abort the turn.

### `CodexErrorInfo` (the wire-level error enum)

The error variants are bucketed into a smaller protocol-level enum that is emitted on the wire to clients. `codex-rs/protocol/src/error.rs` lines 216–243:

```
216      pub fn to_codex_protocol_error(&self) -> CodexErrorInfo {
...
219              CodexErr::UsageLimitReached(_)
220              | CodexErr::QuotaExceeded
221              | CodexErr::UsageNotIncluded => CodexErrorInfo::UsageLimitExceeded,
222              CodexErr::ServerOverloaded => CodexErrorInfo::ServerOverloaded,
...
224              CodexErr::RetryLimit(_) => CodexErrorInfo::ResponseTooManyFailedAttempts {
225                  http_status_code: self.http_status_code_value(),
226              },
```

So **all three of `UsageLimitReached`, `QuotaExceeded`, `UsageNotIncluded` collapse to `CodexErrorInfo::UsageLimitExceeded`** at the wire level (`codex-rs/protocol/src/protocol.rs` line 1702).

`CodexErrorInfo` definition, `codex-rs/protocol/src/protocol.rs` lines 1700–1731:

```
1700  pub enum CodexErrorInfo {
1701      ContextWindowExceeded,
1702      UsageLimitExceeded,
1703      ServerOverloaded,
1704      CyberPolicy,
1705      HttpConnectionFailed { http_status_code: Option<u16> },
1706      ResponseStreamConnectionFailed { http_status_code: Option<u16> },
1707      InternalServerError,
1708      Unauthorized,
1709      BadRequest,
1710      SandboxError,
1711      ResponseStreamDisconnected { http_status_code: Option<u16> },
1712      ResponseTooManyFailedAttempts { http_status_code: Option<u16> },
1713      ActiveTurnNotSteerable { turn_kind: NonSteerableTurnKind },
1714      ThreadRollbackFailed,
1715      Other,
1716  }
```

This means that on the JSON wire, the discriminator for a quota error is `codex_error_info: "usage_limit_exceeded"` (snake_case enum, see `#[serde(rename_all = "snake_case")]` line 1698).

## 2. Where the error is constructed: 429 mapping

File: `codex-rs/codex-api/src/api_bridge.rs` lines 80–106. This is the **canonical place HTTP 429s are decoded**:

```
80                  } else if status == http::StatusCode::TOO_MANY_REQUESTS {
81                      if let Ok(err) = serde_json::from_str::<UsageErrorResponse>(&body_text) {
82                          if err.error.error_type.as_deref() == Some("usage_limit_reached") {
83                              let limit_id = extract_header(headers.as_ref(), ACTIVE_LIMIT_HEADER);
84                              let rate_limits = headers.as_ref().and_then(|map| {
85                                  parse_rate_limit_for_limit(map, limit_id.as_deref())
86                              });
87                              let promo_message = headers.as_ref().and_then(parse_promo_message);
88                              let resets_at = err
89                                  .error
90                                  .resets_at
91                                  .and_then(|seconds| DateTime::<Utc>::from_timestamp(seconds, 0));
92                              return CodexErr::UsageLimitReached(UsageLimitReachedError {
93                                  plan_type: err.error.plan_type,
94                                  resets_at,
95                                  rate_limits: rate_limits.map(Box::new),
96                                  promo_message,
97                              });
98                          } else if err.error.error_type.as_deref() == Some("usage_not_included") {
99                              return CodexErr::UsageNotIncluded;
100                         }
101                     }
102 
103                     CodexErr::RetryLimit(RetryLimitReachedError {
104                         status,
105                         request_id: extract_request_tracking_id(headers.as_ref()),
106                     })
107                 } else {
```

Key observations:
- 429 + JSON body containing `"type": "usage_limit_reached"` → `UsageLimitReached` (sticky, no retry, account-level "cooked").
- 429 + body `"type": "usage_not_included"` → `UsageNotIncluded` (the ChatGPT plan doesn't include Codex usage at all).
- 429 with **any other body** (or unparseable) → `RetryLimit(RetryLimitReachedError { status: 429, ... })`. **This means a generic 429 (e.g. an API-key rate-limit ceiling) ends up as `RetryLimit`, not `UsageLimitReached`.** The RetryLimit variant is what surfaces after the codex-client transport has exhausted its retries.
- The `UsageErrorResponse` body shape (lines 179–190) is:
  ```
  179 struct UsageErrorResponse { error: UsageErrorBody }
  184 struct UsageErrorBody {
  186     #[serde(rename = "type")] error_type: Option<String>,
  188     plan_type: Option<PlanType>,
  189     resets_at: Option<i64>,
  190 }
  ```
  `resets_at` is a unix epoch in seconds.

Also note the special-cased 503 handling immediately above (lines 45–56): a 503 with body `{"error":{"code":"server_is_overloaded"|"slow_down"}}` returns `CodexErr::ServerOverloaded` (still non-retryable). Plain 500 → `InternalServerError` (retryable). 400 → `InvalidRequest` (non-retryable) unless the body matches the cyber-policy or invalid-image patterns.

### SSE-stream `response.failed` mapping

`codex-rs/codex-api/src/sse/responses.rs` lines 346–391. Inside a streaming response, if the server emits `event: response.failed`, codex inspects `response.error.code`:

```
352                  if is_context_window_error(&error) {
353                      response_error = ApiError::ContextWindowExceeded;
354                  } else if is_quota_exceeded_error(&error) {
355                      response_error = ApiError::QuotaExceeded;
356                  } else if is_usage_not_included(&error) {
357                      response_error = ApiError::UsageNotIncluded;
...
366                  } else if is_server_overloaded_error(&error) {
367                      response_error = ApiError::ServerOverloaded;
368                  } else {
369                      let delay = try_parse_retry_after(&error);
370                      let message = error.message.unwrap_or_default();
371                      response_error = ApiError::Retryable { message, delay };
372                  }
```

The relevant codes (lines 547–570):

```
547  fn is_context_window_error(error: &Error) -> bool { error.code.as_deref() == Some("context_length_exceeded") }
551  fn is_quota_exceeded_error(error: &Error) -> bool { error.code.as_deref() == Some("insufficient_quota") }
555  fn is_usage_not_included(error: &Error) -> bool { error.code.as_deref() == Some("usage_not_included") }
559  fn is_invalid_prompt_error(error: &Error) -> bool { error.code.as_deref() == Some("invalid_prompt") }
563  fn is_cyber_policy_error(error: &Error) -> bool { error.code.as_deref() == Some("cyber_policy") }
567  fn is_server_overloaded_error(error: &Error) -> bool {
568      error.code.as_deref() == Some("server_is_overloaded")
569          || error.code.as_deref() == Some("slow_down")
570  }
```

So during streaming the catalogue of error codes that map to terminal/quota states is: `context_length_exceeded`, `insufficient_quota` (→ `QuotaExceeded`), `usage_not_included` (→ `UsageNotIncluded`), `cyber_policy`, `server_is_overloaded` / `slow_down` (→ `ServerOverloaded`). Anything else with a `try again in <N> s|ms|seconds` phrase produces `ApiError::Retryable { delay }` (lines 521–544, with a regex `(?i)try again in\s*(\d+(?:\.\d+)?)\s*(s|ms|seconds?)`), and the code path requires the error `code` to be exactly `"rate_limit_exceeded"` (line 522).

### Rate-limit headers parsed alongside the 429 body

`codex-rs/codex-api/src/rate_limits.rs` lines 60–96 / 162–166. Codex looks for header families of the form `x-<limit_id>-...` (default `limit_id = "codex"`, lowercased and underscores swapped for dashes):

```
65      let prefix = format!("x-{normalized_limit}");
66      let primary = parse_rate_limit_window(
67          headers,
68          &format!("{prefix}-primary-used-percent"),
69          &format!("{prefix}-primary-window-minutes"),
70          &format!("{prefix}-primary-reset-at"),
71      );
72  
73      let secondary = parse_rate_limit_window(
74          headers,
75          &format!("{prefix}-secondary-used-percent"),
76          &format!("{prefix}-secondary-window-minutes"),
77          &format!("{prefix}-secondary-reset-at"),
78      );
...
80      let credits = parse_credits_snapshot(headers);
81      let limit_name_header = format!("{prefix}-limit-name");
```

In `codex-rs/codex-api/src/api_bridge.rs`:

```
135  const ACTIVE_LIMIT_HEADER: &str = "x-codex-active-limit";
```

`x-codex-active-limit` selects which limit family the server says was just hit; codex then parses `x-<that-limit>-primary-...` / `-secondary-...` headers into a `RateLimitSnapshot`. So for the ChatGPT subscription path the well-known headers are:
- `x-codex-primary-used-percent`, `x-codex-primary-window-minutes`, `x-codex-primary-reset-at` (the "5-hour" / "primary" cap)
- `x-codex-secondary-used-percent`, `x-codex-secondary-window-minutes`, `x-codex-secondary-reset-at` (the "weekly" / "secondary" cap)
- `x-codex-limit-name`
- `x-codex-promo-message`
- `x-codex-active-limit` (which limit name to actually consult; may be different from `codex`, e.g. `codex_other` for per-model limits)

Confirmation from the test fixture, `codex-rs/core/tests/suite/client.rs` lines 2611–2626:

```
2613      let response = ResponseTemplate::new(429)
2614          .insert_header("x-codex-primary-used-percent", "100.0")
2615          .insert_header("x-codex-secondary-used-percent", "87.5")
2616          .insert_header("x-codex-primary-over-secondary-limit-percent", "95.0")
2617          .insert_header("x-codex-primary-window-minutes", "15")
2618          .insert_header("x-codex-secondary-window-minutes", "60")
2619          .set_body_json(json!({
2620              "error": {
2621                  "type": "usage_limit_reached",
2622                  "message": "limit reached",
2623                  "resets_at": 1704067242,
2624                  "plan_type": "pro"
2625              }
2626          }));
```

So in production the canonical "5-hour cap" maps to `primary` (`window_minutes` ~ 300) and the "weekly cap" maps to `secondary` (`window_minutes` ~ 10080). The `resets_at` (epoch seconds) is what `UsageLimitReachedError.resets_at` is populated from — that is the only authoritative "back off until" timestamp.

### `Retry-After`

There is **no parsing of the HTTP `Retry-After` response header** for the non-streaming path. The two delay sources Codex actually honors are:

1. The JSON body's `resets_at` epoch on a 429 (set on `UsageLimitReachedError.resets_at`).
2. The error message regex `try again in <N> s|ms|seconds?` on SSE `response.failed` events with code `rate_limit_exceeded` (`codex-rs/codex-api/src/sse/responses.rs` lines 521–545); this becomes `ApiError::Retryable { delay }` and then `CodexErr::Stream(msg, Some(delay))` in `codex-rs/codex-api/src/api_bridge.rs` line 22 — but this path is only used during transient stream-level retries (not for hard quota).

(There is a *separate* `retry_after_unauthorized` boolean used by the 401 reauth flow in `codex-rs/core/src/client.rs` — that has nothing to do with rate limits; it controls whether a 401 should trigger a forced token refresh.)

## 3. Internal retry/backoff in core

File: `codex-rs/core/src/util.rs`:

```
11   const INITIAL_DELAY_MS: u64 = 200;
12   const BACKOFF_FACTOR: f64 = 2.0;
...
88   pub fn backoff(attempt: u64) -> Duration {
89       let exp = BACKOFF_FACTOR.powi(attempt.saturating_sub(1) as i32);
90       let base = (INITIAL_DELAY_MS as f64 * exp) as u64;
91       let jitter = rand::rng().random_range(0.9..1.1);
92       Duration::from_millis((base as f64 * jitter) as u64)
93   }
```

Exponential 200ms base × 2^attempt with ±10% jitter.

Retry budget caps in `codex-rs/model-provider-info/src/lib.rs`:

```
27   const DEFAULT_STREAM_MAX_RETRIES: u64 = 5;
28   const DEFAULT_REQUEST_MAX_RETRIES: u64 = 4;
30   const MAX_STREAM_MAX_RETRIES: u64 = 100;
33   const MAX_REQUEST_MAX_RETRIES: u64 = 100;
```

The stream-retry loop in `codex-rs/core/src/session/turn.rs` lines 1075–1142:

```
1075          Err(CodexErr::ContextWindowExceeded) => { ...; return Err(...); }
1079          Err(CodexErr::UsageLimitReached(e)) => {
1080              let rate_limits = e.rate_limits.clone();
1081              if let Some(rate_limits) = rate_limits {
1082                  sess.update_rate_limits(&turn_context, *rate_limits).await;
1083              }
1084              return Err(CodexErr::UsageLimitReached(e));
1085          }
1086          Err(err) => err,
1087      };
1088
1089      if !err.is_retryable() {
1090          return Err(err);
1091      }
...
1094      let max_retries = turn_context.provider.info().stream_max_retries();
...
1111      if retries < max_retries {
1112          retries += 1;
1113          let delay = match &err {
1114              CodexErr::Stream(_, requested_delay) => {
1115                  requested_delay.unwrap_or_else(|| backoff(retries))
1116              }
1117              _ => backoff(retries),
1118          };
```

So:
- **`UsageLimitReached` is returned immediately on the first hit; codex does not retry it at all.** It also pushes the parsed `RateLimitSnapshot` into the session so a `TokenCount` event still fires with the latest window stats before the error is surfaced.
- `Stream(_, Some(delay))` (the "try again in N seconds" path) honors the server-provided delay; otherwise it falls back to `backoff(attempt)`.
- The hard 429-but-not-`usage_limit_reached` case becomes `RetryLimit` (already marks non-retryable). That's the variant that, by the time it bubbles up, has already been retried `request_max_retries` times by the transport.

## 4. How this surfaces from `codex exec` (non-interactive)

`codex exec` is the non-interactive front-end (`codex-rs/exec/`). It runs an in-process app-server and converts the protocol events into either human stdout text (default) or JSONL events (`--json`).

### JSONL event shape

`codex-rs/exec/src/exec_events.rs` lines 9–37, 54–91:

```
11   pub enum ThreadEvent {
13       #[serde(rename = "thread.started")]    ThreadStarted(ThreadStartedEvent),
17       #[serde(rename = "turn.started")]      TurnStarted(TurnStartedEvent),
20       #[serde(rename = "turn.completed")]    TurnCompleted(TurnCompletedEvent),
23       #[serde(rename = "turn.failed")]       TurnFailed(TurnFailedEvent),
26       #[serde(rename = "item.started")]      ItemStarted(ItemStartedEvent),
29       #[serde(rename = "item.updated")]      ItemUpdated(ItemUpdatedEvent),
32       #[serde(rename = "item.completed")]    ItemCompleted(ItemCompletedEvent),
36       #[serde(rename = "error")]             Error(ThreadErrorEvent),
37   }
...
55   pub struct TurnFailedEvent { pub error: ThreadErrorEvent }
...
89   pub struct ThreadErrorEvent { pub message: String }
```

Note: `ThreadErrorEvent` and `TurnFailedEvent.error` contain only a `message` string. **The structured `codex_error_info` discriminator (`UsageLimitExceeded`) is *not* preserved in the codex-exec JSONL output.** Orchestrators using `codex exec --json` must pattern-match on the human-readable `message` text (the `UsageLimitReachedError` Display from §1).

The conversion from the internal `ServerNotification::Error` / `ServerNotification::TurnCompleted{status: Failed}` happens in `codex-rs/exec/src/event_processor_with_jsonl_output.rs`:

```
432              ServerNotification::Error(notification) => {
433                  let message = match notification.error.additional_details {
434                      Some(details) if !details.is_empty() => {
435                          format!("{} ({details})", notification.error.message)
436                      }
437                      _ => notification.error.message,
438                  };
439                  let error = ThreadErrorEvent { message };
440                  self.last_critical_error = Some(error.clone());
441                  events.push(ThreadEvent::Error(error));
...
523                  TurnStatus::Failed => {
524                      self.final_message = None;
525                      self.emit_final_message_on_shutdown = false;
526                      let error = notification
527                          .turn
528                          .error
529                          .map(|error| ThreadErrorEvent {
530                              message: match error.additional_details {
531                                  Some(details) if !details.is_empty() => {
532                                      format!("{} ({details})", error.message)
533                                  }
534                                  _ => error.message,
535                              },
536                          })
537                          .or_else(|| self.last_critical_error.clone())
538                          .unwrap_or_else(|| ThreadErrorEvent {
539                              message: "turn failed".to_string(),
540                          });
541                      events.push(ThreadEvent::TurnFailed(TurnFailedEvent { error }));
542                      CodexStatus::InitiateShutdown
543                  }
```

So under `--json`, a quota event produces (roughly, with all the surrounding turn events):

```
{"type":"error","message":"You've hit your usage limit. ... Try again at 9:30 AM."}
{"type":"turn.failed","error":{"message":"You've hit your usage limit. ... Try again at 9:30 AM."}}
```

Both events carry the same `UsageLimitReachedError` Display string. (Side note: the `error.message` text on the wire is whatever `CodexErr::to_string()` returned, which already includes the reset time when the server provided one.)

### Human (default) output

`codex-rs/exec/src/event_processor_with_human_output.rs` lines 120–150: on `TurnCompleted` with `status=Failed` it prints the error message in red along with the exit code if known. There is no structured marker — just the rendered string from above.

### stderr vs stdout

`codex exec` writes JSONL events and human turn output to **stdout** (via `println!`, see `codex-rs/exec/src/event_processor_with_jsonl_output.rs` line 105). `stderr` carries `tracing` logs (`warn!`, `info!`, `debug!`) — for example "thread/unsubscribe failed during shutdown" or stream-retry warnings. Useful retry traces such as
`"stream disconnected - retrying sampling request ({retries}/{max_retries} in {delay:?})..."` (`codex-rs/core/src/session/turn.rs` line 1120) go through `warn!` and therefore stderr (when logging is enabled).

### Exit code

`codex-rs/exec/src/lib.rs` lines 829–934 (in particular 870–888, 928–934):

```
829  // Run the loop until the task is complete.
830  // Track whether a fatal error was reported by the server so we can
831  // exit with a non-zero status for automation-friendly signaling.
832  let mut error_seen = false;
...
870              InProcessServerEvent::ServerNotification(mut notification) => {
871                  if let ServerNotification::Error(payload) = &notification {
872                      if payload.thread_id == primary_thread_id_for_requests
873                          && payload.turn_id == task_id
874                          && !payload.will_retry
875                      {
876                          error_seen = true;
877                      }
878                  } else if let ServerNotification::TurnCompleted(payload) = &notification
879                      && payload.thread_id == primary_thread_id_for_requests
880                      && payload.turn.id == task_id
881                      && matches!(
882                          payload.turn.status,
883                          codex_app_server_protocol::TurnStatus::Failed
884                              | codex_app_server_protocol::TurnStatus::Interrupted
885                      )
886                  {
887                      error_seen = true;
888                  }
...
931      event_processor.print_final_output();
932      if error_seen {
933          std::process::exit(1);
934      }
```

The non-interactive process exits with **`1`** (generic) on a turn that ended in `Failed` or `Interrupted`, including the quota cases. There is no dedicated exit code that distinguishes "quota" from "context-window" from "tool failed" — `1` is overloaded. The numerous other `std::process::exit(1)` sites in `lib.rs` (auth setup, login, etc.) likewise all return 1. So **exit code alone is insufficient** to identify a quota event.

## 5. ChatGPT-Account-Id header (account-level identity)

The header is sent on requests that hit the ChatGPT backend (subscription auth path), e.g. `codex-rs/backend-client/src/client.rs` lines 205–225:

```
205      fn headers(&self) -> HeaderMap {
206          let mut h = HeaderMap::new();
...
212          self.auth_provider.add_auth_headers(&mut h);
213          if let Some(acc) = &self.chatgpt_account_id
214              && let Ok(name) = HeaderName::from_bytes(b"ChatGPT-Account-Id")
215              && let Ok(hv) = HeaderValue::from_str(acc)
216          {
217              h.insert(name, hv);
218          }
```

The account id is sourced from the cached id-token (`tokens.id_token.chatgpt_account_id`, see `codex-rs/tui/src/local_chatgpt_auth.rs` lines 32–37). The 429 / `usage_limit_reached` decision on the server is made against *this* account id (workspace owner vs member, plan type). The mapping for "who owns the depleted quota" comes back as `RateLimitReachedType` (`codex-rs/protocol/src/protocol.rs` lines 2083–2089):

```
2083  pub enum RateLimitReachedType {
2084      RateLimitReached,
2085      WorkspaceOwnerCreditsDepleted,
2086      WorkspaceMemberCreditsDepleted,
2087      WorkspaceOwnerUsageLimitReached,
2088      WorkspaceMemberUsageLimitReached,
2089  }
```

These values come over in `RateLimitSnapshot.rate_limit_reached_type` and tell the UI whether the *owner* or a *member* of the workspace is the one whose quota tripped — relevant for orchestrators routing across multiple ChatGPT accounts.

## 6. API-key 429s vs subscription-quota 429s

Both flow through the same `api_bridge.rs` 429 handler (§2). The discriminator is **purely the body shape**:

- API-key 429 from `api.openai.com` / `/v1/responses`: typically returns a generic OpenAI error body. Unless the body has `"error.type" == "usage_limit_reached"` it is *not* mapped to `UsageLimitReached`. It hits the fallthrough at line 103 → `CodexErr::RetryLimit { status: 429, request_id }`. **No `resets_at`, no `RateLimitSnapshot`** because there are no `x-codex-*` headers in front of the OpenAI API.
- A 429 surfaced *mid-stream* via SSE `response.failed` with `error.code == "insufficient_quota"` → `ApiError::QuotaExceeded` → `CodexErr::QuotaExceeded` (also `UsageLimitExceeded` on the wire).
- A 429 surfaced *mid-stream* via SSE with `error.code == "rate_limit_exceeded"` and a `"Please try again in N seconds"` message → `ApiError::Retryable { delay }` → transient, will be retried.
- Subscription path (`chatgpt.com/backend-api/codex`, see `CHATGPT_CODEX_BASE_URL` in `codex-rs/model-provider-info/src/lib.rs` line 37): 429 with body `{ "error": { "type": "usage_limit_reached", "plan_type": "...", "resets_at": <epoch> } }` plus `x-codex-*` headers → full `UsageLimitReached` payload with reset timestamp.

Note also that the codex-client transport has its own retry budget (`request_max_retries`, default 4 — `codex-rs/model-provider-info/src/lib.rs` line 28). When the underlying transport sees an HTTP error it can retry the request. But because `api_bridge.rs::map_api_error` explicitly identifies 429+`usage_limit_reached` and creates `CodexErr::UsageLimitReached` (not via `ApiError::Retryable`), there is no transport-level retry of that case — it short-circuits.

For a "vanilla" 429 (no `usage_limit_reached` body), the transport exhausts `request_max_retries` and only *then* surfaces `RetryLimit { status: 429 }`. On the wire that becomes `CodexErrorInfo::ResponseTooManyFailedAttempts { http_status_code: 429 }` (`codex-rs/protocol/src/error.rs` lines 224–226) — distinct from `UsageLimitExceeded`.

## 7. Account-level vs key-level

- `chatgpt-account-id` header (§5) ties the request to a particular ChatGPT workspace+account. The server enforces the account/workspace quota; the 429 body's `plan_type` and `resets_at` come from that account's plan.
- API-key auth does not send `ChatGPT-Account-Id`. Quotas are enforced per-org/key by the OpenAI API and arrive as either plain 429s (after `request_max_retries` → `RetryLimit`) or `response.failed` events with `insufficient_quota` / `rate_limit_exceeded`.
- The orchestrator can use the presence of `chatgpt-account-id` (or, more usefully, the codex auth mode) to know *whose* quota tripped. It can also rely on the structured `RateLimitReachedType` workspace-owner/member values when codex re-emits them (only on the subscription path).

## 8. What an orchestrator should pattern-match

If you are scraping `codex exec --json` output:

1. **Watch for `{"type":"turn.failed", ...}`**. That is the unambiguous terminal signal that the run aborted. There is also an earlier `{"type":"error", ...}` event carrying the same message.
2. **Pattern-match the `error.message` string**:
   - `^You've hit your usage limit\b` → **account-level usage cap hit** (subscription). The message also embeds `Try again at <HH:MM (AM|PM)>` (same day) or `Try again at <Mon D{st|nd|rd|th}, YYYY H:MM AM/PM>` (different day), or `Try again later.` if `resets_at` was missing. Parse the time to compute the backoff window.
   - Substring `usage limit for <name>` → per-model/per-limit cap (the user can still switch model).
   - `^Quota exceeded\.` → `QuotaExceeded` (API-key billing exhausted, or `insufficient_quota` mid-stream).
   - `^To use Codex with your ChatGPT plan, upgrade to Plus` → `UsageNotIncluded` (plan doesn't include Codex — permanent until upgraded).
   - `^Selected model is at capacity\.` → `ServerOverloaded` (treat as transient).
   - `^exceeded retry limit, last status: 429` → exhausted retries on a generic 429 (`RetryLimit`). Treat as account-cooked for a conservative backoff (e.g. 60s) since you don't have a `resets_at`.
   - `^We're currently experiencing high demand` → `InternalServerError` (transient).
3. **Exit code**: 1 on any failed turn. Not discriminating on its own.
4. **There is no `Retry-After` HTTP header propagated through codex exec stdout/stderr.** The only reset-time available to you is the human time string embedded in the message; the structured `resets_at` epoch never reaches the JSONL events (it is consumed inside core to build the Display string and to set `RateLimitSnapshot.primary/secondary.resets_at`, but neither field is part of the `exec_events.rs` schema).
5. If you can use the app-server / MCP server interface instead of `codex exec`, you get the structured `codex_error_info: "usage_limit_exceeded"` discriminator on `ErrorEvent` (`codex-rs/protocol/src/protocol.rs` line 1905, field `codex_error_info: Option<CodexErrorInfo>`), and the `RateLimitSnapshot` with epoch `resets_at` on `TokenCountEvent` (`protocol.rs` line 2066). That is the recommended source if your orchestrator can speak the app-server protocol.

### Concrete recommended detection regex (against the JSONL `message` field)

- Account/plan cap (back off until `resets_at`):
  `/^You've hit your usage limit\b/`
  Then sub-regex for reset time:
  `/Try again at ([^.]+)\./`  (HH:MM AM/PM or Mon D{th}, YYYY HH:MM AM/PM)
  or `/Try again later\./` (no reset known — back off conservatively, e.g. an hour).
- Plan doesn't include Codex (permanent):
  `/^To use Codex with your ChatGPT plan, upgrade to Plus/`
- API-key billing exhausted:
  `/^Quota exceeded\./`
- Generic exhausted 429:
  `/^exceeded retry limit, last status: 429/`
- Transient (do NOT back off the account, just retry):
  `/^Selected model is at capacity\./`
  `/^We're currently experiencing high demand/`
  `/^stream disconnected before completion:/`

## 9. Caveats / gotchas

- `codex exec --json` flattens away the structured `CodexErrorInfo` and `RateLimitSnapshot.resets_at` epoch. To get clean, machine-readable account-cooldown information you have to use the app-server / mcp-server transport, not `codex exec`.
- Stream-disconnect retries are surfaced via `warn!` to stderr only (when logs are enabled with `RUST_LOG`/`--debug`); they do not appear in `--json` stdout.
- `UsageLimitReached` is emitted as an `EventMsg::Error` on the inner protocol but the test in `codex-rs/core/tests/suite/client.rs` line 2684 confirms only that `error.message.to_lowercase().contains("usage limit")`. So **"usage limit" (case-insensitive) inside the message is the most stable substring match**.
- The 429 → `RetryLimit` fallthrough path means *not every 429 produces a "usage limit" message*. A bare 429 with non-conforming body looks like `"exceeded retry limit, last status: 429 Too Many Requests, request id: ..."` (see `RetryLimitReachedError::Display`, `codex-rs/protocol/src/error.rs` lines 431–443, and the test at `codex-rs/protocol/src/error_tests.rs` lines 129–148).
- Backoff inside core is exponential 200ms × 2^attempt with ±10% jitter (`util.rs` lines 11–12, 88–93). Streamed `try again in N` hints are honored. The HTTP `Retry-After` header is not read.
- The `chatgpt-account-id` header is added by the backend-client (and by the model-provider when talking to `chatgpt.com/backend-api/codex`); the orchestrator can choose to set/rotate this if running multiple accounts, but Codex CLI itself takes it from the cached login.
- All three of `UsageLimitReached`, `QuotaExceeded`, `UsageNotIncluded` produce the same wire-level `codex_error_info: "usage_limit_exceeded"`. If you have access to the structured event but not the message, you cannot tell "Plus user hit 5-hour cap (retry in 4 hours)" from "free user not entitled to Codex at all (never retry)" without inspecting the message text.
