# TLDR

Codex stores each conversation as an append-only JSONL "rollout" at `~/.codex/sessions/YYYY/MM/DD/rollout-<ts>-<uuid>.jsonl` (the trailing UUID is the session id), with the first line a `session_meta` record and subsequent lines tagged `response_item | event_msg | turn_context | compacted`; `~/.codex/state_5.sqlite` is a derived index, and `~/.codex/history.jsonl` is an unrelated user-prompt log. For real-time monitoring an orchestrator either spawns `codex exec --json` (stdout JSONL `ThreadEvent`s — full fidelity, gives a `thread_id` it can later pass to `codex exec resume <id>`) or `tail -F`s the rollout file (lines are flushed every write — good enough for "what just happened", but streaming deltas, approval prompts, and raw command output are deliberately not persisted). There is no FIFO, lock file, or socket — live and completed sessions look identical on disk, distinguished only by recent line timestamps.

---

## Executive summary

- **Format**: per-session append-only **JSONL** "rollout" files; one record per line, schema `{"timestamp","type","payload"}`. Defined by `RolloutLine`/`RolloutItem` in `codex-rs/protocol/src/protocol.rs:2764, 2914`. No sqlite for the transcript itself.
- **Location**: `~/.codex/sessions/YYYY/MM/DD/rollout-YYYY-MM-DDThh-mm-ss-<uuid>.jsonl`. The trailing `<uuid>` is the session/thread id, so a path uniquely identifies a session. Archived sessions move to `~/.codex/archived_sessions/...`. Path builder: `codex-rs/rollout/src/recorder.rs:1404`.
- **First line is always `session_meta`** (id, cwd, originator, cli_version, source, model_provider, base_instructions, optional `forked_from_id`, optional git). Cheap introspection helper: `read_session_meta_line()` (`codex-rs/rollout/src/list.rs:1237`).
- **Line types**: `session_meta`, `response_item` (assistant messages, reasoning, function/tool calls + outputs, web/image-gen calls, compaction), `event_msg` (terminal lifecycle events governed by `EventPersistenceMode::Limited|Extended`, `codex-rs/rollout/src/policy.rs`), `turn_context` (per-turn snapshot of model/sandbox/approval/`user_instructions`), `compacted`.
- **Not persisted**: streaming deltas, approval prompts (`RequestUserInput`, `ExecApprovalRequest`, `ApplyPatchApprovalRequest`, …), exec stdout/stderr deltas. `ExecCommandEnd` aggregated output is truncated to 10 KB (`recorder.rs:196–221`). For raw output you need the `--json` stream or the app-server.
- **Writer**: single background tokio task; every line `flush()`-ed immediately, so `tail -F` is reliable. New sessions defer file creation until first `persist()`; resume opens in append mode (`recorder.rs:686–767`).
- **Live vs completed**: byte-identical on disk; no lock/sentinel file. Liveness = recent file timestamp or `state_5.sqlite.updated_at` (touched at most every 5 s, `THREAD_UPDATED_AT_TOUCH_INTERVAL`).
- **SQLite index**: `~/.codex/state_5.sqlite` (filename versioned, see `codex-rs/state/src/lib.rs:70`; override with `CODEX_SQLITE_HOME`). Indexes all rollouts for pagination/search/filter; backfilled by scanning JSONL files. `~/.codex/logs_2.sqlite` is a separate structured-tracing sink.
- **Other files**: `~/.codex/history.jsonl` is a **separate** global user-prompt log (`{"session_id","ts","text"}`), not the transcript. TUI tracing goes to `~/.codex/log/codex-tui.log`; login to `codex-login.log`. OTEL exports are opt-in via `OtelSettings` (`codex-rs/otel/`).
- **Resume**: `codex exec resume <SESSION_ID|name>` or `codex exec resume --last`. UUID or thread name accepted. Resolution: `find_thread_path_by_id_str` (`codex-rs/rollout/src/list.rs:1400`). Recorder reopens file in append mode; history rebuilt as `InitialHistory::Resumed(ResumedHistory)` (`protocol.rs:2364`). Forks get a new id/file and reference `forked_from_id`.
- **Real-time monitoring for an orchestrator**: (1) **`codex exec --json`** stdout — full-fidelity stable `ThreadEvent` JSONL (`thread.started`/`turn.started|completed|failed`/`item.started|updated|completed`/`error`), gives `thread_id` on the first line (`codex-rs/exec/src/cli.rs:59`, `exec/src/exec_events.rs:11`). (2) **Tail the rollout JSONL** — works for any session including TUI/VSCode/Atlas, but lower fidelity (no deltas/approvals). (3) **app-server JSON-RPC** via `codex-rs/app-server/` for programmatic embedding.
- **No FIFO / socket**: there is no named pipe or Unix-socket session bus. File-watching plus `--json` stdout are the supported integration points.

---

## Detailed summary

Codex CLI persists every conversation as an append-only **JSONL "rollout" file** under `~/.codex/sessions/YYYY/MM/DD/rollout-YYYY-MM-DDThh-mm-ss-<uuid>.jsonl` (constants in `codex-rs/rollout/src/lib.rs`; filename builder at `codex-rs/rollout/src/recorder.rs:1404`). The UUID embedded in the filename **is** the conversation/thread/session id (`ThreadId`), so an orchestrator can identify a run from its path alone. The first line of every file is a `session_meta` record (`codex-rs/rollout/src/list.rs:1237` rejects files where it isn't), holding id, started-at timestamp, `cwd`, `originator`, `cli_version`, `source` (`cli`/`vscode`/custom), `model_provider`, `base_instructions`, optional `forked_from_id`, `agent_*` (for sub-agents), `dynamic_tools`, plus optional git info. Subsequent lines are `RolloutLine { timestamp, type, payload }` records (defined `codex-rs/protocol/src/protocol.rs:2914`); the `type` discriminator is `session_meta | response_item | compacted | turn_context | event_msg` (`protocol.rs:2764`). `response_item` lines capture model-visible items — assistant messages, reasoning, function/tool calls and their outputs, web-search/image-gen calls, compaction records. `event_msg` lines capture internal `EventMsg`s subject to a persistence policy (`codex-rs/rollout/src/policy.rs`): only "terminal" events make it to disk in `Limited` mode (user/agent messages, reasoning, `TurnStarted`/`TurnComplete`, `TokenCount`, `ExecCommandEnd`-style ends, `McpToolCallEnd`, `PatchApplyEnd`, web/image-gen ends, plan-item completes); `Extended` mode adds errors, guardian/sandbox assessments, exec-command ends with truncated output, collab-agent events, and dynamic-tool requests/responses. Streaming deltas, approval prompts, exec output deltas, and stdout/stderr are explicitly excluded; `ExecCommandEnd` aggregated output is truncated to 10 KB and per-stream fields cleared (`recorder.rs:196–221`). `turn_context` lines snapshot the per-turn settings (model, sandbox/approval policy, `cwd`, `user_instructions`, `truncation_policy`, `effort`, etc., `protocol.rs:2805`) once per real user turn so resume/fork can rebuild context.

Writes go through a single background tokio task fed by an mpsc channel (`RolloutRecorder`, `recorder.rs:82`); each line is serialized, terminated with `\n`, written, and `flush().await`-ed (`recorder.rs:1892`). The file is opened in `append` mode for resume, deferred-then-`append`-created for new sessions. There is no per-session lock file, no in-progress sentinel, and no IPC channel — live and completed sessions are byte-identical on disk; liveness is signalled only by recent line timestamps and a `state_5.sqlite` `updated_at` column that the writer bumps at most every 5 seconds (`THREAD_UPDATED_AT_TOUCH_INTERVAL`, `recorder.rs:1471`). An external watcher therefore monitors progress by `tail -F`ing the rollout file, by watching the `sessions/` directory for new files, or by querying SQLite. Because lines are flushed immediately, `tail -F` sees each event as soon as it is written.

Codex maintains a **SQLite index** at `~/.codex/state_5.sqlite` (filename versioned via `STATE_DB_FILENAME` in `codex-rs/state/src/lib.rs:70`; overridable with `CODEX_SQLITE_HOME`) that mirrors thread metadata for fast paginated listing/search (`RolloutRecorder::list_threads*`, `recorder.rs:236+`). A separate `logs_2.sqlite` sinks structured `tracing` records (`codex-rs/state/src/log_db.rs`). Conventional `tracing` log files live under `~/.codex/log/` (e.g. `codex-tui.log`, `codex-login.log`), and the optional `codex-otel` crate can export OTLP traces/logs/metrics when configured via `OtelSettings`. There is **also** a separate, unrelated `~/.codex/history.jsonl` that records only user prompts as `{"session_id","ts","text"}` lines (`codex-rs/message-history/src/lib.rs`) — not the full transcript.

`codex resume` is a subcommand under `codex exec` (`codex-rs/exec/src/cli.rs:160`). It accepts `<SESSION_ID>` (UUID or thread name; `--last` picks the newest). Resolution walks the SQLite index or the filesystem via `find_thread_path_by_id_str` (`codex-rs/rollout/src/list.rs:1400`); the recorder is then opened in `Resume { path }` mode (`recorder.rs:752`) and the file is parsed into `InitialHistory::Resumed(ResumedHistory { conversation_id, history: Vec<RolloutItem>, rollout_path })` (`protocol.rs:2364`). Forks copy items into a new file with a new id and record the relationship via `SessionMeta.forked_from_id`. The TUI uses the same listing API through its own `resume_picker`.

For real-time progress monitoring an orchestrator generally has **three options**, in order of fidelity for live runs:

1. Spawn `codex exec --json` (`codex-rs/exec/src/cli.rs:59`) and parse stdout JSONL `ThreadEvent`s (`codex-rs/exec/src/exec_events.rs`): `thread.started`, `turn.started`, `turn.completed`, `turn.failed`, `item.started`, `item.updated`, `item.completed`, `error`. The first `thread.started` line yields the `thread_id` for later `codex resume`. This stream **does** carry streaming deltas, command-execution status, MCP/tool/patch lifecycle, todo lists, token usage — i.e. everything the TUI shows.
2. Tail the rollout JSONL — only "terminal" events and persisted response items, no streaming deltas, no approvals, but works for any TUI/VSCode/Atlas/CLI session you didn't start yourself. The schema is stable JSONL with `type`/`payload`/`timestamp`. The `read_session_meta_line()` helper is the cheap "what is this session?" probe.
3. Embed/connect to the `codex-rs/app-server/` JSON-RPC service (stdio JSON-RPC, emits `ServerNotification`s, supports resume/redaction). This is what the VSCode extension and SDK clients use.

There is **no named pipe, no FIFO, and no Unix socket** dedicated to session events.

---

# Codex CLI session / conversation storage (extensive)

Source tree examined: `/Users/johntokash/Downloads/codex/codex-rs/`. The session-persistence layer lives in the dedicated `codex-rs/rollout/` crate; the per-session on-disk format is JSONL ("rollouts"). A SQLite database next to the rollouts indexes those files for fast listing. A separate `~/.codex/history.jsonl` holds only the user-prompt history. The `codex exec --json` stream is a third surface that emits live JSONL events to stdout, which is the easiest way for an orchestrator to tail a running session in real time.

## 1. On-disk layout

### 1.1 Codex home

Everything lives under `~/.codex/` (configurable). Key children:

- `~/.codex/sessions/YYYY/MM/DD/rollout-YYYY-MM-DDThh-mm-ss-<uuid>.jsonl` — per-session rollout files.
- `~/.codex/archived_sessions/...` — archived rollouts (same layout). Constants in `codex-rs/rollout/src/lib.rs`:
  ```rust
  pub const SESSIONS_SUBDIR: &str = "sessions";
  pub const ARCHIVED_SESSIONS_SUBDIR: &str = "archived_sessions";
  ```
- `~/.codex/history.jsonl` — append-only user-message history (separate from rollouts). See `codex-rs/message-history/src/lib.rs`:
  ```rust
  const HISTORY_FILENAME: &str = "history.jsonl";
  ```
  Schema per line: `{"session_id":"<uuid>","ts":<unix_seconds>,"text":"<message>"}` (file doc-comment, lines 1–9). One JSON object per line; intended to be written atomically with `O_APPEND` so concurrent processes can append safely.
- `~/.codex/state_5.sqlite` — index of all known threads (one row per rollout, for fast listing/search). `codex-rs/state/src/lib.rs`:
  ```rust
  pub const STATE_DB_FILENAME: &str = "state_5.sqlite";
  pub const LOGS_DB_FILENAME:  &str = "logs_2.sqlite";
  pub const SQLITE_HOME_ENV: &str = "CODEX_SQLITE_HOME"; // override location
  ```
  Filenames are versioned ("state_5", "logs_2") because the schema has migrated. Path computed by `state_db_path()` in `codex-rs/state/src/runtime.rs:291`.
- `~/.codex/logs_2.sqlite` — structured `tracing` log sink (see `codex-rs/state/src/log_db.rs`).
- `~/.codex/log/codex-tui.log` — TUI tracing log file (`codex-rs/tui/src/lib.rs:1025`).
- `~/.codex/log/codex-login.log` — login flow log (`codex-rs/cli/src/login.rs:75`).
- `log_dir` is configurable via `config.toml` (`log_dir`); default is `<codex_home>/log` (`codex-rs/core/src/config/mod.rs:2868`).

### 1.2 Rollout filename anatomy

From `codex-rs/rollout/src/recorder.rs:1404–1434` (`precompute_log_file_info`):

```rust
let mut dir = config.codex_home().to_path_buf();
dir.push(SESSIONS_SUBDIR);
dir.push(timestamp.year().to_string());
dir.push(format!("{:02}", u8::from(timestamp.month())));
dir.push(format!("{:02}", timestamp.day()));

let format: &[FormatItem] =
    format_description!("[year]-[month]-[day]T[hour]-[minute]-[second]");
let date_str = timestamp.format(format)?;

let filename = format!("rollout-{date_str}-{conversation_id}.jsonl");
```

Colons are replaced with dashes "for compatibility with filesystems that do not allow colons in filenames" (comment lines 1417–1418). The `<conversation_id>` in the filename is the thread / session UUID — so the **session id is recoverable purely from the path**. List/discovery code parses it back via `parse_timestamp_uuid_from_filename` (`codex-rs/rollout/src/list.rs`, line 932:`let core = name.strip_prefix("rollout-")?.strip_suffix(".jsonl")?;`). Both active and archived listings reject names that don't `starts_with("rollout-") && ends_with(".jsonl")` (lines 898, 918, 988).

### 1.3 Documented inspection tooling

The recorder header doc (`codex-rs/rollout/src/recorder.rs:74–80`) literally shows the public inspection idiom:

```rust
/// Rollouts are recorded as JSONL and can be inspected with tools such as:
///
/// ```ignore
/// $ jq -C . ~/.codex/sessions/rollout-2025-05-07T17-24-21-5973b6c0-94b8-487b-a530-2aeb6098ae0e.jsonl
/// $ fx ~/.codex/sessions/rollout-2025-05-07T17-24-21-5973b6c0-94b8-487b-a530-2aeb6098ae0e.jsonl
/// ```
```

## 2. JSONL line schema

Each rollout line is a `RolloutLine` (`codex-rs/protocol/src/protocol.rs:2914–2919`):

```rust
#[derive(Serialize, Deserialize, Clone, JsonSchema)]
pub struct RolloutLine {
    pub timestamp: String,
    #[serde(flatten)]
    pub item: RolloutItem,
}
```

`RolloutItem` (`protocol.rs:2764–2772`):

```rust
#[derive(Serialize, Deserialize, Debug, Clone, JsonSchema, TS)]
#[serde(tag = "type", content = "payload", rename_all = "snake_case")]
pub enum RolloutItem {
    SessionMeta(SessionMetaLine),
    ResponseItem(ResponseItem),
    Compacted(CompactedItem),
    TurnContext(TurnContextItem),
    EventMsg(EventMsg),
}
```

Because of `#[serde(flatten)]` on the timestamp wrapper and `tag="type", content="payload"` on the enum, every JSONL line has the shape:

```json
{ "timestamp": "...", "type": "<variant>", "payload": { ... } }
```

…where `<variant>` is one of `session_meta`, `response_item`, `compacted`, `turn_context`, `event_msg`. The line timestamp is generated by the writer at write time using format `[year]-[month]-[day]T[hour]:[minute]:[second].[subsecond digits:3]Z` (`recorder.rs:1879–1884`) — i.e. UTC millisecond RFC3339.

### 2.1 First line: `session_meta`

`SessionMetaLine` flattens `SessionMeta` and adds optional `git` info (`protocol.rs:2756–2762`):

```rust
pub struct SessionMetaLine {
    #[serde(flatten)]
    pub meta: SessionMeta,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub git: Option<GitInfo>,
}
```

`SessionMeta` fields (`protocol.rs:2701–2732`):

```rust
pub struct SessionMeta {
    pub id: ThreadId,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub forked_from_id: Option<ThreadId>,
    pub timestamp: String,
    pub cwd: PathBuf,
    pub originator: String,
    pub cli_version: String,
    #[serde(default)] pub source: SessionSource,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub thread_source: Option<ThreadSource>,
    #[serde(skip_serializing_if = "Option::is_none")] pub agent_nickname: Option<String>,
    #[serde(default, alias = "agent_type", skip_serializing_if = "Option::is_none")]
    pub agent_role: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")] pub agent_path: Option<String>,
    pub model_provider: Option<String>,
    pub base_instructions: Option<BaseInstructions>,
    #[serde(skip_serializing_if = "Option::is_none")] pub dynamic_tools: Option<Vec<DynamicToolSpec>>,
    #[serde(skip_serializing_if = "Option::is_none")] pub memory_mode: Option<String>,
}
```

Verbatim example of how `session_meta` is serialized on disk, from `codex-rs/rollout/src/recorder_tests.rs:45–58`:

```json
{
  "timestamp": "2025-01-03T12:00:00Z",
  "type": "session_meta",
  "payload": {
    "id": "<uuid>",
    "timestamp": "2025-01-03T12:00:00Z",
    "cwd": ".",
    "originator": "test_originator",
    "cli_version": "test_version",
    "source": "cli",
    "model_provider": "test-provider"
  }
}
```

`read_session_meta_line()` in `codex-rs/rollout/src/list.rs:1237` reads only the head of the file and parses it as a `SessionMetaLine`, returning an error if the first record is not session metadata. This is the canonical "introspect a session" path.

### 2.2 Subsequent lines

- **`response_item`** — items the model sees/emits. The persisted variants are gated by `should_persist_response_item` in `codex-rs/rollout/src/policy.rs:27–44`:
  ```rust
  ResponseItem::Message { .. }
  | ResponseItem::Reasoning { .. }
  | ResponseItem::LocalShellCall { .. }
  | ResponseItem::FunctionCall { .. }
  | ResponseItem::ToolSearchCall { .. }
  | ResponseItem::FunctionCallOutput { .. }
  | ResponseItem::ToolSearchOutput { .. }
  | ResponseItem::CustomToolCall { .. }
  | ResponseItem::CustomToolCallOutput { .. }
  | ResponseItem::WebSearchCall { .. }
  | ResponseItem::ImageGenerationCall { .. }
  | ResponseItem::Compaction { .. }
  | ResponseItem::ContextCompaction { .. } => true,
  ```
  So function/tool calls **and** their outputs, reasoning blocks, assistant messages, and web/image-gen calls are recorded as discrete `response_item` lines. Test fixtures (`recorder_tests.rs:172–199`) show the wire format:
  ```json
  {
    "timestamp": "2025-01-03T12:00:00Z",
    "type": "response_item",
    "payload": {
      "type": "message",
      "role": "assistant",
      "content": [{ "type": "output_text", "text": "hello" }]
    }
  }
  ```

- **`event_msg`** — internal `EventMsg` variants. Policy lives in `codex-rs/rollout/src/policy.rs:93–177`. Two `EventPersistenceMode`s, `Limited` (default) and `Extended`. `Limited` records: `UserMessage`, `AgentMessage`, `AgentReasoning`, `AgentReasoningRawContent`, `PatchApplyEnd`, `TokenCount`, `ThreadGoalUpdated`, `ContextCompacted`, `EnteredReviewMode`, `ExitedReviewMode`, `McpToolCallEnd`, `ThreadRolledBack`, `TurnAborted`, `TurnStarted`, `TurnComplete`, `WebSearchEnd`, `ImageGenerationEnd`, and `ItemCompleted` for plan items. `Extended` adds `Error`, `GuardianAssessment`, `ExecCommandEnd`, `ViewImageToolCall`, the `CollabAgent*End` family, and `DynamicToolCallRequest/Response`. The big "should NOT persist" group at lines 133–176 includes streaming deltas (`AgentMessageContentDelta`, `ReasoningContentDelta`, `ExecCommandOutputDelta`), approval requests, MCP startup events, etc. — those are emitted to subscribers but **not written to the rollout file**. So a file-tailer cannot see stdout chunks of running commands; it can only see the aggregated end event. The recorder also truncates `ExecCommandEnd.aggregated_output` to 10 KB and clears `stdout`/`stderr`/`formatted_output` before persisting (`recorder.rs:196–221`, `PERSISTED_EXEC_AGGREGATED_OUTPUT_MAX_BYTES = 10_000`).

  Sample event line from `recorder_tests.rs:59–67`:
  ```json
  {
    "timestamp": "2025-01-03T12:00:00Z",
    "type": "event_msg",
    "payload": { "type": "user_message", "message": "Hello from user", "kind": "plain" }
  }
  ```

- **`turn_context`** — written once per real user turn (and again after mid-turn compaction). `TurnContextItem` (`protocol.rs:2805–2841`) captures `cwd`, `current_date`, `timezone`, `approval_policy`, `sandbox_policy`, `permission_profile`, `network`, `file_system_sandbox_policy`, `model`, `personality`, `collaboration_mode`, `realtime_active`, `effort`, `summary`, `user_instructions`, `developer_instructions`, `final_output_json_schema`, `truncation_policy`, plus optional `turn_id`/`trace_id`. The doc-comment explicitly says these exist so "resume/fork replay can recover the latest durable baseline" (lines 2800–2803).

- **`compacted`** — `CompactedItem { message, replacement_history }` (`protocol.rs:2774–2779`) marks a compaction with optional full replacement history.

### 2.3 Writing pipeline

`RolloutRecorder` (`codex-rs/rollout/src/recorder.rs:82–104`):

```rust
pub struct RolloutRecorder {
    tx: Sender<RolloutCmd>,
    writer_task: Arc<RolloutWriterTask>,
    pub(crate) rollout_path: PathBuf,
    event_persistence_mode: EventPersistenceMode,
}

pub enum RolloutRecorderParams {
    Create { conversation_id: ThreadId, forked_from_id: Option<ThreadId>, source: SessionSource,
             thread_source: Option<ThreadSource>, base_instructions: BaseInstructions,
             dynamic_tools: Vec<DynamicToolSpec>, event_persistence_mode: EventPersistenceMode },
    Resume { path: PathBuf, event_persistence_mode: EventPersistenceMode },
}
```

The recorder owns a tokio mpsc channel; a background task (`rollout_writer`, `recorder.rs:1690+`) owns the file handle and writes JSONL serially. For *new* sessions the path is precomputed but the file is **not** opened until `persist()` (lines 686–690 doc). On `Resume`, the existing file is opened in `append` mode (`recorder.rs:756–761`). Each line is written and `flush().await` is called after every write (`recorder.rs:1893–1897`):

```rust
async fn write_line(&mut self, item: &impl serde::Serialize) -> std::io::Result<()> {
    let mut json = serde_json::to_string(item)?;
    json.push('\n');
    self.file.write_all(json.as_bytes()).await?;
    self.file.flush().await?;
    Ok(())
}
```

So an external watcher can tail the file with `tail -F` and see lines arrive incrementally; there's no buffering beyond the OS. There is also a public helper `append_rollout_item_to_path()` (`recorder.rs:1854–1864`) that opens the file in `append` mode and writes one item — used to add records out-of-band.

## 3. SQLite session index (`state_5.sqlite`)

`codex-rs/rollout/src/state_db.rs` and `codex-rs/state/src/runtime.rs` set up an index keyed on thread id. On startup the recorder lazily backfills entries by scanning rollout files (see `recorder_tests.rs:73–142` for an example test asserting backfill-before-return semantics). The `RolloutRecorder::list_threads*` family (lines 236–299) supports paginated, sorted, filtered listing — by `SessionSource`, `model_provider`, `cwd_filters`, `search_term`, sort by `CreatedAt` or `UpdatedAt`. Most clients (TUI resume picker, app-server) hit this DB rather than walking the filesystem.

Notable: `ThreadUpdatedAtTouch` (`recorder.rs:1470+`) bumps the `updated_at` column at most every 5 seconds (`THREAD_UPDATED_AT_TOUCH_INTERVAL = Duration::from_secs(5)`) — so an orchestrator polling SQLite sees per-thread liveness within a few seconds.

`logs_2.sqlite` is a separate DB written by the `codex-state` log layer (`codex-rs/state/src/log_db.rs`), receiving entries from a `LogSinkQueueConfig` queue (line 99+). It contains structured `tracing` records, useful for offline log inspection but not for live progress.

## 4. Live vs completed sessions

Both look identical on disk — the only difference is whether the writer task is still appending. There is **no in-progress sentinel** and no `.lock` file written by Codex itself. The newest line's `timestamp` (and the SQLite `updated_at`) is the only signal of liveness. The session is considered "complete" when the recorder is dropped (which triggers a `RolloutCmd::Shutdown` flush, `recorder.rs:115–117`). Concurrent processes appending to the same file are not coordinated by Codex; the runtime model is one writer per rollout.

Implications for an orchestrator:
- Tail the rollout JSONL with `tail -F` — every flushed line is immediately visible.
- Or query `state_5.sqlite` `ORDER BY updated_at DESC` to find the most recent active thread.
- The session id is embedded in the filename, so a simple `inotify`/`fswatch` on `~/.codex/sessions/YYYY/MM/DD/` reveals new sessions as files are created.

## 5. Attach / resume

CLI side: `codex resume` is a subcommand of `codex exec` (`codex-rs/exec/src/cli.rs:160–207`):

```rust
#[derive(Debug, clap::Subcommand)]
pub enum Command {
    /// Resume a previous session by id or pick the most recent with --last.
    Resume(ResumeArgs),
    Review(ReviewArgs),
}

pub struct ResumeArgs {
    /// Conversation/session id (UUID) or thread name. UUIDs take precedence if it parses.
    /// If omitted, use --last to pick the most recent recorded session.
    pub session_id: Option<String>,
    /// Resume the most recent recorded session (newest) without specifying an id.
    pub last: bool,
    ...
    pub prompt: Option<String>,
}
```

Resolution: `find_thread_path_by_id_str()` (`codex-rs/rollout/src/list.rs:1400`) walks the SQLite index / filesystem to find a rollout whose embedded UUID matches; thread *names* (slug-like aliases) are resolved via `find_thread_meta_by_name_str` / `find_thread_name_by_id` (`codex-rs/rollout/src/session_index.rs`).

Replay model — `RolloutRecorder::new()` with `Resume { path }` opens the file in append mode (`recorder.rs:752–766`). The history is rebuilt into one of the `InitialHistory` variants (`protocol.rs:2370–2376`):

```rust
pub enum InitialHistory { New, Cleared, Resumed(ResumedHistory), Forked(Vec<RolloutItem>) }
pub struct ResumedHistory { pub conversation_id: ThreadId, pub history: Vec<RolloutItem>, pub rollout_path: Option<PathBuf> }
```

So resume = parse the JSONL, materialize `Vec<RolloutItem>`, and continue appending to the same file. Forks copy the items into a new thread with a new id and new rollout file (the original is referenced via `SessionMeta.forked_from_id`).

There is **no IPC / named pipe / Unix socket** for attaching to a running CLI session. The "attach" model for orchestrators is one of:
1. **Spawn `codex exec --json`** and read live `ThreadEvent`s from stdout (best for real-time monitoring of a run *you* started).
2. **Tail the rollout JSONL** (best for monitoring a run someone else started, or any TUI/VSCode/Atlas session).
3. **Use the app-server** (`codex-rs/app-server/`) which exposes JSON-RPC over stdio with `ServerNotification` events and persistent session ids.

## 6. Stdout JSON event stream (`codex exec --json`)

`codex-rs/exec/src/cli.rs:59–66`:

```rust
/// Print events to stdout as JSONL.
#[arg(long = "json", alias = "experimental-json", default_value_t = false, global = true)]
pub json: bool,
```

When enabled, `EventProcessorWithJsonOutput` (`codex-rs/exec/src/event_processor_with_jsonl_output.rs:58`) writes one `ThreadEvent` per line. The schema is **different** from the rollout schema — it's a stable client-facing event model. From `codex-rs/exec/src/exec_events.rs:11–37`:

```rust
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, TS)]
#[serde(tag = "type")]
pub enum ThreadEvent {
    #[serde(rename = "thread.started")] ThreadStarted(ThreadStartedEvent),
    #[serde(rename = "turn.started")]   TurnStarted(TurnStartedEvent),
    #[serde(rename = "turn.completed")] TurnCompleted(TurnCompletedEvent),
    #[serde(rename = "turn.failed")]    TurnFailed(TurnFailedEvent),
    #[serde(rename = "item.started")]   ItemStarted(ItemStartedEvent),
    #[serde(rename = "item.updated")]   ItemUpdated(ItemUpdatedEvent),
    #[serde(rename = "item.completed")] ItemCompleted(ItemCompletedEvent),
    #[serde(rename = "error")]          Error(ThreadErrorEvent),
}

pub struct ThreadStartedEvent {
    /// The identified of the new thread. Can be used to resume the thread later.
    pub thread_id: String,
}
```

So the first stdout line of any `--json` run gives the `thread_id` an orchestrator can later pass to `codex resume <id>`. `ThreadItem` carries the actual per-step payload (assistant messages, tool calls, reasoning, command-execution status, MCP tool calls, patch applies, todo lists, web search, errors, token usage). There is **also** `--output-last-message <FILE>` (`cli.rs:69–75`) to dump the final assistant message to a file, and `--output-schema <FILE>` to constrain final response shape.

## 7. Telemetry

`codex-rs/otel/` is the OpenTelemetry integration: configurable OTLP HTTP exporters for logs, traces, metrics, plus a `SessionTelemetry` business-event emitter (`otel/src/lib.rs:20–22`). Settings are loaded from `OtelSettings` (`codex_home`, exporters, span attributes, W3C `tracestate`). When configured, span attributes are propagated; nothing is exported by default. There are SQLite metrics (`codex.sqlite.init.count`, `codex.db.backfill`, etc., `state/src/lib.rs:73–83`).

The `codex-rs/rollout-trace/` crate is a *separate* developer-only trace format (see `codex-rs/tui/tests/fixtures/oss-story.jsonl`) with line shape:

```json
{"ts":"2025-08-10T03:12:26.500Z","dir":"meta","kind":"session_start","cwd":"...","model":"gpt-oss:20b",...}
{"ts":"...","dir":"to_tui","kind":"app_event","variant":"RequestRedraw"}
{"ts":"...","dir":"to_tui","kind":"log_line","line":"[INFO codex_core::codex] resume_path: None"}
```

This is for TUI replay tests, not the session storage path; do not confuse with the rollout format.

## 8. Caveats / gotchas

- **No raw stdout/stderr in rollout**: `ExecCommandOutputDelta` is filtered out; only `ExecCommandEnd` is kept, and even that is truncated to 10 KB aggregated output with `stdout`/`stderr`/`formatted_output` cleared (`recorder.rs:206–221`). To get live command output, you must subscribe via the app-server or `codex exec --json` stream — not via file tail.
- **No approval prompts in rollout**: `ExecApprovalRequest`, `RequestPermissions`, `RequestUserInput`, `ElicitationRequest`, `ApplyPatchApprovalRequest` are explicitly *not* persisted (`policy.rs:148–152`). A file-tailer cannot see "waiting for user".
- **No streaming deltas**: token-by-token assistant streaming (`AgentMessageContentDelta`, `ReasoningContentDelta`, `ReasoningRawContentDelta`, `PlanDelta`) is excluded — only the final `AgentMessage`, `AgentReasoning`, `PlanUpdate` end events are recorded.
- **Filename encodes session id**: easy regex `^rollout-(\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2})-([0-9a-f-]{36})\.jsonl$` to extract started_at and `<uuid>` without opening the file.
- **`state_5.sqlite` is versioned**: any orchestrator that wants to query SQLite directly should be ready for the schema/filename to bump (e.g. `state_6.sqlite`). Walking the JSONL files is more stable.
- **`session_meta` is *always* the first line** of any rollout (`list.rs:1245`: returns an error if it isn't). Useful for cheap introspection — read the first line, parse it as `SessionMetaLine`, done.
- **Two completely different "history" concepts**: `history.jsonl` (single global file of user prompts) vs `sessions/.../rollout-*.jsonl` (per-session full transcript). Don't confuse them.
- **`codex resume` is `codex exec resume`** — the resume subcommand sits under `exec`, not at the top level (`exec/src/cli.rs:160`). The TUI also has its own resume picker (`codex-rs/tui/src/resume_picker.rs`) backed by the same listing API.
- **Log filenames**: TUI writes `~/.codex/log/codex-tui.log`; login writes `codex-login.log`; structured logs additionally go to `~/.codex/logs_2.sqlite` via `log_db.rs`. The exec binary does not write its own named log file by default — its progress comes from stdout or the rollout JSONL.
