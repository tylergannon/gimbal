## TLDR

Codex CLI stores ChatGPT OAuth credentials as a plaintext-JSON `auth.json` (mode 0600) under `$CODEX_HOME` (or in the OS keyring, same JSON payload). There is no device binding, so the file is fully portable across machines — but the refresh token rotates on every refresh, so multiple concurrent machines sharing one credential will inevitably collide and one side will be permanently locked out with `refresh_token_reused`. Rate limits are also per-account, so spreading the login across machines does not buy you more quota.

---

## Executive summary

- **Three login UX flows**: (a) browser/loopback OAuth on `127.0.0.1:1455` (fallback 1457) with PKCE S256 and a 32-byte `state`; (b) OAuth 2.0 device-code flow at `${issuer}/codex/device` for headless use (15-minute window); (c) direct stdin pastes for API key or agent-identity JWT. Hard-coded `client_id = "app_EMoamEEZ73f0CkXaXp7hrann"`, default issuer `https://auth.openai.com`.
- **Storage**: `$CODEX_HOME/auth.json` (default `~/.codex/auth.json`), mode `0o600`. Contains `auth_mode`, `OPENAI_API_KEY` (optional, derived via token-exchange), `tokens.{id_token, access_token, refresh_token, account_id}`, `last_refresh`, `agent_identity`. Selectable backend: file / OS keyring (service `"Codex Auth"`, key hashes `CODEX_HOME` path) / auto / in-memory ephemeral.
- **Refresh**: proactive when access-token JWT `exp` has passed or `last_refresh` is older than 8 days; reactive on 401 via a Reload-then-RefreshToken state machine. In-process refreshes are serialized by a `Semaphore(permits=1)`. POST `https://auth.openai.com/oauth/token` with `grant_type=refresh_token`; the server may rotate `refresh_token` in the response.
- **Failure modes the auth layer recognizes**: `refresh_token_expired`, `refresh_token_reused` (rotation race), `refresh_token_invalidated` (revoked). These become sticky `permanent_refresh_failure` caches and demand a fresh login.
- **Rate limits are out-of-band of auth**: surfaced as `RateLimitSnapshot` (primary/secondary windows + `RateLimitReachedType` including workspace credits/usage depletion) on API responses. Backend requests carry `ChatGPT-Account-Id` and (for FedRAMP) `X-OpenAI-Fedramp: true`. No per-machine client-side throttle, just generic exponential backoff.
- **No client-side device binding**: tokens parse only `email`, plan, user/account ids, fedramp flag, and `exp`. Copying `auth.json` to another machine works.
- **Multi-machine concurrency breaks on refresh-token rotation**: as soon as one node refreshes and the server rotates, every other node using the old refresh token gets `refresh_token_reused` and is permanently lost until re-login or a re-copy of `auth.json`.
- **Rate-limit quotas are per ChatGPT account**, not per credential copy: running N concurrent sessions shares one bucket.
- **Safer multi-machine patterns**: single designated refresher process redistributing `auth.json`; or use `CODEX_ACCESS_TOKEN` (agent-identity JWT verified against `chatgpt.com/backend-api` JWKS) for containers — no refresh token, so no rotation race.
- **Workspace lock-in**: `forced_chatgpt_workspace_id` (config flag) force-logs-out if cached `chatgpt_account_id` ≠ expected.

---

## Detailed summary

**Login UX.** Three CLI entry points (`codex-rs/cli/src/login.rs`): (1) browser/loopback `codex login` starts a `tiny_http` server on `127.0.0.1:1455` (fallback `1457` — both on the Hydra redirect allow-list) and opens `https://auth.openai.com/oauth/authorize` with PKCE S256, `state`, scope `openid profile email offline_access api.connectors.read api.connectors.invoke`, `id_token_add_organizations=true`, `codex_cli_simplified_flow=true`, and hard-coded `client_id = "app_EMoamEEZ73f0CkXaXp7hrann"`; (2) `codex login --device-auth` POSTs to `${issuer}/api/accounts/deviceauth/usercode`, prints the `{issuer}/codex/device` URL plus a one-time `user_code` ("expires in 15 minutes"), and polls `/deviceauth/token` (15-min cap, 403/404 = keep polling); (3) `--with-api-key` / `--with-access-token` from stdin for non-interactive setups. The browser flow's `/auth/callback` validates `state`, exchanges code at `/oauth/token` (`grant_type=authorization_code`), optionally swaps the `id_token` for an `OPENAI_API_KEY` via `urn:ietf:params:oauth:grant-type:token-exchange` (best-effort), persists, then 302s the browser to a local `/success` page that embeds `id_token`, `org_id`, `project_id`, `plan_type`, `platform_url` for onboarding handoff.

**Storage.** Credentials live at `$CODEX_HOME/auth.json` (default `~/.codex/auth.json`), written with `0o600` on Unix. The schema (`AuthDotJson`, `codex-rs/login/src/auth/storage.rs:32`) is `{ auth_mode, OPENAI_API_KEY, tokens: { id_token (raw JWT), access_token (JWT), refresh_token, account_id }, last_refresh (UTC RFC3339), agent_identity }`. The id_token is reserialized as the raw JWT; claims (`email`, `chatgpt_plan_type`, `chatgpt_user_id`, `chatgpt_account_id`, `chatgpt_account_is_fedramp`) are parsed from the `https://api.openai.com/auth` namespace. Storage backend is selectable via `AuthCredentialsStoreMode`: `File` (default), `Keyring` (service `"Codex Auth"`, key = `cli|<sha256(canonical codex_home)[..16]>`), `Auto` (keyring with file fallback), `Ephemeral` (in-memory `HashMap`). Env vars: `OPENAI_API_KEY`, `CODEX_API_KEY` (only honored when `enable_codex_api_key_env=true`; *takes precedence over disk*), `CODEX_ACCESS_TOKEN` (agent-identity JWT verified against `chatgpt.com/backend-api` JWKS), plus `CODEX_REFRESH_TOKEN_URL_OVERRIDE` / `CODEX_REVOKE_TOKEN_URL_OVERRIDE` testing knobs.

**Refresh.** Proactive: `AuthManager::auth()` (`manager.rs:1404`) calls `is_stale_for_proactive_refresh` which refreshes if the access-token JWT's `exp` is past, or as a fallback if `last_refresh < now - 8 days` (`TOKEN_REFRESH_INTERVAL`). Reactive: on 401, `UnauthorizedRecovery` runs Reload → RefreshToken → Done; the reload step *only fires if the on-disk account_id matches the cached one*, and if disk has changed it assumes another process already refreshed. Refresh POSTs `{client_id, grant_type:"refresh_token", refresh_token}` to `https://auth.openai.com/oauth/token`; the response's optional new `refresh_token` overwrites the old one (rotation). In-process refreshes are serialized by `refresh_lock: Semaphore(1)`. 401 from refresh is classified into `refresh_token_expired` | `refresh_token_reused` | `refresh_token_invalidated` | `Other`, cached as a sticky `permanent_refresh_failure` per auth snapshot until logout or a disk reload yields a different snapshot.

**Rate limiting and account scope.** Rate limits are server-side and surface as `RateLimitSnapshot { limit_id, limit_name, primary, secondary, credits, plan_type, rate_limit_reached_type }` (`protocol.rs:2069`) with `RateLimitReachedType` covering plain rate-limit, workspace owner/member credit depletion, and owner/member usage-cap reached. Backend requests include `ChatGPT-Account-Id: <chatgpt_account_id>` (`backend-client/src/client.rs:213`) and, for FedRAMP, `X-OpenAI-Fedramp: true`. There is no per-machine client throttle; only a generic exponential `backoff` for retries (`core/src/util.rs:88`).

**Portability across machines.** Tokens have no client-side device binding: only `email`, plan claims, account/user ids, fedramp flag, and `exp` are parsed. Copying `auth.json` (or recreating the keyring blob with the same JSON, but mindful that the keyring key derives from a hash of the canonical codex_home path) works. The break points are (a) refresh-token rotation: as soon as any one machine refreshes and the server rotates the refresh token, every other machine using the old refresh token is permanently dead (`refresh_token_reused`, sticky failure); (b) workspace-id mismatch under `forced_chatgpt_workspace_id` triggers forced logout; (c) all machines share the same per-account rate-limit buckets — running N concurrent sessions does not buy you more quota; (d) `WorkspaceOwnerCreditsDepleted` and friends apply at the account/workspace level. Safe patterns: short-lived bursts with a non-expired access_token (no refresh fires); a single designated refresher process re-publishing `auth.json` to peers; or, better, switch to `CODEX_ACCESS_TOKEN` with a server-issued agent-identity JWT (no refresh token, JWT expires and is reissued by the issuing service, so no rotation race).

---

## Extensive analysis

### 1. UX: how a user actually logs in

Codex CLI's ChatGPT (subscription) sign-in has three entry points, all defined in `codex-rs/cli/src/login.rs`:

1. **Browser flow** (`codex login`) — default on a workstation. Implemented by `login_with_chatgpt` (`codex-rs/cli/src/login.rs:116`), which builds `ServerOptions` and calls `run_login_server` (`codex-rs/login/src/server.rs:140`).
2. **Device-code flow** (`codex login --device-auth`) — for headless / remote machines. Implemented by `run_login_with_device_code` (`codex-rs/cli/src/login.rs:267`) → `run_device_code_login` (`codex-rs/login/src/device_code_auth.rs:224`).
3. **Direct token paste** (`codex login --with-api-key` reading from stdin, `codex login --with-access-token` reading an agent-identity JWT from stdin). API-key paste produces an `AuthMode::ApiKey` `auth.json`; access-token paste produces `AuthMode::AgentIdentity`. Neither uses ChatGPT subscription auth in the OAuth sense.

There is also a fallback combinator, `run_login_with_device_code_fallback_to_browser` (`codex-rs/cli/src/login.rs:305`), which tries device-code first with `open_browser = false`, and falls back to spinning up the localhost server if the issuer returns 404 (i.e. device-code is disabled for that deployment).

#### 1a. Browser / loopback flow

`run_login_server` (`codex-rs/login/src/server.rs:140`):

- Generates a PKCE pair (`generate_pkce()` from `codex-rs/login/src/pkce.rs`) and a 32-byte random `state` (`generate_state`, `server.rs:521`).
- Binds a `tiny_http` server on `127.0.0.1:1455` (with a fallback to `1457`). Both ports are explicitly noted as on the Codex CLI Hydra redirect-URI allow-list:
  ```rust
  const DEFAULT_PORT: u16 = 1455;
  // Keep in sync with the Codex CLI Hydra redirect URI allow-list.
  const FALLBACK_PORT: u16 = 1457;
  ```
  (`codex-rs/login/src/server.rs:55-57`). If the default port is in use, it first POSTs a `/cancel` to the existing instance, retries, then falls back to 1457 (`bind_server`, `server.rs:544`).
- Constructs the authorize URL via `build_authorize_url` (`server.rs:483`). The OAuth params include `scope=openid profile email offline_access api.connectors.read api.connectors.invoke`, PKCE S256, `id_token_add_organizations=true`, `codex_cli_simplified_flow=true`, the random `state`, and an `originator` header value. The `client_id` is hard-coded as:
  ```rust
  pub const CLIENT_ID: &str = "app_EMoamEEZ73f0CkXaXp7hrann";
  ```
  (`codex-rs/login/src/auth/manager.rs:921`).
- Default issuer is `https://auth.openai.com` (`server.rs:54`).
- If `opts.open_browser` is true (which it is by default), the CLI calls `webbrowser::open(&auth_url)`. The terminal additionally prints the URL and adds: "On a remote or headless machine? Use `codex login --device-auth` instead." (`cli/src/login.rs:111`).
- The user authenticates against `auth.openai.com` in their default browser. The browser redirects back to `http://localhost:{port}/auth/callback?code=...&state=...`. `process_request` (`server.rs:263`) handles this: validates `state`, exchanges code for tokens, applies optional workspace restriction, persists tokens, and 302-redirects to a local `/success` page (`compose_success_url`, `server.rs:841`). The `/success` route returns an HTML page (`assets/success.html` for the streamlined flow, `assets/success_legacy.html` otherwise) and terminates the local server (`server.rs:406-426`).
- The success-page URL embeds `id_token`, `org_id`, `project_id`, `plan_type`, `platform_url`, and a `needs_setup` flag derived from JWT claims (`compose_success_url`, `server.rs:841-895`). This is what powers the post-login onboarding redirect over to `platform.openai.com`.
- Error paths render a branded HTML error page via `LOGIN_ERROR_PAGE_TEMPLATE` (`assets/error.html`, `server.rs:58`) and surface specific copy for missing Codex entitlement (`is_missing_codex_entitlement_error`, `server.rs:970`).

#### 1b. Device-code flow

`run_device_code_login` (`codex-rs/login/src/device_code_auth.rs:224`):

- POSTs `client_id` to `${issuer}/api/accounts/deviceauth/usercode` (`request_user_code`, `device_code_auth.rs:62`). Returns `device_auth_id`, `user_code`, and a polling `interval`.
- Prints a prompt to stderr:
  ```
  1. Open this link in your browser and sign in to your account
     {issuer}/codex/device
  2. Enter this one-time code (expires in 15 minutes)
     {user_code}
  Device codes are a common phishing target. Never share this code.
  ```
  (`print_device_code_prompt`, `device_code_auth.rs:148`).
- Polls `${issuer}/api/accounts/deviceauth/token` every `interval` seconds for up to **15 minutes** (`max_wait = Duration::from_secs(15 * 60)`, `device_code_auth.rs:107`). 403 / 404 are treated as "still waiting"; any other non-2xx is a hard fail.
- On success the response contains `authorization_code`, `code_challenge`, and `code_verifier` (the server, not the client, generates PKCE here — see `CodeSuccessResp`, `device_code_auth.rs:54`). The CLI then performs the same `exchange_code_for_tokens` call as the browser flow, but with `redirect_uri = ${issuer}/deviceauth/callback`.
- A 404 from `usercode` is special-cased into `ErrorKind::NotFound` so callers can fall back to browser login (`device_code_auth.rs:82`).

#### 1c. Token exchange and post-login

Both flows funnel through `exchange_code_for_tokens` (`server.rs:714`), which POSTs to `${issuer}/oauth/token` with `grant_type=authorization_code`. The TokenResponse provides `id_token`, `access_token`, and `refresh_token` — all are JWTs.

After exchange, `obtain_api_key` (`server.rs:1118`) performs a second OAuth call using `grant_type=urn:ietf:params:oauth:grant-type:token-exchange` to swap the `id_token` for an `openai-api-key`-style access token. This is stored alongside the OAuth tokens under the `OPENAI_API_KEY` field in `auth.json`. It is opportunistic: failure is silently ignored (`.ok()` at `server.rs:357`).

Finally, `persist_tokens_async` (`server.rs:789`) writes everything to disk (or keyring/ephemeral) and best-effort revokes any previous superseded tokens (`should_revoke_auth_tokens`, see `codex-rs/login/src/auth/revoke.rs`).

### 2. Data: where credentials live and what's in them

#### 2a. Path

By default Codex stores everything under `$CODEX_HOME` (default `~/.codex`). The file is exactly:
```rust
pub(super) fn get_auth_file(codex_home: &Path) -> PathBuf {
    codex_home.join("auth.json")
}
```
(`codex-rs/login/src/auth/storage.rs:84`). It is written with `0o600` permissions on Unix:
```rust
#[cfg(unix)]
{
    options.mode(0o600);
}
```
(`codex-rs/login/src/auth/storage.rs:145-148`).

#### 2b. Storage backends

`AuthCredentialsStoreMode` (`codex-rs/config/src/types.rs:85-97`) chooses among:

- `File` — plain JSON at `$CODEX_HOME/auth.json` (default).
- `Keyring` — OS keyring (macOS Keychain / Linux Secret Service / Windows Credential Manager via `codex_keyring_store::DefaultKeyringStore`). Service name is `"Codex Auth"` (`storage.rs:160`); the key is `cli|<sha256(canonical codex_home)[..16]>` (`compute_store_key`, `storage.rs:163`). When keyring is used, the JSON file is *deleted* (`storage.rs:231-233`).
- `Auto` — try keyring, fall back to file (`AutoAuthStorage`, `storage.rs:250-291`).
- `Ephemeral` — process-local `HashMap<String, AuthDotJson>` (`EPHEMERAL_AUTH_STORE`, `storage.rs:294`). Used for externally injected ChatGPT auth tokens and tests.

#### 2c. File format (`AuthDotJson`)

Defined in `codex-rs/login/src/auth/storage.rs:32-48`:
```rust
pub struct AuthDotJson {
    pub auth_mode: Option<AuthMode>,                  // "ApiKey" | "Chatgpt" | "ChatgptAuthTokens" | "AgentIdentity"
    #[serde(rename = "OPENAI_API_KEY")]
    pub openai_api_key: Option<String>,
    pub tokens: Option<TokenData>,
    pub last_refresh: Option<DateTime<Utc>>,
    pub agent_identity: Option<String>,
}
```

`TokenData` (`codex-rs/login/src/token_data.rs:10-25`):
```rust
pub struct TokenData {
    pub id_token: IdTokenInfo,        // serialized as the raw JWT string, parsed on read
    pub access_token: String,         // JWT
    pub refresh_token: String,
    pub account_id: Option<String>,
}
```

Concrete on-disk shape (from test fixtures, `codex-rs/login/src/auth/auth_tests.rs:60-67`):
```json
{
  "OPENAI_API_KEY": "sk-…",
  "tokens": {
    "id_token": "<jwt>",
    "access_token": "<jwt>",
    "refresh_token": "<opaque>",
    "account_id": "<chatgpt_account_id>"
  },
  "last_refresh": "2024-…Z"
}
```

`id_token` is serialized back as `raw_jwt` (`token_data.rs:171`), with a flat in-memory cache of the parsed claims for `email`, `chatgpt_plan_type`, `chatgpt_user_id`, `chatgpt_account_id`, and `chatgpt_account_is_fedramp` extracted from the `https://api.openai.com/auth` claim namespace (`parse_chatgpt_jwt_claims`, `token_data.rs:137`).

#### 2d. Env-var overrides

Recognized env vars (`codex-rs/login/src/auth/manager.rs:465-489`):

- `OPENAI_API_KEY` — read by `read_openai_api_key_from_env`. Not auto-loaded into `auth.json`; primarily for API-key auth fallback.
- `CODEX_API_KEY` — opt-in (only honored when `AuthManager::new(... enable_codex_api_key_env=true, ...)`). When present, **takes precedence over any persisted auth** (`load_auth`, `manager.rs:730-733`).
- `CODEX_ACCESS_TOKEN` — interpreted as an agent-identity JWT and verified against `chatgpt.com/backend-api` JWKS before being accepted (`load_auth`, `manager.rs:757-761`; `verified_agent_identity_record`, `manager.rs:491`).
- `CODEX_HOME` — relocates the entire credentials directory.
- `CODEX_REFRESH_TOKEN_URL_OVERRIDE` / `CODEX_REVOKE_TOKEN_URL_OVERRIDE` — testing/staging overrides (`manager.rs:96-97`).

### 3. Refresh semantics

Defined in `codex-rs/login/src/auth/manager.rs`:

- The refresh endpoint is `https://auth.openai.com/oauth/token` (`REFRESH_TOKEN_URL`, `manager.rs:94`).
- Request is JSON: `{ client_id, grant_type: "refresh_token", refresh_token }` (`RefreshRequest`, `manager.rs:906`).
- On success the response may include any subset of `id_token`, `access_token`, `refresh_token`. Whatever is returned is merged into `auth.json`, and `last_refresh` is set to `Utc::now()` (`persist_tokens`, `manager.rs:781-804`). This means the **refresh token itself rotates** when the server chooses to issue a new one.

**Proactive refresh.** `AuthManager::auth()` (`manager.rs:1404-1417`) calls `is_stale_for_proactive_refresh` (`manager.rs:1786-1806`):
```rust
const TOKEN_REFRESH_INTERVAL: i64 = 8;
// …
if let Some(tokens) = auth_dot_json.tokens.as_ref()
    && let Ok(Some(expires_at)) = parse_jwt_expiration(&tokens.access_token)
{
    return expires_at <= Utc::now();
}
// fallback if no exp claim:
last_refresh < Utc::now() - chrono::Duration::days(TOKEN_REFRESH_INTERVAL)
```
So Codex refreshes when the access-token JWT is past `exp`, or as a fallback when `last_refresh` is older than **8 days**.

**Reactive refresh on 401.** When the upstream API returns 401, `UnauthorizedRecovery` (`manager.rs:1068-1235`) walks a small state machine:
1. **Reload from storage** if `account_id` matches the in-memory account_id. If on-disk auth differs from cached, treat that as "another process already refreshed; just adopt it" and skip the network refresh.
2. **Refresh via authority** (call the token endpoint with the cached refresh token).
3. Done.

Account-id matching is the key guard: `reload_if_account_id_matches` (`manager.rs:1427-1460`). If the account_id on disk has changed (user logged out / logged in as someone else), recovery is *aborted* with `REFRESH_TOKEN_ACCOUNT_MISMATCH_MESSAGE = "Your access token could not be refreshed because you have since logged out or signed in to another account."` (`manager.rs:92`).

**Refresh concurrency.** `AuthManager` holds a `Semaphore` with `permits = 1` (`manager.rs:1326`). Every `refresh_token` / `refresh_token_from_authority` acquires it (`manager.rs:1658-1664`, `1697-1704`). So within a single process, refreshes are serialized — no internal refresh race. **Across processes**, there is no mutex on `auth.json`; the only protection is the read-modify-write pattern in `persist_tokens` plus the reload-on-401 step. The semaphore comment block at `manager.rs:1050-1067` explicitly calls out the design:
> "Attempt to reload the auth data from disk. We only reload if the account id matches the one the current process is running as. … If the persisted token differs from the cached token, we can assume that some other instance already refreshed it."

**Permanent refresh failure classification.** A 401 from the refresh endpoint is parsed into `RefreshTokenFailedReason` via `classify_refresh_token_failure` (`manager.rs:851-878`):
- `refresh_token_expired` → "Please log out and sign in again."
- `refresh_token_reused` → "Please log out and sign in again." (token-reuse / replay detection)
- `refresh_token_invalidated` → revoked.
- anything else → "Other" (logged with `backend_body` for diagnosis).

Once a permanent failure is recorded, it is cached in `CachedAuth.permanent_refresh_failure` (`manager.rs:996-1008`) so subsequent calls fail fast without hitting the network (`refresh_token_from_authority_impl`, `manager.rs:1707-1739`).

### 4. Rate-limit and account-level signals

Rate-limit signals come back **on the API requests, not the auth endpoint**. From `codex-rs/protocol/src/protocol.rs:2069-2089`:
```rust
pub struct RateLimitSnapshot {
    pub limit_id: Option<String>,
    pub limit_name: Option<String>,
    pub primary: Option<RateLimitWindow>,
    pub secondary: Option<RateLimitWindow>,
    pub credits: Option<CreditsSnapshot>,
    pub plan_type: Option<crate::account::PlanType>,
    pub rate_limit_reached_type: Option<RateLimitReachedType>,
}

pub enum RateLimitReachedType {
    RateLimitReached,
    WorkspaceOwnerCreditsDepleted,
    WorkspaceMemberCreditsDepleted,
    WorkspaceOwnerUsageLimitReached,
    WorkspaceMemberUsageLimitReached,
}
```
Each `RateLimitWindow` carries `used_percent`, `window_minutes`, and `resets_at` (`protocol.rs:2091-2101`). These rate limits are **per ChatGPT account**, scoped by the `ChatGPT-Account-Id` header that Codex sends on backend requests:
```rust
if let Some(acc) = &self.chatgpt_account_id
    && let Ok(name) = HeaderName::from_bytes(b"ChatGPT-Account-Id")
    && let Ok(hv) = HeaderValue::from_str(acc)
{
    h.insert(name, hv);
}
```
(`codex-rs/backend-client/src/client.rs:213-218`). A FedRAMP-flagged account additionally sends `X-OpenAI-Fedramp: true` (`backend-client/src/client.rs:219-223`).

There is generic exponential backoff in `codex_core::util::backoff` used by the chat client (`codex-rs/core/src/util.rs:88`, used by `core/src/compact.rs:241`), but the auth layer itself only handles `401` (refresh) and `429` is surfaced to the caller as a `RateLimitSnapshot`.

### 5. The critical question: ship auth from one machine to another?

#### What's portable

- The entire credential is the contents of `auth.json` (or the keyring blob, which is the same JSON serialized as a string under `service="Codex Auth"`, key derived from a *hash of the canonical codex_home path*).
- The tokens themselves contain **no device-binding claims**: the JWT claims that Codex parses are `email`, `chatgpt_plan_type`, `chatgpt_user_id`, `chatgpt_account_id`, `chatgpt_account_is_fedramp`, and standard `exp` (`token_data.rs:71-99`). No `device_id`, no IP pin, no client-fingerprint constraint is parsed or enforced client-side.
- The refresh token is the only long-lived secret. It is opaque (not parsed as a JWT) and is sent verbatim to `https://auth.openai.com/oauth/token`.
- PKCE is per-login only; once `exchange_code_for_tokens` succeeds, the `code_verifier` is discarded. The persisted tokens do not depend on it.
- The optional `OPENAI_API_KEY` field is itself a portable token-exchanged API key derived from the id_token; it carries the same account binding.

**Practical implication.** Copying `~/.codex/auth.json` (mode 0600) from machine A to machine B and running `codex` on B with the same `CODEX_HOME` works. There is no client-side check that pins the credential to a host, hostname, hardware, MAC, or install. The keyring-stored variant requires re-serializing the same JSON into the destination keyring (or just dropping it as `auth.json` and using `AuthCredentialsStoreMode::File` or `Auto` — `Auto`'s loader reads the file if keyring is empty: `AutoAuthStorage::load`, `storage.rs:266-275`).

If the keyring is the source, note that `compute_store_key` (`storage.rs:163`) hashes the *canonicalized* codex_home path. If you set `CODEX_HOME` differently on the destination, the keyring entry won't be found — the `auth.json` file path is the safer transport.

#### What breaks across multiple concurrent sessions

1. **Refresh-token rotation races.** On each refresh, the server may return a new `refresh_token` (it's an optional field in `RefreshResponse`, `manager.rs:913-918`). If machine A refreshes first and gets a rotated token, machine B's now-stale refresh token will be rejected with `refresh_token_reused` (`manager.rs:857`) — surfaced to the user as: *"Your access token could not be refreshed because your refresh token was already used. Please log out and sign in again."* (`REFRESH_TOKEN_REUSED_MESSAGE`, `manager.rs:88`).

   - Inside one process this is safely serialized by `refresh_lock: Semaphore::new(1)` plus the "reload if disk newer" check.
   - Across processes / machines, the disk-reload step only helps if both share the same `auth.json` on a synchronously-mounted filesystem. Across separate machines (the migration scenario), once A rotates, B is dead until you re-copy `auth.json`.

2. **Permanent failure caching.** Once B sees `refresh_token_reused`, the failure is sticky for that auth snapshot (`record_permanent_refresh_failure_if_unchanged`, `manager.rs:1493-1508`). B will fail fast on every subsequent request until either a logout or a successful `reload()` with a *new* on-disk `auth.json`.

3. **Workspace-id enforcement.** `forced_chatgpt_workspace_id` (CLI flag and `enforce_login_restrictions`, `manager.rs:617-695`) checks that the cached `chatgpt_account_id` matches the configured workspace. If the migrating user's workspace flag differs across machines, the credentials are nuked with `logout_with_message` (`manager.rs:697`).

4. **Rate limits are account-scoped, not credential-scoped.** Because every request carries `ChatGPT-Account-Id` (`backend-client/src/client.rs:213`), running N concurrent Codex processes on N machines under the same login will all share the same `RateLimitSnapshot` buckets (`primary` short window + `secondary` long window). The CLI does **not** parallel-divide quota; it just observes that the bucket is closer to full. `RateLimitReachedType` includes `WorkspaceOwnerCreditsDepleted` and `WorkspaceMemberCreditsDepleted` for credit-based plans, which apply to the whole account regardless of how many machines you spread the credential across.

5. **No client-side per-machine throttle.** There is no internal QPS limit beyond the generic `backoff()` retry; the only quotas are server-side.

#### What is safe-ish

- Read-only / short-lived burst usage on multiple machines is fine as long as the access_token hasn't expired (its `exp` is decoded from the JWT, `parse_jwt_expiration`, `token_data.rs:130`). With a non-expired access_token, no refresh fires, no rotation race.
- The "ephemeral" mode is interesting for containers: `login_with_chatgpt_auth_tokens` (`manager.rs:567-583`) writes auth into the in-memory ephemeral store (process-local), useful for a parent app injecting access tokens without ever touching disk. Used by app-server / external auth integrations.
- The `AgentIdentity` flow (`login_with_access_token`, `manager.rs:545-564`; consumes a JWT verified against `chatgpt.com/backend-api` JWKS) is a separate path designed for non-interactive agents and uses an embedded `agent_private_key`; the agent-identity claim is workspace-scoped (`AgentIdentityAuthRecord`, `storage.rs:50-59`). That's a more principled mechanism than copying user OAuth tokens, but requires server-side issuance.

#### Concrete recipe for "auth once, run many"

If you must do it:
1. `codex login` on a single trusted machine.
2. Copy `$CODEX_HOME/auth.json` to each target (or set `AuthCredentialsStoreMode::File` to keep it out of the keyring; this is the default).
3. Set `CODEX_HOME` consistently (or accept that the keyring key derives from that path).
4. **Centralize refresh.** Designate exactly one process/machine as "refresher": call `AuthManager::refresh_token` (or simply let it do its proactive 8-day / `exp <= now` check). Everyone else must re-pull `auth.json` after each refresh. Without this, you will hit `refresh_token_reused` permanently.
5. Alternative: keep `auth.json` on a shared filesystem with strong write consistency, so the per-process semaphore + the "reload if account_id matches" check (`UnauthorizedRecoveryStep::Reload`, `manager.rs:1186`) can dedupe refreshes. This is fragile (no advisory locking on the file).
6. For containers, prefer `CODEX_ACCESS_TOKEN` with a server-issued agent-identity JWT (`load_auth` precedence is documented above) — it skips the refresh-token rotation problem entirely because there is no refresh token; the JWT either validates or expires.

### 6. File-by-file reference index

| Concern | File |
|---|---|
| Browser/loopback OAuth server | `codex-rs/login/src/server.rs` |
| Device-code flow | `codex-rs/login/src/device_code_auth.rs` |
| `auth.json` schema and disk I/O | `codex-rs/login/src/auth/storage.rs` |
| Token / JWT parsing | `codex-rs/login/src/token_data.rs` |
| Refresh + 401 recovery + AuthManager | `codex-rs/login/src/auth/manager.rs` |
| Revocation of superseded tokens | `codex-rs/login/src/auth/revoke.rs` |
| Keyring backend | `codex-rs/keyring-store/` (used via `codex_keyring_store::DefaultKeyringStore`) |
| Storage mode enum | `codex-rs/config/src/types.rs` |
| `ChatGPT-Account-Id` header injection | `codex-rs/backend-client/src/client.rs:213` |
| Rate-limit shape | `codex-rs/protocol/src/protocol.rs:2069` |
| CLI entry points | `codex-rs/cli/src/login.rs` |
