# Round-1 acceptance MCP server: `@modelcontextprotocol/server-filesystem`

For the round-1 end-to-end test of per-step MCP support, Tenacious uses
the official MCP reference filesystem server,
[`@modelcontextprotocol/server-filesystem`](https://github.com/modelcontextprotocol/servers/tree/main/src/filesystem),
invoked via `npx`.

## Why this server

- **Off-the-shelf**. It is the canonical reference implementation
  shipped under the `@modelcontextprotocol` npm scope. We did not write
  it; we only invoke it.
- **No network**. The server reads and writes inside one user-supplied
  directory — no network sockets opened, no outbound HTTP calls made.
- **Available in this environment**. Verified during planning:
  `node v22.22.1`, `npm 11.12.1` are on the user's PATH and `npx -y`
  fetches the package on demand.
- **Wire-format correctness guaranteed**. As the reference
  implementation, its NDJSON JSON-RPC 2.0 framing is exactly what other
  MCP clients (codex, claude) expect.
- **Small, well-understood tool surface**. It exposes file-scoped tools
  (`read_file`, `list_directory`, `write_file`, …) suitable for a
  deterministic acceptance test.

## Exact invocation

```bash
npx -y @modelcontextprotocol/server-filesystem /tmp/tenacious-mcp-sandbox
```

`-y` skips the npx install confirmation prompt so the spawn is
unattended. The trailing path is the only directory the server is
allowed to access. The test creates a fresh tmp dir per run, seeds it
with `hello.txt`, and points the server at it.

## How Tenacious declares it in a step

```json
{
  "agent": "claude",
  "prompt": "use the filesystem MCP server to read hello.txt and write its contents to the outcome path",
  "next_steps": ["end"],
  "mcp_servers": {
    "fs": {
      "command": "/opt/homebrew/bin/npx",
      "args": ["-y",
               "@modelcontextprotocol/server-filesystem",
               "/tmp/tenacious-mcp-sandbox"]
    }
  }
}
```

The `command` MUST be an absolute path (or a name on PATH that the
agent can resolve at spawn time). Tenacious does not perform shell
lookup on the user's behalf.

## Sandbox layout (test harness)

The off-the-shelf acceptance test
(`tests/test_mcp_e2e_offshelf.py`) creates a tmp dir per run and seeds
it with a single file before invoking either the fake claude shim or
the real server:

```
<tmpdir>/sandbox/
  hello.txt           # "hello from mcp\n"
```

The filesystem server is granted access to `<tmpdir>/sandbox/` only.
Any path traversal outside that dir is rejected by the server itself,
not by Tenacious.

## Why the in-repo echo fixture is NOT the acceptance target

`tests/_mcp_servers/echo_server.py` is a self-contained NDJSON echo
server kept for the unit tests that exercise orchestrator-side
materialization without a Node dependency. It does NOT count as the
round-1 acceptance proof — the requirements call for an off-the-shelf
server, which is the filesystem reference implementation above.
