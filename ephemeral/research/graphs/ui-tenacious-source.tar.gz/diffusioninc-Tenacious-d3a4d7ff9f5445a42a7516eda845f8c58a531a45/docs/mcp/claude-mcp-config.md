# How the claude CLI configures MCP servers

> Source read at `~/Downloads/_old/src` (the requirements text refers to
> `~/Downloads/src`; the real local copy on this machine is under
> `_old/`). File paths below are relative to that root.

## Profile directory: `CLAUDE_CONFIG_DIR`

Claude resolves its profile dir from the `CLAUDE_CONFIG_DIR` env var
(see `utils/config.ts` and the action handler in `main.tsx`). Tenacious
already exports `CLAUDE_CONFIG_DIR=<run_root>/profiles/<step>` per step
(`tenacious/orchestrator.py::run_claude`). User/project/local MCP
sources are read from that directory and from the current project.

## The relevant CLI flags

Claude has a CLI surface for dynamic MCP configuration. Two flags
matter for the Tenacious per-step path:

- `--mcp-config <configs...>` — variadic. Each entry is either a path
  to a JSON file or an inline JSON string. The flag is registered in
  `main.tsx` (the action handler around line 1000):

  ```ts
  .option('--mcp-config <configs...>',
          'Load MCP servers from JSON files or strings (space-separated)')
  ```

  Parsing happens around `main.tsx:1413`: each arg is tried as JSON
  first (`safeParseJSON`), then as a file path (`parseMcpConfigFromFilePath`).
  All accepted entries land in the `"dynamic"` scope.

- `--strict-mcp-config` — when present, claude uses ONLY the servers
  from `--mcp-config` and ignores user/project/local/enterprise sources
  for this invocation. Same `main.tsx` registration:

  ```ts
  .option('--strict-mcp-config',
          'Only use MCP servers from --mcp-config, ignoring all other ' +
          'MCP configurations', () => true)
  ```

  Used together, the two flags give a deterministic, replacement-only
  MCP context — exactly what Tenacious wants for a step.

## File schema

`services/mcp/types.ts` defines the zod schemas:

- `McpJsonConfigSchema` requires a top-level `{ "mcpServers": { ... } }`
  object.
- `McpServerConfigSchema` is the union of stdio / sse / http / ws /
  sdk / claudeai-proxy / sse-ide variants. Tenacious round-1 emits the
  stdio variant only:

  ```ts
  export const McpStdioServerConfigSchema = lazySchema(() =>
    z.object({
      type: z.literal('stdio').optional(),  // back-compat: default stdio
      command: z.string().min(1, 'Command cannot be empty'),
      args: z.array(z.string()).default([]),
      env: z.record(z.string(), z.string()).optional(),
    }))
  ```

Tenacious emits an explicit `type: "stdio"` to keep the file
unambiguous to a reader.

### Sample mcp-servers.json

```json
{
  "mcpServers": {
    "fs": {
      "type": "stdio",
      "command": "/opt/homebrew/bin/npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem",
               "/tmp/mcp-sandbox"],
      "env": {"ECHO_PREFIX": "X:"}
    }
  }
}
```

## Discovery vs flag-driven config

Claude has several MCP configuration scopes — `local`, `user`, `project`,
`dynamic`, `enterprise`, `claudeai`, `managed` (see `ConfigScopeSchema`
in `services/mcp/types.ts`). The orchestrator's profile dir feeds the
`user`/`project`/`local` scopes for that invocation; the auto-discovered
`enterprise`/`claudeai`/`managed` scopes come from system-wide policy.

For per-step MCP, Tenacious uses the explicit `--mcp-config`/`--strict-mcp-config`
pair so the step sees exactly and only its declared servers. This avoids
accidental tool inheritance from the user's wider claude environment and
keeps a step's tool surface reproducible across machines.

## How servers are launched

Claude spawns each stdio server as a subprocess with the declared
`command`, `args`, and `env`, then exchanges newline-delimited
JSON-RPC 2.0 messages over the child's stdio (per the MCP spec). Sse,
http, ws, sdk, etc., are different transports with different schemas;
the stdio variant is the simplest and the only one Tenacious round-1
exposes.

## Practical implications for Tenacious

1. The orchestrator writes
   `<profile_dir>/mcp-servers.json` per step with the per-step server
   set (or nothing, if `mcp_servers` is empty/missing).
2. When the file exists, the orchestrator appends
   `--mcp-config <abs-path> --strict-mcp-config` to the claude
   command. Without `--strict-mcp-config`, claude would merge the
   step's servers with whatever it auto-discovered for the calling
   user/project — a non-deterministic tool surface from the step's POV.
3. The file location inside `CLAUDE_CONFIG_DIR` is incidental — claude
   doesn't auto-load it. The path is what matters because the orchestrator
   passes it explicitly.
