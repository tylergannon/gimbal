# How codex configures MCP servers

> Source read at `~/Downloads/_old/codex` (the requirements text refers to
> `~/Downloads/codex`; the real local copy on this machine is under
> `_old/`). All file paths below are relative to that root.

## Profile directory: `CODEX_HOME`

Codex resolves its configuration root from the `CODEX_HOME` env var
(default `~/.codex`). The resolution function is in
`codex-rs/utils/home-dir/src/lib.rs::find_codex_home`:

- If `CODEX_HOME` is set it MUST point to an existing directory; codex
  canonicalizes it and uses it as-is.
- If unset, codex appends `.codex` to the user home dir.

Tenacious already exports `CODEX_HOME=<run_root>/profiles/<step>` per
step (`tenacious/orchestrator.py::run_codex`), so any file the
orchestrator drops into that directory is what codex will read.

## Where MCP server config lives

Codex reads `[mcp_servers.<name>]` blocks from `$CODEX_HOME/config.toml`.
The entry point is `codex-rs/core/src/config/mod.rs::load_global_mcp_servers`:

```rust
pub async fn load_global_mcp_servers(
    codex_home: &Path,
) -> std::io::Result<BTreeMap<String, McpServerConfig>>
```

It reads the merged TOML for `codex_home`, pulls the `mcp_servers`
table, and deserializes each entry through `McpServerConfig`.

There is no command-line flag for an alternate MCP config path — codex
always reads `$CODEX_HOME/config.toml`. To inject per-step MCP
configuration, write that file into the profile directory before
invoking `codex exec`.

## TOML schema (stdio servers)

The full struct definitions are in
`codex-rs/config/src/mcp_types.rs` (`RawMcpServerConfig` → `McpServerConfig`,
`McpServerTransportConfig::Stdio`). Codex supports two transports;
Tenacious round-1 wires only `stdio`.

Stdio fields (all optional except `command`):

| TOML key | Type | Notes |
| --- | --- | --- |
| `command` | string (required) | Executable path or name |
| `args` | array of strings | Default `[]` |
| `env` | inline table of string → string | Default omitted |
| `env_vars` | array | Used to forward selected outer env vars (round-1 N/A) |
| `cwd` | string (path) | Per-server working directory (round-1 N/A) |
| `startup_timeout_sec` | float | Initialize + tools/list timeout |
| `tool_timeout_sec` | float | Per-tool default timeout |
| `enabled` | bool | Default `true` |

The same struct also accepts `url`, `bearer_token_env_var`,
`http_headers`, and `env_http_headers` for streamable HTTP transports,
but those are mutually exclusive with `command` (codex picks the
transport based on which key is set; `command` → stdio, `url` → HTTP).

### Sample config.toml

```toml
[mcp_servers.fs]
command = "/opt/homebrew/bin/npx"
args = ["-y", "@modelcontextprotocol/server-filesystem", "/tmp/mcp-sandbox"]
env = { ECHO_PREFIX = "X:" }

[mcp_servers.echo]
command = "/usr/bin/python3"
args = ["/abs/path/to/echo_server.py"]
```

`bearer_token` is intentionally rejected at load time
(`ensure_no_inline_bearer_tokens`) — codex requires
`bearer_token_env_var` instead.

## How servers are launched

After config load codex starts each stdio server as a subprocess with
the declared `command`, `args`, and (optional) `env`, then exchanges
newline-delimited JSON-RPC 2.0 messages over the child's stdio. See
`codex-rs/codex-mcp/src/mcp/mod.rs` for the connection manager; the
plugin/requirements layering happens on top of the raw map returned
from `load_global_mcp_servers`.

## Practical implications for Tenacious

1. Setting `CODEX_HOME=<profile_dir>` is enough — codex looks at one
   well-known path inside it.
2. The orchestrator writes `<profile_dir>/config.toml` with
   `[mcp_servers.<name>]` blocks before spawning `codex exec`.
3. No CLI flag is needed; codex auto-discovers via `$CODEX_HOME`.
4. The schema accepts more keys than Tenacious exposes (e.g. timeouts,
   approval mode, OAuth scopes). Round-1 keeps the common schema small
   on purpose; advanced keys can be added later by extending the
   per-step JSON validator and the TOML emitter together.
