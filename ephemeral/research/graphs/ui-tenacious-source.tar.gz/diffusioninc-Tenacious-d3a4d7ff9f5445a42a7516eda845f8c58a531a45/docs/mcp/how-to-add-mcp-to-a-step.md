# Adding an MCP server to a step

A workflow step can declare MCP servers in its YAML. When the orchestrator
visits the step, it writes the server set into the per-step profile
directory, and (for claude) passes `--mcp-config <abs-path>
--strict-mcp-config` to the CLI. The spawned agent then sees exactly the
servers you declared.

For background on the wiring, see
[`tenacious-mcp-design.md`](./tenacious-mcp-design.md). For the underlying
agent-side mechanics see [`claude-mcp-config.md`](./claude-mcp-config.md)
and [`codex-mcp-config.md`](./codex-mcp-config.md).

## Schema recap

Each step may carry an optional `mcp_servers` map. YAML is preferred:

```yaml
mcp_servers:
  fs:
    command: /opt/homebrew/bin/npx
    args:
    - -y
    - "@modelcontextprotocol/server-filesystem"
    - /tmp/tenacious-mcp-sandbox
```

The legacy JSON shape is the same:

```json
"mcp_servers": {
  "<name>": {
    "command": "/abs/path/to/exe",
    "args": ["--flag", "value"],
    "env": {"KEY": "value"}
  }
}
```

Rules: `command` is required; `args` defaults to `[]`; `env` defaults to
`{}`. Names must match `^[A-Za-z0-9_-]{1,64}$`. Unknown keys (including
`cwd`) are rejected at load time. Explicit `null` for `mcp_servers` is
rejected — omit the key if you mean "no servers".

## Three worked examples

### Example 1: filesystem reference server (off-the-shelf)

The legacy JSON working snippet is in
[`example-step-with-mcp.json`](./example-step-with-mcp.json). It
declares the `@modelcontextprotocol/server-filesystem` server scoped to
one sandbox directory:

```json
"mcp_servers": {
  "fs": {
    "command": "/opt/homebrew/bin/npx",
    "args": ["-y",
             "@modelcontextprotocol/server-filesystem",
             "/tmp/tenacious-mcp-sandbox"]
  }
}
```

This server requires no credentials and makes no network calls beyond
the initial `npx` fetch. See [`chosen-test-server.md`](./chosen-test-server.md).

### Example 2: in-repo echo fixture (stdio, no Node)

For tests or quick local demos you can point a step at the bundled
echo server. It uses stdlib Python only — no extra install step.

```json
"mcp_servers": {
  "echo": {
    "command": "/usr/bin/python3",
    "args": ["/abs/path/to/tenacious/tests/_mcp_servers/echo_server.py"],
    "env": {"ECHO_PREFIX": "X:"}
  }
}
```

The `ECHO_PREFIX` env var changes the echoed string so you can prove
the orchestrator's `env` plumbing actually reached the spawned server.

### Example 3: a `uvx`-launched stdio server

Many of the official MCP reference servers ship as Python packages and
can be launched through `uvx` (Astral's per-package runner). For
example, the time server:

```json
"mcp_servers": {
  "time": {
    "command": "/opt/homebrew/bin/uvx",
    "args": ["mcp-server-time", "--local-timezone", "America/Los_Angeles"]
  }
}
```

`uvx` will fetch + cache the `mcp-server-time` package on first use,
then spawn it directly. The launch model is identical to the npx case:
Tenacious supplies the command + args, the agent talks NDJSON JSON-RPC
on the child's stdio.

## What happens at runtime

1. The orchestrator validates the `mcp_servers` block at workflow load.
2. On each visit of the step, the orchestrator writes one file into the
   per-step profile directory (`<run_root>/profiles/<step>/`):
   - For `agent: "claude"` → `mcp-servers.json`.
   - For `agent: "codex"`  → `config.toml`.
3. For claude, the rendered command line gains
   `--mcp-config <abs-path> --strict-mcp-config`. For codex, no extra
   flag is needed — codex auto-loads via `$CODEX_HOME`.
4. The orchestrator emits one summary line in `run.log` per visit,
   e.g. `mcp_servers: 1 stdio (fs)` (or `mcp_servers: none`).
5. The agent process talks to each declared server over its child's
   stdio and exposes the server's tools alongside its built-in tools.

## Tips

- Always use an absolute path in `command`. The agent's `cwd` is the
  project dir, not the orchestrator's cwd.
- Server names should be short and stable — they appear in run.log and
  in the agent's tool listing.
- Stdio and HTTP transports are supported. SSE / WebSocket / SDK
  transports are still deferred.
- Per-server `cwd`, OAuth flows, and timeouts are also deferred. For HTTP
  bearer auth, use `bearer_token_env_var`.

## Verifying it worked

After running a workflow with MCP-equipped steps, you can inspect:

- `~/.tenacious/runs/<run-slug>/profiles/<step>/mcp-servers.json`
  (claude) or `…/config.toml` (codex).
- `~/.tenacious/runs/<run-slug>/run.log` for the
  `mcp_servers: N stdio (...), M http (...)` line.
- The agent's transcript in `~/.tenacious/runs/<run-slug>/<step>/<visit>/stdout.txt`
  for tool calls that match the names of your declared servers.
