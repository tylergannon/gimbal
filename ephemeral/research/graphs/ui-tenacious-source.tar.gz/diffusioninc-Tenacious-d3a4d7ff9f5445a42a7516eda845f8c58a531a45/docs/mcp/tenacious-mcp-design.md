# Per-step MCP server support in Tenacious

This doc describes how Tenacious materializes MCP server configuration
declared inside a workflow step into the temporary profile
directory created for that step, so the spawned CLI agent (claude or
codex) picks the servers up automatically.

For the underlying agent mechanics see
[`codex-mcp-config.md`](./codex-mcp-config.md) and
[`claude-mcp-config.md`](./claude-mcp-config.md).

## Goal

A workflow step may carry a `mcp_servers` map describing one or more MCP
servers. YAML is the primary workflow format; legacy JSON workflows use
the same schema. When the orchestrator visits that step, it:

1. Writes a per-agent MCP configuration file into the per-(run, step)
   profile dir (`<run_root>/profiles/<step>/`).
2. For claude, also passes `--mcp-config <abs-path> --strict-mcp-config`
   to the CLI so the step sees only those servers.
3. Emits one line in `run.log` of the form
   `mcp_servers: 1 stdio (fs), 1 http (slack)` (or
   `mcp_servers: none`).

## Step schema

The orchestrator already loads each step via
`Step.from_dict(slug, dict)`. A new OPTIONAL key, `mcp_servers`, was
added:

```yaml
agent: claude
prompt: "..."
next_steps:
- code_review
mcp_servers:
  fs:
    command: /opt/homebrew/bin/npx
    args:
    - -y
    - "@modelcontextprotocol/server-filesystem"
    - /tmp/tenacious-mcp-sandbox
    env: {}
```

Legacy JSON is accepted too:

```json
{
  "agent": "claude",
  "prompt": "...",
  "next_steps": ["code_review"],
  "mcp_servers": {
    "fs": {
      "command": "/opt/homebrew/bin/npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem",
               "/tmp/tenacious-mcp-sandbox"],
      "env": {}
    }
  }
}
```

Validation, enforced at `Workflow.load`:

- Missing key → empty dict (no servers materialized).
- Explicit `null` → rejected with `ValueError("step <slug>: mcp_servers
  must be an object, got null")`. Round-1 picks rejection over
  silent-empty so misconfiguration cannot be ignored.
- Server name MUST match `^[A-Za-z0-9_-]{1,64}$`.
- Each server value MUST be an object for exactly one transport:
  - stdio: `command` (string, required, non-empty), optional `args`, and
    optional `env`.
  - HTTP: `url` (string, required, non-empty), optional `headers`, and
    optional `bearer_token_env_var`.
- Unknown keys (including `cwd`) under a server entry raise
  `ValueError("step <slug>: unknown mcp_servers field(s) for <name>: …")`.

The dataclass field uses `field(default_factory=dict)` so two freshly
constructed steps never share the same mutable default.

## Materialization

```python
def _materialize_mcp_config(step: Step, profile_dir: Path) -> Path | None
```

The helper is called by both runners before they spawn the agent.

- **codex** → writes `<profile_dir>/config.toml` with one
  `[mcp_servers.<name>]` block per server and returns `None`. Codex
  discovers it via `$CODEX_HOME=<profile_dir>` (see
  `codex-mcp-config.md`). No CLI flag is needed.
- **claude** → writes `<profile_dir>/mcp-servers.json` (with
  `mcpServers: {<name>: {type, ...}}`) and returns the absolute path.
  The caller appends
  `--mcp-config <abs-path> --strict-mcp-config` to the claude CLI.
- **empty `mcp_servers`** → no file written, helper returns `None`.
  The no-MCP-configured profile dir stays empty of MCP artifacts.

The helper overwrites unconditionally on every visit. `workflow.json` is
frozen at run creation, so resumed runs produce byte-identical content
on re-emit.

## Replacement-only semantics for claude

`--strict-mcp-config` makes step-declared MCP servers the ONLY MCP
sources the claude agent sees for that invocation (replacement, not
augmentation). User, project,
local, enterprise, and claudeai sources are ignored.

This is a deliberate round-1 contract choice:

- Steps must be reproducible across machines. If a step inherited a
  user's wider MCP set, the step's tool surface would silently vary by
  developer.
- The requirements explicitly rule out global/run-level MCP defaults
  this round. Strict mode is the simplest enforcement.

Step-declared MCP servers are unrelated to any pre-existing MCP servers
the runtime might have configured for the user — the orchestrator does
not read them and the agent does not see them.

Codex does not have a `--strict-mcp-config` equivalent (its global
MCP set is the union of all configured sources in its config layer
stack). Because Tenacious points codex at a per-step `CODEX_HOME` that
contains only what the orchestrator writes, the effect is the same:
only the step's servers are visible.

## Logging

Each step visit emits exactly one summary line right after the cmd
line in run.log:

```
[2026-...] step code visit 1 (agent=claude, context=empty)
[2026-...]   mcp_servers: 1 stdio (fs)
[2026-...]   claude cmd: ...
```

When no MCP is declared the line reads `mcp_servers: none`. This is
useful for the read-only viewer and for grepping a run's history.

## Out of scope

- SSE / WebSocket / SDK MCP transports.
- OAuth flows for MCP servers. Bearer-token injection from an environment
  variable is supported for HTTP servers, but Tenacious does not perform
  OAuth.
- Per-server `cwd`. Codex and claude both accept it, but their
  semantics differ slightly and the common schema deliberately stays
  small for round 1.
- Sharing or inheriting MCP config across steps.
- Run-level or workflow-level MCP defaults.
- Any UI/viewer change beyond the new files in the run dir tree.
