# Plan: per-step effort / reasoning level, validated at startup

## Goal

Add an optional per-step `effort` field to the workflow JSON that maps to:

- Claude steps: `claude -p ... --effort <level>`
- Codex steps:  `codex exec ... -c 'model_reasoning_effort="<level>"'`

The orchestrator must **fail fast at load time** (before any run dir is
created) if a step's `effort` value is not a level that makes sense for
that step's `agent` + `model`. This mirrors the existing
`_parse_health_monitor` fail-fast contract: a durable config must not
silently self-disable or pass a bad flag to the CLI.

## Verified CLI facts (installed versions)

- `claude` 2.1.144: flag is `--effort <level>`; values `low`, `medium`,
  `high`, `xhigh`, `max`. `xhigh` is **Opus-4.7-exclusive**. No env-var
  equivalent.
- `codex-cli` 0.130.0: no flag; config override
  `-c 'model_reasoning_effort="<level>"'`. Values `minimal`, `low`,
  `medium`, `high`, `xhigh` (verified `high` and `xhigh` echo back as
  `reasoning effort: ...` for `gpt-5.4`). Note `minimal` exists for
  codex but not claude; `max` exists for claude but not codex.

## Allowed-level matrix

A single source-of-truth table in `orchestrator.py`, agent default plus
per-model overrides:

```python
EFFORT_LEVELS = {
    "claude": {
        None: {"low", "medium", "high", "max"},          # any non-opus-4.7
        "claude-opus-4-7": {"low", "medium", "high", "xhigh", "max"},
    },
    "codex": {
        None: {"minimal", "low", "medium", "high", "xhigh"},
    },
}
```

Resolution rule for a step with `effort` set:

1. `agent` must be a key in `EFFORT_LEVELS` (claude/codex). Else
   `ValueError`.
2. allowed = `EFFORT_LEVELS[agent].get(model, EFFORT_LEVELS[agent][None])`
   — i.e. exact-model override if present, else the agent default set.
3. `effort` must be a non-empty string in `allowed`. Else `ValueError`
   naming the step slug, agent, model, bad value, and the sorted allowed
   set.
4. `effort` unset / `None` → no flag emitted (current behavior, the only
   value that means "don't touch reasoning").

Rationale for the `model=None` fallback: every Claude model accepts
`low/medium/high/max`; only `xhigh` is model-gated (Opus 4.7), so a step
that omits `model` but asks for `xhigh` is correctly rejected, while
`high` on an unspecified Claude model is allowed. Codex levels are not
model-gated in the versions we target, so one default set suffices.

## Changes

### 1. `tenacious/orchestrator.py` — dataclass + parse

- Add `effort: str | None = None` to `@dataclass class Step`
  (after `model`, before `outcome_retries`; ~line 136).
- In `Step.from_dict` (~line 150): `effort=d.get("effort")`.

### 2. `tenacious/orchestrator.py` — fail-fast validation

- Add module-level `EFFORT_LEVELS` table (near other constants).
- Add `@staticmethod Workflow._validate_effort(steps)` that iterates
  every step, applies the resolution rule above, and raises `ValueError`
  on the first offender. Message format consistent with
  `_parse_health_monitor`, e.g.:
  `step 'plan_eval': effort 'max' invalid for agent 'codex' model 'gpt-5.4'; allowed: high, low, medium, minimal, xhigh`
- Call it in `Workflow.load` right after the steps dict is built and
  before `_parse_health_monitor` (line ~180), so it raises during
  `Workflow.load`, before `create_run` makes any run dir. Both
  `execute_workflow` (1749) and the resume path (1809) go through
  `Workflow.load`, so resume is covered too.

### 3. `tenacious/orchestrator.py` — emit the CLI args

- `run_claude` (~line 788, after the `--model` block):
  ```python
  if step.effort:
      cmd += ["--effort", step.effort]
  ```
- `run_codex` (~line 739, after the `--model` block):
  ```python
  if step.effort:
      cmd += ["-c", f'model_reasoning_effort="{step.effort}"']
  ```
  (`-c` goes before the prompt/`resume` positional, matching how
  `--model` is appended before the prompt is added at line 745-747.)

### 4. `tenacious/orchestrator.py` — serialization

- Add `"effort": s.effort` to the per-step dict dumped at ~line 360 so
  the snapshot round-trips (kept consistent with `outcome_retries`).

### 5. `6step.yaml` — apply levels (workflow content)

Add `"effort"` to each step. Proposed values (adjustable — this is a
content choice, not required by the code change):

- claude steps (`requirements`, `plan`, `plan_update`, `code`,
  `health_monitor`, model `claude-opus-4-7`): `"effort": "xhigh"`
- codex steps (`plan_eval`, `code_review`, model `gpt-5.4`):
  `"effort": "xhigh"`

### 6. `tenacious/orchestrator.py` — surface levels in `--help`

`effort` is a per-step **workflow-JSON** field, not a CLI flag, so it
will not appear in argparse `--help` on its own. Add an argparse
`epilog` (with `formatter_class=argparse.RawDescriptionHelpFormatter`)
to the parser in `main()` (~line 1862), **generated from the
`EFFORT_LEVELS` table** so it cannot drift from validation. Rendered
form:

```
valid per-step "effort" levels (set per step in the workflow JSON):
  claude (claude-opus-4-7): low, medium, high, xhigh, max
  claude (other models):    low, medium, high, max
  codex:                    minimal, low, medium, high, xhigh
```

Implement as a small `_effort_help_text()` helper that walks
`EFFORT_LEVELS` (agent → {model: set}) and formats sorted level lists,
labeling the `None` key as "other models" / the agent default. The same
helper text is reused by the docs in change 7.

### 7. Docs — README + CLAUDE.md

- README (project-level usage doc): add a short "Per-step effort /
  reasoning level" subsection documenting the `effort` field, the
  per-agent/model matrix, that it is optional (omit = no flag), and that
  an invalid value fails fast at startup. Mirror the table from the
  `_effort_help_text()` helper so all three surfaces (validation error,
  `--help` epilog, README) state the same levels.
- CLAUDE.md: add one line under guidance noting that workflow `effort`
  values are validated at load against `EFFORT_LEVELS`, so when changing
  models/levels both must stay consistent (points future edits at the
  single source of truth).

### 8. Tests — `tests/test_effort.py` (new)

Pure, fast tests (no agent process needed):

- `Step.from_dict` parses `effort`; absent → `None`.
- `Workflow.load` **raises ValueError**:
  - claude step, `model` unset or non-opus, `effort: "xhigh"`
  - claude step, `effort: "minimal"` (codex-only level)
  - codex step, `effort: "max"` (claude-only level)
  - any step, `effort: "banana"` (unknown)
  - `effort` set on a step whose `agent` is neither claude nor codex
  - non-string `effort` (e.g. `5`)
- `Workflow.load` **accepts**: opus-4.7 + `xhigh`; codex + `minimal`;
  any + omitted `effort`.
- Arg construction: build a `Step` with `effort` and assert the cmd
  list from `run_claude` / `run_codex` contains `["--effort","high"]`
  / `["-c",'model_reasoning_effort="high"']`. Reuse whatever monkeypatch
  pattern `tests/test_*` already uses to stub `_supervise`/auth; if that
  is heavy, assert on a small extracted cmd-builder instead.

## Per-change validation (run these to prove each change)

1. Parse + dataclass:
   `python -c "from tenacious.orchestrator import Step; s=Step.from_dict('x',{'agent':'claude','prompt':'p','next_steps':[],'effort':'high'}); print(s.effort)"`
   → prints `high`.
2. Fail-fast (the headline requirement): a temp workflow JSON with a
   codex step `"effort":"max"` →
   `python -m tenacious.orchestrator /tmp/bad.json --goal x` exits
   non-zero with the `step '...': effort 'max' invalid for agent
   'codex'...` message and **no run dir created** under the runs root.
3. Valid passes: same harness with codex `"effort":"xhigh"` and claude
   `"effort":"xhigh"` loads without error.
4. Claude arg: assert `run_claude` cmd contains `--effort xhigh`.
5. Codex arg: assert `run_codex` cmd contains
   `-c model_reasoning_effort="xhigh"` before the prompt positional.
6. `--help` epilog: `python -m tenacious.orchestrator --help` prints
   the "valid per-step \"effort\" levels" block with the claude /
   claude-opus-4-7 / codex level lists matching `EFFORT_LEVELS`.
7. Docs consistency: README and CLAUDE.md effort sections list the same
   levels as the `--help` epilog and the validation error message
   (single source: `_effort_help_text()` / `EFFORT_LEVELS`).
8. Full suite still green: `python -m pytest tests/ -q`.

## Decisions / open points

- **Codex `xhigh`**: confirmed accepted by codex 0.130.0 for `gpt-5.4`.
  If you later pin codex models with different ladders, add per-model
  overrides under `EFFORT_LEVELS["codex"]`.
- **Should `effort` be required when `model` is set?** No — keeping it
  optional preserves current behavior; only the explicit string is
  validated.
- **Cleaner death vs. traceback**: `main()` does not wrap
  `execute_workflow` in try/except, so today a `ValueError` from
  `Workflow.load` prints a traceback and exits non-zero. That satisfies
  "die at startup". Optional polish: catch `ValueError` in `main()` and
  print `error: <msg>` + `return 1` (consistent with the
  `FileNotFoundError`/`RuntimeError` handling already in the resume
  branch). Recommend including this small polish.

## Git hygiene note

`scratch/` is currently untracked and **not** in `.gitignore`. Per
`CLAUDE.md`, every file must be committed or explicitly gitignored. This
plan file is scratch/working material — recommend adding a `scratch/`
line to `.gitignore` (committed) rather than committing the doc itself.
The actual change (orchestrator.py, 6step.yaml, tests/test_effort.py)
must be staged individually by explicit path — no wildcard `git add`.
