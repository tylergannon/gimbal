# Requirements - Round 1

## Q&A transcript

**Q1.** This is round 1. Your `next.md` lists several candidate improvements to the Tenacious orchestrator. Which ONE area should this round focus on?
- A. Multi-line interactive input
- B. Session viewer / telemetry
- C. Run isolation in a git worktree
- D. Questions control + "continue" context fix

**A1.** "This work needs to happen in a git worktree in another directory. There are currently running sessions that are using the code in this directory. Need a way to enter multi-line responses. Including multi-line text paste. Maybe we can look how codex and claude code do it. The source for claude code is in ~/Downloads/src. The source for codex is in ~/Downloads/codex. Downloads might have moved to _old. Need a viewer for the underlying cli coding agent sessions. It can be a CLI. It should let me choose the run and then let me view info about the underlying coding agent sessions including the messages."

**Q2.** Multi-line input UX: when an agent asks a question and you answer interactively (the `AnswerSource` /dev/tty path in orchestrator.py), how should you enter and SUBMIT a multi-line answer?
- A. Read-until-EOF (Ctrl-D)
- B. Empty-line / lone "." sentinel
- C. External editor ($EDITOR)
- D. Full inline TUI line editor (bracketed paste, cursor editing)

**A2.** "No more questions. Good luck!" — user ended the interview without selecting an option. Per the user's stated priorities (must support multi-line text paste; keep the round tightly bounded; "maybe look how codex/claude do it"), the requirements below adopt a robust, low-risk default and explicitly defer the heavier full-TUI approach.

## Decisions made on the user's behalf (Q2 unanswered)

- **Multi-line submission mechanism:** primary = **external editor ($EDITOR, like `git commit`)**. Rationale: it makes multi-line entry and multi-line *paste* work reliably with no terminal/bracketed-paste edge cases, is a small bounded change to `AnswerSource`, and supports editing before submit. **Fallback** when there is no usable TTY or `$EDITOR`: **read-until-EOF (Ctrl-D)**, which also natively accepts pasted multi-line blocks. A full inline TUI editor (Q2 option D) is explicitly OUT of scope this round.
- **Session viewer form:** a **read-only CLI** that lists runs, lets you pick one, then drills into that run's per-step coding-agent sessions and their messages. No live tail / no TUI dashboard this round.
- **Where dev happens:** all code changes for this round are made in a **dedicated git worktree in a separate directory**, not in the live `/Users/johntokash/dev/Tenacious` working tree (running Tenacious sessions depend on that checkout's code).

## In scope

1. **Multi-line interactive answers** in `tenacious/orchestrator.py` `AnswerSource.next_answer`:
   - When the orchestrator needs an interactive answer for an agent question, open `$EDITOR` on a temp file (seeded with the question as commented context if convenient), and use the saved file contents (trailing newline stripped, comment lines if any removed) as the answer.
   - The answer passed downstream may contain embedded newlines (multi-line). Verify the rest of the pipeline (`answer.txt` write, `render_continuation_prompt`) handles multi-line answers correctly.
   - Fallback path (no controlling TTY or no `$EDITOR`): read from `/dev/tty`/stdin until EOF (Ctrl-D) so multi-line and pasted input still work; this replaces the current single `readline()`.
   - Pre-canned answers file behavior: preserve the existing one-line-per-answer queue semantics; do not break existing `--answers` usage. (Multi-line entries in the canned file are NOT required this round.)

2. **Session-viewer CLI** for inspecting underlying coding-agent sessions:
   - A new command (e.g. `python -m tenacious.viewer` or a `tenacious view` subcommand) that:
     - Lists runs under `$TENACIOUS_HOME/runs` (newest first) and lets the user choose one.
     - For the chosen run, lists its steps/visits and the coding-agent session(s) involved.
     - Displays the agent **messages / conversation content** for a chosen session — derived from the per-visit `stdout.txt` (codex `--json` JSONL events; claude `--output-format json` result) and/or the per-step CLI profile session storage (see `docs/investigations/codex-session-storage.md` and `claude-code-session-storage.md`).
     - Also surfaces useful between-turn info already on disk: `meta.json` (agent, model, duration, exit, thread_id), `prompt.txt`, `outcome.txt`, and relevant `run.log` lines.
   - Read-only. Selection can be via simple numbered prompts or arguments; no full-screen TUI required.

3. **Git-worktree dev workflow**: create a worktree (off `main`) in a separate directory and perform all of this round's edits there, leaving the live checkout that running sessions use untouched until the user merges.

## Out of scope / NOT building this round

- Full inline TUI line editor with bracketed-paste detection and cursor key bindings (Q2 option D). Researching how Claude Code (`~/Downloads/_old/src`) and Codex (`~/Downloads/_old/codex`) implement it is allowed as background reference, but porting a TUI is a non-goal.
- Multi-line entries inside the pre-canned `--answers` file format.
- Turning the questions feature on/off mid-run; fixing the `"continue"` vs empty requirements-context interaction (Q1 option D) — deferred to a later round.
- Run isolation as a *product feature* (making orchestrated agents run inside per-run worktrees). The worktree requirement this round is only about where WE do the development, not a new orchestrator capability.
- Live/streaming session view, web UI, log following, search/filter across runs, editing or replaying sessions.
- Auth-bank changes, telemetry storage/schema changes, or any change to how agents are invoked.

## Goal

In a dedicated git worktree off `main` (so the live `/Users/johntokash/dev/Tenacious` checkout used by running Tenacious sessions is untouched), deliver two tightly-scoped improvements to the Tenacious orchestrator. First, replace the single-line interactive answer path in `AnswerSource` so the user can supply multi-line answers — including pasted multi-line blocks — by opening `$EDITOR` (git-commit style) with a robust read-until-EOF (Ctrl-D) fallback when no TTY/editor is available, while preserving the existing `--answers` canned-file behavior and ensuring multi-line answers flow correctly through the continuation prompt. Second, add a read-only session-viewer CLI that lists runs under `$TENACIOUS_HOME/runs`, lets the user pick a run, and then inspect that run's underlying coding-agent sessions — their messages plus per-visit metadata (prompt, meta.json, outcome, relevant log lines) — sourced from the per-visit `stdout.txt` and/or the per-step CLI profile session storage. Explicitly exclude a full bracketed-paste TUI editor, questions-control/"continue"-context fixes, run-isolation as a product feature, and any live/streaming or web viewer.
