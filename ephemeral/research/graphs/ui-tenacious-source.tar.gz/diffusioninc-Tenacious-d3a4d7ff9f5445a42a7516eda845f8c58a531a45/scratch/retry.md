# Plan: bounded feedback-retry on bad/missing/invalid outcome

Goal: convert single-step outcome flakes into self-healing retries instead
of aborting the whole run. Keep fail-fast after the budget is exhausted.
Scope: `tenacious/orchestrator.py` only. No workflow-schema changes
required (retry budget is a constant/optional field).

## Failure classes & retry mode

| Trigger | Where today | Retry session mode |
|---|---|---|
| Exited, no valid `outcome.txt` | `_run_step_visit` `:982` | **continue** (work likely done) |
| Outcome not in `valid_outcomes` | `execute_step` `:1029` | **continue** |
| `"question"` but questions disabled | `:1006` | **continue** |
| `"question"` but `question.txt` missing/empty | `:1010` (add empty check) | **continue** |
| Killed for hang/idle timeout | (new, Tier-1 #2) | **fresh** (`empty`) |

"continue" = force `should_continue=True` regardless of `step.context`,
exactly like the existing question loop at `:1026`.

## Changes

1. **Constant + optional override.** Add
   `OUTCOME_RETRY_BUDGET = 2`; allow per-step `"outcome_retries"` in
   `Step.from_dict` (default to the constant). No other schema change.

2. **Classify instead of raise.** In `_run_step_visit`, replace the
   no-outcome `raise` (`:982`) with a sentinel return (or a typed
   exception) carrying: reason, stderr tail, last-seen outcome,
   `killed: bool` (was the process group killed by us vs. clean exit).

3. **Retry orchestration in `execute_step`.** Wrap the visit + outcome
   validation in a bounded loop:
   - On any failure class above, if `attempts_left > 0`: decrement,
     `run.visit_counts[slug] += 1`, build a feedback prompt (below),
     run another visit. Log `retry N/B: <reason>` to `run.log`.
   - `should_continue`: `True` for the botched-protocol classes,
     `False` for the kill-triggered class.
   - On budget exhaustion, raise the original `RuntimeError` (unchanged
     message + `(after B retries)`).
   - Count retries against the global step budget `:1046` so a stuck
     step can't loop forever or drain auth-bank slots.

4. **Feedback prompt builder.** New
   `render_retry_prompt(step, run, step_dir, reason, prior_value)`,
   modeled on `render_continuation_prompt`. Must be **self-contained**
   (continue can silently degrade to fresh if no resumable handle):
   - restate goal + the normal outcome contract;
   - state what went wrong and the exact bad value;
   - for botched-protocol: "do NOT redo the work — only write one of
     `[...]` to `<outcome_path>`";
   - for kill/fresh: "a prior attempt may have partially produced work;
     verify and complete it."

5. **Empty `question.txt` is invalid.** At `:1010`, also fail when
   `read_text().strip() == ""`, routing into the retry path instead of
   surfacing a blank question to the user / eating an `--answers` line.

6. **Resumable-handle awareness.** Before a "continue" retry, check a
   resumable handle exists (Codex `thread_id.txt` near `:308`, or
   populated `CLAUDE_CONFIG_DIR`). If absent, proceed as fresh — the
   self-contained prompt already covers this; just don't claim the agent
   "remembers."

## Out of scope (later)

- The idle/hang timeout in `_supervise` itself (Tier-1 #2) — this plan
  only consumes its `killed` signal; implement separately.
- `--resume <run-slug>`, structured `failure.json`, per-step timing
  constants, declarative `on_failure` routing.

## Verification

- Unit: fake runner that (a) writes nothing, (b) writes garbage,
  (c) writes `question` with no/empty file, (d) succeeds on retry 2,
  (e) never succeeds → asserts budget exhaustion raises with original
  message. Assert visit dirs `001..00N`, `run.log` retry lines,
  `should_continue` per class.
- Integration: a workflow whose first step fails once then succeeds
  completes the run; one that always fails aborts after B retries.
- Regression: existing question-loop and happy-path tests unchanged.
</content>
