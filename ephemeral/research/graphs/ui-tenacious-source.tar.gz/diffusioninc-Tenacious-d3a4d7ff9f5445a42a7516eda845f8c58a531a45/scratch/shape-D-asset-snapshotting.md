# Shape D — Built-in Asset Snapshotting (idempotent backfill)

Status: **deferred** — captured here for a future round. Not in scope
for the round we are scoping right now.

## Background

Today every step prompt is responsible for the `-NNNN` / `-current`
asset dance. Each prompt (see `workflows/6step.yaml`) tells the agent
to:

1. Glob `assets/<base>-NNNN.md`, find the max, add 1 → N.
2. Write the same content to BOTH `<base>-current.md` and
   `<base>-<NNNN>.md`.
3. Make sure `outcome.txt` is the last write.

The `_contract_block` in `tenacious/orchestrator.py:772–825` also
hard-codes a long exemplar list of all the paired filenames.

The only place this is automated today is the `HealthMonitor` step
(`orchestrator.py:1496–1551`), which fingerprints
`health-{quick,deepdive}-current.md` before/after the tick and
post-copies `current → <ts>-t<NNN>.md` only if content changed. The
list of bases is a hardcoded `_HISTORY_BASES` tuple inside the class.

## Proposal (Shape D)

After a step's `outcome.txt` is accepted, the orchestrator walks a
list of asset bases owned by that step. For each base, it:

1. Computes N = (count of existing `<base>-NNNN.md` in `assets/`) + 1
   if no file for the current round exists yet; otherwise re-uses the
   round's existing N (the step might have run multiple visits before
   finalising).
2. If `<base>-NNNN.md` already exists → leave it alone.
   (Backwards-compat: prompts that still dual-write are unchanged.)
3. Else if `<base>-current.md` exists → copy `current → NNNN`.
   (Forward path: new/simplified prompts only need to write current.)
4. Else → no-op (the step didn't produce that asset this round).

Backwards-compatible in both directions: ship the orchestrator change
with zero prompt edits, then simplify prompts one at a time as
confidence grows.

## Open design choices to resolve when picking this up

1. **Asset-base list source** — declared per-step in workflow JSON/YAML
   (`"assets": ["requirements"]`), hardcoded by step slug, or
   auto-discovered by globbing `*-current.md` that appeared/changed
   during the step. Recommendation: declared in the workflow file, so
   ownership of each asset is explicit and reviewable.

2. **Suffix scheme** — keep `-NNNN.md` zero-padded round counter (what
   prompts and viewer already use) vs. switch to timestamp+visit like
   the health monitor. Recommendation: keep `-NNNN.md`. Health monitor
   is the odd one out because it produces N artefacts per round; every
   other step produces one per round.

3. **Skip-if-unchanged?** Probably no — round counting is semantically
   "this step ran in round N" not "the content changed". Unconditional
   copy is simpler and matches user expectations.

4. **Prompt simplification scope** — three settings (a) ship
   orchestrator only, leave prompts alone; (b) simplify `_contract_block`
   and 6step.yaml prompts; (c) simplify `_contract_block` only. The
   backwards-compat property of shape D means we can ship (a) first and
   migrate prompts in a separate round once we have evidence it works.

5. **Migration of older runs** — likely out of scope. New runs get
   auto-snapshotting; older runs that were authored under the dual-write
   contract already have both files on disk, so nothing to migrate.

6. **Viewer changes** — none required. The viewer's
   `_newest_requirements()` in `tenacious/viewer/model.py:56–74` reads
   `requirements-NNNN.md`, which is exactly what shape D produces.

## Files likely to touch when implementing later

- `tenacious/orchestrator.py` — add a post-step snapshot helper invoked
  after a successful `outcome.txt` accept; thread an `assets:` field
  through workflow loading; optionally trim `_contract_block`.
- `workflows/6step.yaml` (and any other workflow files) — add an
  `"assets"` array per step; optionally trim the per-step prompt's
  "compute N + write both" boilerplate.
- Tests — a `test_asset_snapshot_backfill.py` covering the three
  branches (already exists / current only / neither) and a regression
  proving an old-style prompt that dual-writes still works.

## Not in scope (when this is picked up)

- Changing health-monitor's distinct timestamp+tick suffix — it
  produces multiple snapshots per round, so the unified scheme does
  not fit it cleanly. Leave it alone.
- Snapshot diffing / dedup beyond exact-file-presence checks.
- Cross-step asset ownership (one base owned by two steps).
