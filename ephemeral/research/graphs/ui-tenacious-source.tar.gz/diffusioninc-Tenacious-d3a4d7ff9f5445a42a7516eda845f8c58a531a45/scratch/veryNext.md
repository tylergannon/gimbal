# Very Next — Orchestrator Robustness Fixes

These items came directly from the 2026-05-17 incident where a Claude coding
step wrote its outcome file but never exited, causing the orchestrator to hang
and then crash when the process was killed.

## Items to implement

### 1. Outcome-based advancement (Option B)
Once the agent writes a valid outcome.txt, the orchestrator should treat the
step as complete. Do not wait indefinitely for the agent process to exit.
After outcome.txt appears, give the process a short grace period (e.g. 30
seconds) to exit cleanly, then kill it and advance to the next step regardless.

### 2. Exit-code tolerance when outcome.txt is present (Option C)
If the agent produced a valid outcome.txt before it was killed or crashed, the
orchestrator should treat the step as successful regardless of the exit code
(including 143 SIGTERM, 137 SIGKILL, or any other non-zero code). A written
outcome is the contract; the exit code is secondary.

### 3. Orphan process cleanup (Option D)
When a step's agent process exits (or is killed), the orchestrator should also
kill any child processes it spawned. Track child PIDs using a process group or
by recording the agent PID and killing the whole group on step completion.

### 4. Unattended-mode guidance in step prompts (Option E)
Add an explicit paragraph to the code step system prompt (and any other step
that runs shell commands) reminding the agent that it is running unattended:
- Never launch a process that blocks waiting for terminal input without
  providing that input via scripted stdin (printf, heredoc, expect, etc.)
- Always use non-interactive flags (--no-input, --non-interactive, -y, etc.)
  when available
- Never open /dev/tty directly without a pty-safe fallback and do not rely on
  interactive terminal features
- Ensure all child processes are explicitly waited on or killed before the
  step writes its outcome and exits
