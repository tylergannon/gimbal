"""Tenacious — coding-agent orchestrator over Codex / Claude Code CLIs."""
