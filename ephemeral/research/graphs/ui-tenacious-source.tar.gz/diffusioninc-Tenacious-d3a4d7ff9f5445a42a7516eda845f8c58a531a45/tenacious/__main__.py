from .orchestrator import main
import sys
sys.exit(main())
