"""Auth slot bank for the CLI agents.

Layout on disk:

    $TENACIOUS_HOME/auth-bank/
        openai/
            <account-name>/
                <slot-file>.json        # e.g. auth.json
                <slot-file>.json.lock   # created on first lease (openai only)
        anthropic/
            <account-name>/
                <slot-file>.txt         # e.g. ccsecret.txt

Each provider/account directory can hold one or more slot files. A slot is
the auth artifact (codex `auth.json` for openai; claude oauth-token text
file for anthropic).

Lease model:
- Each run is "magnetized" to one account per provider for the entire
  run (so subsequent calls hit the same account — better for prompt
  caching). Selection is deterministic per (provider, run-slug) so a
  given run consistently picks the same account on retry.
- Openai/codex (`writeback=True`): each CLI invocation leases ONE slot
  inside that account for the duration of the subprocess call, then
  releases. Mutual exclusion is via `fcntl.flock` on an adjacent
  `<slot>.lock` file. The caller copies the slot file in, lets codex
  rotate it as needed, copies it back over the slot file before the
  lock is released. flock is auto-released on fd close so a crashed
  orchestrator never permanently strands a slot.
- Anthropic (`writeback=False`): tokens are static — there is no
  rotation race to protect — so anthropic is lockless. `lease()` simply
  yields the first available `.txt` slot without opening any `.lock`
  file and without calling `fcntl.flock`. One slot per account is
  sufficient; extra slots remain harmless but unnecessary.
"""

from __future__ import annotations

import fcntl
import hashlib
import os
import random
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator


# Provider config: file extension for slot files, whether the agent
# rotates the file in place (and thus requires write-back).
PROVIDERS: dict[str, dict] = {
    "openai":    {"ext": ".json", "writeback": True},
    "anthropic": {"ext": ".txt",  "writeback": False},
}


def tenacious_home() -> Path:
    return Path(os.environ.get("TENACIOUS_HOME") or (Path.home() / ".tenacious"))


def bank_root() -> Path:
    return tenacious_home() / "auth-bank"


def list_accounts(provider: str) -> list[str]:
    d = bank_root() / provider
    if not d.is_dir():
        return []
    return sorted(p.name for p in d.iterdir() if p.is_dir())


def list_slots(provider: str, account: str) -> list[Path]:
    cfg = PROVIDERS[provider]
    d = bank_root() / provider / account
    if not d.is_dir():
        return []
    return sorted(p for p in d.iterdir()
                  if p.is_file() and p.suffix == cfg["ext"]
                  and not p.name.endswith(".lock"))


def pick_account(provider: str, run_slug: str) -> str:
    """Deterministically magnetize a run to one account per provider.

    Uses a stable hash of (provider, run-slug) so all calls within the
    same run pick the same account (cache-friendly), while different
    runs spread across the available accounts.
    """
    accounts = list_accounts(provider)
    if not accounts:
        raise RuntimeError(
            f"no accounts in bank for {provider!r} at {bank_root()/provider}; "
            f"create at least one account directory with a slot file."
        )
    h = hashlib.sha256(f"{provider}|{run_slug}".encode()).digest()
    idx = int.from_bytes(h[:8], "big") % len(accounts)
    return accounts[idx]


def _lock_path(slot: Path) -> Path:
    return slot.with_name(slot.name + ".lock")


def _attempt_order(slots: list[Path]) -> list[Path]:
    """Order in which `lease()` tries to lock the account's slots.

    Default is RANDOM, so codex slot selection spreads across the account
    instead of always hammering the alphabetically-first slot. Set
    `TENACIOUS_AUTHBANK_ORDER=sorted` to force the deterministic
    alphabetical order (used by tests that assert a fixed attempt order).
    """
    mode = os.environ.get("TENACIOUS_AUTHBANK_ORDER", "random").lower()
    out = list(slots)
    if mode != "sorted":
        random.shuffle(out)
    return out


# --------------------------------------------------------------------------
# Auth-refresh failure detection (openai/codex only)
# --------------------------------------------------------------------------
#
# When a codex bank slot's OAuth refresh token has died, codex's token
# refresh fails with an HTTP 401 and the subprocess exits non-zero in ~4s
# with no useful output. These signatures distinguish that genuine
# token-refresh failure from ordinary task failures, network blips, and
# rate limits (which must keep normal retry behavior — NO eviction).

# Canonical codex token-manager line; sufficient on its own.
_AUTH_MANAGER_LINE = "codex_login::auth::manager: Failed to refresh token"

# Specific server error codes. The two narrow codes are codex-internal;
# the broad `token_expired` is gated by refresh/401 context below.
_AUTH_CODES = ("refresh_token_invalidated", "refresh_token_reused",
               "token_expired")

# Exact human-readable phrases codex prints; each sufficient on its own.
_AUTH_PHRASES = ("refresh token was already used",
                 "Provided authentication token is expired",
                 "Please log out and sign in again")

# Context that confirms a code refers to a token-refresh 401 rather than an
# unrelated mention.
_AUTH_CONTEXT = ("401", "Failed to refresh token", "refresh token")


def is_auth_refresh_failure(exit_code: int, stderr: str) -> bool:
    """True ONLY for a genuine codex OAuth token-refresh 401 failure.

    Requires a non-zero exit AND a specific signature in `stderr` (never
    `stdout`). Ordinary task failures, network errors, rate limits (429),
    and bare `401`/`Unauthorized` do NOT match — those keep today's normal
    retry + writeback behavior with no eviction.
    """
    if exit_code == 0:
        return False
    if not stderr:
        return False
    if _AUTH_MANAGER_LINE in stderr:
        return True
    if any(p in stderr for p in _AUTH_PHRASES):
        return True
    if any(c in stderr for c in _AUTH_CODES) and any(g in stderr for g in _AUTH_CONTEXT):
        return True
    return False


def auth_refresh_marker(stderr: str) -> str | None:
    """Return the most specific marker for logging, or None.

    Priority: concrete error code, then exact human phrase, then the
    canonical manager line literal. Guarantees the run-log line names the
    real code for the three required signatures.
    """
    for code in _AUTH_CODES:
        if code in stderr:
            return code
    for phrase in _AUTH_PHRASES:
        if phrase in stderr:
            return phrase
    if _AUTH_MANAGER_LINE in stderr:
        return _AUTH_MANAGER_LINE
    return None


class AllSlotsExhausted(RuntimeError):
    """Raised by lease() when a non-empty `exclude` filtered away every
    remaining slot in a (non-empty) account — i.e. every slot has been
    tried/evicted. Distinct from a genuinely empty account (RuntimeError)
    and from a busy bank (TimeoutError).
    """

    def __init__(self, provider: str, account: str):
        self.provider = provider
        self.account = account
        super().__init__(
            f"all slots in {provider}/{account} have been "
            f"evicted/exhausted this run"
        )


def evict(slot: Path) -> Path:
    """Quarantine a dead openai/codex slot so it is never leased again.

    Moves the slot file into a sibling `_evicted/` subdir (owner-private)
    with a collision-resistant timestamped name, then removes its `.lock`
    sentinel. The `_evicted/` subdir is never returned by `list_slots`, so
    the slot disappears from leasing immediately once the `.json` is moved.

    openai/codex ONLY. Must be called while the caller still holds the
    slot's flock, so no sibling run can have it leased.
    """
    evicted_dir = slot.parent / "_evicted"
    evicted_dir.mkdir(mode=0o700, exist_ok=True)
    try:
        os.chmod(evicted_dir, 0o700)
    except OSError:
        pass

    base = f"{slot.name}.{time.strftime('%Y%m%dT%H%M%S')}.{os.getpid()}"
    dest = evicted_dir / base
    n = 1
    while dest.exists():
        dest = evicted_dir / f"{base}.{n}"
        n += 1

    # Move the credential out of the account dir FIRST so it leaves
    # list_slots before anything else, then drop the lock sentinel.
    slot.rename(dest)
    _lock_path(slot).unlink(missing_ok=True)
    try:
        os.chmod(dest, 0o600)
    except OSError:
        pass
    return dest


@contextmanager
def lease(provider: str, account: str, timeout: float = 120.0,
          exclude: "frozenset[str] | set[str]" = frozenset()) -> Iterator[Path]:
    """Try-lock each slot in the account; yields the locked slot Path.

    On context exit the file descriptor is closed, which releases the
    flock. If a process holding a slot crashes, the kernel releases the
    lock automatically — no stale-lock sweeping needed.

    Anthropic short-circuit: anthropic tokens are static
    (`writeback=False`), so there is no rotation race to guard against.
    The anthropic path yields the first slot directly without opening a
    `.lock` file or calling `fcntl.flock`. Openai/codex still leases
    with flock to serialize codex's in-place credential rotation, and
    tries the account's slots in RANDOM order (see `_attempt_order`) so
    selection spreads across the bank rather than always picking the
    alphabetically-first slot.

    `exclude` is a set of slot *names* (e.g. evicted/already-tried slots)
    to skip — used by the codex failover loop. If a non-empty `exclude`
    filters away every slot in a non-empty account, `AllSlotsExhausted`
    is raised (the bank-exhausted signal). A genuinely empty account still
    raises the original `RuntimeError`, unchanged.
    """
    slots = list_slots(provider, account)
    if exclude:
        # Mid-failover: a non-empty exclude means we've already tried/evicted
        # slots this run. Any emptiness now — whether the filter drains the
        # list or every slot has been quarantined out of list_slots — is the
        # bank-exhausted signal, NOT a genuinely-empty-account error.
        slots = [s for s in slots if s.name not in exclude]
        if not slots:
            raise AllSlotsExhausted(provider, account)
    elif not slots:
        raise RuntimeError(f"no slots in {provider}/{account} under {bank_root()}")

    if provider == "anthropic":
        yield slots[0]
        return

    order = _attempt_order(slots)
    deadline = time.time() + timeout
    while True:
        for slot in order:
            lock_path = _lock_path(slot)
            try:
                fd = open(lock_path, "a+")
            except OSError as e:
                raise RuntimeError(f"cannot open lock file {lock_path}: {e}")
            try:
                fcntl.flock(fd.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                fd.close()
                continue
            try:
                yield slot
            finally:
                fd.close()  # releases flock
            return
        if time.time() >= deadline:
            raise TimeoutError(
                f"no free slots in {provider}/{account} within {timeout}s"
            )
        time.sleep(0.2)


def writeback(provider: str) -> bool:
    return PROVIDERS[provider]["writeback"]
