"""Tiny self-contained colorizer for orchestrator terminal output.

Public API:
    color_enabled(stream=sys.stdout) -> bool   # decision; pure (no caching)
    colorize_log_line(line, *, known_steps=None, enabled=None) -> str
    banner(text, role, *, enabled=None) -> str
    dim(text, *, enabled=None) -> str

Single env-precedence rule (used by every helper, asserted by every test,
documented in docs/ui/terminal-colors.md):

    color_enabled(stream) is True  iff
      os.environ.get("NO_COLOR", "") == ""        # NO_COLOR wins, always
      AND  ( os.environ.get("TENACIOUS_COLOR") == "1"   # force-enable
             OR ( os.environ.get("TENACIOUS_COLOR") != "0"
                  AND _isatty(stream) ) )         # default: TTY-only

Stdlib only. Pure functional: no module-level cache, no shared mutable
state. Thread-safe.
"""

from __future__ import annotations

import os
import re
import sys
from typing import Iterable


# 8 standard ANSI + bold + dim. No truecolor, no 256-color (per requirements).
RESET = "\x1b[0m"
BOLD = "\x1b[1m"
DIM = "\x1b[2m"
RED = "\x1b[31m"
GREEN = "\x1b[32m"
YELLOW = "\x1b[33m"
BLUE = "\x1b[34m"
MAGENTA = "\x1b[35m"
CYAN = "\x1b[36m"


_BANNER_COLORS = {
    "step": BOLD + CYAN,
    "question": BOLD + YELLOW,
    "health": BOLD + MAGENTA,
    "warn": BOLD + RED,
}


# Leading "[YYYY-MM-DDTHH:MM:SS] " timestamp produced by Run.log().
_TS_RE = re.compile(r"^(\[\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\]) ")

# Bracketed prefix at the start of a line (after the timestamp), allowing
# the leading whitespace the orchestrator routinely emits.
_BRACKET_PREFIX_RE = re.compile(r"^(\s*)\[([A-Za-z_][A-Za-z0-9_]*)\]")

# Real exit-line substring: word boundary on both sides so "uncommitted" or
# similar adjacent text never trips it.
_EXITED_RE = re.compile(r"\bexited (-?\d+)\b")

_CLAUDE_CMD = "claude cmd:"
_CODEX_CMD = "codex cmd:"

# Step-boundary banner body (after the timestamp). Matches both the first
# visit form `step <slug> visit <N> (agent=..., context=...)` AND retry /
# continuation forms `step <slug> visit <N> (retry; ...)` / `(continuation
# after question)` — they are all step-boundary banners.
_STEP_BANNER_RE = re.compile(
    r"^step [A-Za-z_][A-Za-z0-9_-]* visit \d+\b")

# Health-update wrapper lines (literal prefixes).
_HEALTH_HEADER_LITERAL = "===== SESSION HEALTH UPDATE "  # trailing space
_HEALTH_END_LITERAL = "===== END SESSION HEALTH UPDATE ====="

# Parallel-composite FYI banner prefixes; both colored bold red.
_FYI_LOAD_LITERAL = "FYI: workflow declares "
_FYI_RUNTIME_LITERAL = "FYI: launching parallel composite "


def _isatty(stream) -> bool:
    """Defensive isatty(); returns False on missing attr or any exception.

    Accepts either a stream-like object (with `.isatty()`) or an int file
    descriptor (uses `os.isatty(fd)`). The raw-mode answer editor passes
    its tty fd here directly, so this dual form keeps the single
    env-precedence rule centralized in `color_enabled()`.
    """
    if isinstance(stream, int):
        try:
            return os.isatty(stream)
        except (OSError, ValueError):
            return False
    try:
        fn = getattr(stream, "isatty", None)
        if fn is None:
            return False
        return bool(fn())
    except Exception:
        return False


def color_enabled(stream=None) -> bool:
    """Return True iff ANSI color should be emitted on `stream`.

    Pure function: recomputed every call. `NO_COLOR` always wins;
    `TENACIOUS_COLOR=1` force-enables, `=0` force-disables; otherwise
    falls back to a stream.isatty() check.
    """
    if stream is None:
        stream = sys.stdout
    if os.environ.get("NO_COLOR", "") != "":
        return False
    tc = os.environ.get("TENACIOUS_COLOR")
    if tc == "1":
        return True
    if tc == "0":
        return False
    return _isatty(stream)


def _wrap(text: str, color: str) -> str:
    return f"{color}{text}{RESET}"


def banner(text: str, role: str, *, enabled: bool | None = None) -> str:
    """Bold-color a single banner line per its role.

    role="step"     -> bold cyan
    role="question" -> bold yellow
    role="health"   -> bold magenta
    """
    if role not in _BANNER_COLORS:
        raise ValueError(f"unknown banner role: {role!r}")
    if enabled is None:
        enabled = color_enabled(sys.stdout)
    if not enabled:
        return text
    return _wrap(text, _BANNER_COLORS[role])


def dim(text: str, *, enabled: bool | None = None) -> str:
    """Wrap `text` in DIM..RESET (used for the question help footer)."""
    if enabled is None:
        enabled = color_enabled(sys.stdout)
    if not enabled:
        return text
    return _wrap(text, DIM)


def colorize_log_line(line: str, *,
                      known_steps: Iterable[str] | None = None,
                      enabled: bool | None = None) -> str:
    """Apply categorical coloring + banner overlays to one log line.

    The input is expected to already carry the leading
    "[YYYY-MM-DDTHH:MM:SS] " timestamp that Run.log() prepends; that
    timestamp (and any embedded one on a later physical line of a
    multi-line health banner) gets dimmed.

    Multi-line input is split on '\\n' and each physical line is colored
    independently; results are joined back with '\\n'. When color is
    disabled (or `enabled=False`), the input is returned unchanged.

    `known_steps` is the set of step slugs that should get their
    `[<slug>]` bracket prefix colored cyan when it appears at the start
    of a line. Unknown bracket prefixes are left alone.
    """
    if enabled is None:
        enabled = color_enabled(sys.stdout)
    if not enabled:
        return line
    steps = set(known_steps) if known_steps else set()
    if "\n" in line:
        return "\n".join(
            _color_one_line(part, steps) for part in line.split("\n")
        )
    return _color_one_line(line, steps)


def _color_one_line(line: str, known_steps: set[str]) -> str:
    """Color a single physical line (no embedded '\\n')."""
    # 1) Strip + dim leading timestamp.
    m = _TS_RE.match(line)
    if m:
        ts = m.group(1)
        rest = line[m.end():]
        prefix = f"{DIM}{ts}{RESET} "
    else:
        rest = line
        prefix = ""

    # 2) Banner overlays — apply to the whole rest and return early.
    rest_stripped = rest.lstrip()
    leading_ws = rest[: len(rest) - len(rest_stripped)]
    if _STEP_BANNER_RE.match(rest_stripped):
        return prefix + leading_ws + _wrap(
            rest_stripped, _BANNER_COLORS["step"])
    if (rest_stripped.startswith(_HEALTH_END_LITERAL)
            or rest_stripped.startswith(_HEALTH_HEADER_LITERAL)):
        return prefix + leading_ws + _wrap(
            rest_stripped, _BANNER_COLORS["health"])
    if (rest_stripped.startswith(_FYI_LOAD_LITERAL)
            or rest_stripped.startswith(_FYI_RUNTIME_LITERAL)):
        return prefix + leading_ws + _wrap(
            rest_stripped, _BANNER_COLORS["warn"])

    # 3) Categorical inline coloring on `rest`.
    return prefix + _categorical(rest, known_steps)


def _categorical(rest: str, known_steps: set[str]) -> str:
    # 3a) Bracketed prefix: [health_monitor] -> magenta, [<known step>] -> cyan.
    m = _BRACKET_PREFIX_RE.match(rest)
    if m:
        ws, name = m.group(1), m.group(2)
        tail = rest[m.end():]
        if name == "health_monitor":
            rest = f"{ws}{_wrap(f'[{name}]', MAGENTA)}{tail}"
        elif name in known_steps:
            rest = f"{ws}{_wrap(f'[{name}]', CYAN)}{tail}"
        # else: unknown bracket, leave alone

    # 3b) claude cmd: / codex cmd: -> blue (literal substring).
    if _CLAUDE_CMD in rest:
        rest = rest.replace(_CLAUDE_CMD, _wrap(_CLAUDE_CMD, BLUE))
    if _CODEX_CMD in rest:
        rest = rest.replace(_CODEX_CMD, _wrap(_CODEX_CMD, BLUE))

    # 3c) exited <N> -> green for 0, red for non-zero.
    def _exited_sub(mt: re.Match) -> str:
        n = int(mt.group(1))
        color = GREEN if n == 0 else RED
        return _wrap(mt.group(0), color)
    rest = _EXITED_RE.sub(_exited_sub, rest)

    return rest
