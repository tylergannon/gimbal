"""Read-only Tenacious run/session inspector (pure logic package).

This package discovers runs under the Tenacious home, parses Claude and
Codex CLI session transcripts, and renders them human-readably. It is
strictly read-only and never writes to or controls runs.

Importing this package (and its `model`, `transcripts`, `render`
submodules) has no I/O side effects and does **not** import `curses`, so
the non-interactive verification surface works with no terminal. The
`curses` TUI lives in `tenacious.viewer.tui` and is imported lazily by
`tenacious.viewer.__main__` only when an interactive session is launched.
"""

from . import model, transcripts, render

__all__ = ["model", "transcripts", "render"]
