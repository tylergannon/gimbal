"""Self-contained stdio MCP echo server (stdlib only, no `mcp` package).

Implements the minimum slice of the MCP JSON-RPC protocol needed for a
round-trip handshake plus a single `echo` tool call:

    * NDJSON framing on stdio (one `\n`-terminated JSON object per line).
    * `initialize` -> returns a fixed protocolVersion + capabilities.
    * `tools/list` -> advertises one tool `echo` that takes `{text: str}`.
    * `tools/call` for tool `echo` -> returns `text` (optionally prefixed
      by the env var ECHO_PREFIX so we can prove env wiring works).
    * Unknown methods -> JSON-RPC error -32601.
    * Malformed JSON lines -> swallowed (the server keeps reading; no crash).

No network access, no third-party dependency, no filesystem writes. Used by
tests/test_mcp_echo_server.py as a deterministic fixture; also referenced
in the how-to doc as the simplest possible example MCP server.
"""

from __future__ import annotations

import json
import os
import sys


PROTOCOL_VERSION = "2024-11-05"


def _send(obj: dict) -> None:
    sys.stdout.write(json.dumps(obj, separators=(",", ":")) + "\n")
    sys.stdout.flush()


def _reply(req_id, result: dict) -> None:
    _send({"jsonrpc": "2.0", "id": req_id, "result": result})


def _error(req_id, code: int, message: str) -> None:
    _send({"jsonrpc": "2.0", "id": req_id,
           "error": {"code": code, "message": message}})


def _handle(msg: dict) -> None:
    method = msg.get("method")
    req_id = msg.get("id")
    params = msg.get("params") or {}

    # Notifications (no id) -> swallow.
    if req_id is None:
        return

    if method == "initialize":
        _reply(req_id, {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "echo", "version": "0.1.0"},
        })
        return

    if method == "tools/list":
        _reply(req_id, {
            "tools": [{
                "name": "echo",
                "description": "Echoes the input text back to the caller.",
                "inputSchema": {
                    "type": "object",
                    "properties": {"text": {"type": "string"}},
                    "required": ["text"],
                },
            }],
        })
        return

    if method == "tools/call":
        name = params.get("name")
        if name != "echo":
            _error(req_id, -32602, f"unknown tool: {name!r}")
            return
        args = params.get("arguments") or {}
        text = args.get("text", "")
        if not isinstance(text, str):
            _error(req_id, -32602, "argument 'text' must be a string")
            return
        prefix = os.environ.get("ECHO_PREFIX", "")
        _reply(req_id, {
            "content": [{"type": "text", "text": prefix + text}],
            "isError": False,
        })
        return

    _error(req_id, -32601, f"method not found: {method!r}")


def main() -> int:
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(msg, dict):
            continue
        try:
            _handle(msg)
        except Exception as e:  # noqa: BLE001 - protocol fault must not crash
            req_id = msg.get("id")
            if req_id is not None:
                _error(req_id, -32603, f"internal error: {e!r}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
