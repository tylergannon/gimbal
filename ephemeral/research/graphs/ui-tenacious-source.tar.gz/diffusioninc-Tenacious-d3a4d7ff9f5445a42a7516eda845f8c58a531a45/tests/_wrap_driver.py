"""Tiny in-tmux driver for the wrap-repaint tmux test (CV-13).

Run INSIDE a tmux pane. Instantiates the real `_RawLineEditor` on the
pane tty, runs it, and writes the returned answer (raw UTF-8 bytes) to the
out file given as argv[1]. Not a standalone test.
"""

from __future__ import annotations

import os
import sys

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from tenacious.orchestrator import _RawLineEditor  # noqa: E402


def main() -> None:
    out_path = sys.argv[1]
    # Optional argv[2]: the question text (defaults to "Q?" so existing
    # one-arg callers stay byte-identical).
    question = sys.argv[2] if len(sys.argv) > 2 else "Q?"
    fd = os.open("/dev/tty", os.O_RDWR | os.O_NOCTTY)
    try:
        answer = _RawLineEditor(fd, fd, question).run()
    finally:
        try:
            os.close(fd)
        except OSError:
            pass
    with open(out_path, "wb") as f:
        f.write(answer.encode("utf-8"))
        f.flush()
        os.fsync(f.fileno())
    # Hard-exit so nothing re-touches the (already restored) tty.
    os._exit(0)


if __name__ == "__main__":
    main()
