"""Canonical one-shot regression runner for round 2 (and beyond).

Discovers every `tests/test_*.py` via glob and runs each one as a
subprocess with the project root on PYTHONPATH. Prints `RUN <file>` then
`OK <file>` (or `FAIL <file> (exit <rc>)` and short-circuits the run).

Exit 0 iff every discovered test file exited 0; otherwise the first
non-zero return code is propagated.

Usage:

    python3 tests/run_all.py

Stdlib only. No new test discovery framework — pure glob + subprocess.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

_THIS = Path(__file__).resolve()
_TESTS_DIR = _THIS.parent
_PROJECT_ROOT = _TESTS_DIR.parent


def main() -> int:
    files = sorted(p for p in _TESTS_DIR.glob("test_*.py") if p.is_file())
    if not files:
        print("RAN 0 files, FAILED 0")
        print("ALL 0 TEST FILES PASSED")
        return 0
    env = os.environ.copy()
    py_path = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = (
        f"{_PROJECT_ROOT}{os.pathsep}{py_path}" if py_path else str(_PROJECT_ROOT)
    )
    ran = 0
    for f in files:
        rel = f.relative_to(_PROJECT_ROOT)
        print(f"RUN {rel}", flush=True)
        try:
            rc = subprocess.call(
                [sys.executable, str(f)],
                cwd=str(_PROJECT_ROOT),
                env=env,
            )
        except KeyboardInterrupt:
            print(f"FAIL {rel} (interrupted)")
            return 130
        if rc != 0:
            print(f"FAIL {rel} (exit {rc})")
            print(f"RAN {ran + 1} files, FAILED 1")
            return rc
        print(f"OK {rel}", flush=True)
        ran += 1
    print(f"RAN {ran} files, FAILED 0")
    print(f"ALL {ran} TEST FILES PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
