"""User-supplied Codex/Claude home mode.

Stdlib-only tests. Fake `codex` and `claude` shims verify that Tenacious can
run without an auth bank when explicit homes are supplied, that external
session files are indexed for the viewer, and that user Codex config is not
overwritten by per-step MCP config.

Run from the project root:

    python3 tests/test_agent_home_mode.py
"""

from __future__ import annotations

import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import textwrap
import traceback
from pathlib import Path

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

import tenacious.orchestrator as o  # noqa: E402
from tenacious.viewer import model as viewer_model  # noqa: E402


_SHIM = r'''#!{python}
import json, os, re, sys

agent = "{agent}"
argv = sys.argv[1:]
prompt = ""
if agent == "claude":
    for i, a in enumerate(sys.argv):
        if a == "-p" and i + 1 < len(sys.argv):
            prompt = sys.argv[i + 1]
            break
else:
    prompt = sys.argv[-1] if sys.argv else ""

outcome_path = None
m = re.search(r"write the slug of the next step to:\s*\n\s+(\S+)", prompt)
if m:
    outcome_path = m.group(1)
next_slug = "end"
m = re.search(r"Valid next-step slugs:\s*([^\n]+)", prompt)
if m:
    slugs = [s.strip() for s in m.group(1).split(",") if s.strip()]
    if slugs:
        next_slug = slugs[0]

record = {{
    "agent": agent,
    "argv": argv,
    "env": {{
        k: os.environ[k]
        for k in ("CODEX_HOME", "CLAUDE_CONFIG_DIR", "CODEX_API_KEY",
                  "OPENAI_API_KEY", "ANTHROPIC_API_KEY",
                  "CLAUDE_CODE_OAUTH_TOKEN")
        if k in os.environ
    }},
}}
cap = os.environ.get("SHIM_CAPTURE")
if cap:
    with open(cap, "a") as f:
        f.write(json.dumps(record) + "\n")

if outcome_path:
    os.makedirs(os.path.dirname(outcome_path), exist_ok=True)
    with open(outcome_path, "w") as f:
        f.write(next_slug + "\n")

if agent == "codex":
    home = os.environ["CODEX_HOME"]
    session_dir = os.path.join(home, "sessions", "2026", "06", "27")
    os.makedirs(session_dir, exist_ok=True)
    rollout = os.path.join(session_dir, "rollout-2026-06-27T00-00-00-thr-home.jsonl")
    with open(rollout, "a") as f:
        f.write(json.dumps({{"type": "session_meta",
                             "payload": {{"id": "thr-home", "cwd": os.getcwd()}}}}) + "\n")
    print(json.dumps({{"type": "thread.started", "thread_id": "thr-home"}}))
else:
    home = os.environ["CLAUDE_CONFIG_DIR"]
    project_dir = os.path.join(home, "projects", "-tmp-project")
    os.makedirs(project_dir, exist_ok=True)
    sid = "11111111-1111-1111-1111-111111111111"
    transcript = os.path.join(project_dir, sid + ".jsonl")
    with open(transcript, "a") as f:
        f.write(json.dumps({{"type": "user",
                             "message": {{"role": "user", "content": "hi"}}}}) + "\n")
    print(json.dumps({{"type": "result", "subtype": "success",
                       "is_error": False, "session_id": sid,
                       "total_cost_usd": 0}}))
'''


def _write_shim(bin_dir: Path, agent: str) -> None:
    bin_dir.mkdir(parents=True, exist_ok=True)
    path = bin_dir / agent
    path.write_text(_SHIM.format(python=sys.executable, agent=agent))
    mode = path.stat().st_mode
    path.chmod(mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def _workflow(path: Path, agent: str, *, mcp: bool = False) -> None:
    step = {
        "agent": agent,
        "prompt": "Do the tiny test.",
        "next_steps": ["end"],
    }
    if mcp:
        step["mcp_servers"] = {
            "fs": {"command": "/bin/true", "args": ["x"],
                   "env": {"K": "V"}}
        }
    path.write_text(json.dumps({
        "goal": "g",
        "start_step": "s",
        "steps": {"s": step},
    }))


def _run(home: Path, workflow: Path, *args: str,
         capture: Path) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    env["TENACIOUS_HOME"] = str(home)
    env["SHIM_CAPTURE"] = str(capture)
    env["PYTHONPATH"] = str(_PROJECT_ROOT) + os.pathsep + env.get("PYTHONPATH", "")
    env["PATH"] = str(home / "bin") + os.pathsep + env.get("PATH", "")
    env["CODEX_API_KEY"] = "SHOULD_NOT_LEAK"
    env["OPENAI_API_KEY"] = "SHOULD_NOT_LEAK"
    env["ANTHROPIC_API_KEY"] = "SHOULD_NOT_LEAK"
    env["CLAUDE_CODE_OAUTH_TOKEN"] = "SHOULD_NOT_LEAK"
    return subprocess.run(
        [sys.executable, "-m", "tenacious", str(workflow), *args],
        cwd=_PROJECT_ROOT, env=env, capture_output=True, text=True,
        timeout=30,
    )


def _latest_run(home: Path) -> Path:
    runs = sorted((home / "runs").iterdir())
    assert runs, "no run created"
    return runs[-1]


def s_codex_home_indexes_sessions_and_preserves_config() -> None:
    d = Path(tempfile.mkdtemp(prefix="tnc-home-codex-"))
    try:
        _write_shim(d / "bin", "codex")
        wf = d / "wf.json"
        _workflow(wf, "codex", mcp=True)
        codex_home = d / "codex-home"
        codex_home.mkdir()
        config = codex_home / "config.toml"
        config.write_text("# user config\nmodel = \"keep-me\"\n")
        capture = d / "capture.jsonl"
        cp = _run(d, wf, "--codex-home", str(codex_home), capture=capture)
        assert cp.returncode == 0, (cp.stdout, cp.stderr)
        assert config.read_text() == "# user config\nmodel = \"keep-me\"\n"
        rec = json.loads(capture.read_text().splitlines()[0])
        assert rec["env"].get("CODEX_HOME") == str(codex_home.resolve())
        assert "CODEX_API_KEY" not in rec["env"], rec
        assert "OPENAI_API_KEY" not in rec["env"], rec
        assert "-c" in rec["argv"], rec["argv"]
        assert any("mcp_servers.fs.command" in a for a in rec["argv"]), rec["argv"]
        run = _latest_run(d)
        assert json.loads((run / "accounts.json").read_text()) == {}
        assert json.loads((run / "agent_homes.json").read_text())["codex"] == str(codex_home.resolve())
        sessions = viewer_model.list_sessions(run, "s")
        assert len(sessions) == 1, sessions
        assert sessions[0].kind == "codex", sessions[0]
        assert str(codex_home) in str(sessions[0].path), sessions[0].path
    finally:
        shutil.rmtree(d, ignore_errors=True)


def s_claude_home_indexes_sessions_without_bank() -> None:
    d = Path(tempfile.mkdtemp(prefix="tnc-home-claude-"))
    try:
        _write_shim(d / "bin", "claude")
        wf = d / "wf.json"
        _workflow(wf, "claude")
        claude_home = d / "claude-home"
        capture = d / "capture.jsonl"
        cp = _run(d, wf, "--claude-code-home", str(claude_home),
                  capture=capture)
        assert cp.returncode == 0, (cp.stdout, cp.stderr)
        rec = json.loads(capture.read_text().splitlines()[0])
        assert rec["env"].get("CLAUDE_CONFIG_DIR") == str(claude_home.resolve())
        assert "ANTHROPIC_API_KEY" not in rec["env"], rec
        assert "CLAUDE_CODE_OAUTH_TOKEN" not in rec["env"], rec
        run = _latest_run(d)
        sessions = viewer_model.list_sessions(run, "s")
        assert len(sessions) == 1, sessions
        assert sessions[0].kind == "claude", sessions[0]
        assert str(claude_home.resolve()) in str(sessions[0].path)
    finally:
        shutil.rmtree(d, ignore_errors=True)


def s_claude_home_continue_uses_resume_id() -> None:
    d = Path(tempfile.mkdtemp(prefix="tnc-home-resume-"))
    old_path = os.environ.get("PATH", "")
    old_cap = os.environ.get("SHIM_CAPTURE")
    try:
        _write_shim(d / "bin", "claude")
        capture = d / "capture.jsonl"
        os.environ["PATH"] = str(d / "bin") + os.pathsep + old_path
        os.environ["SHIM_CAPTURE"] = str(capture)
        root = d / "run"
        root.mkdir()
        project = d / "project"
        project.mkdir()
        wf = o.Workflow(goal="g", start_step="s", steps={})
        run = o.Run(slug="r", root=root, workflow=wf, project_dir=project,
                    claude_code_home=d / "claude-home")
        state = run.profile_dir("s")
        state.mkdir(parents=True)
        (state / "claude_session_id.txt").write_text(
            "11111111-1111-1111-1111-111111111111")
        step = o.Step(slug="s", agent="claude", prompt="p",
                      next_steps=["end"])
        step_dir = root / "s" / "001"
        step_dir.mkdir(parents=True)
        o.run_claude(step, run, 1, step_dir, "prompt", True)
        rec = json.loads(capture.read_text().splitlines()[0])
        assert "--resume" in rec["argv"], rec["argv"]
        idx = rec["argv"].index("--resume")
        assert rec["argv"][idx + 1] == "11111111-1111-1111-1111-111111111111"
    finally:
        os.environ["PATH"] = old_path
        if old_cap is None:
            os.environ.pop("SHIM_CAPTURE", None)
        else:
            os.environ["SHIM_CAPTURE"] = old_cap
        shutil.rmtree(d, ignore_errors=True)


def s_cli_rejects_home_plus_api_key_mode() -> None:
    cases = [
        ["--codex-home", "/tmp/x", "--costly-use-codex-api-key"],
        ["--claude-code-home", "/tmp/x", "--costly-use-anthropic-api-key"],
        ["--resume", "fake", "--codex-home", "/tmp/x",
         "--costly-use-codex-api-key"],
        ["--resume", "fake", "--claude-code-home", "/tmp/x",
         "--costly-use-anthropic-api-key"],
    ]
    for args in cases:
        cp = subprocess.run(
            [sys.executable, "-m", "tenacious", *args],
            cwd=_PROJECT_ROOT, capture_output=True, text=True, timeout=30,
        )
        assert cp.returncode == 2, (args, cp.returncode, cp.stderr)
        assert "cannot be combined" in cp.stderr, (args, cp.stderr)


SCENARIOS = [
    ("codex_home_indexes_sessions_and_preserves_config",
     s_codex_home_indexes_sessions_and_preserves_config),
    ("claude_home_indexes_sessions_without_bank",
     s_claude_home_indexes_sessions_without_bank),
    ("claude_home_continue_uses_resume_id",
     s_claude_home_continue_uses_resume_id),
    ("cli_rejects_home_plus_api_key_mode",
     s_cli_rejects_home_plus_api_key_mode),
]


def main() -> int:
    for name, fn in SCENARIOS:
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            print(f"FAIL {name}: {e}")
            traceback.print_exc()
            return 1
        print(f"PASS {name}")
    print(f"ALL PASS ({len(SCENARIOS)} scenarios)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
