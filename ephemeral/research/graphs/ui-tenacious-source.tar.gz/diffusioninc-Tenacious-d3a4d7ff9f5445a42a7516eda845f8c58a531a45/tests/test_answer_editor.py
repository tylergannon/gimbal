"""Verification for the orchestrator interactive answer editor (Part B).

Two layers:

  1. Pure buffer-op unit checks (no tty): char/word cursor movement,
     newline insert, paste insert.
  2. A stdlib `pty` integration harness: allocate a pseudo-terminal, feed
     byte sequences into the real raw-mode editor, and assert the returned
     answer string.

`Alt+Enter` is intentionally NOT asserted as required behavior — only
`Esc`-then-`Enter`, `Ctrl-D`, bracketed paste, Left/Right, and the
recognized word-motion CSI/`ESC b` sequences are required to pass.

Run directly:  python3 tests/test_answer_editor.py
Exit 0 = all pass; non-zero = a failure (message on stderr).
"""

from __future__ import annotations

import os
import pty
import select
import sys
import threading
import time

# Pin TENACIOUS_COLOR=0 so the round-2 banner colorization is a no-op for
# this test. The byte-identity check `_banner('Q?') @ width 80 == original
# bytes` pins the pre-color shape and must not flicker based on whether the
# parent process happens to have stdout connected to a tty.
os.environ.setdefault("TENACIOUS_COLOR", "0")

# Import the editor from the package under test.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tenacious.orchestrator import _RawLineEditor  # noqa: E402

_failures: list[str] = []


def check(name: str, got, want) -> None:
    if got == want:
        print(f"  ok: {name}")
    else:
        _failures.append(f"{name}: got {got!r}, want {want!r}")
        print(f"  FAIL: {name}: got {got!r}, want {want!r}")


# ---------------------------------------------------------------------------
# 1. Pure buffer-op unit checks (no tty involved)
# ---------------------------------------------------------------------------

def buffer_unit_checks() -> None:
    print("buffer unit checks:")

    ed = _RawLineEditor(0, 1, "q")
    ed._insert("foo")
    check("insert", (ed.buf, ed.pos), ("foo", 3))

    ed._left(); ed._left(); ed._left()
    check("char-left x3", ed.pos, 0)
    ed._right()
    check("char-right", ed.pos, 1)

    ed = _RawLineEditor(0, 1, "q")
    ed._insert("one two three")
    ed._word_left()
    check("word-left from end", ed.buf[ed.pos:], "three")
    ed._word_left()
    check("word-left again", ed.buf[ed.pos:], "two three")
    ed._word_right()
    check("word-right", ed.buf[ed.pos:], " three")

    ed = _RawLineEditor(0, 1, "q")
    ed._insert("a")
    ed._insert("\n")
    ed._insert("b")
    check("newline insert", ed.buf, "a\nb")

    ed = _RawLineEditor(0, 1, "q")
    ed._insert("XY")
    ed._left()
    ed._insert("line1\nline2")  # simulates a paste body insert at cursor
    check("paste-insert at cursor", ed.buf, "Xline1\nline2Y")

    ed = _RawLineEditor(0, 1, "q")
    ed._insert("abc")
    ed._backspace()
    check("backspace", ed.buf, "ab")


# ---------------------------------------------------------------------------
# 2. PTY integration harness
# ---------------------------------------------------------------------------

def _run_editor_with_input(input_bytes: bytes, timeout: float = 5.0):
    """Feed input_bytes to a real _RawLineEditor over a pty; return answer."""
    master, slave = pty.openpty()
    result: dict = {}

    def worker():
        try:
            result["val"] = _RawLineEditor(slave, slave, "Question?").run()
        except BaseException as e:  # noqa: BLE001 - report any failure
            result["err"] = e

    stop = threading.Event()

    def drain():
        while not stop.is_set():
            try:
                r, _, _ = select.select([master], [], [], 0.05)
                if r:
                    if not os.read(master, 4096):
                        break
            except OSError:
                break

    t = threading.Thread(target=worker, daemon=True)
    d = threading.Thread(target=drain, daemon=True)
    t.start()
    d.start()
    time.sleep(0.25)  # let the editor enter raw mode + draw
    os.write(master, input_bytes)
    t.join(timeout=timeout)
    alive = t.is_alive()
    stop.set()
    try:
        os.close(master)
    except OSError:
        pass
    try:
        os.close(slave)
    except OSError:
        pass
    if alive:
        raise AssertionError("editor did not return (no submit?)")
    if "err" in result:
        raise result["err"]
    return result.get("val")


def pty_integration_checks() -> None:
    print("pty integration checks:")
    ESC_ENTER = b"\x1b\r"  # documented submit gesture

    check("multi-line typed + Esc-Enter",
          _run_editor_with_input(b"a\rb" + ESC_ENTER), "a\nb")

    check("bracketed multi-line paste (CR inside does not submit)",
          _run_editor_with_input(
              b"\x1b[200~line1\nline2\x1b[201~" + ESC_ENTER),
          "line1\nline2")

    check("char-left (ESC[D x3) then insert",
          _run_editor_with_input(
              b"foo\x1b[D\x1b[D\x1b[DX" + ESC_ENTER), "Xfoo")

    check("word-left (ESC b) then insert",
          _run_editor_with_input(b"one two\x1bbZ" + ESC_ENTER),
          "one Ztwo")

    check("CSI word-left ESC[1;3D",
          _run_editor_with_input(b"one two\x1b[1;3DZ" + ESC_ENTER),
          "one Ztwo")

    check("CSI word-left ESC[1;5D",
          _run_editor_with_input(b"one two\x1b[1;5DZ" + ESC_ENTER),
          "one Ztwo")

    # "ab cd": word-left x2 -> pos 0; word-right (ESC f) -> pos 2 (end of
    # "ab"); insert "X" -> "abX cd".
    check("word-right (ESC f)",
          _run_editor_with_input(
              b"ab cd\x1bb\x1bb\x1bfX" + ESC_ENTER),
          "abX cd")

    check("Ctrl-D on empty -> empty answer",
          _run_editor_with_input(b"\x04"), "")

    check("trailing newlines stripped, interior kept",
          _run_editor_with_input(b"x\ry\r\r" + ESC_ENTER), "x\ny")


# ---------------------------------------------------------------------------
# 3. Pure wrap-aware layout checks (no tty) — the Round 2 wrap-repaint fix
# ---------------------------------------------------------------------------

def layout_unit_checks() -> None:
    print("layout unit checks:")

    def lay(buf: str, pos: int, width: int):
        ed = _RawLineEditor(0, 1, "q")
        ed.buf = buf
        ed.pos = pos
        return ed._layout(width)

    # A single logical line longer than the width wraps onto extra physical
    # rows (the original bug counted only logical newlines, so wrapped rows
    # were never cleared and the previous line was repeated each keystroke).
    rs, total, crow, ccol = lay("0123456789ABCD", 14, 10)
    check("wrap render_str", rs, "0123456789\r\nABCD")
    check("wrap total_rows", total, 2)
    check("wrap cursor at end", (crow, ccol), (1, 4))

    rs, total, crow, ccol = lay("0123456789ABCD", 12, 10)
    check("wrap cursor mid second row", (crow, ccol), (1, 2))

    # Exact-multiple logical line: an explicit empty continuation row so a
    # cursor at column W is unambiguously column 0 of the next row.
    rs, total, crow, ccol = lay("0123456789", 10, 10)
    check("exact-multiple total_rows", total, 2)
    check("exact-multiple trailing empty row", rs, "0123456789\r\n")
    check("exact-multiple cursor", (crow, ccol), (1, 0))

    # Mixed logical newlines + wrapping.
    rs, total, crow, ccol = lay("abcdefghijkl\nxy", 15, 10)
    check("mixed render_str", rs, "abcdefghij\r\nkl\r\nxy")
    check("mixed total_rows", total, 3)
    check("mixed cursor at end", (crow, ccol), (2, 2))

    # Non-regression (Finding 5): a short buffer containing a tab and a
    # non-ASCII codepoint that does NOT exceed the width must stay a single
    # physical row with no spurious cursor drift.
    rs, total, crow, ccol = lay("a\téb", 4, 10)
    check("tab/non-ascii non-wrap total_rows", total, 1)
    check("tab/non-ascii non-wrap cur_row", crow, 0)
    check("tab/non-ascii non-wrap render_str", rs, "a\téb")

    # Empty buffer is one row at the origin.
    rs, total, crow, ccol = lay("", 0, 10)
    check("empty total_rows", total, 1)
    check("empty cursor", (crow, ccol), (0, 0))


# ---------------------------------------------------------------------------
# 4. Deterministic VT reproduction of Bug 4 (Round 2) — no tty
# ---------------------------------------------------------------------------
#
# A minimal in-test VT model with a single `autowrap` flag. It is forced
# True before every redraw, simulating DECAWM having been reset after
# `run()`'s one-time `\x1b[?7l`. The fixed `_redraw` re-asserts `\x1b[?7l`
# at the start of EVERY payload, so render_str is written with autowrap
# OFF and the first physical row never duplicates.
#
# FAIL-BEFORE (documented): with the pre-fix `_redraw` (no `\x1b[?7l` in
# the payload) `autowrap` stays True, the column-W glyph auto-wraps, the
# subsequent explicit `\r\n` adds an extra row, prev_crow under-counts,
# and the stale first physical row is left behind — `"0123456789"` then
# appears on TWO grid rows once typing passes the wrap point. The
# assertions below (exactly one row, payload starts with `\x1b[?7l`)
# therefore fail on the unfixed code and pass after the one-token fix.

def redraw_vt_repro_checks() -> None:
    print("redraw vt repro checks:")
    W = 10
    FIRST = "0123456789"

    class VT:
        def __init__(self, width):
            self.W = width
            self.rows = [""]
            self.r = 0
            self.c = 0
            self.autowrap = True

        def _ensure_row(self, idx):
            while len(self.rows) <= idx:
                self.rows.append("")

        def _putc(self, ch):
            self._ensure_row(self.r)
            row = self.rows[self.r]
            if len(row) < self.c:
                row = row + " " * (self.c - len(row))
            self.rows[self.r] = row[:self.c] + ch + row[self.c + 1:]
            self.c += 1
            if self.autowrap and self.c >= self.W:
                self.r += 1
                self.c = 0
                self._ensure_row(self.r)

        def _csi(self, params, final):
            if final == "J":  # ED mode 0: cursor -> end of screen
                self._ensure_row(self.r)
                self.rows[self.r] = self.rows[self.r][:self.c]
                del self.rows[self.r + 1:]
                return
            if params == "?7" and final in ("l", "h"):
                self.autowrap = (final == "h")
                return
            num = int(params) if params.isdigit() else 1
            if final == "A":
                self.r = max(0, self.r - num)
            elif final == "B":
                self.r += num
                self._ensure_row(self.r)
            elif final == "C":
                self.c += num
            elif final == "D":
                self.c = max(0, self.c - num)

        def feed(self, s):
            i, n = 0, len(s)
            while i < n:
                ch = s[i]
                if ch == "\x1b":
                    if i + 1 < n and s[i + 1] == "[":
                        j = i + 2
                        params = ""
                        while j < n and (s[j].isdigit() or s[j] in "?;"):
                            params += s[j]
                            j += 1
                        final = s[j] if j < n else ""
                        self._csi(params, final)
                        i = j + 1
                    else:
                        i += 1
                    continue
                if ch == "\r":
                    self.c = 0
                elif ch == "\n":
                    self.r += 1
                    self._ensure_row(self.r)
                else:
                    self._putc(ch)
                i += 1

        def count_first(self):
            return sum(1 for row in self.rows if FIRST in row)

    ed = _RawLineEditor(0, 1, "q")
    ed._term_width = lambda: W
    vt = VT(W)
    payloads: list[str] = []

    def fake_write(s):
        payloads.append(s)
        vt.feed(s)

    ed._write = fake_write
    ed._prev_crow = 0

    # One logical line typed incrementally past the wrap point.
    steps = [
        ("012345678", 9, 0),                 # before the first row completes
        ("0123456789", 10, 1),               # exactly W (explicit cont. row)
        ("0123456789A", 11, 1),              # one past the wrap point
        ("0123456789ABCDEFGHIJK", 21, 1),    # well past the wrap point
    ]
    for buf, plen, expected in steps:
        ed.buf = buf
        ed.pos = plen
        vt.autowrap = True  # DECAWM reset between redraws (failure cond.)
        payloads.clear()
        ed._redraw()
        payload = payloads[-1]
        check(f"redraw re-asserts autowrap-off (len={plen})",
              payload.startswith("\x1b[?7l"), True)
        check(f"redraw has exactly one ED clear (len={plen})",
              payload.count("\x1b[J"), 1)
        check(f"first row appears on exactly one grid row (len={plen})",
              vt.count_first(), expected)


# ---------------------------------------------------------------------------
# 5. Pure question-banner wrap checks (no tty) — the Round 1 wrap fix
# ---------------------------------------------------------------------------
#
# Bug 2 (Round 1): the raw-mode editor disables terminal autowrap
# (\x1b[?7l), so any question line longer than the terminal width was
# truncated at the right edge. `_banner()` now word-wraps every logical
# line to the current width, preserving the agent's explicit newlines /
# blank lines / paragraph structure, with graceful fallback width 80.
# These pure checks reproduce the bug (a long line, a hard token, narrow
# widths) and lock the byte-identity of the unchanged width-80 banner.

def banner_wrap_unit_checks() -> None:
    print("banner wrap unit checks:")
    import math

    def editor(q: str, w: int) -> _RawLineEditor:
        ed = _RawLineEditor(0, 1, q)
        ed._term_width = lambda: w
        return ed

    _wb = _RawLineEditor(0, 1, "q")._wrap_block

    def wrap(text: str, w: int):
        return _wb(text, w).split("\n")

    # (i) a question line >200 chars wraps so no row exceeds width 40 and
    # every word survives in order (nothing truncated at the right edge).
    words = [f"word{i:03d}" for i in range(45)]      # 45*7 + 44 = 359 chars
    q_long = " ".join(words)
    assert len(q_long) > 200, len(q_long)
    rows = wrap(q_long, 40)
    check("(i) long line: no row exceeds width",
          all(len(r) <= 40 for r in rows), True)
    check("(i) long line: every word kept in order",
          " ".join(rows).split(), words)

    # (ii) a 250-char single token (no spaces) is HARD-split into
    # ceil(250/40) rows, none over width, no character lost.
    tok = "T" * 250
    rows = wrap(tok, 40)
    check("(ii) hard-split row count", len(rows), math.ceil(250 / 40))
    check("(ii) hard-split: no row exceeds width",
          all(len(r) <= 40 for r in rows), True)
    check("(ii) hard-split: no characters lost", "".join(rows), tok)

    # (iii) explicit '\n' and a blank line each survive as exactly one
    # empty row (paragraph break preserved).
    check("(iii) explicit newlines/blank line preserved",
          wrap("para one\n\npara two\nline three", 80),
          ["para one", "", "para two", "line three"])

    # (iv) whitespace-semantics lock. A logical line that FITS the width
    # is returned verbatim — internal runs of spaces and leading indent
    # are preserved (we do not collapse spacing), every word kept in
    # order. A whitespace-only logical line becomes exactly one empty
    # row. A line that must wrap drops whitespace only at the break.
    fit = "   - bullet    with   runs"
    check("(iv) fitting line preserved verbatim (indent + runs kept)",
          wrap(fit, 80), [fit])
    check("(iv) fitting line: every word kept in order",
          " ".join(wrap(fit, 80)).split(), ["-", "bullet", "with", "runs"])
    check("(iv) whitespace-only logical line -> one empty row",
          wrap("a\n   \nb", 80), ["a", "", "b"])
    forced = "tok " + ("z" * 90)
    frows = wrap(forced, 40)
    joined = "".join(frows)
    check("(iv) forced wrap: no row exceeds width",
          all(len(r) <= 40 for r in frows), True)
    check("(iv) forced wrap: no character of the long token lost",
          (joined.count("z"), "tok" in joined), (90, True))

    # (v) a narrow/odd width never raises and never yields a row > width.
    rows = wrap(q_long + "\n" + "S" * 77, 10)
    check("(v) narrow width 10: no row exceeds 10",
          all(len(r) <= 10 for r in rows), True)
    check("(v) width 1 clamp: no row exceeds 1 and never raises",
          all(len(r) <= 1 for r in wrap("ab cd", 1)), True)

    # (vi) the banner is emitted with CRLF line endings only (every '\n'
    # is preceded by '\r'; autowrap is OFF so the editor needs CRLF).
    b = editor("a question that is short", 80)._banner()
    check("(vi) banner uses CRLF",
          (b.count("\n") == b.count("\r\n")
           and b.count("\r") == b.count("\r\n")), True)

    # (vii) byte-identity regression anchor: for question "Q?" at the
    # fallback width 80 the new _banner() is byte-for-byte identical to
    # the original pre-change banner, and _wrap_block(body,80) == body.
    ORIG = (
        "\r\n[Question from agent]\r\nQ?\r\n\r\n"
        "Enter inserts a newline.\r\n"
        "Submit: press Esc then Enter.  (Ctrl-D also submits.)\r\n"
        "Ctrl-C cancels.  Left/Right = char; "
        "Option/Alt+Left/Right = word.\r\n"
        "(On some terminals Alt+Enter also submits; use Esc then "
        "Enter if unsure.)\r\n"
        "--- type your answer below ---\r\n"
    )
    check("(vii) _banner('Q?') @ width 80 == original bytes",
          editor("Q?", 80)._banner(), ORIG)
    BODY = ORIG.replace("\r\n", "\n")
    check("(vii) _wrap_block(body, 80) == body (no content add/drop)",
          _wb(BODY, 80), BODY)


def main() -> int:
    buffer_unit_checks()
    layout_unit_checks()
    banner_wrap_unit_checks()
    redraw_vt_repro_checks()
    pty_integration_checks()
    if _failures:
        sys.stderr.write(f"\n{len(_failures)} failure(s):\n")
        for f in _failures:
            sys.stderr.write(f"  - {f}\n")
        return 1
    print("\nALL ANSWER-EDITOR CHECKS PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
