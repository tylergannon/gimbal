"""Real-terminal verification of the answer-editor wrap-repaint fix (CV-13).

Drives the REAL `_RawLineEditor` inside a real, narrow tmux pane:

  (a) A single-logical-line ASCII answer of length 100 in a 40-wide pane
      (=> 3 physical rows). Asserts the first 40-char physical row appears
      EXACTLY ONCE in `tmux capture-pane` (the original bug repeated the
      previous line on every keystroke), that the 3 expected rows are all
      present, and that after Esc-then-Enter the driver's out file equals
      the exact 100-char string.

  (b) Non-regression: a short answer "a\\tXéb" (tab + non-ASCII) that does
      NOT reach the pane width is typed; the captured pane shows it on a
      single row (no duplicated/extra rows: the distinctive 'X' and 'é'
      each appear exactly once) and the out file equals that exact string
      byte-for-byte.

Run from the project root:

    .venv/bin/python tests/test_answer_editor_wrap_tmux.py

Prints `WRAP-TMUX OK` and exits 0 on success. If `tmux` is genuinely not
installed it prints `SKIP: tmux not found` and exits 0 (but a skipped run
does NOT satisfy the round — the code-review/test step must ensure tmux is
present so this actually runs).
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import time
import uuid

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_DRIVER = os.path.join(_PROJECT_ROOT, "tests", "_wrap_driver.py")
_PANE_W = 40
_PANE_H = 20
_READY_MARKER = "--- type your answer below ---"


def _tmux(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(["tmux", *args], capture_output=True, text=True)


def _capture(session: str) -> str:
    r = _tmux("capture-pane", "-p", "-t", session)
    return r.stdout if r.returncode == 0 else ""


def _wait_for(session: str, needle: str, timeout: float = 15.0) -> str:
    deadline = time.time() + timeout
    last = ""
    while time.time() < deadline:
        last = _capture(session)
        if needle in last:
            return last
        time.sleep(0.1)
    return last


def _kill(session: str) -> None:
    _tmux("kill-session", "-t", session)


def _run_case(answer_keys, expected_bytes: bytes, question: str | None = None):
    """Start the driver in a fresh tmux pane, type `answer_keys`, submit,
    return (captured_pane_before_submit, out_file_bytes). When `question`
    is given it is passed as the driver's argv[2] (the banner question);
    one-arg callers keep the driver's default "Q?" byte-identically."""
    session = f"wraptest-{uuid.uuid4().hex[:8]}"
    out_fd, out_path = tempfile.mkstemp(prefix="wrapdrv-", suffix=".out")
    os.close(out_fd)
    os.unlink(out_path)
    cmd = (
        f"exec {_q(sys.executable)} {_q(_DRIVER)} {_q(out_path)}"
    )
    if question is not None:
        cmd += f" {_q(question)}"
    _tmux("new-session", "-d", "-s", session,
          "-x", str(_PANE_W), "-y", str(_PANE_H),
          "-c", _PROJECT_ROOT, cmd)
    try:
        ready = _wait_for(session, _READY_MARKER)
        if _READY_MARKER not in ready:
            raise AssertionError(
                f"editor never became ready; pane was:\n{ready}")
        # Give the initial redraw a beat to settle.
        time.sleep(0.3)
        for keyargs in answer_keys:
            r = _tmux("send-keys", "-t", session, *keyargs)
            if r.returncode != 0:
                raise AssertionError(f"send-keys failed: {r.stderr}")
            time.sleep(0.15)
        # Capture the typed (pre-submit) screen.
        time.sleep(0.4)
        captured = _capture(session)
        # Submit: Esc then Enter, tight together (documented gesture).
        _tmux("send-keys", "-t", session, "Escape", "Enter")
        # Wait for the driver to write the out file.
        deadline = time.time() + 15.0
        data = None
        while time.time() < deadline:
            if os.path.exists(out_path):
                with open(out_path, "rb") as f:
                    data = f.read()
                if data == expected_bytes or data:
                    break
            time.sleep(0.1)
        return captured, data
    finally:
        _kill(session)
        try:
            os.unlink(out_path)
        except OSError:
            pass


def _q(s: str) -> str:
    import shlex
    return shlex.quote(s)


def case_ascii_wrap() -> None:
    s = "".join(chr(97 + (i % 26)) for i in range(100))  # 100 ASCII, len 100
    row0, row1, row2 = s[0:40], s[40:80], s[80:100]
    captured, data = _run_case([["-l", s]], s.encode("utf-8"))

    assert data is not None, "(a) driver produced no out file"
    assert data == s.encode("utf-8"), (
        f"(a) returned answer mismatch: {data!r} != {s.encode()!r}")

    lines = captured.split("\n")
    n0 = lines.count(row0)
    assert n0 == 1, (
        f"(a) first 40-char physical row appears {n0} times (want exactly "
        f"1 — >1 means the wrap-repaint bug). Pane:\n{captured}")
    assert lines.count(row1) == 1, (
        f"(a) second physical row not rendered exactly once. Pane:\n{captured}")
    assert lines.count(row2) == 1, (
        f"(a) third physical row not rendered exactly once. Pane:\n{captured}")
    # The three rows must be consecutive (the answer region == 3 rows).
    i = lines.index(row0)
    assert lines[i + 1] == row1 and lines[i + 2] == row2, (
        f"(a) answer region is not exactly the 3 expected contiguous rows. "
        f"Pane:\n{captured}")
    print("  ok: (a) ascii wrap — no duplicated line, exact 3 rows, exact "
          "returned answer")


def case_tab_nonascii_nonregression() -> None:
    expected = "a\tXéb"
    keys = [["-l", "a"], ["Tab"], ["-l", "Xéb"]]
    captured, data = _run_case(keys, expected.encode("utf-8"))

    assert data is not None, "(b) driver produced no out file"
    assert data == expected.encode("utf-8"), (
        f"(b) returned answer not byte-exact: {data!r} != "
        f"{expected.encode()!r}")

    # Single render: the distinctive 'X' and 'é' each appear exactly once
    # in the whole captured pane (the repaint bug would duplicate the row).
    cx, ce = captured.count("X"), captured.count("é")
    assert cx == 1, (
        f"(b) 'X' appears {cx} times (want 1 — >1 means duplicated row). "
        f"Pane:\n{captured}")
    assert ce == 1, (
        f"(b) 'é' appears {ce} times (want 1 — >1 means duplicated row). "
        f"Pane:\n{captured}")
    print("  ok: (b) tab/non-ascii non-wrap — single row, byte-exact answer")


def case_incremental_wrap() -> None:
    """Bug 4 (Round 2): type a 100-char single logical line ONE key at a
    time (separate `send-keys -l <char>` per char, settle between). Each
    keystroke triggers a real `_redraw`; the duplicated-first-line bug
    compounds per keystroke past the wrap point. Assert the first 40-char
    physical row still appears EXACTLY ONCE."""
    s = "".join(chr(97 + (i % 26)) for i in range(100))  # 100 ASCII
    row0, row1, row2 = s[0:40], s[40:80], s[80:100]
    keys = [["-l", ch] for ch in s]  # one send-keys per character
    captured, data = _run_case(keys, s.encode("utf-8"))

    assert data is not None, "(c) driver produced no out file"
    assert data == s.encode("utf-8"), (
        f"(c) returned answer mismatch: {data!r} != {s.encode()!r}")

    lines = captured.split("\n")
    n0 = lines.count(row0)
    assert n0 == 1, (
        f"(c) first 40-char physical row appears {n0} times after "
        f"per-keystroke typing (want exactly 1 — >1 means the wrap-repaint "
        f"bug compounded per keystroke). Pane:\n{captured}")
    assert lines.count(row1) == 1, (
        f"(c) second physical row not rendered exactly once. "
        f"Pane:\n{captured}")
    assert lines.count(row2) == 1, (
        f"(c) third physical row not rendered exactly once. "
        f"Pane:\n{captured}")
    i = lines.index(row0)
    assert lines[i + 1] == row1 and lines[i + 2] == row2, (
        f"(c) answer region is not exactly the 3 expected contiguous rows. "
        f"Pane:\n{captured}")
    print("  ok: (c) incremental wrap — first row appears exactly once")


def case_banner_wraps() -> None:
    """Bug 2 (Round 1): a single-logical-line question ~120 chars in the
    40-wide pane. With the fix the banner soft-wraps to the pane width:
    the `[Question from agent]` line is present, NO captured line exceeds
    40 columns, every whitespace-separated token of the question is
    visible somewhere in the pane (nothing truncated at the right edge),
    and the un-wrapped question string never appears on any single
    captured line (proof it wrapped, not truncated). Pre-fix the editor
    disabled autowrap and emitted the question unwrapped, so it was cut
    at the 40th column and most tokens were lost."""
    Q = "BANNER " + "wrapword " * 16  # ~150 chars, single logical line
    Q = Q.rstrip()
    # Submit immediately (Ctrl-D), empty answer; we only inspect the
    # banner the editor drew.
    captured, data = _run_case([], b"", question=Q)

    assert data is not None, "(d) driver produced no out file"
    assert data == b"", (
        f"(d) expected empty answer (Ctrl-D), got {data!r}")

    lines = captured.split("\n")
    assert any("[Question from agent]" in ln for ln in lines), (
        f"(d) banner header missing from pane:\n{captured}")
    over = [ln for ln in lines if len(ln) > _PANE_W]
    assert not over, (
        f"(d) {len(over)} captured line(s) exceed pane width {_PANE_W} "
        f"(truncation/no-wrap). First: {over[0]!r}\nPane:\n{captured}")
    blob = "\n".join(lines)
    for tok in Q.split():
        assert tok in blob, (
            f"(d) question token {tok!r} missing from pane (truncated?)."
            f"\nPane:\n{captured}")
    assert not any(Q in ln for ln in lines), (
        f"(d) the full un-wrapped question appears on a single line "
        f"(it did not wrap). Pane:\n{captured}")
    print("  ok: (d) banner wraps — header present, no line over width, "
          "every token visible, not truncated")


def main() -> int:
    if shutil.which("tmux") is None:
        print("SKIP: tmux not found")
        return 0
    print("wrap-repaint tmux checks:")
    case_ascii_wrap()
    case_tab_nonascii_nonregression()
    case_incremental_wrap()
    case_banner_wraps()
    print("WRAP-TMUX OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
