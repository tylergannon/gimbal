"""Shape D — post-step asset snapshot backfill tests.

Per the round 3 plan (Change 1) and the round 3 feedback, the helper
implements the **count-plus-one** algorithm:

    existing = files in assets_dir matching r'^<base>-(\\d{4})\\.md$'
    N = len(existing) + 1
    target = assets_dir / f"{base}-{N:04d}.md"
    if target.exists():
        return "exists"     # branch A
    elif (assets_dir / f"{base}-current.md").exists():
        shutil.copyfile(current, target)
        return "copied"     # branch B
    else:
        return "none"       # branch C

Key correctness rule: N is **count + 1**, NOT "first vacant slot".
With files `<base>-0001.md` and `<base>-0003.md` on disk (gap at
0002), count=2 → N=3, and 0003 already exists → branch A. The
helper NEVER backfills the gap at 0002.

Scenarios:

  1. branch_a_target_exists_sparse — [0001, 0003, current]:
                                     count=2, N=3, target 0003 EXISTS
                                     → 'exists'. No new file written.
                                     Also asserts Workflow.load
                                     accepts the new `assets` field on
                                     workflows/6step.yaml.
  2. branch_b_current_only         — [current]: count=0, N=1, target
                                     0001 not on disk → copy current
                                     → 0001 → 'copied'.
  3. branch_c_neither              — []: → 'none'.
  4. current_only_multi_round_progression
                                   — the regression demanded by round
                                     3 feedback. Simulates a single-
                                     write prompt (only writes
                                     `<base>-current.md`) across
                                     rounds 1..3 and proves each
                                     successive round produces the
                                     next NNNN (0001, 0002, 0003).
                                     This is the XV-2 cross-cutting
                                     contract widened to three rounds.
  5. sparse_history_no_gap_backfill
                                   — [0001, 0003, current]: branch A
                                     (N=3, 0003 exists) — gap at 0002
                                     NOT filled. Add 0004: count=3,
                                     N=4, 0004 exists — still branch A.
                                     Delete 0003 and 0004 leaving
                                     [0001, current]: count=1, N=2,
                                     target 0002 not on disk, current
                                     present → 'copied' (branch B).
                                     Nails the count-plus-one semantic.
  6. dual_write_existing_round_unchanged
                                   — round 3's plan acknowledges that
                                     today's dual-writing prompts
                                     keep dual-writing
                                     (out-of-scope: "Prompt
                                     simplification"). With
                                     [<base>-0001.md, <base>-current.md]
                                     pre-existing, the helper's
                                     count-plus-one rule does write a
                                     fresh <base>-0002.md (count=1,
                                     N=2, target 0002 not on disk →
                                     branch B copy). The
                                     backwards-compat guarantee that
                                     matters is that the prompt's
                                     pre-existing <base>-0001.md is
                                     never mutated. This scenario
                                     asserts exactly that (sha256
                                     stable) and confirms the result
                                     is 'copied'.
  7. not_called_on_question_path   — proves the snapshot helper is
                                     only wired to the routable-
                                     success leaf of execute_step
                                     (no <base>-NNNN.md is written
                                     when the step asked a question
                                     or wrote an invalid outcome).

Stdlib-only. Run from the project root:

    .venv/bin/python tests/test_asset_snapshot_backfill.py
"""

from __future__ import annotations

import hashlib
import os
import sys
import tempfile
from pathlib import Path

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import tenacious.orchestrator as o  # noqa: E402


FAILS: list[str] = []
PASSES = 0


def _ok(name: str) -> None:
    global PASSES
    PASSES += 1
    print(f"PASS {name}")


def _fail(name: str, detail: str) -> None:
    FAILS.append(f"{name}: {detail}")
    print(f"FAIL {name}: {detail}")


def _sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _branch_a_target_exists_sparse() -> None:
    """Branch A: count+1 lands on an existing NNNN file.

    Setup: [plan-0001.md, plan-0003.md, plan-current.md]. count=2,
    N=count+1=3, target=plan-0003.md EXISTS → 'exists'. No new file
    written. plan-0002.md gap is NOT filled.

    Also asserts Workflow.load accepts the new `assets` field on
    the shipped workflows/6step.yaml.
    """
    name = "branch_a_target_exists_sparse"

    # Workflow.load accepts the new `assets` field for the shipped wf.
    wf = o.Workflow.load(Path(_PROJECT_ROOT) / "workflows" / "6step.yaml")
    if wf.steps["requirements"].assets != ["requirements"]:
        _fail(name, "6step.yaml requirements step missing assets")
        return
    if wf.steps["code_review"].assets != ["status-update", "code-feedback"]:
        _fail(name, "6step.yaml code_review step missing assets")
        return

    d = Path(tempfile.mkdtemp(prefix="s-aA-"))
    (d / "plan-0001.md").write_text("A")
    (d / "plan-0003.md").write_text("C")
    (d / "plan-current.md").write_text("cur")
    before_0001 = _sha(d / "plan-0001.md")
    before_0003 = _sha(d / "plan-0003.md")
    before_cur = _sha(d / "plan-current.md")

    res = o._snapshot_step_assets(d, ["plan"])

    if res.get("plan") != "exists":
        _fail(name, f"expected branch A 'exists', got {res!r}")
        return
    if (d / "plan-0002.md").exists():
        _fail(name, "branch A must NOT backfill the 0002 gap")
        return
    if (d / "plan-0004.md").exists():
        _fail(name, "branch A must NOT write any new NNNN file")
        return
    if _sha(d / "plan-0001.md") != before_0001:
        _fail(name, "plan-0001.md mutated")
        return
    if _sha(d / "plan-0003.md") != before_0003:
        _fail(name, "plan-0003.md mutated")
        return
    if _sha(d / "plan-current.md") != before_cur:
        _fail(name, "plan-current.md mutated")
        return
    _ok(name)


def _branch_b_current_only() -> None:
    """Branch B: no NNNN files, current exists → copy current → 0001."""
    name = "branch_b_current_only"
    d = Path(tempfile.mkdtemp(prefix="s-b-"))
    (d / "requirements-current.md").write_text("current\n")
    res = o._snapshot_step_assets(d, ["requirements"])
    target = d / "requirements-0001.md"
    if not target.exists():
        _fail(name, f"target {target} not created")
        return
    if target.read_text() != "current\n":
        _fail(name, "target content differs from current")
        return
    if res.get("requirements") != "copied":
        _fail(name, f"expected branch B, got {res!r}")
        return
    _ok(name)


def _branch_c_neither() -> None:
    """Branch C: no NNNN and no current → no-op, return 'none'."""
    name = "branch_c_neither"
    d = Path(tempfile.mkdtemp(prefix="s-c-"))
    res = o._snapshot_step_assets(d, ["requirements"])
    if list(d.iterdir()):
        _fail(name, f"directory unexpectedly populated: {list(d.iterdir())}")
        return
    if res.get("requirements") != "none":
        _fail(name, f"expected branch C, got {res!r}")
        return
    _ok(name)


def _current_only_multi_round_progression() -> None:
    """Single-write prompt across rounds 1..3 advances NNNN correctly.

    This is the regression the round 3 feedback demanded: prove that a
    step that only writes `<base>-current.md` produces a successive
    `<base>-0001.md`, `<base>-0002.md`, `<base>-0003.md` over three
    rounds. Each round preserves all earlier snapshots byte-identical.

    The XV-2 cross-cutting validation in plan-current.md covers
    rounds 1 and 2; this scenario widens the contract to round 3 and
    adds an idempotency check at the end.
    """
    name = "current_only_multi_round_progression"
    d = Path(tempfile.mkdtemp(prefix="s-prog-"))

    # Round 1: write current, snapshot. Expect 0001 = current.
    (d / "plan-current.md").write_text("PLAN-V1\n")
    r1 = o._snapshot_step_assets(d, ["plan"])
    if r1.get("plan") != "copied":
        _fail(name, f"round 1 expected 'copied', got {r1!r}")
        return
    if not (d / "plan-0001.md").exists():
        _fail(name, "round 1 did not create plan-0001.md")
        return
    if (d / "plan-0001.md").read_text() != "PLAN-V1\n":
        _fail(name, "round 1 plan-0001.md content wrong")
        return

    # Round 2: update current, snapshot. Expect 0002 = current,
    # 0001 unchanged.
    (d / "plan-current.md").write_text("PLAN-V2\n")
    r2 = o._snapshot_step_assets(d, ["plan"])
    if r2.get("plan") != "copied":
        _fail(name, f"round 2 expected 'copied', got {r2!r}")
        return
    if not (d / "plan-0002.md").exists():
        _fail(name, "round 2 did not create plan-0002.md")
        return
    if (d / "plan-0002.md").read_text() != "PLAN-V2\n":
        _fail(name, "round 2 plan-0002.md content wrong")
        return
    if (d / "plan-0001.md").read_text() != "PLAN-V1\n":
        _fail(name, "round 2 mutated plan-0001.md")
        return

    # Round 3: update current, snapshot. Expect 0003 = current,
    # 0001 + 0002 unchanged.
    (d / "plan-current.md").write_text("PLAN-V3\n")
    r3 = o._snapshot_step_assets(d, ["plan"])
    if r3.get("plan") != "copied":
        _fail(name, f"round 3 expected 'copied', got {r3!r}")
        return
    for slug, expect in [
        ("plan-0001.md", "PLAN-V1\n"),
        ("plan-0002.md", "PLAN-V2\n"),
        ("plan-0003.md", "PLAN-V3\n"),
    ]:
        if not (d / slug).exists():
            _fail(name, f"round 3 missing {slug}")
            return
        if (d / slug).read_text() != expect:
            _fail(name, f"round 3 {slug} content wrong")
            return

    # Idempotency: a redundant call with current unchanged advances
    # again because count-plus-one is purely on-disk and the helper
    # never compares content. This documents the contract:
    # the step is responsible for only invoking snapshot once per
    # successful round (orchestrator wires it to the routable-success
    # leaf — see scenario 7). Here, a manual extra call simulates
    # what would happen if the orchestrator misfired.
    r4 = o._snapshot_step_assets(d, ["plan"])
    if r4.get("plan") != "copied":
        _fail(name, f"redundant call expected 'copied', got {r4!r}")
        return
    if not (d / "plan-0004.md").exists():
        _fail(name, "redundant call should advance to 0004 (count=3 → N=4)")
        return
    if (d / "plan-0004.md").read_text() != "PLAN-V3\n":
        _fail(name, "redundant 0004 content wrong")
        return

    _ok(name)


def _sparse_history_no_gap_backfill() -> None:
    """Sparse-history gap discipline under count-plus-one.

    Phase 1 — Setup [0001, 0003, current]: count=2, N=3, target 0003
    EXISTS → branch A, no write. The 0002 gap stays.

    Phase 2 — Add 0004 → [0001, 0003, 0004, current]: count=3, N=4,
    target 0004 EXISTS → branch A, no write. The 0002 gap STILL stays.

    Phase 3 — Delete 0003 and 0004 leaving [0001, current]: count=1,
    N=2, target 0002 NOT exists, current exists → branch B copies
    current → 0002 → 'copied'. Note we did NOT "fill the gap" at
    0002 by walking the historical sparse history — we filled 0002
    because count of remaining files happens to be 1 and 1+1=2 lands
    on a vacant slot. This is the count-plus-one rule end-to-end.
    """
    name = "sparse_history_no_gap_backfill"
    d = Path(tempfile.mkdtemp(prefix="s-sp-"))
    (d / "plan-0001.md").write_text("A")
    (d / "plan-0003.md").write_text("C")
    (d / "plan-current.md").write_text("cur")

    res = o._snapshot_step_assets(d, ["plan"])
    if res.get("plan") != "exists":
        _fail(name, f"phase 1: expected 'exists', got {res!r}")
        return
    if (d / "plan-0002.md").exists():
        _fail(name, "phase 1: must NOT backfill 0002 gap")
        return
    if (d / "plan-0004.md").exists():
        _fail(name, "phase 1: helper unexpectedly wrote 0004")
        return

    (d / "plan-0004.md").write_text("D")
    res = o._snapshot_step_assets(d, ["plan"])
    if res.get("plan") != "exists":
        _fail(name, f"phase 2: expected 'exists', got {res!r}")
        return
    if (d / "plan-0002.md").exists():
        _fail(name, "phase 2: helper backfilled 0002 gap")
        return

    (d / "plan-0003.md").unlink()
    (d / "plan-0004.md").unlink()
    # Now disk: [plan-0001.md, plan-current.md]. count=1, N=2.
    res = o._snapshot_step_assets(d, ["plan"])
    if res.get("plan") != "copied":
        _fail(name, f"phase 3: expected 'copied', got {res!r}")
        return
    if not (d / "plan-0002.md").exists():
        _fail(name, "phase 3: count=1 → N=2 should have been copied")
        return
    if (d / "plan-0002.md").read_text() != "cur":
        _fail(name, "phase 3: 0002 content differs from current")
        return
    if (d / "plan-0001.md").read_text() != "A":
        _fail(name, "phase 3: plan-0001.md mutated")
        return
    _ok(name)


def _dual_write_existing_round_unchanged() -> None:
    """Dual-write backwards-compat: helper no-ops on a dual-write state.

    Round 3 keeps today's dual-writing prompts (out-of-scope: "Prompt
    simplification... Existing prompts continue to dual-write current
    + NNNN"). The contract a dual-writing prompt depends on: when it
    has already produced <base>-NNNN.md (and refreshed
    <base>-current.md), the snapshot helper must NOT create an extra
    <base>-{NNNN+1}.md for the same round.

    This is the C1-V1 plan validation translated into a test: with
    [<base>-0001.md, <base>-current.md] pre-existing on disk (and no
    prior snapshot sentinel — fresh state, simulating the first time
    the helper runs against a dual-writing prompt's output), the
    helper must:
      - return 'exists',
      - leave <base>-0001.md byte-identical (sha256 stable),
      - leave <base>-current.md byte-identical,
      - create no additional <base>-NNNN.md files.

    Multi-round dual-write must keep no-opping each round (e.g.
    [0001..0003, current] → 'exists', no 0004 written), so we also
    cover that downstream case here.
    """
    name = "dual_write_existing_round_unchanged"
    d = Path(tempfile.mkdtemp(prefix="s-dw-"))
    (d / "requirements-0001.md").write_text("frozen")
    (d / "requirements-current.md").write_text("current")
    before_0001 = _sha(d / "requirements-0001.md")
    before_cur = _sha(d / "requirements-current.md")

    res = o._snapshot_step_assets(d, ["requirements"])

    if res.get("requirements") != "exists":
        _fail(name,
              f"expected 'exists' (dual-write backwards-compat), got {res!r}")
        return
    if _sha(d / "requirements-0001.md") != before_0001:
        _fail(name, "pre-existing requirements-0001.md mutated")
        return
    if _sha(d / "requirements-current.md") != before_cur:
        _fail(name, "requirements-current.md mutated")
        return
    extra = sorted(
        p.name for p in d.iterdir()
        if p.is_file() and o._SNAPSHOT_NNNN_RE.match(p.name)
        and p.name != "requirements-0001.md"
    )
    if extra:
        _fail(name,
              f"dual-write helper unexpectedly created extra NNNN files: {extra}")
        return

    # Round 3 (and beyond): after the prompt for round N writes a new
    # NNNN, the helper bumps its sentinel and continues no-opping.
    d2 = Path(tempfile.mkdtemp(prefix="s-dw2-"))
    for k in (1, 2, 3):
        (d2 / f"plan-{k:04d}.md").write_text(f"v{k}")
    (d2 / "plan-current.md").write_text("v3")
    pre = sorted(p.name for p in d2.iterdir() if p.is_file())
    res2 = o._snapshot_step_assets(d2, ["plan"])
    post = sorted(p.name for p in d2.iterdir() if p.is_file())
    if res2.get("plan") != "exists":
        _fail(name, f"multi-round dual-write expected 'exists', got {res2!r}")
        return
    if pre != post:
        _fail(name,
              f"dual-write helper changed the file set: pre={pre} post={post}")
        return
    _ok(name)


def _not_called_on_question_path() -> None:
    """Snapshot helper is wired ONLY to the routable-success leaf of
    execute_step. Drive a question + invalid-outcome retry path and
    assert no <base>-NNNN.md ever lands on disk."""
    name = "not_called_on_question_path"
    d = Path(tempfile.mkdtemp(prefix="s-q-"))
    (d / "assets").mkdir()
    wf = o.Workflow(goal="g", start_step="s", steps={
        "s": o.Step(slug="s", agent="claude", prompt="p",
                    next_steps=["plan"], questions=True,
                    assets=["requirements"]),
    })
    run = o.Run(slug="r", root=d, workflow=wf, project_dir=d, accounts={})
    # Pre-populate a -current.md so any rogue snapshot call would
    # leave a side effect (branch B would create 0001.md).
    (d / "assets" / "requirements-current.md").write_text("cur")

    calls = {"n": 0}

    def fake_runner(step, run_, visit, step_dir, prompt,
                    should_continue, **kw):
        calls["n"] += 1
        # First visit asks a question; subsequent visits write invalid
        # outcomes to force the retry loop until budget exhausts.
        if calls["n"] == 1:
            (step_dir / "question.txt").write_text("q?\n")
            (step_dir / "outcome.txt").write_text("question\n")
            return {"exit": 0, "stdout": "", "stderr": "", "thread_id": None}
        (step_dir / "outcome.txt").write_text("not-a-valid-next\n")
        return {"exit": 0, "stdout": "", "stderr": "", "thread_id": None}

    saved = dict(o.AGENT_RUNNERS)
    o.AGENT_RUNNERS["claude"] = fake_runner

    class Answers:
        def next_answer(self, question: str) -> str:
            return "OK"

    try:
        try:
            o.execute_step(wf.steps["s"], run, Answers(), monitor=None)
        except RuntimeError:
            # Expected: retry budget exhausts on the invalid outcome.
            pass
    finally:
        o.AGENT_RUNNERS.clear()
        o.AGENT_RUNNERS.update(saved)

    if (d / "assets" / "requirements-0001.md").exists():
        _fail(name, "snapshot ran on a non-success path (created 0001.md)")
        return
    _ok(name)


def main() -> int:
    _branch_a_target_exists_sparse()
    _branch_b_current_only()
    _branch_c_neither()
    _current_only_multi_round_progression()
    _sparse_history_no_gap_backfill()
    _dual_write_existing_round_unchanged()
    _not_called_on_question_path()

    if FAILS:
        print(f"\nFAILED ({len(FAILS)}):")
        for f in FAILS:
            print(f"  {f}")
        return 1
    print(f"\nALL PASS ({PASSES})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
