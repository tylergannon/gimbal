"""Tests for auth-bank evict + failover for dead codex (openai) slots.

Two layers:

  * Direct unit tests of the detection predicate
    (`authbank.is_auth_refresh_failure` / `authbank.auth_refresh_marker`)
    and the eviction primitive (`authbank.evict`).
  * End-to-end scenarios that spawn a real `python -m tenacious <wf>` with a
    behavior-driven fake `codex` shim on PATH. The shim reads the per-step
    credential (`$CODEX_HOME/auth.json`, i.e. the copy of the leased slot)
    and either succeeds (rotating its credential) or emits a specific codex
    auth-refresh 401 stderr signature and exits non-zero — letting tests
    assert eviction, writeback-skip, slot failover, and exhaustion. The bank
    path never falls back to the off-bank login.

Every scenario uses a temp TENACIOUS_HOME (bank) AND a temp CODEX_HOME so no
real `~/.tenacious` or `~/.codex` is touched (CODEX_HOME is also overridden
per-step by the orchestrator; the temp dir guards against accidental reads).

Run from the project root:

    python3 tests/test_authbank_evict_failover.py
"""

from __future__ import annotations

import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import traceback
from pathlib import Path

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_PROJECT_ROOT))

from tenacious import authbank  # noqa: E402


# --------------------------------------------------------------------------
# Behavior-driven fake codex shim
# --------------------------------------------------------------------------
#
# Reads $CODEX_HOME/auth.json (the per-step copy of the leased credential),
# parses {"id", "behavior"} and acts. Built via .replace() (not .format) to
# avoid brace-escaping the embedded JSON.

_CODEX_SHIM = r'''#!__PYTHON__
import json, os, re, sys

home = os.environ.get("CODEX_HOME", "")
auth_path = os.path.join(home, "auth.json") if home else ""
cred = {}
raw = ""
if auth_path and os.path.isfile(auth_path):
    try:
        raw = open(auth_path).read()
        cred = json.loads(raw)
    except Exception:
        cred = {}

behavior = cred.get("behavior", "ok")
cred_id = cred.get("id", "")

prompt = sys.argv[-1] if len(sys.argv) >= 1 else ""

outcome_path = None
m = re.search(r"write the slug of the next step to:\s*\n\s+(\S+)", prompt)
if m:
    outcome_path = m.group(1)
next_slug = "end"
m = re.search(r"Valid next-step slugs:\s*([^\n]+)", prompt)
if m:
    slugs = [s.strip() for s in m.group(1).split(",") if s.strip()]
    if slugs:
        next_slug = slugs[0]

for pm in re.finditer(r"\bto(?: the file)?:\s*\n\s+(\S+\.[A-Za-z0-9]+)", prompt):
    p = pm.group(1)
    if p == outcome_path:
        continue
    try:
        d = os.path.dirname(p)
        if d:
            os.makedirs(d, exist_ok=True)
        open(p, "w").write("shim-dummy\n")
    except OSError:
        pass

record = {
    "behavior": behavior,
    "cred_id": cred_id,
    "auth_path": auth_path,
    "pid": os.getpid(),
}
cap = os.environ.get("SHIM_CAPTURE_PATH")
if cap:
    with open(cap, "a") as f:
        f.write(json.dumps(record) + "\n")

if behavior.startswith("auth_fail"):
    marker = behavior.split(":", 1)[1] if ":" in behavior else "refresh_token_reused"
    # Mutate the per-step credential FIRST so any stray writeback would
    # persist the dead/rotated token (the tests prove writeback is skipped).
    try:
        open(auth_path, "w").write(json.dumps({"id": cred_id, "state": "DEAD-ROTATED"}))
    except OSError:
        pass
    if marker == "manager_line":
        sys.stderr.write(
            "ERROR codex_login::auth::manager: Failed to refresh token: "
            "Please try again later.\n")
    elif marker == "phrase_reused":
        sys.stderr.write(
            "Your refresh token was already used to generate a new access "
            "token. Please log out and sign in again.\n")
    else:
        err = json.dumps({"error": {"code": marker, "message": "bad"}})
        sys.stderr.write(
            "ERROR codex_login::auth::manager: Failed to refresh token: "
            "401 Unauthorized: " + err + "\n")
    sys.exit(1)

if behavior == "task_fail":
    sys.stderr.write("Error: the task failed for an ordinary reason\n")
    sys.stderr.write("429 Too Many Requests\n")
    sys.exit(1)

# behavior == "ok": rotate the credential, write outcome, succeed.
try:
    open(auth_path, "w").write(json.dumps({"id": cred_id, "state": "ROTATED"}))
except OSError:
    pass
if outcome_path:
    try:
        open(outcome_path, "w").write(next_slug + "\n")
    except OSError:
        pass
sys.stdout.write(json.dumps({"type": "thread.started", "thread_id": "thr_test"}) + "\n")
sys.exit(0)
'''


def _write_codex_shim(bin_dir: Path) -> Path:
    bin_dir.mkdir(parents=True, exist_ok=True)
    shim = bin_dir / "codex"
    shim.write_text(_CODEX_SHIM.replace("__PYTHON__", sys.executable))
    mode = shim.stat().st_mode
    shim.chmod(mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return shim


# --------------------------------------------------------------------------
# Single-step codex workflow (no retries → deterministic slot-attempt counts)
# --------------------------------------------------------------------------

def _write_workflow(d: Path) -> Path:
    wf = {
        "goal": "exercise the codex bank failover path",
        "start_step": "write",
        "steps": {
            "write": {
                "agent": "codex",
                "prompt": ("Goal: {goal}\n\nTask: do nothing of note. "
                           "Then write the literal text 'end' to:\n"
                           "  {outcome_path}\nDo not ask any questions."),
                "asset_slugs": [],
                "next_steps": ["end"],
                "context": "empty",
                "outcome_retries": 0,
            }
        },
    }
    p = d / "wf.json"
    p.write_text(json.dumps(wf))
    return p


def _slot(content: dict) -> str:
    return json.dumps(content)


def _populate_bank(home: Path, slots: dict[str, dict]) -> Path:
    """Create openai/fake bank with the given {name: cred-dict} slots."""
    bank = home / "auth-bank" / "openai" / "fake"
    bank.mkdir(parents=True, exist_ok=True)
    for name, cred in slots.items():
        (bank / name).write_text(_slot(cred))
    return bank


# --------------------------------------------------------------------------
# Env + runner
# --------------------------------------------------------------------------

def _make_env(home: Path, bin_dir: Path, codex_home: Path,
              capture: Path, extra: dict[str, str]) -> dict:
    env = os.environ.copy()
    for k in ("ANTHROPIC_API_KEY", "CLAUDE_CODE_OAUTH_TOKEN",
              "CODEX_API_KEY", "OPENAI_API_KEY",
              "CLAUDE_CONFIG_DIR", "CODEX_HOME"):
        env.pop(k, None)
    env["TENACIOUS_HOME"] = str(home)
    env["PATH"] = f"{bin_dir}:{env.get('PATH', '')}"
    env["SHIM_CAPTURE_PATH"] = str(capture)
    # Off-bank login dir — ALWAYS a temp dir so real ~/.codex is never read.
    env["CODEX_HOME"] = str(codex_home)
    env.update(extra)
    return env


def _run(env: dict, wf: Path) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, "-m", "tenacious", str(wf)],
        cwd=str(_PROJECT_ROOT), env=env,
        capture_output=True, text=True, timeout=90,
    )


def _latest_run(home: Path) -> Path | None:
    runs = home / "runs"
    if not runs.is_dir():
        return None
    entries = sorted(p for p in runs.iterdir() if p.is_dir())
    return entries[-1] if entries else None


def _read_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    out: list[dict] = []
    for line in path.read_text().splitlines():
        line = line.strip()
        if line:
            out.append(json.loads(line))
    return out


class _Ctx:
    def __init__(self, d: Path):
        self.d = d
        self.home = d / "home"
        self.bin_dir = d / "bin"
        self.codex_home = d / "codex_home"   # temp off-bank login dir
        self.capture = d / "shim-capture.jsonl"
        self.home.mkdir()
        self.codex_home.mkdir()
        self.rc: int | None = None
        self.stdout = ""
        self.stderr = ""
        self.run_root: Path | None = None
        self.wf = _write_workflow(d)
        _write_codex_shim(self.bin_dir)

    def off_bank(self) -> Path:
        return self.codex_home / "auth.json"

    def write_off_bank(self, cred: dict) -> None:
        self.off_bank().write_text(_slot(cred))

    def go(self, extra: dict[str, str] | None = None) -> None:
        env = _make_env(self.home, self.bin_dir, self.codex_home,
                        self.capture, extra or {})
        r = _run(env, self.wf)
        self.rc = r.returncode
        self.stdout = r.stdout
        self.stderr = r.stderr
        self.run_root = _latest_run(self.home)

    def captures(self) -> list[dict]:
        return _read_jsonl(self.capture)

    def run_log_text(self) -> str:
        if self.run_root is None:
            return ""
        log = self.run_root / "run.log"
        return log.read_text() if log.exists() else ""

    def bank_dir(self) -> Path:
        return self.home / "auth-bank" / "openai" / "fake"

    def evicted(self) -> list[Path]:
        ev = self.bank_dir() / "_evicted"
        return sorted(ev.iterdir()) if ev.is_dir() else []

    def cleanup(self) -> None:
        shutil.rmtree(self.d, ignore_errors=True)


def _setup() -> _Ctx:
    return _Ctx(Path(tempfile.mkdtemp(prefix="tnc-evict-")))


def _no_real_codex_touched(ctx: _Ctx) -> None:
    """No path under the developer's real ~/.codex appears anywhere."""
    real = str(Path.home() / ".codex")
    blob = ctx.run_log_text() + "\n" + json.dumps(ctx.captures())
    assert real not in blob, f"real ~/.codex referenced: {real}"


# --------------------------------------------------------------------------
# Unit tests — predicate + marker + evict
# --------------------------------------------------------------------------

_MGR = "ERROR codex_login::auth::manager: Failed to refresh token: 401 Unauthorized"


def s_predicate() -> None:
    f = authbank.is_auth_refresh_failure
    mk = authbank.auth_refresh_marker

    # Exit 0 never an auth failure, even with a marker present.
    assert f(0, _MGR) is False

    # Bare 401 / Unauthorized alone → not auth.
    assert f(1, "HTTP 401 Unauthorized") is False
    # Rate limit → not auth.
    assert f(1, "429 Too Many Requests") is False
    # Ordinary task error mentioning 'token' casually → not auth.
    assert f(1, "Error: could not parse token budget in config") is False
    # Empty stderr → not auth.
    assert f(1, "") is False

    # Each required concrete code (in refresh/401 context) → True, exact marker.
    for code in ("refresh_token_invalidated", "refresh_token_reused",
                 "token_expired"):
        s = f'401 Unauthorized: {{ "error": {{ "code": "{code}" }} }}'
        assert f(1, s) is True, code
        assert mk(s) == code, code

    # A concrete code WITHOUT refresh/401 context → not auth (guards token_expired).
    assert f(1, "note: the cache token_expired flag was cleared") is False

    # Canonical manager line alone → True.
    line = "ERROR codex_login::auth::manager: Failed to refresh token: oops"
    assert f(1, line) is True
    assert mk(line) == "codex_login::auth::manager: Failed to refresh token"

    # Each exact human phrase alone → True.
    for phrase in ("refresh token was already used",
                   "Provided authentication token is expired",
                   "Please log out and sign in again"):
        assert f(1, f"some prefix {phrase} some suffix") is True, phrase
        assert mk(f"x {phrase} y") == phrase, phrase

    # Marker prefers the concrete code over a co-occurring phrase.
    both = ('Please log out and sign in again. code: refresh_token_reused')
    assert mk(both) == "refresh_token_reused"

    # No marker in benign text.
    assert mk("just a normal error") is None


def s_evict_unit() -> None:
    d = Path(tempfile.mkdtemp(prefix="tnc-evict-unit-"))
    try:
        acct = d / "openai" / "fake"
        acct.mkdir(parents=True)
        slot = acct / "slot1.json"
        slot.write_text('{"id":"slot1"}')
        lock = acct / "slot1.json.lock"
        lock.write_text("")  # sentinel

        dest = authbank.evict(slot)

        # Original gone from top-level dir; lock sentinel removed.
        assert not slot.exists()
        assert not lock.exists()
        # Quarantined under _evicted/ with original payload intact.
        assert dest.exists()
        assert dest.parent == acct / "_evicted"
        assert json.loads(dest.read_text()) == {"id": "slot1"}
        # _evicted/ is a subdir → never returned by list_slots.
        # (list_slots only lists files with the provider ext at top level.)
        assert dest.name.startswith("slot1.json.")
        # Owner-private permissions on the quarantine dir.
        mode = stat.S_IMODE((acct / "_evicted").stat().st_mode)
        assert mode == 0o700, oct(mode)
    finally:
        shutil.rmtree(d, ignore_errors=True)


def s_lease_exclude_exhausted() -> None:
    """A non-empty exclude that empties a non-empty account → AllSlotsExhausted;
    a genuinely empty account → RuntimeError (unchanged)."""
    home = Path(tempfile.mkdtemp(prefix="tnc-lease-"))
    try:
        os.environ["TENACIOUS_HOME"] = str(home)
        _populate_bank(home, {"slot1.json": {"id": "slot1"}})
        # Exclude the only slot → AllSlotsExhausted.
        raised = None
        try:
            with authbank.lease("openai", "fake", exclude={"slot1.json"}):
                pass
        except authbank.AllSlotsExhausted as e:
            raised = e
        assert isinstance(raised, authbank.AllSlotsExhausted), raised
        assert raised.account == "fake"

        # Genuinely empty account → original RuntimeError (not AllSlotsExhausted).
        (home / "auth-bank" / "openai" / "empty").mkdir(parents=True)
        raised = None
        try:
            with authbank.lease("openai", "empty"):
                pass
        except authbank.AllSlotsExhausted as e:
            raised = ("exhausted", e)
        except RuntimeError as e:
            raised = ("runtime", e)
        assert raised[0] == "runtime", raised
    finally:
        os.environ.pop("TENACIOUS_HOME", None)
        shutil.rmtree(home, ignore_errors=True)


def s_random_slot_selection() -> None:
    """Codex slot selection is RANDOM by default (not alphabetical);
    TENACIOUS_AUTHBANK_ORDER=sorted restores deterministic order."""
    home = Path(tempfile.mkdtemp(prefix="tnc-rand-"))
    try:
        os.environ["TENACIOUS_HOME"] = str(home)
        os.environ.pop("TENACIOUS_AUTHBANK_ORDER", None)
        _populate_bank(home, {f"slot{i}.json": {"id": f"slot{i}"}
                              for i in range(1, 6)})

        # Default = random: across many leases of an all-free account, the
        # first-picked slot varies and is NOT pinned to the alphabetically
        # first slot. (All slots free → lease yields the first in its order.)
        picks = []
        for _ in range(60):
            with authbank.lease("openai", "fake") as slot:
                picks.append(slot.name)
        assert len(set(picks)) >= 2, set(picks)
        # All-slot1 by chance is (1/5)^60 ≈ 0 — guards a silent regression
        # back to alphabetical selection.
        assert not all(p == "slot1.json" for p in picks), "selection not random"

        # Forced sorted order → always the alphabetically-first free slot.
        os.environ["TENACIOUS_AUTHBANK_ORDER"] = "sorted"
        try:
            sorted_picks = []
            for _ in range(10):
                with authbank.lease("openai", "fake") as slot:
                    sorted_picks.append(slot.name)
            assert set(sorted_picks) == {"slot1.json"}, sorted_picks
        finally:
            os.environ.pop("TENACIOUS_AUTHBANK_ORDER", None)
    finally:
        os.environ.pop("TENACIOUS_HOME", None)
        shutil.rmtree(home, ignore_errors=True)


# --------------------------------------------------------------------------
# E2E scenarios
# --------------------------------------------------------------------------

def s_evict_and_no_writeback() -> None:
    """(a) Each auth-refresh signature evicts its slot WITHOUT writeback;
    the healthy slot is used and the run succeeds."""
    ctx = _setup()
    try:
        ctx.write_off_bank({"id": "offbank", "behavior": "ok"})  # should never be reached
        _populate_bank(ctx.home, {
            "slot1.json": {"id": "slot1", "behavior": "auth_fail:refresh_token_invalidated"},
            "slot2.json": {"id": "slot2", "behavior": "auth_fail:refresh_token_reused"},
            "slot3.json": {"id": "slot3", "behavior": "auth_fail:token_expired"},
            "slot4.json": {"id": "slot4", "behavior": "ok"},
        })
        # Pin alphabetical order so the dead slots are tried before slot4.
        ctx.go(extra={"TENACIOUS_AUTHBANK_ORDER": "sorted"})
        assert ctx.rc == 0, (ctx.rc, ctx.stderr, ctx.run_log_text())

        top = {p.name for p in ctx.bank_dir().iterdir() if p.is_file()}
        # Dead slots gone from the account top dir.
        for dead in ("slot1.json", "slot2.json", "slot3.json"):
            assert dead not in top, top
        # Healthy slot survives.
        assert "slot4.json" in top, top

        # Quarantined dead slots keep their ORIGINAL payload (writeback skipped).
        evicted = ctx.evicted()
        names = "\n".join(p.name for p in evicted)
        assert sum(1 for p in evicted if p.name.startswith("slot1.json.")) == 1, names
        assert sum(1 for p in evicted if p.name.startswith("slot2.json.")) == 1, names
        assert sum(1 for p in evicted if p.name.startswith("slot3.json.")) == 1, names
        for p in evicted:
            cred = json.loads(p.read_text())
            assert cred.get("state") != "DEAD-ROTATED", (p.name, cred)
            assert cred.get("behavior", "").startswith("auth_fail"), (p.name, cred)

        # Off-bank login never used (run succeeded on bank).
        seen_ids = [c["cred_id"] for c in ctx.captures()]
        assert "offbank" not in seen_ids, seen_ids
        # Off-bank file untouched.
        assert json.loads(ctx.off_bank().read_text())["behavior"] == "ok"
        _no_real_codex_touched(ctx)
    finally:
        ctx.cleanup()


def s_failover_order_and_log() -> None:
    """(b) Slots are leased in order, codex retried per slot, and the run.log
    failover trail names each concrete code. (b2) the healthy slot gets a
    normal writeback."""
    ctx = _setup()
    try:
        ctx.write_off_bank({"id": "offbank", "behavior": "ok"})
        _populate_bank(ctx.home, {
            "slot1.json": {"id": "slot1", "behavior": "auth_fail:refresh_token_invalidated"},
            "slot2.json": {"id": "slot2", "behavior": "auth_fail:refresh_token_reused"},
            "slot3.json": {"id": "slot3", "behavior": "auth_fail:token_expired"},
            "slot4.json": {"id": "slot4", "behavior": "ok"},
        })
        # Pin alphabetical order so the failover trail is deterministic.
        ctx.go(extra={"TENACIOUS_AUTHBANK_ORDER": "sorted"})
        assert ctx.rc == 0, (ctx.rc, ctx.stderr, ctx.run_log_text())

        # codex was invoked exactly once per slot within the single visit.
        seen = [c["cred_id"] for c in ctx.captures()]
        assert seen == ["slot1", "slot2", "slot3", "slot4"], seen

        log = ctx.run_log_text()
        i1 = log.find("slot1.json")
        i2 = log.find("slot2.json")
        i3 = log.find("slot3.json")
        assert -1 < i1 < i2 < i3, (i1, i2, i3)
        assert "[AUTH-EVICT]" in log
        assert "refresh_token_invalidated" in log
        assert "refresh_token_reused" in log
        assert "token_expired" in log

        # (b2) healthy slot4 received the rotated writeback.
        slot4 = json.loads((ctx.bank_dir() / "slot4.json").read_text())
        assert slot4.get("state") == "ROTATED", slot4
        _no_real_codex_touched(ctx)
    finally:
        ctx.cleanup()


def s_non_auth_failure_not_evicted() -> None:
    """(c) An ordinary (non-auth) failure is NOT treated as an auth failure:
    no eviction, no failover, normal writeback, no off-bank attempt."""
    ctx = _setup()
    try:
        ctx.write_off_bank({"id": "offbank", "behavior": "ok"})
        _populate_bank(ctx.home, {
            "slot1.json": {"id": "slot1", "behavior": "task_fail"},
        })
        ctx.go()
        assert ctx.rc != 0, (ctx.rc, "task_fail should fail the run")

        # No eviction whatsoever.
        assert not (ctx.bank_dir() / "_evicted").exists(), ctx.evicted()
        assert (ctx.bank_dir() / "slot1.json").exists()

        log = ctx.run_log_text()
        assert "[AUTH-EVICT]" not in log, log
        assert "[AUTH-FAILOVER]" not in log, log
        assert "[AUTH-EXHAUSTED]" not in log, log

        # Off-bank never consulted.
        assert "offbank" not in [c["cred_id"] for c in ctx.captures()]
        # Normal writeback occurred (slot rewritten with auth_target copy).
        # The shim does not rotate on task_fail, so slot1 still parses.
        assert json.loads((ctx.bank_dir() / "slot1.json").read_text())["id"] == "slot1"
        _no_real_codex_touched(ctx)
    finally:
        ctx.cleanup()


def s_off_bank_never_used() -> None:
    """(d) When all bank slots are dead, the bank path does NOT fall back to
    the user's off-bank login. Even with a healthy off-bank present, the run
    fails with exhaustion and the off-bank file is never read or mutated."""
    ctx = _setup()
    try:
        _populate_bank(ctx.home, {
            "slot1.json": {"id": "slot1", "behavior": "auth_fail:refresh_token_invalidated"},
        })
        ctx.write_off_bank({"id": "offbank", "behavior": "ok"})
        before = ctx.off_bank().read_text()
        ctx.go()
        # Run FAILS — bank exhausted, off-bank is NOT a fallback tier.
        assert ctx.rc != 0, (ctx.rc, ctx.run_log_text())

        # slot1 evicted.
        assert sum(1 for p in ctx.evicted() if p.name.startswith("slot1.json.")) == 1

        # Off-bank credential was NEVER invoked by codex.
        seen = [c["cred_id"] for c in ctx.captures()]
        assert "offbank" not in seen, seen

        log = ctx.run_log_text()
        assert "[AUTH-EXHAUSTED]" in log, log
        assert "POPULATING_THE_AUTH_BANK.md" in log, log
        # No off-bank wording or failover-to-off-bank trail anywhere.
        assert "off-bank" not in log, log
        assert "[AUTH-FAILOVER]" not in log, log

        # Off-bank file STILL exists, byte-identical (never read or written).
        assert ctx.off_bank().exists()
        assert ctx.off_bank().read_text() == before, ctx.off_bank().read_text()
        _no_real_codex_touched(ctx)
    finally:
        ctx.cleanup()


def s_exhaustion() -> None:
    """(e) The exhaustion error fires whenever every bank slot is dead,
    regardless of any off-bank login. It names the account and points at
    POPULATING_THE_AUTH_BANK.md."""
    # Variant 1: single dead slot, no off-bank file.
    ctx = _setup()
    try:
        _populate_bank(ctx.home, {
            "slot1.json": {"id": "slot1", "behavior": "auth_fail:refresh_token_reused"},
        })
        assert not ctx.off_bank().exists()
        ctx.go()
        assert ctx.rc != 0, ctx.rc
        log = ctx.run_log_text()
        assert "[AUTH-EXHAUSTED]" in log, log
        assert "openai/fake" in log, log
        assert "POPULATING_THE_AUTH_BANK.md" in log, log
        assert "off-bank" not in log, log
        # slot1 evicted.
        assert sum(1 for p in ctx.evicted() if p.name.startswith("slot1.json.")) == 1
        _no_real_codex_touched(ctx)
    finally:
        ctx.cleanup()

    # Variant 2: TWO dead slots → both evicted in order, then exhausted.
    ctx = _setup()
    try:
        _populate_bank(ctx.home, {
            "slot1.json": {"id": "slot1", "behavior": "auth_fail:refresh_token_reused"},
            "slot2.json": {"id": "slot2", "behavior": "auth_fail:token_expired"},
        })
        ctx.go()
        assert ctx.rc != 0, ctx.rc
        log = ctx.run_log_text()
        assert "[AUTH-EXHAUSTED]" in log, log
        # Both dead slots evicted.
        assert sum(1 for p in ctx.evicted() if p.name.startswith("slot1.json.")) == 1
        assert sum(1 for p in ctx.evicted() if p.name.startswith("slot2.json.")) == 1
        _no_real_codex_touched(ctx)
    finally:
        ctx.cleanup()


SCENARIOS = [
    ("predicate", s_predicate),
    ("evict_unit", s_evict_unit),
    ("lease_exclude_exhausted", s_lease_exclude_exhausted),
    ("random_slot_selection", s_random_slot_selection),
    ("evict_and_no_writeback", s_evict_and_no_writeback),
    ("failover_order_and_log", s_failover_order_and_log),
    ("non_auth_failure_not_evicted", s_non_auth_failure_not_evicted),
    ("off_bank_never_used", s_off_bank_never_used),
    ("exhaustion", s_exhaustion),
]


def main() -> int:
    for name, fn in SCENARIOS:
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            print(f"FAIL {name}: {e}")
            traceback.print_exc()
            return 1
        print(f"PASS {name}")
    print(f"ALL PASS ({len(SCENARIOS)} scenarios)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
