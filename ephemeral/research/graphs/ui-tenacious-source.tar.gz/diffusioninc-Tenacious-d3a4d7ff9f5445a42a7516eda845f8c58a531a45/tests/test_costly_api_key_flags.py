"""End-to-end tests for the `--costly-use-*-api-key` CLI flags.

Covers Round 1's in-scope behaviors:

  s_anthropic_flag_passes_api_key_strips_oauth_token
  s_anthropic_flag_works_with_empty_bank
  s_anthropic_flag_errors_when_env_missing
  s_codex_flag_passes_api_key_both_envs (variants A and B)
  s_codex_flag_works_with_empty_bank
  s_codex_flag_errors_when_env_missing
  s_anthropic_lease_never_creates_lockfile_off_path
  s_codex_lease_still_creates_lockfile_off_path
  s_off_path_equivalence_smoke

Each scenario spawns `python -m tenacious workflows/<name>.json` with
TENACIOUS_HOME / PATH pointed at a per-test temp dir. A sitecustomize.py
on PYTHONPATH monkey-patches `tenacious.authbank.{lease,pick_account}`
inside the orchestrator subprocess so every call is recorded to a
capture file — letting tests assert directly on "was the bank consulted
at all?" rather than only on filesystem side-effects.

Run from the project root:

    python3 tests/test_costly_api_key_flags.py
"""

from __future__ import annotations

import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import textwrap
import traceback
from pathlib import Path

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
_REAL_HELLO_CLAUDE = _PROJECT_ROOT / "workflows" / "hello-claude.json"
_REAL_HELLO_CODEX = _PROJECT_ROOT / "workflows" / "hello-codex.json"


# --------------------------------------------------------------------------
# Fake-agent shim writers
# --------------------------------------------------------------------------

_GENERIC_SHIM = r'''#!{python}
import json, os, re, sys

argv = sys.argv[1:]

# Extract the prompt body. claude uses `-p PROMPT`; codex passes it as the
# last positional argument (or after `resume <tid>`).
prompt = ""
if "{agent}" == "claude":
    for i, a in enumerate(sys.argv):
        if a == "-p" and i + 1 < len(sys.argv):
            prompt = sys.argv[i + 1]
            break
else:
    prompt = sys.argv[-1] if len(sys.argv) >= 1 else ""

# Outcome path: extracted from the orchestrator contract block.
outcome_path = None
m = re.search(r"write the slug of the next step to:\s*\n\s+(\S+)", prompt)
if m:
    outcome_path = m.group(1)

# First valid next-step slug from the contract block.
next_slug = "end"
m = re.search(r"Valid next-step slugs:\s*([^\n]+)", prompt)
if m:
    slugs = [s.strip() for s in m.group(1).split(",") if s.strip()]
    if slugs:
        next_slug = slugs[0]

# Create dummy files for any indented `to:` / `to the file:` targets so
# follow-up steps that reference them via asset_slugs don't see "missing".
for pm in re.finditer(
        r"\bto(?: the file)?:\s*\n\s+(\S+\.[A-Za-z0-9]+)",
        prompt):
    p = pm.group(1)
    if p == outcome_path:
        continue
    try:
        d = os.path.dirname(p)
        if d:
            os.makedirs(d, exist_ok=True)
        with open(p, "w") as f:
            f.write("shim-dummy\n")
    except OSError:
        pass

ENV_KEYS = (
    "ANTHROPIC_API_KEY", "CLAUDE_CODE_OAUTH_TOKEN", "CLAUDE_CONFIG_DIR",
    "CODEX_API_KEY", "OPENAI_API_KEY", "CODEX_HOME",
)
home = os.environ.get("CODEX_HOME", "")
record = {{
    "agent": "{agent}",
    "argv": argv,
    "env": {{k: os.environ[k] for k in ENV_KEYS if k in os.environ}},
    "outcome_path": outcome_path,
    "next_slug": next_slug,
    "pid": os.getpid(),
}}
if "{agent}" == "codex" and home:
    record["config_toml_exists"] = os.path.isfile(os.path.join(home, "config.toml"))
    record["auth_json_exists"] = os.path.isfile(os.path.join(home, "auth.json"))

cap = os.environ.get("SHIM_CAPTURE_PATH")
if cap:
    with open(cap, "a") as f:
        f.write(json.dumps(record) + "\n")

if outcome_path:
    try:
        with open(outcome_path, "w") as f:
            f.write(next_slug + "\n")
    except OSError:
        pass

if "{agent}" == "claude":
    sys.stdout.write(json.dumps({{
        "type": "result", "subtype": "success", "result": "ok"}}) + "\n")
else:
    sys.stdout.write(json.dumps({{
        "type": "thread.started", "thread_id": "thr_fake_costly"}}) + "\n")
sys.exit(0)
'''


def _write_shim(bin_dir: Path, agent: str) -> Path:
    bin_dir.mkdir(parents=True, exist_ok=True)
    shim = bin_dir / agent
    shim.write_text(_GENERIC_SHIM.format(python=sys.executable, agent=agent))
    mode = shim.stat().st_mode
    shim.chmod(mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return shim


# --------------------------------------------------------------------------
# Auth-bank populators
# --------------------------------------------------------------------------

def _populate_anthropic(home: Path, token: str = "BANK-TOKEN") -> Path:
    bank = home / "auth-bank" / "anthropic" / "fake"
    bank.mkdir(parents=True, exist_ok=True)
    slot = bank / "slot.txt"
    slot.write_text(token)
    return slot


def _populate_openai(home: Path, content: str = '{"BANK":"json"}') -> Path:
    bank = home / "auth-bank" / "openai" / "fake"
    bank.mkdir(parents=True, exist_ok=True)
    slot = bank / "slot.json"
    slot.write_text(content)
    return slot


# --------------------------------------------------------------------------
# Sitecustomize injection — traces authbank.lease / authbank.pick_account
# inside the spawned `python -m tenacious` subprocess.
# --------------------------------------------------------------------------

_SITECUSTOMIZE = '''
# auto-injected for tests/test_costly_api_key_flags.py
import json
import os
from contextlib import contextmanager

try:
    from tenacious import authbank as _ab
except Exception:  # noqa: BLE001
    _ab = None

_LOG = os.environ.get("AUTHBANK_CALL_LOG")


def _append(entry):
    if not _LOG:
        return
    try:
        with open(_LOG, "a") as f:
            f.write(json.dumps(entry) + "\\n")
    except OSError:
        pass


if _ab is not None:
    _orig_lease = _ab.lease
    _orig_pick = _ab.pick_account

    @contextmanager
    def _trace_lease(provider, account, *args, **kw):
        _append({"fn": "lease", "provider": provider,
                 "account": account, "pid": os.getpid()})
        with _orig_lease(provider, account, *args, **kw) as slot:
            yield slot

    def _trace_pick(provider, run_slug):
        _append({"fn": "pick_account", "provider": provider,
                 "run_slug": run_slug, "pid": os.getpid()})
        return _orig_pick(provider, run_slug)

    _ab.lease = _trace_lease
    _ab.pick_account = _trace_pick
'''


def _write_sitecustomize(site_dir: Path) -> None:
    site_dir.mkdir(parents=True, exist_ok=True)
    (site_dir / "sitecustomize.py").write_text(_SITECUSTOMIZE)


# --------------------------------------------------------------------------
# Env builder + subprocess runner
# --------------------------------------------------------------------------

def _make_env(home: Path, bin_dir: Path, site_dir: Path,
              call_log: Path, capture: Path, extra: dict[str, str]) -> dict:
    env = os.environ.copy()
    # Strip anything inherited from the developer's shell so each test
    # explicitly opts in to every credential it cares about.
    for k in ("ANTHROPIC_API_KEY", "CLAUDE_CODE_OAUTH_TOKEN",
              "CODEX_API_KEY", "OPENAI_API_KEY",
              "CLAUDE_CONFIG_DIR", "CODEX_HOME"):
        env.pop(k, None)
    env["TENACIOUS_HOME"] = str(home)
    env["PATH"] = f"{bin_dir}:{env.get('PATH', '')}"
    pp = str(site_dir)
    env["PYTHONPATH"] = (
        f"{pp}{os.pathsep}{env['PYTHONPATH']}" if env.get("PYTHONPATH") else pp
    )
    env["AUTHBANK_CALL_LOG"] = str(call_log)
    env["SHIM_CAPTURE_PATH"] = str(capture)
    env.update(extra)
    return env


def _run(env: dict, args: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, "-m", "tenacious", *args],
        cwd=str(_PROJECT_ROOT), env=env,
        capture_output=True, text=True, timeout=90,
    )


def _latest_run(home: Path) -> Path | None:
    runs = home / "runs"
    if not runs.is_dir():
        return None
    entries = sorted(p for p in runs.iterdir() if p.is_dir())
    return entries[-1] if entries else None


def _read_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    out: list[dict] = []
    for line in path.read_text().splitlines():
        line = line.strip()
        if line:
            out.append(json.loads(line))
    return out


# --------------------------------------------------------------------------
# Common per-test setup helper
# --------------------------------------------------------------------------

class _Ctx:
    """Per-scenario filesystem + subprocess result holder."""

    def __init__(self, d: Path):
        self.d = d
        self.home = d / "home"
        self.bin_dir = d / "bin"
        self.site_dir = d / "site"
        self.call_log = d / "authbank-calls.jsonl"
        self.capture = d / "shim-capture.jsonl"
        self.home.mkdir()
        _write_sitecustomize(self.site_dir)
        self.rc: int | None = None
        self.stdout: str = ""
        self.stderr: str = ""
        self.run_root: Path | None = None

    def env(self, extra: dict[str, str]) -> dict:
        return _make_env(self.home, self.bin_dir, self.site_dir,
                         self.call_log, self.capture, extra)

    def go(self, args: list[str], extra: dict[str, str]) -> None:
        r = _run(self.env(extra), args)
        self.rc = r.returncode
        self.stdout = r.stdout
        self.stderr = r.stderr
        self.run_root = _latest_run(self.home)

    def captures(self) -> list[dict]:
        return _read_jsonl(self.capture)

    def calls(self) -> list[dict]:
        return _read_jsonl(self.call_log)

    def run_log_text(self) -> str:
        if self.run_root is None:
            return ""
        log = self.run_root / "run.log"
        return log.read_text() if log.exists() else ""

    def cleanup(self) -> None:
        shutil.rmtree(self.d, ignore_errors=True)


def _setup() -> _Ctx:
    return _Ctx(Path(tempfile.mkdtemp(prefix="tnc-costly-")))


# --------------------------------------------------------------------------
# Scenarios
# --------------------------------------------------------------------------

def s_anthropic_flag_passes_api_key_strips_oauth_token() -> None:
    ctx = _setup()
    try:
        _write_shim(ctx.bin_dir, "claude")
        _populate_anthropic(ctx.home, token="BANK-TOKEN")
        ctx.go(
            [str(_REAL_HELLO_CLAUDE), "--costly-use-anthropic-api-key"],
            extra={
                "ANTHROPIC_API_KEY": "test-anthropic-key",
                "CLAUDE_CODE_OAUTH_TOKEN": "should-be-stripped",
            },
        )
        assert ctx.rc == 0, (ctx.rc, ctx.stderr, ctx.stdout)
        caps = ctx.captures()
        assert caps, ("no shim invocations", ctx.stderr)
        for cap in caps:
            env = cap["env"]
            assert env.get("ANTHROPIC_API_KEY") == "test-anthropic-key", env
            assert env.get("CLAUDE_CODE_OAUTH_TOKEN") is None, env
            assert env.get("ANTHROPIC_API_KEY") != "BANK-TOKEN", env
        # Bank was never consulted for anthropic.
        anth_calls = [c for c in ctx.calls() if c["provider"] == "anthropic"]
        assert anth_calls == [], anth_calls
        # Run-start banner appears in run.log.
        log = ctx.run_log_text()
        assert "[API-KEY MODE: anthropic — billed per token]" in log, log
    finally:
        ctx.cleanup()


def s_anthropic_flag_works_with_empty_bank() -> None:
    ctx = _setup()
    try:
        _write_shim(ctx.bin_dir, "claude")
        # NOTE: no _populate_anthropic — auth-bank/anthropic/ does not exist.
        ctx.go(
            [str(_REAL_HELLO_CLAUDE), "--costly-use-anthropic-api-key"],
            extra={"ANTHROPIC_API_KEY": "test-anthropic-key"},
        )
        assert ctx.rc == 0, (ctx.rc, ctx.stderr, ctx.stdout)
        caps = ctx.captures()
        assert caps, "no shim invocations"
        for cap in caps:
            assert cap["env"].get("ANTHROPIC_API_KEY") == "test-anthropic-key"
        # Zero calls to pick_account / lease for provider=anthropic.
        anth_calls = [c for c in ctx.calls() if c["provider"] == "anthropic"]
        assert anth_calls == [], anth_calls
        # No anthropic dir was created in the bank.
        anth_dir = ctx.home / "auth-bank" / "anthropic"
        assert not anth_dir.exists(), list(anth_dir.rglob("*")) if anth_dir.exists() else None
    finally:
        ctx.cleanup()


def s_anthropic_flag_errors_when_env_missing() -> None:
    ctx = _setup()
    try:
        _write_shim(ctx.bin_dir, "claude")
        _populate_anthropic(ctx.home, token="BANK-TOKEN")
        ctx.go(
            [str(_REAL_HELLO_CLAUDE), "--costly-use-anthropic-api-key"],
            extra={},  # ANTHROPIC_API_KEY intentionally unset
        )
        assert ctx.rc == 2, (ctx.rc, ctx.stderr, ctx.stdout)
        assert "requires ANTHROPIC_API_KEY" in ctx.stderr, ctx.stderr
        assert ctx.captures() == [], ctx.captures()
        assert ctx.calls() == [], ctx.calls()
        assert ctx.run_root is None, ctx.run_root
    finally:
        ctx.cleanup()


def _codex_flag_passes_api_key_variant(env_extra: dict[str, str],
                                       expected_key: str) -> None:
    ctx = _setup()
    try:
        _write_shim(ctx.bin_dir, "codex")
        slot = _populate_openai(ctx.home)
        slot_before = slot.read_text()
        ctx.go(
            [str(_REAL_HELLO_CODEX), "--costly-use-codex-api-key"],
            extra=env_extra,
        )
        assert ctx.rc == 0, (env_extra, ctx.rc, ctx.stderr, ctx.stdout)
        caps = ctx.captures()
        assert caps, "no shim invocations"
        for cap in caps:
            env = cap["env"]
            assert env.get("CODEX_API_KEY") == expected_key, (env_extra, env)
            assert env.get("OPENAI_API_KEY") == expected_key, (env_extra, env)
            assert cap.get("auth_json_exists") is False, cap
        # No profile auth.json materialized anywhere under the run dir.
        assert ctx.run_root is not None
        auths = list((ctx.run_root / "profiles").rglob("auth.json"))
        assert auths == [], auths
        # Bank slot byte-for-byte unchanged (no writeback).
        assert slot.read_text() == slot_before
        # Zero lease/pick_account calls for openai.
        oai_calls = [c for c in ctx.calls() if c["provider"] == "openai"]
        assert oai_calls == [], oai_calls
        # Banner present.
        assert "[API-KEY MODE: codex — billed per token]" in ctx.run_log_text()
    finally:
        ctx.cleanup()


def s_codex_flag_passes_api_key_both_envs() -> None:
    # Variant A: only OPENAI_API_KEY set — read it, write both.
    _codex_flag_passes_api_key_variant(
        env_extra={"OPENAI_API_KEY": "sk-openai-test"},
        expected_key="sk-openai-test",
    )
    # Variant B: both set — CODEX_API_KEY wins, BOTH child env vars equal it.
    _codex_flag_passes_api_key_variant(
        env_extra={"CODEX_API_KEY": "primary",
                   "OPENAI_API_KEY": "secondary"},
        expected_key="primary",
    )


def s_codex_flag_works_with_empty_bank() -> None:
    ctx = _setup()
    try:
        _write_shim(ctx.bin_dir, "codex")
        # No _populate_openai — auth-bank/openai/ does not exist.
        ctx.go(
            [str(_REAL_HELLO_CODEX), "--costly-use-codex-api-key"],
            extra={"OPENAI_API_KEY": "sk-openai-test"},
        )
        assert ctx.rc == 0, (ctx.rc, ctx.stderr, ctx.stdout)
        caps = ctx.captures()
        assert caps
        for cap in caps:
            env = cap["env"]
            assert env.get("CODEX_API_KEY") == "sk-openai-test", env
            assert env.get("OPENAI_API_KEY") == "sk-openai-test", env
        # Zero openai bank calls.
        oai_calls = [c for c in ctx.calls() if c["provider"] == "openai"]
        assert oai_calls == [], oai_calls
        # No openai dir was created in the bank.
        oai_dir = ctx.home / "auth-bank" / "openai"
        assert not oai_dir.exists()
    finally:
        ctx.cleanup()


def s_codex_flag_errors_when_env_missing() -> None:
    ctx = _setup()
    try:
        _write_shim(ctx.bin_dir, "codex")
        _populate_openai(ctx.home)
        ctx.go(
            [str(_REAL_HELLO_CODEX), "--costly-use-codex-api-key"],
            extra={},
        )
        assert ctx.rc == 2, (ctx.rc, ctx.stderr, ctx.stdout)
        assert "requires CODEX_API_KEY or OPENAI_API_KEY" in ctx.stderr, ctx.stderr
        assert ctx.captures() == [], ctx.captures()
        assert ctx.calls() == [], ctx.calls()
        assert ctx.run_root is None, ctx.run_root
    finally:
        ctx.cleanup()


def s_anthropic_lease_never_creates_lockfile_off_path() -> None:
    ctx = _setup()
    try:
        _write_shim(ctx.bin_dir, "claude")
        _populate_anthropic(ctx.home, token="BANK-TOKEN")
        ctx.go([str(_REAL_HELLO_CLAUDE)], extra={})
        assert ctx.rc == 0, (ctx.rc, ctx.stderr, ctx.stdout)
        bank_root = ctx.home / "auth-bank" / "anthropic"
        locks = list(bank_root.rglob("*.lock"))
        assert locks == [], locks
        # And specifically the named one we'd expect under the old behavior:
        assert not (bank_root / "fake" / "slot.txt.lock").exists()
    finally:
        ctx.cleanup()


def s_codex_lease_still_creates_lockfile_off_path() -> None:
    ctx = _setup()
    try:
        _write_shim(ctx.bin_dir, "codex")
        _populate_openai(ctx.home)
        ctx.go([str(_REAL_HELLO_CODEX)], extra={})
        assert ctx.rc == 0, (ctx.rc, ctx.stderr, ctx.stdout)
        lock = ctx.home / "auth-bank" / "openai" / "fake" / "slot.json.lock"
        assert lock.is_file(), list(
            (ctx.home / "auth-bank" / "openai" / "fake").iterdir())
    finally:
        ctx.cleanup()


def s_off_path_equivalence_smoke() -> None:
    # Anthropic side: no flag -> CLAUDE_CODE_OAUTH_TOKEN from bank.
    ctx_a = _setup()
    try:
        _write_shim(ctx_a.bin_dir, "claude")
        _populate_anthropic(ctx_a.home, token="BANK-TOKEN")
        ctx_a.go([str(_REAL_HELLO_CLAUDE)], extra={})
        assert ctx_a.rc == 0, (ctx_a.rc, ctx_a.stderr, ctx_a.stdout)
        caps_a = ctx_a.captures()
        assert caps_a
        for cap in caps_a:
            env = cap["env"]
            assert env.get("CLAUDE_CODE_OAUTH_TOKEN") == "BANK-TOKEN", env
            assert "ANTHROPIC_API_KEY" not in env, env
        log_a = ctx_a.run_log_text()
        assert "[API-KEY MODE:" not in log_a, log_a
        accounts_a = json.loads((ctx_a.run_root / "accounts.json").read_text())
        assert accounts_a.get("anthropic") == "fake", accounts_a
    finally:
        ctx_a.cleanup()

    # Codex side: no flag -> auth.json materialized + writeback round-trip.
    ctx_c = _setup()
    try:
        _write_shim(ctx_c.bin_dir, "codex")
        slot = _populate_openai(ctx_c.home, content='{"BANK":"json"}')
        ctx_c.go([str(_REAL_HELLO_CODEX)], extra={})
        assert ctx_c.rc == 0, (ctx_c.rc, ctx_c.stderr, ctx_c.stdout)
        caps_c = ctx_c.captures()
        assert caps_c
        for cap in caps_c:
            assert cap.get("auth_json_exists") is True, cap
        # Writeback round-trip: bank slot unchanged after the shim ran
        # (shim never mutates auth.json, but the writeback path executed).
        assert slot.read_text() == '{"BANK":"json"}'
        log_c = ctx_c.run_log_text()
        assert "[API-KEY MODE:" not in log_c, log_c
        accounts_c = json.loads((ctx_c.run_root / "accounts.json").read_text())
        assert accounts_c.get("openai") == "fake", accounts_c
    finally:
        ctx_c.cleanup()


SCENARIOS = [
    ("anthropic_flag_passes_api_key_strips_oauth_token",
     s_anthropic_flag_passes_api_key_strips_oauth_token),
    ("anthropic_flag_works_with_empty_bank",
     s_anthropic_flag_works_with_empty_bank),
    ("anthropic_flag_errors_when_env_missing",
     s_anthropic_flag_errors_when_env_missing),
    ("codex_flag_passes_api_key_both_envs",
     s_codex_flag_passes_api_key_both_envs),
    ("codex_flag_works_with_empty_bank",
     s_codex_flag_works_with_empty_bank),
    ("codex_flag_errors_when_env_missing",
     s_codex_flag_errors_when_env_missing),
    ("anthropic_lease_never_creates_lockfile_off_path",
     s_anthropic_lease_never_creates_lockfile_off_path),
    ("codex_lease_still_creates_lockfile_off_path",
     s_codex_lease_still_creates_lockfile_off_path),
    ("off_path_equivalence_smoke", s_off_path_equivalence_smoke),
]


def main() -> int:
    for name, fn in SCENARIOS:
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            print(f"FAIL {name}: {e}")
            traceback.print_exc()
            return 1
        print(f"PASS {name}")
    print(f"ALL PASS ({len(SCENARIOS)} scenarios)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
