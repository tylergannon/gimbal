"""Audit test: every non-trivial step of every round-style workflow
references `{goal}` in its prompt body.

For each shipped round-style workflow file (6step, iterative,
6step-goal-only — YAML), render each step's prompt with a known
sentinel goal value via `step.prompt.format(...)` and assert the
sentinel appears in the rendered text. The `health_monitor` step and
steps with `prompt is None` (composite parents) are intentionally
skipped.

Stdlib-only. YAML scenarios skip with PASS-N/A when PyYAML is missing.

Run from the project root:

    .venv/bin/python tests/test_goal_in_every_step.py
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import tenacious.orchestrator as o  # noqa: E402


FAILS: list[str] = []
PASSES = 0
SENTINEL = "ROUND-3-AUDIT-GOAL-SENTINEL-X9"


def _ok(name: str) -> None:
    global PASSES
    PASSES += 1
    print(f"PASS {name}")


def _fail(name: str, detail: str) -> None:
    FAILS.append(f"{name}: {detail}")
    print(f"FAIL {name}: {detail}")


# Shipped round-style workflow files: each must thread `{goal}` into
# every non-health-monitor step's prompt body.
ROUND_STYLE_YAML = [
    "6step.yaml",
    "iterative.yaml",
    "6step-goal-only.yaml",
]


def _check_workflow(name: str, path: Path) -> None:
    wf = o.Workflow.load(path, goal_override=SENTINEL)
    for slug, step in wf.steps.items():
        if slug == "health_monitor":
            continue
        if step.prompt is None:
            continue  # composite parent
        rendered = step.prompt.format(
            goal=wf.goal, run_slug="x", run_root="/r",
            assets_dir="/a", outcome_path="/o", step_dir="/s",
            project_dir="/p")
        if SENTINEL not in rendered:
            _fail(name, f"{path.name}: step {slug!r} dropped goal")
            return
    _ok(name)


def main() -> int:
    try:
        import yaml  # noqa: F401
        yaml_available = True
    except ImportError:
        yaml_available = False
    for fname in ROUND_STYLE_YAML:
        nm = f"goal-in-every-step::{fname}"
        if not yaml_available:
            print(f"PASS {nm}-skipped (PyYAML missing)")
            continue
        _check_workflow(nm, Path(_PROJECT_ROOT) / "workflows" / fname)

    if FAILS:
        print(f"\nFAILED ({len(FAILS)}):")
        for f in FAILS:
            print(f"  {f}")
        return 1
    print(f"\nALL PASS ({PASSES})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
