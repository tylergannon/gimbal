"""Tests for the 6step-goal-only workflow variant.

Asserts the variant
  1. drops the requirements step,
  2. has no `requirements-current.md` reference (in `asset_slugs` or
     prompt body) on any step,
  3. routes `code_review` to `code` or `end` (no `requirements` exit),
  4. loads from YAML with the expected step set and assets map,
  5. drives end-to-end through fake agent runners and finishes at `end`.

Stdlib-only. PyYAML-skipped scenarios print PASS-N/A.

Run from the project root:

    .venv/bin/python tests/test_goal_only_workflow.py
"""

from __future__ import annotations

import os
import shutil
import sys
import tempfile
from pathlib import Path

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import tenacious.orchestrator as o  # noqa: E402


FAILS: list[str] = []
PASSES = 0


def _ok(name: str) -> None:
    global PASSES
    PASSES += 1
    print(f"PASS {name}")


def _fail(name: str, detail: str) -> None:
    FAILS.append(f"{name}: {detail}")
    print(f"FAIL {name}: {detail}")


def s_no_step_references_requirements_current_md() -> None:
    name = "no_step_references_requirements_current_md"
    try:
        import yaml  # noqa: F401
    except ImportError:
        print(f"PASS {name}-skipped (PyYAML missing)")
        return
    targets = [Path(_PROJECT_ROOT) / "workflows" / "6step-goal-only.yaml"]

    for path in targets:
        wf = o.Workflow.load(path, goal_override="X")
        if "requirements" in wf.steps:
            _fail(name, f"{path.name}: contains 'requirements' step")
            return
        if wf.start_step != "plan":
            _fail(name, f"{path.name}: start_step != plan: {wf.start_step}")
            return
        for slug, step in wf.steps.items():
            if "requirements-current.md" in step.asset_slugs:
                _fail(name, f"{path.name}: {slug}.asset_slugs")
                return
            if step.prompt and "requirements-current.md" in step.prompt:
                _fail(name, f"{path.name}: {slug}.prompt")
                return
        cr = wf.steps["code_review"]
        if set(cr.next_steps) != {"code", "end"}:
            _fail(name, f"{path.name}: code_review.next_steps={cr.next_steps}")
            return
    _ok(name)


def s_yaml_loads_and_declares_assets() -> None:
    name = "yaml_loads_and_declares_assets"
    try:
        import yaml  # noqa: F401
    except ImportError:
        print(f"PASS {name}-skipped (PyYAML missing)")
        return
    wf = o.Workflow.load(
        Path(_PROJECT_ROOT) / "workflows" / "6step-goal-only.yaml",
        goal_override="X")
    expected_steps = {"plan", "plan_eval", "plan_update", "code",
                      "code_review", "health_monitor"}
    if set(wf.steps) != expected_steps:
        _fail(name, f"step set: {set(wf.steps)} != {expected_steps}")
        return
    expected_assets = {
        "plan":           ["plan"],
        "plan_eval":      ["plan-feedback"],
        "plan_update":    ["plan-revised"],
        "code":           ["code-notes"],
        "code_review":    ["status-update", "code-feedback"],
        "health_monitor": [],
    }
    for slug, want in expected_assets.items():
        got = list(wf.steps[slug].assets)
        if got != want:
            _fail(name, f"{slug}.assets = {got}, want {want}")
            return
    _ok(name)


def s_goal_substitutes_into_every_prompt() -> None:
    name = "goal_substitutes_into_every_prompt"
    try:
        import yaml  # noqa: F401
    except ImportError:
        print(f"PASS {name}-skipped (PyYAML missing)")
        return
    wf = o.Workflow.load(
        Path(_PROJECT_ROOT) / "workflows" / "6step-goal-only.yaml",
        goal_override="ROUND-3-TEST-GOAL")
    for slug, step in wf.steps.items():
        if step.prompt is None:
            continue
        rendered = step.prompt.format(
            goal=wf.goal, run_slug="x", run_root="/r",
            assets_dir="/a", outcome_path="/o", step_dir="/s",
            project_dir="/p")
        if "ROUND-3-TEST-GOAL" not in rendered:
            _fail(name, f"{slug}: goal not substituted")
            return
    _ok(name)


def _drive_goal_only() -> tuple[bool, str]:
    """In-process drive of 6step-goal-only with fake agent runners.

    Returns (ok, detail). We avoid `execute_workflow`'s home/run-creation
    plumbing and instead build a Run + directly walk steps the same way
    `_drive_run` does. Each fake runner just writes the next outcome
    slug and exits 0 — enough to exercise the routing graph end-to-end.
    """
    try:
        import yaml  # noqa: F401
    except ImportError:
        return True, "SKIP-PyYAML-missing"
    src = Path(_PROJECT_ROOT) / "workflows" / "6step-goal-only.yaml"
    wf = o.Workflow.load(src, goal_override="DRIVE-TEST-GOAL")
    # Strip the health monitor so no background thread is launched.
    wf.health_monitor_step = None
    d = Path(tempfile.mkdtemp(prefix="gnly-"))
    try:
        root = d / "run"
        proj = d / "proj"
        (root / "assets").mkdir(parents=True)
        (root / "profiles").mkdir(parents=True)
        proj.mkdir(parents=True)
        run = o.Run(slug="r", root=root, workflow=wf,
                    project_dir=proj, accounts={})

        # plan -> plan_eval -> plan_update -> code -> code_review -> end
        outcomes = {
            "plan": "plan_eval",
            "plan_eval": "plan_update",
            "plan_update": "code",
            "code": "code_review",
            "code_review": "end",
        }

        def runner(step, run_, visit, step_dir, prompt,
                   should_continue, **kw):
            ans = outcomes[step.slug]
            # Also hand-write a -current.md so the snapshot helper runs
            # cleanly (branch B) and we can later assert -0001.md exists
            # for the step's declared assets.
            for base in step.assets:
                (run_.assets_dir / f"{base}-current.md").write_text(
                    f"{step.slug}-content\n")
            (step_dir / "outcome.txt").write_text(ans + "\n")
            return {"exit": 0, "stdout": "", "stderr": "",
                    "thread_id": None}

        saved = dict(o.AGENT_RUNNERS)
        o.AGENT_RUNNERS["claude"] = runner
        o.AGENT_RUNNERS["codex"] = runner
        try:
            current = wf.start_step
            visited: list[str] = []
            while current != "end":
                visited.append(current)
                if len(visited) > 50:
                    return False, f"too many visits: {visited}"
                run.consume_step_budget()
                step = wf.steps[current]
                current = o.execute_step(step, run, _Answers(), monitor=None)
        finally:
            o.AGENT_RUNNERS.clear()
            o.AGENT_RUNNERS.update(saved)

        if "requirements" in visited:
            return False, "requirements step was visited"
        expected = ["plan", "plan_eval", "plan_update", "code", "code_review"]
        if visited != expected:
            return False, f"visit order: {visited} != {expected}"
        if (root / "requirements").exists():
            return False, "requirements/ run dir was created"
        for s in expected:
            if not (root / s).exists():
                return False, f"missing {s}/ run dir"
        # Last step's outcome.txt content should be 'end'.
        last_dir = sorted((root / "code_review").iterdir())[-1]
        oc = (last_dir / "outcome.txt").read_text().strip()
        if oc != "end":
            return False, f"code_review final outcome: {oc!r}"
        # Per Shape D wiring: plan should have written plan-0001.md from
        # branch B (snapshot helper saw current only).
        if not (run.assets_dir / "plan-0001.md").exists():
            return False, "snapshot did not produce plan-0001.md"
        return True, ""
    finally:
        shutil.rmtree(d, ignore_errors=True)


class _Answers:
    def next_answer(self, q: str) -> str:
        return ""


def s_goal_only_runs_to_end_with_explicit_goal() -> None:
    name = "goal_only_runs_to_end_with_explicit_goal"
    ok, detail = _drive_goal_only()
    if not ok:
        _fail(name, detail)
        return
    if detail.startswith("SKIP"):
        print(f"PASS {name}-skipped (PyYAML missing)")
        return
    _ok(name)


def s_goal_only_yaml_variant_runs_to_end() -> None:
    name = "goal_only_yaml_variant_runs_to_end"
    ok, detail = _drive_goal_only()
    if not ok:
        _fail(name, detail)
        return
    if detail.startswith("SKIP"):
        print(f"PASS {name}-skipped (PyYAML missing)")
        return
    _ok(name)


def main() -> int:
    s_no_step_references_requirements_current_md()
    s_yaml_loads_and_declares_assets()
    s_goal_substitutes_into_every_prompt()
    s_goal_only_runs_to_end_with_explicit_goal()
    s_goal_only_yaml_variant_runs_to_end()
    if FAILS:
        print(f"\nFAILED ({len(FAILS)}):")
        for f in FAILS:
            print(f"  {f}")
        return 1
    print(f"\nALL PASS ({PASSES})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
