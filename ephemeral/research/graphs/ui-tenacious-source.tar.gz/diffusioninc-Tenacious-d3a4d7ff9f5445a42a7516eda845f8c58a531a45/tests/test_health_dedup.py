"""Bug 1 (Round 2): health-check stdout de-duplication.

Stdlib only. Creates its own temp dirs. Drives the *real* HealthMonitor
tick path in-process with a fake agent and proves:

  1. a single health tick emits its banner + report paths to stdout
     EXACTLY ONCE (not 2x / 4x), nothing to stderr, and run.log still
     records the tick once;
  2. the Round-1 during-question queuing still works: while paused the
     output is buffered (absent from stdout/stderr) yet written to
     run.log in real time, and on resume it replays to stdout exactly
     once in emission order with no stderr copy.

Run from the project root:

    .venv/bin/python tests/test_health_dedup.py

Prints `PASS <scenario>` per scenario then `ALL PASS (<n>)`; exits 0 if
all pass, 1 with `FAIL <scenario>: <detail>` otherwise.
"""

from __future__ import annotations

import io
import os
import re
import shutil
import sys
import tempfile
import traceback
from contextlib import contextmanager
from pathlib import Path

# A health line whose [timestamp] prefix is doubled, e.g.
# "[2026-05-18T23:12:05] [2026-05-18T23:12:05] ===== SESSION HEALTH ...".
_DOUBLED_TS_RE = re.compile(
    r"\[\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\] "
    r"\[\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\] =====")

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import tenacious.orchestrator as o  # noqa: E402


class Patcher:
    def __init__(self):
        self._saved = []

    def set(self, obj, attr, value):
        self._saved.append((obj, attr, getattr(obj, attr)))
        setattr(obj, attr, value)

    def undo(self):
        for obj, attr, value in reversed(self._saved):
            setattr(obj, attr, value)
        self._saved.clear()


@contextmanager
def temp_run():
    d = tempfile.mkdtemp(prefix="tnc-dedup-")
    try:
        root = Path(d) / "run"
        proj = Path(d) / "proj"
        (root / "assets").mkdir(parents=True)
        proj.mkdir(parents=True)
        wf = o.Workflow(goal="g", start_step="s", steps={})
        run = o.Run(slug="dedup", root=root, workflow=wf, project_dir=proj,
                    accounts={})
        yield run, Path(d)
    finally:
        shutil.rmtree(d, ignore_errors=True)


def hm_step():
    return o.Step(slug="health_monitor", agent="fake",
                  prompt="m {assets_dir} {outcome_path}",
                  next_steps=["monitor_done"], context="empty",
                  questions=False)


def report_paths_runner():
    """Fake monitor agent: writes a quick body with ONE `## Report paths`
    section listing both absolute asset paths exactly once (mirrors the
    real health_monitor prompt's mandatory section)."""
    def runner(step, run, visit, step_dir, prompt, should_continue=False):
        ad = run.assets_dir
        deep = ad / "health-deepdive-current.md"
        quick = ad / "health-quick-current.md"
        deep.write_text(f"DEEP tick {visit}\n")
        quick.write_text(
            f"quick status {visit}\n"
            f"## Report paths\n{deep}\n{quick}\n")
        (step_dir / "outcome.txt").write_text("monitor_done\n")
        return {"exit": 0, "stdout": "", "stderr": ""}
    return runner


def s_single_tick_one_stdout_block():
    p = Patcher()
    try:
        p.set(o, "AGENT_RUNNERS", {"fake": report_paths_runner()})
        with temp_run() as (run, _d):
            mon = o.HealthMonitor(run, hm_step(), interval_seconds=1e9)
            ad = run.assets_dir
            deep_path = str(ad / "health-deepdive-current.md")
            quick_path = str(ad / "health-quick-current.md")
            real_out, real_err = sys.stdout, sys.stderr
            cap_out, cap_err = io.StringIO(), io.StringIO()
            sys.stdout, sys.stderr = cap_out, cap_err
            try:
                mon._run_tick()
            finally:
                sys.stdout, sys.stderr = real_out, real_err
            out = cap_out.getvalue()
            err = cap_err.getvalue()
            assert out.count("===== SESSION HEALTH UPDATE") == 1, (
                f"banner header not exactly once in stdout:\n{out}")
            assert out.count("===== END SESSION HEALTH UPDATE") == 1, (
                f"banner footer not exactly once in stdout:\n{out}")
            assert out.count(deep_path) == 1, (
                f"deep-dive path not exactly once in stdout:\n{out}")
            assert out.count(quick_path) == 1, (
                f"quick path not exactly once in stdout:\n{out}")
            assert "SESSION HEALTH UPDATE" not in err, (
                f"health banner duplicated onto stderr:\n{err}")
            log_text = (run.root / "run.log").read_text()
            assert log_text.count("===== SESSION HEALTH UPDATE") == 1, (
                f"run.log did not record the tick exactly once:\n{log_text}")
            assert not _DOUBLED_TS_RE.search(out), (
                f"doubled [ts] [ts] prefix on a health line in stdout:\n{out}")
            assert not _DOUBLED_TS_RE.search(log_text), (
                f"doubled [ts] [ts] prefix on a health line in run.log:\n"
                f"{log_text}")
    finally:
        p.undo()


def s_queue_replays_once_in_order_no_stderr():
    p = Patcher()
    try:
        p.set(o, "AGENT_RUNNERS", {"fake": report_paths_runner()})
        with temp_run() as (run, _d):
            mon = o.HealthMonitor(run, hm_step(), interval_seconds=1e9)
            real_out, real_err = sys.stdout, sys.stderr

            mon.begin_pause()  # suspends terminal output
            cap_out, cap_err = io.StringIO(), io.StringIO()
            sys.stdout, sys.stderr = cap_out, cap_err
            try:
                mon._run_tick()
                run.log_monitor("MARK-2")
                paused_out = cap_out.getvalue()
                paused_err = cap_err.getvalue()
            finally:
                sys.stdout, sys.stderr = real_out, real_err

            assert "SESSION HEALTH UPDATE" not in paused_out, (
                f"banner leaked to stdout while paused: {paused_out!r}")
            assert "SESSION HEALTH UPDATE" not in paused_err, (
                f"banner leaked to stderr while paused: {paused_err!r}")
            assert "MARK-2" not in paused_out, (
                f"MARK-2 leaked to stdout while paused: {paused_out!r}")

            log_text = (run.root / "run.log").read_text()
            assert "===== SESSION HEALTH UPDATE" in log_text, (
                f"tick not written to run.log in real time:\n{log_text}")
            assert "MARK-2" in log_text, (
                "MARK-2 not written to run.log file in real time")

            cap_out2, cap_err2 = io.StringIO(), io.StringIO()
            sys.stdout, sys.stderr = cap_out2, cap_err2
            try:
                mon.end_pause()
            finally:
                sys.stdout, sys.stderr = real_out, real_err
            replay_out = cap_out2.getvalue()
            replay_err = cap_err2.getvalue()

            assert replay_out.count("===== SESSION HEALTH UPDATE") == 1, (
                f"banner not replayed exactly once to stdout: {replay_out!r}")
            assert "MARK-2" in replay_out, (
                f"MARK-2 not replayed to stdout on resume: {replay_out!r}")
            i_banner = replay_out.index("SESSION HEALTH UPDATE")
            i_mark = replay_out.index("MARK-2")
            assert i_banner < i_mark, (
                f"replay out of emission order: banner@{i_banner} "
                f"after mark@{i_mark}")
            assert "SESSION HEALTH UPDATE" not in replay_err, (
                f"stderr received a health banner copy: {replay_err!r}")
    finally:
        p.undo()


SCENARIOS = [
    ("single_tick_one_stdout_block", s_single_tick_one_stdout_block),
    ("queue_replays_once_in_order_no_stderr",
     s_queue_replays_once_in_order_no_stderr),
]


def main() -> int:
    for name, fn in SCENARIOS:
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            print(f"FAIL {name}: {e}")
            traceback.print_exc()
            return 1
        print(f"PASS {name}")
    print(f"ALL PASS ({len(SCENARIOS)})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
