"""Verification harness for the out-of-band session health monitor (Part A).

Stdlib only. Creates its own temp dirs. Does not need the auth bank, real
`codex`/`claude` binaries, or network. Drives the *real* `HealthMonitor`
(timer loop, pause-once-per-episode, per-tick history, report-only,
stdout+stderr surfacing) and the real `Workflow.load` / `execute_workflow`
with a fake "agent" runner.

Run from the project root:

    .venv/bin/python tests/test_health_monitor.py

Prints `PASS <scenario>` per scenario, then `ALL PASS (<n> scenarios)`.
Exits 0 if all pass; 1 with `FAIL <scenario>: <detail>` on first failure.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import re
import traceback
from contextlib import contextmanager
from pathlib import Path

# A health line whose [timestamp] prefix is doubled, e.g.
# "[2026-05-18T23:12:05] [2026-05-18T23:12:05] ===== SESSION HEALTH ...".
_DOUBLED_TS_RE = re.compile(
    r"\[\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\] "
    r"\[\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\] =====")

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import tenacious.orchestrator as o  # noqa: E402

# In-process acceleration only. The shipped default (600.0) and that it is
# NOT env-configurable is proven by `default_interval_constant` in a clean
# subprocess.
o.HEALTH_MONITOR_POLL_SLICE_SECONDS = 0.02


# ----- helpers ---------------------------------------------------------------

class Patcher:
    def __init__(self):
        self._saved = []

    def set(self, obj, attr, value):
        self._saved.append((obj, attr, getattr(obj, attr)))
        setattr(obj, attr, value)

    def undo(self):
        for obj, attr, value in reversed(self._saved):
            setattr(obj, attr, value)
        self._saved.clear()


@contextmanager
def temp_run():
    d = tempfile.mkdtemp(prefix="tnc-hm-")
    try:
        root = Path(d) / "run"
        proj = Path(d) / "proj"
        (root / "assets").mkdir(parents=True)
        proj.mkdir(parents=True)
        wf = o.Workflow(goal="g", start_step="s", steps={})
        run = o.Run(slug="hmrun", root=root, workflow=wf, project_dir=proj,
                    accounts={})
        yield run, Path(d)
    finally:
        shutil.rmtree(d, ignore_errors=True)


def hm_step(agent="fake"):
    return o.Step(slug="health_monitor", agent=agent,
                  prompt=("monitor {run_slug} root={run_root} "
                          "assets={assets_dir} out={outcome_path}"),
                  next_steps=["monitor_done"], context="empty",
                  questions=False)


def make_monitor_runner(calls: list, produce_ticks=None):
    """Fake agent for the health_monitor step.

    Records each tick number in `calls`. Writes the two -current.md assets
    (so a tick "produces") only when `produce_ticks` is None (always) or the
    tick is in it; otherwise it leaves the assets untouched (a deliberately
    non-producing tick). Always writes outcome.txt='monitor_done'.
    """
    def runner(step, run, visit, step_dir, prompt, should_continue):
        calls.append(visit)
        produce = produce_ticks is None or visit in produce_ticks
        if produce:
            ad = run.assets_dir
            deep = ad / "health-deepdive-current.md"
            quick = ad / "health-quick-current.md"
            deep.write_text(f"DEEP tick {visit}\nper-step status...\n")
            quick.write_text(
                f"QUICK status tick {visit}\n"
                f"deep-dive: {deep}\nquick: {quick}\n")
        (step_dir / "outcome.txt").write_text("monitor_done\n")
        return {"exit": 0, "stdout": f"tick {visit}", "stderr": ""}
    return runner


def _ts_copies(assets_dir: Path, base: str) -> list[Path]:
    return sorted(assets_dir.glob(f"{base}-*-t*.md"))


# ----- scenarios -------------------------------------------------------------

def s_timer_cadence():
    """CV-4: timer fires >=2 producing ticks; per-tick timestamped history
    is exact (one copy per producing tick, none for a non-producing tick);
    *-current.md is always the latest agent output; the quick-update text
    contains both *-current.md absolute paths."""
    p = Patcher()
    try:
        # Part 1: real timer cadence (always-producing).
        calls: list = []
        p.set(o, "AGENT_RUNNERS", {"fake": make_monitor_runner(calls)})
        with temp_run() as (run, _d):
            mon = o.HealthMonitor(run, hm_step(), interval_seconds=0.05)
            mon.start()
            t0 = time.time()
            while len(calls) < 3 and time.time() - t0 < 5.0:
                time.sleep(0.02)
            mon.stop()
            assert len(calls) >= 2, f"timer fired <2 ticks: {calls}"
            ad = run.assets_dir
            nticks = len(calls)
            dd = _ts_copies(ad, "health-deepdive")
            qq = _ts_copies(ad, "health-quick")
            assert len(dd) == nticks, (
                f"deepdive history {len(dd)} != ticks {nticks}")
            assert len(qq) == nticks, (
                f"quick history {len(qq)} != ticks {nticks}")
            last = max(calls)
            cur_deep = (ad / "health-deepdive-current.md").read_text()
            assert f"tick {last}" in cur_deep, (
                f"current deepdive is not the latest tick: {cur_deep!r}")
            cur_quick = (ad / "health-quick-current.md").read_text()
            assert str(ad / "health-deepdive-current.md") in cur_quick \
                and str(ad / "health-quick-current.md") in cur_quick, (
                "quick-update missing one/both absolute asset paths")
        p.undo()

        # Part 2: deterministic per-tick history with a non-producing tick.
        p2 = Patcher()
        try:
            calls2: list = []
            p2.set(o, "AGENT_RUNNERS",
                   {"fake": make_monitor_runner(calls2,
                                                produce_ticks={1, 2, 4})})
            with temp_run() as (run, _d):
                mon = o.HealthMonitor(run, hm_step(), interval_seconds=1e9)
                ad = run.assets_dir
                mon._run_tick()  # tick 1 (produces)
                assert len(_ts_copies(ad, "health-deepdive")) == 1
                assert len(_ts_copies(ad, "health-quick")) == 1
                mon._run_tick()  # tick 2 (produces)
                assert len(_ts_copies(ad, "health-deepdive")) == 2
                assert len(_ts_copies(ad, "health-quick")) == 2
                mon._run_tick()  # tick 3 (NON-producing)
                assert len(_ts_copies(ad, "health-deepdive")) == 2, (
                    "non-producing tick wrongly archived a deepdive copy")
                assert len(_ts_copies(ad, "health-quick")) == 2, (
                    "non-producing tick wrongly archived a quick copy")
                mon._run_tick()  # tick 4 (produces)
                assert len(_ts_copies(ad, "health-deepdive")) == 3
                assert len(_ts_copies(ad, "health-quick")) == 3
                assert "tick 4" in (
                    ad / "health-deepdive-current.md").read_text()
                # every tick wrote its own visit dir + meta
                for k in (1, 2, 3, 4):
                    sd = run.step_dir("health_monitor", k)
                    assert (sd / "meta.json").exists(), f"no meta for tick {k}"
                assert calls2 == [1, 2, 3, 4], calls2
        finally:
            p2.undo()
    finally:
        p.undo()


def s_zero_ticks_while_paused():
    """Bug 1.B (Round 1): while paused on a pending question the monitor
    launches ZERO agents (never ticks during a pause). After the answer
    is submitted the timer still works (forcing _next_due=now yields
    exactly one tick); a second pause again yields zero ticks.

    Reproduces Bug 1.B: FAILS on pre-fix code, whose `_loop` ticked once
    per pending-question episode (`calls == [1]` while paused)."""
    p = Patcher()
    try:
        calls: list = []
        p.set(o, "AGENT_RUNNERS", {"fake": make_monitor_runner(calls)})
        with temp_run() as (run, _d):
            # Huge interval so a progressing tick never fires in-window.
            mon = o.HealthMonitor(run, hm_step(), interval_seconds=1e9)
            ep1 = mon.begin_pause()       # open episode before start()
            mon.start()
            mon._next_due = time.monotonic() + 1e9  # belt & suspenders
            # Many real poll slices elapse; ZERO ticks while paused.
            time.sleep(0.4)
            assert calls == [], (
                f"monitor ticked while paused (want none): {calls}")
            mon.end_pause()
            # Timer still works after the pause: force the next tick due.
            mon._next_due = time.monotonic()
            t0 = time.time()
            while not calls and time.time() - t0 < 3.0:
                time.sleep(0.02)
            assert calls == [1], (
                f"timer broken after pause (want exactly one tick): {calls}")
            mon._next_due = time.monotonic() + 1e9  # no more progressing
            ep2 = mon.begin_pause()       # a NEW pending-question episode
            assert ep2 != ep1, "new episode must get a fresh id"
            time.sleep(0.3)
            mon.stop()
            assert calls == [1], (
                f"monitor ticked during the second pause: {calls}")
    finally:
        p.undo()


def _baseline_workflow(d: Path, with_monitor: bool) -> Path:
    steps = {
        "work": {"agent": "fake", "prompt": "w", "next_steps": ["done"]},
        "done": {"agent": "fake", "prompt": "d", "next_steps": ["end"]},
        "health_monitor": {
            "agent": "fake", "prompt": "hm {assets_dir} {outcome_path}",
            "next_steps": ["monitor_done"], "context": "empty",
            "questions": False},
    }
    wf = {"goal": "g", "project_dir": str(d / "proj"),
          "start_step": "work", "steps": steps}
    if with_monitor:
        wf["health_monitor"] = {"step": "health_monitor",
                                "interval_seconds": 0.05}
    path = d / ("wf_mon.json" if with_monitor else "wf_plain.json")
    path.write_text(json.dumps(wf))
    return path


def _flow_runner():
    def runner(step, run, visit, step_dir, prompt, should_continue):
        if step.slug == "health_monitor":
            ad = run.assets_dir
            (ad / "health-deepdive-current.md").write_text(f"d{visit}")
            (ad / "health-quick-current.md").write_text(f"q{visit}")
            (step_dir / "outcome.txt").write_text("monitor_done\n")
            return {"exit": 0, "stdout": "", "stderr": ""}
        if step.slug == "work":
            time.sleep(0.3)  # long enough for the monitor to tick
            (step_dir / "outcome.txt").write_text("done\n")
        else:
            (step_dir / "outcome.txt").write_text("end\n")
        return {"exit": 0, "stdout": "", "stderr": ""}
    return runner


def _run_wf(d: Path, wf_path: Path):
    home = d / "home"
    home.mkdir(parents=True, exist_ok=True)
    prev = os.environ.get("TENACIOUS_HOME")
    os.environ["TENACIOUS_HOME"] = str(home)
    try:
        return o.execute_workflow(wf_path)
    finally:
        if prev is None:
            os.environ.pop("TENACIOUS_HOME", None)
        else:
            os.environ["TENACIOUS_HOME"] = prev


def s_report_only():
    """CV-6: with the monitor configured the workflow still reaches
    `workflow complete (end)`, flow visit_counts are identical to a run
    WITHOUT a monitor, and `monitor_done` is never a routed flow outcome."""
    p = Patcher()
    d = Path(tempfile.mkdtemp(prefix="tnc-hm-ro-"))
    try:
        p.set(o, "_magnetize_accounts", lambda slug, wf, **_kw: {})
        p.set(o, "AGENT_RUNNERS", {"fake": _flow_runner()})

        base = _run_wf(d, _baseline_workflow(d, with_monitor=False))
        mon = _run_wf(d, _baseline_workflow(d, with_monitor=True))

        for r, tag in ((base, "baseline"), (mon, "with-monitor")):
            log = (r.root / "run.log").read_text()
            assert "workflow complete (end)" in log, f"{tag} did not finish"
        assert base.visit_counts == {"work": 1, "done": 1}, base.visit_counts
        assert mon.visit_counts == base.visit_counts, (
            f"monitor changed flow routing: {mon.visit_counts} != "
            f"{base.visit_counts}")
        assert "health_monitor" not in mon.visit_counts, (
            "monitor must not be a routed flow step")
        mon_log = (mon.root / "run.log").read_text()
        assert "outcome: 'monitor_done'" not in mon_log, (
            "monitor_done leaked into flow routing")
        # The monitor did run out-of-band (its visit dir exists), but never
        # via execute_step.
        assert (mon.root / "health_monitor").is_dir(), (
            "monitor never ran out-of-band")
    finally:
        p.undo()
        shutil.rmtree(d, ignore_errors=True)


def s_optional_disabled():
    """CV-7: no health_monitor key => no monitor thread/dir, behavior
    identical to before."""
    p = Patcher()
    d = Path(tempfile.mkdtemp(prefix="tnc-hm-off-"))
    try:
        p.set(o, "_magnetize_accounts", lambda slug, wf, **_kw: {})
        p.set(o, "AGENT_RUNNERS", {"fake": _flow_runner()})
        wf_path = _baseline_workflow(d, with_monitor=False)
        wfobj = o.Workflow.load(wf_path)
        assert wfobj.health_monitor_step is None, (
            "absent key must disable the monitor")
        r = _run_wf(d, wf_path)
        assert "workflow complete (end)" in (r.root / "run.log").read_text()
        assert r.visit_counts == {"work": 1, "done": 1}, r.visit_counts
        assert not (r.root / "health_monitor").exists(), (
            "monitor dir created though monitor is disabled")
    finally:
        p.undo()
        shutil.rmtree(d, ignore_errors=True)


def s_malformed_config_fails_fast():
    """CV-8: a present-but-malformed health_monitor fails fast at
    Workflow.load (ValueError naming the field), before any run dir; a
    valid config and an absent key both load fine."""
    d = Path(tempfile.mkdtemp(prefix="tnc-hm-bad-"))
    try:
        good_steps = {"a": {"agent": "fake", "prompt": "p",
                            "next_steps": ["end"]},
                      "health_monitor": {"agent": "fake", "prompt": "p",
                                         "next_steps": ["monitor_done"]}}

        def wf(hm):
            x = {"goal": "g", "start_step": "a", "steps": good_steps}
            if hm is not None:
                x["health_monitor"] = hm
            path = d / "wf.json"
            path.write_text(json.dumps(x))
            return path

        bad_cases = [
            (["health_monitor"], "not-a-dict"),
            ({"step": "nope"}, "step"),
            ({"step": "health_monitor", "interval_seconds": 0}, "interval"),
            ({"step": "health_monitor", "interval_seconds": -3}, "interval"),
            ({"step": "health_monitor", "interval_seconds": "x"}, "interval"),
            ({"step": ""}, "step"),
            ({}, "step"),
        ]
        for hm, needle in bad_cases:
            try:
                o.Workflow.load(wf(hm))
            except ValueError as e:
                assert needle in str(e) or "health_monitor" in str(e), (
                    f"ValueError msg {str(e)!r} does not name field "
                    f"({needle})")
            else:
                raise AssertionError(
                    f"malformed health_monitor {hm!r} did not fail fast")

        # Valid config loads and is parsed.
        w = o.Workflow.load(wf({"step": "health_monitor",
                                "interval_seconds": 42}))
        assert w.health_monitor_step == "health_monitor"
        assert w.health_monitor_interval_seconds == 42.0

        # Absent key => disabled, no error.
        w2 = o.Workflow.load(wf(None))
        assert w2.health_monitor_step is None

        # Fail-fast happens before any run dir is created.
        home = d / "home"
        os.environ["TENACIOUS_HOME"] = str(home)
        try:
            try:
                o.execute_workflow(wf(["bad"]))
            except ValueError:
                pass
            else:
                raise AssertionError("execute_workflow did not fail fast")
            runs = home / "runs"
            assert not runs.exists() or not any(runs.iterdir()), (
                "a run dir was created despite fail-fast config error")
        finally:
            os.environ.pop("TENACIOUS_HOME", None)
    finally:
        shutil.rmtree(d, ignore_errors=True)


def s_json_interval_override():
    """CV-9: a non-default JSON interval is parsed AND drives cadence
    (kept separate from the 600.0 default constant check)."""
    d = Path(tempfile.mkdtemp(prefix="tnc-hm-iv-"))
    p = Patcher()
    try:
        wf = {"goal": "g", "start_step": "a",
              "steps": {"a": {"agent": "fake", "prompt": "p",
                              "next_steps": ["end"]},
                        "health_monitor": {"agent": "fake", "prompt": "p",
                                           "next_steps": ["monitor_done"]}},
              "health_monitor": {"step": "health_monitor",
                                 "interval_seconds": 0.2}}
        path = d / "wf.json"
        path.write_text(json.dumps(wf))
        w = o.Workflow.load(path)
        assert w.health_monitor_interval_seconds == 0.2, (
            f"parsed interval {w.health_monitor_interval_seconds} != 0.2 "
            f"(must not be the 600.0 default)")
        assert w.health_monitor_interval_seconds != \
            o.HEALTH_MONITOR_DEFAULT_INTERVAL_SECONDS

        calls_fast: list = []
        calls_slow: list = []
        with temp_run() as (run_f, _d1):
            p.set(o, "AGENT_RUNNERS",
                  {"fake": make_monitor_runner(calls_fast)})
            mfast = o.HealthMonitor(run_f, hm_step(), interval_seconds=0.2)
            mfast.start()
            time.sleep(0.7)
            mfast.stop()
        with temp_run() as (run_s, _d2):
            p.set(o, "AGENT_RUNNERS",
                  {"fake": make_monitor_runner(calls_slow)})
            mslow = o.HealthMonitor(run_s, hm_step(), interval_seconds=600.0)
            mslow.start()
            time.sleep(0.7)
            mslow.stop()
        assert len(calls_slow) == 0, (
            f"600s-interval monitor produced {len(calls_slow)} ticks in "
            f"0.7s, want exactly 0 (no tick at run start; first tick only "
            f"after one full 600s interval)")
        assert len(calls_fast) >= 2, (
            f"0.2s-interval monitor produced {len(calls_fast)} ticks; "
            f"non-default interval is not driving cadence "
            f"(want >=2: ticks at ~0.2/0.4/0.6s in 0.7s)")
    finally:
        p.undo()
        shutil.rmtree(d, ignore_errors=True)


def s_prompt_contents():
    """CV-10: the shipped 6step.yaml health_monitor prompt covers run.log,
    telemetry, assets, Claude+Codex transcripts, distress/loop/no-progress,
    and strict report-only / no-intervention."""
    wf = o.Workflow.load(
        Path(_PROJECT_ROOT) / "workflows" / "6step.yaml",
        goal_override="X")
    prompt = wf.steps["health_monitor"].prompt.lower()
    need = ["run.log", "meta.json", "outcome.txt", "assets", "profiles",
            "projects", "rollout", "jsonl", "codex", "claude", "distress",
            "loop", "no forward progress", "report-only", "never pause",
            "abort", "retry", "intervene"]
    missing = [t for t in need if t not in prompt]
    assert not missing, f"health_monitor prompt missing: {missing}"


def s_surface_stdout_once():
    """Bug 1 (Round 2): a child process running execute_workflow with a
    fake monitor agent emits the health banner + BOTH absolute *-current.md
    paths to its stdout EXACTLY ONCE per tick (not 2x), with the report
    paths appearing once (not 4x), nothing on stderr, and run.log still
    recording the tick exactly once. The fake monitor writes a quick body
    with a single `## Report paths` section (mirrors the real prompt).
    Deterministically exactly one tick: the work step blocks until the
    monitor has produced its quick asset once, then exits before the next
    interval elapses."""
    d = Path(tempfile.mkdtemp(prefix="tnc-hm-srf-"))
    try:
        child = d / "child.py"
        child.write_text(
            "import json,os,sys,time\n"
            f"sys.path.insert(0, {json.dumps(_PROJECT_ROOT)})\n"
            "import tenacious.orchestrator as o\n"
            "o.HEALTH_MONITOR_POLL_SLICE_SECONDS=0.02\n"
            "o._magnetize_accounts=lambda slug,wf,**_kw:{}\n"
            "def fake(step,run,visit,step_dir,prompt,should_continue=False):\n"
            "    ad=run.assets_dir\n"
            "    if step.slug=='hm':\n"
            "        deep=ad/'health-deepdive-current.md'\n"
            "        quick=ad/'health-quick-current.md'\n"
            "        deep.write_text('deep '+str(visit)+'\\n')\n"
            "        quick.write_text('quick status '+str(visit)+'\\n'\n"
            "            '## Report paths\\n'+str(deep)+'\\n'+str(quick)+'\\n')\n"
            "        (step_dir/'outcome.txt').write_text('monitor_done\\n')\n"
            "        return {'exit':0,'stdout':'','stderr':''}\n"
            "    qf=ad/'health-quick-current.md'\n"
            "    t0=time.time()\n"
            "    while not qf.exists() and time.time()-t0 < 20:\n"
            "        time.sleep(0.01)\n"
            "    (step_dir/'outcome.txt').write_text('end\\n')\n"
            "    return {'exit':0,'stdout':'','stderr':''}\n"
            "o.AGENT_RUNNERS={'fake':fake}\n"
            "wf={'goal':'g','project_dir':str(" + repr(str(d / "proj")) +
            "),'start_step':'work',"
            "'steps':{'work':{'agent':'fake','prompt':'w','next_steps':['end']},"
            "'hm':{'agent':'fake','prompt':'m','next_steps':['monitor_done'],"
            "'context':'empty','questions':False}},"
            "'health_monitor':{'step':'hm','interval_seconds':0.3}}\n"
            f"home={json.dumps(str(d / 'home'))}\n"
            "os.environ['TENACIOUS_HOME']=home\n"
            "wfp=" + json.dumps(str(d / "wf.json")) + "\n"
            "open(wfp,'w').write(json.dumps(wf))\n"
            "run=o.execute_workflow(__import__('pathlib').Path(wfp))\n"
            "print('CHILD-DONE', run.root)\n"
        )
        r = subprocess.run([sys.executable, str(child)],
                           capture_output=True, text=True, timeout=40,
                           cwd=_PROJECT_ROOT)
        assert r.returncode == 0, (
            f"child failed rc={r.returncode}\nSTDOUT:\n{r.stdout}\n"
            f"STDERR:\n{r.stderr}")
        out, err = r.stdout, r.stderr
        run_root = None
        for ln in out.splitlines():
            if ln.startswith("CHILD-DONE "):
                run_root = Path(ln.split(" ", 1)[1].strip())
        assert run_root is not None, f"no CHILD-DONE marker:\n{out}"
        assert out.count("===== SESSION HEALTH UPDATE") == 1, (
            f"health banner header not emitted exactly once to stdout "
            f"(want 1):\n{out}")
        assert out.count("===== END SESSION HEALTH UPDATE") == 1, (
            f"health banner footer not emitted exactly once to stdout:\n{out}")
        assert out.count("/assets/health-deepdive-current.md") == 1, (
            f"deep-dive path not surfaced exactly once in stdout:\n{out}")
        assert out.count("/assets/health-quick-current.md") == 1, (
            f"quick path not surfaced exactly once in stdout:\n{out}")
        assert "===== SESSION HEALTH UPDATE" not in err, (
            f"health banner duplicated onto stderr:\n{err}")
        log_text = (run_root / "run.log").read_text()
        assert log_text.count("===== SESSION HEALTH UPDATE") == 1, (
            f"run.log did not record the tick exactly once:\n{log_text}")
        assert not _DOUBLED_TS_RE.search(out), (
            f"doubled [ts] [ts] prefix on a health line in stdout:\n{out}")
        assert not _DOUBLED_TS_RE.search(log_text), (
            f"doubled [ts] [ts] prefix on a health line in run.log:\n"
            f"{log_text}")
    finally:
        shutil.rmtree(d, ignore_errors=True)


def s_no_tick_at_start():
    """Item 2: the monitor never ticks at run start. A huge-interval
    monitor started and polled ~0.3s records ZERO ticks; forcing
    `_next_due=now` then waiting one poll slice yields exactly one (the
    timer still works after the first interval)."""
    p = Patcher()
    try:
        calls: list = []
        p.set(o, "AGENT_RUNNERS", {"fake": make_monitor_runner(calls)})
        with temp_run() as (run, _d):
            mon = o.HealthMonitor(run, hm_step(), interval_seconds=1e9)
            mon.start()
            time.sleep(0.3)
            assert calls == [], (
                f"monitor ticked at run start (want none): {calls}")
            mon._next_due = time.monotonic()
            t0 = time.time()
            while not calls and time.time() - t0 < 3.0:
                time.sleep(0.02)
            mon.stop()
            assert calls == [1], (
                f"forcing _next_due=now did not yield exactly one tick "
                f"(timer broken after first interval?): {calls}")
    finally:
        p.undo()


def s_output_queued_during_pause():
    """CV-E/MV3: while paused collecting an answer the monitor's terminal
    output is buffered (absent from stdout/stderr) yet the run.log FILE is
    written in real time; on end_pause the buffered output replays on the
    captured streams in its original emission order."""
    import io
    p = Patcher()
    try:
        calls: list = []
        p.set(o, "AGENT_RUNNERS", {"fake": make_monitor_runner(calls)})
        with temp_run() as (run, _d):
            mon = o.HealthMonitor(run, hm_step(), interval_seconds=1e9)
            real_out, real_err = sys.stdout, sys.stderr

            mon.begin_pause()  # suspends terminal output
            cap_out, cap_err = io.StringIO(), io.StringIO()
            sys.stdout, sys.stderr = cap_out, cap_err
            try:
                mon._run_tick()              # tick 1 -> quick banner
                run.log_monitor("MARK-2")    # a second buffered entry
                paused_out = cap_out.getvalue()
                paused_err = cap_err.getvalue()
            finally:
                sys.stdout, sys.stderr = real_out, real_err

            # (a) nothing surfaced to the terminal while paused.
            assert "SESSION HEALTH UPDATE" not in paused_out, (
                f"banner leaked to stdout while paused: {paused_out!r}")
            assert "SESSION HEALTH UPDATE" not in paused_err, (
                f"banner leaked to stderr while paused: {paused_err!r}")
            assert "MARK-2" not in paused_out, (
                f"MARK-2 leaked to stdout while paused: {paused_out!r}")

            # (b) the run.log FILE already has the tick line + MARK-2.
            log_text = (run.root / "run.log").read_text()
            assert "[health_monitor] tick 1" in log_text, (
                f"tick line not written to run.log in real time:\n"
                f"{log_text}")
            assert "MARK-2" in log_text, (
                "MARK-2 not written to run.log file in real time")

            # (c) end_pause replays the buffered output IN ORDER.
            cap_out2, cap_err2 = io.StringIO(), io.StringIO()
            sys.stdout, sys.stderr = cap_out2, cap_err2
            try:
                mon.end_pause()
            finally:
                sys.stdout, sys.stderr = real_out, real_err
            replay_out = cap_out2.getvalue()
            replay_err = cap_err2.getvalue()
            assert "SESSION HEALTH UPDATE" in replay_out, (
                f"banner not replayed to stdout on resume: {replay_out!r}")
            assert "MARK-2" in replay_out, (
                f"MARK-2 not replayed to stdout on resume: {replay_out!r}")
            i_banner = replay_out.index("SESSION HEALTH UPDATE")
            i_mark = replay_out.index("MARK-2")
            assert i_banner < i_mark, (
                f"replay out of emission order: banner@{i_banner} "
                f"after mark@{i_mark}")
            # No stderr copy exists any more (Bug 1 de-dup): nothing
            # health-related must replay onto stderr.
            assert "SESSION HEALTH UPDATE" not in replay_err, (
                f"stderr received a health banner copy: {replay_err!r}")
    finally:
        p.undo()


def s_run_log_suspended_during_pause():
    """Bug 1.A (Round 1): with the terminal suspended (a pending-question
    pause), three real bug strings emitted via `run.log(...)` are ABSENT
    from stdout/stderr while paused, are present in the run.log FILE in
    real time and in emission order, and replay to stdout (not stderr) in
    emission order on end_pause().

    Reproduces Bug 1.A for `run.log()` specifically: FAILS pre-fix
    because the old `log()` printed immediately, ignoring
    `_term_suspended`."""
    import io
    p = Patcher()
    try:
        calls: list = []
        p.set(o, "AGENT_RUNNERS", {"fake": make_monitor_runner(calls)})
        with temp_run() as (run, _d):
            mon = o.HealthMonitor(run, hm_step(), interval_seconds=1e9)
            real_out, real_err = sys.stdout, sys.stderr

            msgs = [
                "  claude cmd: ...anthropic/acct/slot ... "
                "(prompt len=10B, continue=False)",
                "  [health_monitor] valid outcome.txt detected while "
                "agent still running",
                "  outcome: 'plan_eval'",
            ]

            mon.begin_pause()  # suspends terminal output
            cap_out, cap_err = io.StringIO(), io.StringIO()
            sys.stdout, sys.stderr = cap_out, cap_err
            try:
                for m in msgs:
                    run.log(m)
                paused_out = cap_out.getvalue()
                paused_err = cap_err.getvalue()
            finally:
                sys.stdout, sys.stderr = real_out, real_err

            for m in msgs:
                assert m not in paused_out, (
                    f"{m!r} leaked to stdout while paused: {paused_out!r}")
                assert m not in paused_err, (
                    f"{m!r} leaked to stderr while paused: {paused_err!r}")

            log_text = (run.root / "run.log").read_text()
            idxs = []
            for m in msgs:
                i = log_text.find(m)
                assert i != -1, (
                    f"{m!r} not written to run.log FILE in real time:\n"
                    f"{log_text}")
                idxs.append(i)
            assert idxs == sorted(idxs), (
                f"run.log FILE out of emission order: {idxs}")

            cap_out2, cap_err2 = io.StringIO(), io.StringIO()
            sys.stdout, sys.stderr = cap_out2, cap_err2
            try:
                mon.end_pause()
            finally:
                sys.stdout, sys.stderr = real_out, real_err
            replay_out = cap_out2.getvalue()
            replay_err = cap_err2.getvalue()
            ridx = []
            for m in msgs:
                i = replay_out.find(m)
                assert i != -1, (
                    f"{m!r} not replayed to stdout on resume: "
                    f"{replay_out!r}")
                assert m not in replay_err, (
                    f"{m!r} replayed onto stderr: {replay_err!r}")
                ridx.append(i)
            assert ridx == sorted(ridx), (
                f"replay out of emission order: {ridx}")
    finally:
        p.undo()


_PQI_CHILD = r'''
import json, os, sys, time
sys.path.insert(0, __PROJECT_ROOT__)
import tenacious.orchestrator as o
o.HEALTH_MONITOR_POLL_SLICE_SECONDS = 0.02
o._magnetize_accounts = lambda slug, wf, **_kw: {}

# Capture the Run so the patched next_answer can call run.log() while the
# real run is paused (AnswerSource itself holds no Run handle).
o._LAST_RUN = None
_orig_create_run = o.create_run
def _cr(wf, **_kw):
    r = _orig_create_run(wf, **_kw)
    o._LAST_RUN = r
    return r
o.create_run = _cr

# Child redirects its OWN stdout to a file so the parent can read a
# mid-pause snapshot of exactly what the terminal showed during the pause.
OUTF = __OUTF__
sys.stdout = open(OUTF, "w", buffering=1)

asked = {"n": 0}
def fake(step, run, visit, step_dir, prompt, should_continue=False):
    ad = run.assets_dir
    if step.slug == "hm":
        (ad / "health-deepdive-current.md").write_text(
            "deep " + str(visit) + "\n")
        (ad / "health-quick-current.md").write_text(
            "quick " + str(visit) + "\n## Report paths\n"
            + str(ad / "health-deepdive-current.md") + "\n")
        (step_dir / "outcome.txt").write_text("monitor_done\n")
        return {"exit": 0, "stdout": "", "stderr": ""}
    if step.slug == "ask":
        asked["n"] += 1
        if asked["n"] == 1:
            (step_dir / "question.txt").write_text("Q-MARK what now?\n")
            (step_dir / "outcome.txt").write_text("question\n")
        else:
            (step_dir / "outcome.txt").write_text("end\n")
        return {"exit": 0, "stdout": "", "stderr": ""}
    (step_dir / "outcome.txt").write_text("end\n")
    return {"exit": 0, "stdout": "", "stderr": ""}
o.AGENT_RUNNERS = {"fake": fake}

SNAP = __SNAP__
def patched(self, question):
    # Snapshot the terminal mid-pause, then emit one buffered line via
    # run.log() (proves 1.A independent of monitor timing), then block
    # long enough that a pre-fix monitor would tick during the pause.
    sys.stdout.flush()
    open(SNAP, "w").write(open(OUTF).read())
    o._LAST_RUN.log("PAUSE-SENTINEL")
    time.sleep(0.4)
    return "the answer"
o.AnswerSource.next_answer = patched

wf = {"goal": "g", "project_dir": __PROJ__, "start_step": "ask",
      "steps": {"ask": {"agent": "fake", "prompt": "a",
                        "next_steps": ["end"], "questions": True},
                "hm": {"agent": "fake", "prompt": "m",
                       "next_steps": ["monitor_done"],
                       "context": "empty", "questions": False}},
      "health_monitor": {"step": "hm", "interval_seconds": 0.05}}
os.environ["TENACIOUS_HOME"] = __HOME__
wfp = __WFP__
open(wfp, "w").write(json.dumps(wf))
import pathlib
run = o.execute_workflow(pathlib.Path(wfp))
sys.stdout.flush()
open(__ROOTF__, "w").write(str(run.root))
'''


def s_paused_question_integration():
    """Bug 1 end-to-end (Round 1): a child runs the REAL
    execute_workflow -> execute_step -> begin_pause -> next_answer ->
    end_pause path with a LIVE HealthMonitor thread at a short interval
    and a real question-asking step.

    Proves: the mid-pause stdout snapshot shows the question banner but
    NO monitor/orchestrator noise (1.A+1.B silence the terminal during
    the real pause); the post-submit stdout DOES contain the buffered
    PAUSE-SENTINEL after the banner (ordered replay); the run.log FILE
    contains PAUSE-SENTINEL and the full uninterrupted history. FAILS
    pre-fix: old `_loop` ticked once while paused (banner in snapshot)
    and old `log()` printed PAUSE-SENTINEL immediately (in snapshot)."""
    d = Path(tempfile.mkdtemp(prefix="tnc-hm-pqi-"))
    try:
        child = d / "child.py"
        src = (_PQI_CHILD
               .replace("__PROJECT_ROOT__", json.dumps(_PROJECT_ROOT))
               .replace("__OUTF__", json.dumps(str(d / "child_stdout.txt")))
               .replace("__SNAP__", json.dumps(str(d / "snapshot.txt")))
               .replace("__PROJ__", json.dumps(str(d / "proj")))
               .replace("__HOME__", json.dumps(str(d / "home")))
               .replace("__WFP__", json.dumps(str(d / "wf.json")))
               .replace("__ROOTF__", json.dumps(str(d / "rootdir.txt"))))
        child.write_text(src)

        r = subprocess.run([sys.executable, str(child)],
                           capture_output=True, text=True, timeout=40,
                           cwd=_PROJECT_ROOT)
        assert r.returncode == 0, (
            f"child failed rc={r.returncode}\nSTDOUT:\n{r.stdout}\n"
            f"STDERR:\n{r.stderr}")
        snap = (d / "snapshot.txt").read_text()
        final = (d / "child_stdout.txt").read_text()
        run_root = Path((d / "rootdir.txt").read_text().strip())
        log_text = (run_root / "run.log").read_text()

        # (a) mid-pause snapshot: the question the orchestrator surfaced
        # ("agent asked: 'Q-MARK ...'", logged BEFORE begin_pause) is
        # visible, but NONE of the monitor/orchestrator pause-window
        # noise — including the buffered PAUSE-SENTINEL — has leaked.
        # (The raw-mode editor banner itself only renders on a real tty;
        # next_answer is patched here, so Q-MARK is the faithful proxy
        # for "the question reached the terminal".)
        assert "Q-MARK" in snap, (
            f"question text missing from mid-pause snapshot:\n{snap}")
        for noise in ("===== SESSION HEALTH UPDATE",
                      "outcome: 'monitor_done'", "[health_monitor] tick",
                      "step health_monitor visit", "PAUSE-SENTINEL"):
            assert noise not in snap, (
                f"{noise!r} leaked to terminal during the pause:\n{snap}")

        # (b) post-submit stdout: PAUSE-SENTINEL replayed, in order
        # (after the question line, never before it).
        assert "PAUSE-SENTINEL" in final, (
            f"PAUSE-SENTINEL never replayed to stdout:\n{final}")
        assert final.index("Q-MARK") < final.index("PAUSE-SENTINEL"), (
            f"replay out of order (sentinel before question):\n{final}")

        # (c) run.log FILE has the full uninterrupted history.
        assert "PAUSE-SENTINEL" in log_text, (
            f"PAUSE-SENTINEL missing from run.log FILE:\n{log_text}")
        assert "workflow complete (end)" in log_text, (
            f"run did not complete:\n{log_text}")
    finally:
        shutil.rmtree(d, ignore_errors=True)


def s_default_interval_constant():
    """CV-3: the shipped default is exactly 600.0 and NOT env-overridable."""
    code = (
        "import os\n"
        "os.environ['TENACIOUS_HEALTH_INTERVAL']='1'\n"
        "os.environ['TENACIOUS_HEALTH_MONITOR_INTERVAL_SECONDS']='1'\n"
        "import tenacious.orchestrator as o\n"
        "print(o.HEALTH_MONITOR_DEFAULT_INTERVAL_SECONDS)\n"
    )
    r = subprocess.run([sys.executable, "-c", code], cwd=_PROJECT_ROOT,
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    assert r.stdout.strip() == "600.0", (
        f"shipped default changed or env-configurable: {r.stdout!r}")


SCENARIOS = [
    ("timer_cadence", s_timer_cadence),
    ("zero_ticks_while_paused", s_zero_ticks_while_paused),
    ("report_only", s_report_only),
    ("optional_disabled", s_optional_disabled),
    ("malformed_config_fails_fast", s_malformed_config_fails_fast),
    ("json_interval_override", s_json_interval_override),
    ("no_tick_at_start", s_no_tick_at_start),
    ("output_queued_during_pause", s_output_queued_during_pause),
    ("run_log_suspended_during_pause", s_run_log_suspended_during_pause),
    ("paused_question_integration", s_paused_question_integration),
    ("prompt_contents", s_prompt_contents),
    ("surface_stdout_once", s_surface_stdout_once),
    ("default_interval_constant", s_default_interval_constant),
]


def main() -> int:
    for name, fn in SCENARIOS:
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            print(f"FAIL {name}: {e}")
            traceback.print_exc()
            return 1
        print(f"PASS {name}")
    print(f"ALL PASS ({len(SCENARIOS)} scenarios)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
