"""Tests for the `--max-visits` CLI cap.

Verifies that
  1. argparse rejects 0 / negative values with exit 2;
  2. the override is honored by `Run.consume_step_budget`;
  3. omitting the flag preserves the default GLOBAL_STEP_BUDGET (100);
  4. `Workflow.load` accepts a `max_visits` field on the frozen
     workflow.json so a resumed run inherits the original cap.

Stdlib-only. Run from the project root:

    .venv/bin/python tests/test_max_visits.py
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import tenacious.orchestrator as o  # noqa: E402


FAILS: list[str] = []
PASSES = 0


def _ok(name: str) -> None:
    global PASSES
    PASSES += 1
    print(f"PASS {name}")


def _fail(name: str, detail: str) -> None:
    FAILS.append(f"{name}: {detail}")
    print(f"FAIL {name}: {detail}")


def s_help_mentions_flag() -> None:
    name = "help_mentions_flag"
    proc = subprocess.run(
        [sys.executable, "-m", "tenacious", "--help"],
        cwd=_PROJECT_ROOT,
        capture_output=True, text=True, timeout=20,
        env={**os.environ, "PYTHONPATH": _PROJECT_ROOT})
    if "--max-visits" not in proc.stdout:
        _fail(name, f"flag not in help output")
        return
    _ok(name)


def _run_cli(args: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, "-m", "tenacious",
         str(Path(_PROJECT_ROOT) / "workflows" / "hello-claude.json")] + args,
        cwd=_PROJECT_ROOT,
        capture_output=True, text=True, timeout=20,
        env={**os.environ, "PYTHONPATH": _PROJECT_ROOT})


def s_reject_zero() -> None:
    name = "reject_zero"
    proc = _run_cli(["--max-visits", "0"])
    if proc.returncode != 2:
        _fail(name, f"exit={proc.returncode}")
        return
    if "--max-visits must be a positive integer" not in proc.stderr:
        _fail(name, f"stderr={proc.stderr[:200]!r}")
        return
    _ok(name)


def s_reject_negative() -> None:
    name = "reject_negative"
    proc = _run_cli(["--max-visits", "-1"])
    if proc.returncode != 2:
        _fail(name, f"exit={proc.returncode}")
        return
    if "--max-visits must be a positive integer" not in proc.stderr:
        _fail(name, f"stderr={proc.stderr[:200]!r}")
        return
    _ok(name)


def s_override_takes_effect() -> None:
    name = "override_takes_effect"
    d = Path(tempfile.mkdtemp(prefix="mv-"))
    (d / "assets").mkdir()
    wf = o.Workflow(goal="g", start_step="s", steps={})
    r = o.Run(slug="s", root=d, workflow=wf, project_dir=d,
              accounts={}, max_visits_override=2)
    r.consume_step_budget()
    r.consume_step_budget()
    try:
        r.consume_step_budget()
        _fail(name, "did not raise")
        return
    except RuntimeError as e:
        if "max step budget exceeded" not in str(e):
            _fail(name, f"bad msg: {e}")
            return
    _ok(name)


def s_default_preserved() -> None:
    name = "default_preserved"
    d = Path(tempfile.mkdtemp(prefix="mv-"))
    (d / "assets").mkdir()
    wf = o.Workflow(goal="g", start_step="s", steps={})
    r = o.Run(slug="s", root=d, workflow=wf, project_dir=d, accounts={})
    if o.GLOBAL_STEP_BUDGET != 100:
        _fail(name, f"default changed: {o.GLOBAL_STEP_BUDGET}")
        return
    if r.max_visits_override is not None:
        _fail(name, f"override leaked: {r.max_visits_override}")
        return
    for _ in range(100):
        r.consume_step_budget()
    try:
        r.consume_step_budget()
        _fail(name, "no raise after 101 consumes")
        return
    except RuntimeError:
        pass
    _ok(name)


def s_persisted_workflow_json_reads() -> None:
    name = "persisted_workflow_json_reads"
    d = Path(tempfile.mkdtemp(prefix="mv-"))
    p = d / "workflow.json"
    p.write_text(json.dumps({
        "goal": "g", "start_step": "a",
        "steps": {"a": {"agent": "claude", "prompt": "p",
                        "next_steps": ["end"]}},
        "max_visits": 7,
    }))
    wf = o.Workflow.load(p)
    if wf.max_visits != 7:
        _fail(name, f"max_visits={wf.max_visits}")
        return
    _ok(name)


def s_persisted_rejected_invalid() -> None:
    name = "persisted_rejected_invalid"
    d = Path(tempfile.mkdtemp(prefix="mv-"))
    p = d / "workflow.json"
    p.write_text(json.dumps({
        "goal": "g", "start_step": "a",
        "steps": {"a": {"agent": "claude", "prompt": "p",
                        "next_steps": ["end"]}},
        "max_visits": 0,
    }))
    try:
        o.Workflow.load(p)
        _fail(name, "did not raise for max_visits=0")
        return
    except ValueError as e:
        if "max_visits" not in str(e):
            _fail(name, f"bad msg: {e}")
            return
    _ok(name)


def main() -> int:
    s_help_mentions_flag()
    s_reject_zero()
    s_reject_negative()
    s_override_takes_effect()
    s_default_preserved()
    s_persisted_workflow_json_reads()
    s_persisted_rejected_invalid()
    if FAILS:
        print(f"\nFAILED ({len(FAILS)}):")
        for f in FAILS:
            print(f"  {f}")
        return 1
    print(f"\nALL PASS ({PASSES})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
