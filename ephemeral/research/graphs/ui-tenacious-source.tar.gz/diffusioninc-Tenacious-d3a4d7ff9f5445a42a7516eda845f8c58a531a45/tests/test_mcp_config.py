"""Unit tests for the per-step MCP config plumbing.

Validates:
  - Step.from_dict mcp_servers schema (defaults, null rejection, unknown
    keys, type checks, name regex, cwd rejection).
  - _materialize_mcp_config TOML / JSON emission for codex and claude.
  - Workflow.load -> create_run freezes the mcp_servers dict into the
    on-disk workflow.json.

Stdlib only. No subprocesses, no network, no real agents.

Run from the project root:

    python3 tests/test_mcp_config.py
"""

from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
import traceback
import tomllib
from pathlib import Path

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import tenacious.orchestrator as o  # noqa: E402


def _step(**over):
    d = {"agent": "claude", "prompt": "p", "next_steps": ["end"]}
    d.update(over)
    return o.Step.from_dict("s", d)


def s_step_default_no_mcp() -> None:
    s = _step()
    assert s.mcp_servers == {}, s.mcp_servers


def s_step_default_is_fresh_dict() -> None:
    a = _step()
    b = _step()
    a.mcp_servers["x"] = {"command": "/bin/true"}
    assert b.mcp_servers == {}, b.mcp_servers
    assert a.mcp_servers is not b.mcp_servers


def s_step_parses_minimal_stdio() -> None:
    s = _step(mcp_servers={"fs": {"command": "/usr/bin/echo"}})
    assert s.mcp_servers == {"fs": {"command": "/usr/bin/echo"}}, s.mcp_servers


def s_step_parses_full_stdio() -> None:
    s = _step(mcp_servers={
        "fs": {"command": "/bin/x", "args": ["a", "b"],
               "env": {"K": "V"}},
    })
    assert s.mcp_servers["fs"]["args"] == ["a", "b"]
    assert s.mcp_servers["fs"]["env"] == {"K": "V"}


def s_step_rejects_null() -> None:
    try:
        _step(mcp_servers=None)
    except ValueError as e:
        assert "must be an object, got null" in str(e), e
        return
    raise AssertionError("null mcp_servers not rejected")


def s_step_rejects_missing_command() -> None:
    try:
        _step(mcp_servers={"fs": {"args": ["a"]}})
    except ValueError as e:
        assert "command" in str(e), e
        return
    raise AssertionError("missing command not rejected")


def s_step_rejects_extra_key() -> None:
    try:
        _step(mcp_servers={"fs": {"command": "/bin/x", "weird": True}})
    except ValueError as e:
        assert "unknown mcp_servers field" in str(e), e
        return
    raise AssertionError("extra key not rejected")


def s_step_rejects_bad_args_type() -> None:
    try:
        _step(mcp_servers={"fs": {"command": "/bin/x", "args": "not-a-list"}})
    except ValueError as e:
        assert "args" in str(e), e
        return
    raise AssertionError("bad args type not rejected")


def s_step_rejects_bad_env_type() -> None:
    try:
        _step(mcp_servers={"fs": {"command": "/bin/x",
                                   "env": {"K": 5}}})
    except ValueError as e:
        assert "env" in str(e), e
        return
    raise AssertionError("bad env type not rejected")


def s_step_rejects_cwd_key() -> None:
    try:
        _step(mcp_servers={"fs": {"command": "/bin/x", "cwd": "/tmp"}})
    except ValueError as e:
        assert "unknown mcp_servers field" in str(e) and "cwd" in str(e), e
        return
    raise AssertionError("cwd key was not rejected")


def s_step_rejects_bad_name() -> None:
    try:
        _step(mcp_servers={"bad name!": {"command": "/bin/x"}})
    except ValueError as e:
        assert "must match" in str(e), e
        return
    raise AssertionError("bad name not rejected")


def s_materialize_codex_writes_toml() -> None:
    d = tempfile.mkdtemp(prefix="tnc-mcp-")
    try:
        step = o.Step(slug="s", agent="codex", prompt="p",
                      next_steps=["end"],
                      mcp_servers={"fs": {"command": "/bin/x",
                                          "args": ["a", "b"],
                                          "env": {"K": "V"}}})
        ret = o._materialize_mcp_config(step, Path(d))
        assert ret is None, ret  # codex auto-discovers, helper returns None
        cfg = Path(d) / "config.toml"
        assert cfg.exists(), "config.toml not written"
        parsed = tomllib.loads(cfg.read_text())
        assert "mcp_servers" in parsed, parsed
        assert parsed["mcp_servers"]["fs"]["command"] == "/bin/x", parsed
        assert parsed["mcp_servers"]["fs"]["args"] == ["a", "b"], parsed
        assert parsed["mcp_servers"]["fs"]["env"] == {"K": "V"}, parsed
    finally:
        shutil.rmtree(d, ignore_errors=True)


def s_materialize_codex_quotes_special_chars() -> None:
    d = tempfile.mkdtemp(prefix="tnc-mcp-")
    try:
        step = o.Step(slug="s", agent="codex", prompt="p", next_steps=["end"],
                      mcp_servers={"weird": {
                          "command": '/bin/has "quote" and \\bs',
                          "args": ['arg with "q"', "arg\\two"],
                          "env": {"K": 'v"x\\y'},
                      }})
        o._materialize_mcp_config(step, Path(d))
        parsed = tomllib.loads((Path(d) / "config.toml").read_text())
        srv = parsed["mcp_servers"]["weird"]
        assert srv["command"] == '/bin/has "quote" and \\bs', srv
        assert srv["args"] == ['arg with "q"', "arg\\two"], srv
        assert srv["env"] == {"K": 'v"x\\y'}, srv
    finally:
        shutil.rmtree(d, ignore_errors=True)


def s_materialize_claude_writes_json() -> None:
    d = tempfile.mkdtemp(prefix="tnc-mcp-")
    try:
        step = o.Step(slug="s", agent="claude", prompt="p",
                      next_steps=["end"],
                      mcp_servers={"fs": {"command": "/bin/x",
                                          "args": ["a"],
                                          "env": {"K": "V"}}})
        ret = o._materialize_mcp_config(step, Path(d))
        out = Path(d) / "mcp-servers.json"
        assert ret == out.resolve(), (ret, out)
        payload = json.loads(out.read_text())
        srv = payload["mcpServers"]["fs"]
        assert srv["type"] == "stdio", srv
        assert srv["command"] == "/bin/x", srv
        assert srv["args"] == ["a"], srv
        assert srv["env"] == {"K": "V"}, srv
    finally:
        shutil.rmtree(d, ignore_errors=True)


def s_materialize_claude_omits_empty_args_env() -> None:
    d = tempfile.mkdtemp(prefix="tnc-mcp-")
    try:
        step = o.Step(slug="s", agent="claude", prompt="p",
                      next_steps=["end"],
                      mcp_servers={"min": {"command": "/bin/true"}})
        o._materialize_mcp_config(step, Path(d))
        payload = json.loads((Path(d) / "mcp-servers.json").read_text())
        srv = payload["mcpServers"]["min"]
        assert "args" not in srv, srv
        assert "env" not in srv, srv
    finally:
        shutil.rmtree(d, ignore_errors=True)


def s_materialize_no_servers_writes_nothing() -> None:
    d = tempfile.mkdtemp(prefix="tnc-mcp-")
    try:
        for agent in ("claude", "codex"):
            step = o.Step(slug="s", agent=agent, prompt="p",
                          next_steps=["end"])
            ret = o._materialize_mcp_config(step, Path(d))
            assert ret is None, ret
            entries = list(Path(d).iterdir())
            assert entries == [], (agent, entries)
    finally:
        shutil.rmtree(d, ignore_errors=True)


def s_step_parses_minimal_http() -> None:
    s = _step(mcp_servers={"slack": {"url": "https://mcp.slack.com/mcp"}})
    assert s.mcp_servers == {"slack": {"url": "https://mcp.slack.com/mcp"}}


def s_step_parses_full_http() -> None:
    s = _step(mcp_servers={"slack": {
        "url": "https://mcp.slack.com/mcp",
        "headers": {"X-Custom": "val"},
        "bearer_token_env_var": "SLACK_MCP_TOKEN",
    }})
    assert s.mcp_servers["slack"]["url"] == "https://mcp.slack.com/mcp"
    assert s.mcp_servers["slack"]["headers"] == {"X-Custom": "val"}
    assert s.mcp_servers["slack"]["bearer_token_env_var"] == "SLACK_MCP_TOKEN"


def s_step_rejects_both_command_and_url() -> None:
    try:
        _step(mcp_servers={"s": {"command": "/bin/x", "url": "https://x"}})
    except ValueError as e:
        assert "cannot have both" in str(e), e
        return
    raise AssertionError("both command+url not rejected")


def s_step_rejects_neither_command_nor_url() -> None:
    try:
        _step(mcp_servers={"s": {"args": ["a"]}})
    except ValueError as e:
        assert "must have either" in str(e), e
        return
    raise AssertionError("missing command/url not rejected")


def s_step_rejects_bad_url_type() -> None:
    try:
        _step(mcp_servers={"s": {"url": 123}})
    except ValueError as e:
        assert "url" in str(e), e
        return
    raise AssertionError("bad url type not rejected")


def s_step_rejects_bad_headers_type() -> None:
    try:
        _step(mcp_servers={"s": {"url": "https://x", "headers": "bad"}})
    except ValueError as e:
        assert "headers" in str(e), e
        return
    raise AssertionError("bad headers type not rejected")


def s_materialize_codex_http_writes_toml() -> None:
    d = tempfile.mkdtemp(prefix="tnc-mcp-")
    try:
        step = o.Step(slug="s", agent="codex", prompt="p", next_steps=["end"],
                      mcp_servers={"slack": {
                          "url": "https://mcp.slack.com/mcp",
                          "bearer_token_env_var": "SLACK_MCP_TOKEN",
                      }})
        o._materialize_mcp_config(step, Path(d))
        parsed = tomllib.loads((Path(d) / "config.toml").read_text())
        srv = parsed["mcp_servers"]["slack"]
        assert srv["url"] == "https://mcp.slack.com/mcp", srv
        assert srv["bearer_token_env_var"] == "SLACK_MCP_TOKEN", srv
        assert "command" not in srv, srv
    finally:
        shutil.rmtree(d, ignore_errors=True)


def s_materialize_claude_http_injects_bearer() -> None:
    d = tempfile.mkdtemp(prefix="tnc-mcp-")
    prev = os.environ.get("SLACK_MCP_TOKEN")
    try:
        os.environ["SLACK_MCP_TOKEN"] = "tok-test-123"
        step = o.Step(slug="s", agent="claude", prompt="p", next_steps=["end"],
                      mcp_servers={"slack": {
                          "url": "https://mcp.slack.com/mcp",
                          "bearer_token_env_var": "SLACK_MCP_TOKEN",
                      }})
        o._materialize_mcp_config(step, Path(d))
        payload = json.loads((Path(d) / "mcp-servers.json").read_text())
        srv = payload["mcpServers"]["slack"]
        assert srv["type"] == "http", srv
        assert srv["url"] == "https://mcp.slack.com/mcp", srv
        assert srv["headers"]["Authorization"] == "Bearer tok-test-123", srv
    finally:
        if prev is None:
            os.environ.pop("SLACK_MCP_TOKEN", None)
        else:
            os.environ["SLACK_MCP_TOKEN"] = prev
        shutil.rmtree(d, ignore_errors=True)


def s_mcp_log_summary_mixed() -> None:
    step = o.Step(slug="s", agent="claude", prompt="p", next_steps=["end"],
                  mcp_servers={
                      "fs": {"command": "/bin/x"},
                      "slack": {"url": "https://mcp.slack.com/mcp"},
                  })
    summary = o._mcp_log_summary(step)
    assert "1 stdio (fs)" in summary, summary
    assert "1 http (slack)" in summary, summary


def s_workflow_load_freezes_mcp() -> None:
    d = tempfile.mkdtemp(prefix="tnc-mcp-")
    prev_home = os.environ.get("TENACIOUS_HOME")
    try:
        home = Path(d) / "home"
        home.mkdir(parents=True)
        wf_path = Path(d) / "wf.json"
        wf_path.write_text(json.dumps({
            "goal": "g", "start_step": "s",
            "steps": {"s": {
                "agent": "claude", "prompt": "p", "next_steps": ["end"],
                "mcp_servers": {
                    "fs": {"command": "/bin/x", "args": ["a"],
                           "env": {"K": "V"}}
                },
            }},
        }))
        os.environ["TENACIOUS_HOME"] = str(home)
        prev_magnet = o._magnetize_accounts
        o._magnetize_accounts = lambda slug, wf, **_kw: {}
        try:
            wf = o.Workflow.load(wf_path)
            assert wf.steps["s"].mcp_servers == {
                "fs": {"command": "/bin/x", "args": ["a"], "env": {"K": "V"}}
            }, wf.steps["s"].mcp_servers
            run = o.create_run(wf)
            frozen = json.loads((run.root / "workflow.json").read_text())
            assert frozen["steps"]["s"]["mcp_servers"] == {
                "fs": {"command": "/bin/x", "args": ["a"], "env": {"K": "V"}}
            }, frozen
        finally:
            o._magnetize_accounts = prev_magnet
    finally:
        if prev_home is None:
            os.environ.pop("TENACIOUS_HOME", None)
        else:
            os.environ["TENACIOUS_HOME"] = prev_home
        shutil.rmtree(d, ignore_errors=True)


SCENARIOS = [
    ("step_default_no_mcp", s_step_default_no_mcp),
    ("step_default_is_fresh_dict", s_step_default_is_fresh_dict),
    ("step_parses_minimal_stdio", s_step_parses_minimal_stdio),
    ("step_parses_full_stdio", s_step_parses_full_stdio),
    ("step_rejects_null", s_step_rejects_null),
    ("step_rejects_missing_command", s_step_rejects_missing_command),
    ("step_rejects_extra_key", s_step_rejects_extra_key),
    ("step_rejects_bad_args_type", s_step_rejects_bad_args_type),
    ("step_rejects_bad_env_type", s_step_rejects_bad_env_type),
    ("step_rejects_cwd_key", s_step_rejects_cwd_key),
    ("step_rejects_bad_name", s_step_rejects_bad_name),
    ("materialize_codex_writes_toml", s_materialize_codex_writes_toml),
    ("materialize_codex_quotes_special_chars",
     s_materialize_codex_quotes_special_chars),
    ("materialize_claude_writes_json", s_materialize_claude_writes_json),
    ("materialize_claude_omits_empty_args_env",
     s_materialize_claude_omits_empty_args_env),
    ("materialize_no_servers_writes_nothing",
     s_materialize_no_servers_writes_nothing),
    # http transport
    ("step_parses_minimal_http", s_step_parses_minimal_http),
    ("step_parses_full_http", s_step_parses_full_http),
    ("step_rejects_both_command_and_url", s_step_rejects_both_command_and_url),
    ("step_rejects_neither_command_nor_url",
     s_step_rejects_neither_command_nor_url),
    ("step_rejects_bad_url_type", s_step_rejects_bad_url_type),
    ("step_rejects_bad_headers_type", s_step_rejects_bad_headers_type),
    ("materialize_codex_http_writes_toml", s_materialize_codex_http_writes_toml),
    ("materialize_claude_http_injects_bearer",
     s_materialize_claude_http_injects_bearer),
    ("mcp_log_summary_mixed", s_mcp_log_summary_mixed),
    ("workflow_load_freezes_mcp", s_workflow_load_freezes_mcp),
]


def main() -> int:
    for name, fn in SCENARIOS:
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            print(f"FAIL {name}: {e}")
            traceback.print_exc()
            return 1
        print(f"PASS {name}")
    print(f"ALL PASS ({len(SCENARIOS)} scenarios)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
