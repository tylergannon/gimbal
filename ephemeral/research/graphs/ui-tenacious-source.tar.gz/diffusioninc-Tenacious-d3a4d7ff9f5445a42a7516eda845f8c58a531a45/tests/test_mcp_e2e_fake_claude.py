"""End-to-end test that `python -m tenacious` wires MCP into claude.

Strategy: spawn the real orchestrator entrypoint with TENACIOUS_HOME and PATH
pointed at a temp dir, where:
  * a fake `claude` shim records its argv (especially --mcp-config /
    --strict-mcp-config) and writes the expected next-step slug to
    outcome.txt, and
  * the auth bank holds a stub anthropic slot so magnetize_accounts can
    pick it without needing a real OAuth token.

Assertions exercise the four scenarios described in plan-current.md V-G3:

  - tenacious_invokes_claude_with_strict_flags
  - profile_dir_contains_mcp_servers_json
  - run_log_records_mcp_line
  - outcome_advances_workflow

Run from the project root:

    python3 tests/test_mcp_e2e_fake_claude.py
"""

from __future__ import annotations

import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import traceback
from pathlib import Path

_PROJECT_ROOT = Path(__file__).resolve().parent.parent


def _write_fake_claude(bin_dir: Path, capture_path: Path) -> Path:
    bin_dir.mkdir(parents=True, exist_ok=True)
    shim = bin_dir / "claude"
    shim.write_text(f"""#!{sys.executable}
import json, os, sys
record = {{"argv": sys.argv[1:], "cwd": os.getcwd(),
           "env": {{k: os.environ[k] for k in
                    ('CLAUDE_CONFIG_DIR', 'CLAUDE_CODE_OAUTH_TOKEN')
                    if k in os.environ}}}}
mcp_path = None
for i, a in enumerate(sys.argv):
    if a == '--mcp-config' and i + 1 < len(sys.argv):
        mcp_path = sys.argv[i + 1]
        break
if mcp_path:
    with open(mcp_path) as f:
        record['mcp_payload'] = json.load(f)
out_path = None
# Find the rendered prompt (the value after `-p`) and dig out the outcome.txt
# path from the orchestrator contract block embedded in it.
for i, a in enumerate(sys.argv):
    if a == '-p' and i + 1 < len(sys.argv):
        body = sys.argv[i + 1]
        marker = 'write the slug of the next step to:'
        idx = body.find(marker)
        if idx != -1:
            tail = body[idx + len(marker):].lstrip()
            line_end = tail.find('\\n')
            out_path = tail[:line_end].strip() if line_end != -1 else tail.strip()
        break
record['outcome_path'] = out_path
with open({str(capture_path)!r}, 'w') as f:
    json.dump(record, f, indent=2)
if out_path:
    with open(out_path, 'w') as f:
        f.write('end\\n')
sys.stdout.write(json.dumps({{'type': 'result', 'subtype': 'success',
                              'result': 'ok'}}) + '\\n')
sys.exit(0)
""")
    mode = shim.stat().st_mode
    shim.chmod(mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return shim


def _populate_auth_bank(home: Path) -> None:
    """Create a minimal anthropic slot so magnetize_accounts can pick one."""
    bank = home / "auth-bank" / "anthropic" / "fake"
    bank.mkdir(parents=True, exist_ok=True)
    (bank / "slot.txt").write_text("fake-token\n")


def _write_workflow(path: Path, mcp: dict) -> None:
    path.write_text(json.dumps({
        "goal": "g", "start_step": "s",
        "steps": {"s": {
            "agent": "claude", "prompt": "go do the thing",
            "next_steps": ["end"],
            "mcp_servers": mcp,
        }},
    }))


def _run_tenacious(home: Path, bin_dir: Path, wf_path: Path) -> tuple[int, str, str]:
    env = os.environ.copy()
    env["TENACIOUS_HOME"] = str(home)
    env["PATH"] = f"{bin_dir}:{env.get('PATH', '')}"
    r = subprocess.run(
        [sys.executable, "-m", "tenacious", str(wf_path)],
        cwd=str(_PROJECT_ROOT), env=env,
        capture_output=True, text=True, timeout=60,
    )
    return r.returncode, r.stdout, r.stderr


def _latest_run(home: Path) -> Path:
    runs = home / "runs"
    entries = sorted(p for p in runs.iterdir() if p.is_dir())
    if not entries:
        raise AssertionError(f"no runs created under {runs}")
    return entries[-1]


SERVERS = {
    "echo": {
        "command": "/bin/true",
        "args": ["hello"],
        "env": {"ECHO_PREFIX": "X:"},
    },
}


def _setup() -> tuple[Path, Path, Path, Path]:
    d = Path(tempfile.mkdtemp(prefix="tnc-e2e-claude-"))
    home = d / "home"
    bin_dir = d / "bin"
    home.mkdir()
    capture = d / "claude-args.json"
    _write_fake_claude(bin_dir, capture)
    _populate_auth_bank(home)
    wf = d / "wf.json"
    _write_workflow(wf, SERVERS)
    return d, home, bin_dir, wf, capture  # type: ignore[return-value]


def _go() -> dict:
    """Run the orchestrator once and return assert context."""
    d, home, bin_dir, wf, capture = _setup()
    rc, out, err = _run_tenacious(home, bin_dir, wf)
    return {"d": d, "home": home, "bin_dir": bin_dir, "wf": wf,
            "capture": capture, "rc": rc, "out": out, "err": err,
            "run_root": _latest_run(home) if (home / "runs").is_dir() else None}


def s_tenacious_invokes_claude_with_strict_flags() -> None:
    ctx = _go()
    try:
        assert ctx["rc"] == 0, (ctx["rc"], ctx["err"], ctx["out"])
        cap = json.loads(ctx["capture"].read_text())
        argv = cap["argv"]
        assert "--mcp-config" in argv, argv
        assert "--strict-mcp-config" in argv, argv
        idx = argv.index("--mcp-config")
        mcp_path = argv[idx + 1]
        assert os.path.isabs(mcp_path), mcp_path
        payload = json.loads(Path(mcp_path).read_text())
        assert payload["mcpServers"]["echo"]["command"] == "/bin/true", payload
        assert payload["mcpServers"]["echo"]["args"] == ["hello"], payload
        assert payload["mcpServers"]["echo"]["env"] == {"ECHO_PREFIX": "X:"}, payload
        assert payload["mcpServers"]["echo"]["type"] == "stdio", payload
    finally:
        shutil.rmtree(ctx["d"], ignore_errors=True)


def s_profile_dir_contains_mcp_servers_json() -> None:
    ctx = _go()
    try:
        run_root = ctx["run_root"]
        assert run_root is not None
        profile = run_root / "profiles" / "s" / "mcp-servers.json"
        assert profile.exists(), profile
        payload = json.loads(profile.read_text())
        assert "echo" in payload["mcpServers"], payload
    finally:
        shutil.rmtree(ctx["d"], ignore_errors=True)


def s_run_log_records_mcp_line() -> None:
    ctx = _go()
    try:
        log = (ctx["run_root"] / "run.log").read_text()
        assert "mcp_servers: 1 stdio (echo)" in log, log
    finally:
        shutil.rmtree(ctx["d"], ignore_errors=True)


def s_outcome_advances_workflow() -> None:
    ctx = _go()
    try:
        log = (ctx["run_root"] / "run.log").read_text()
        assert "workflow complete (end)" in log, log
        outcome = (ctx["run_root"] / "s" / "001" / "outcome.txt").read_text().strip()
        assert outcome == "end", outcome
    finally:
        shutil.rmtree(ctx["d"], ignore_errors=True)


SCENARIOS = [
    ("tenacious_invokes_claude_with_strict_flags",
     s_tenacious_invokes_claude_with_strict_flags),
    ("profile_dir_contains_mcp_servers_json",
     s_profile_dir_contains_mcp_servers_json),
    ("run_log_records_mcp_line", s_run_log_records_mcp_line),
    ("outcome_advances_workflow", s_outcome_advances_workflow),
]


def main() -> int:
    for name, fn in SCENARIOS:
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            print(f"FAIL {name}: {e}")
            traceback.print_exc()
            return 1
        print(f"PASS {name}")
    print(f"ALL PASS ({len(SCENARIOS)} scenarios)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
