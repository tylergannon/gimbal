"""End-to-end test that `python -m tenacious` materializes codex's config.toml.

Counterpart to test_mcp_e2e_fake_claude.py. The codex runner does not pass
flags for MCP — it relies on `$CODEX_HOME/config.toml` discovery — so the
acceptance is:

  - tenacious_writes_codex_config_toml   (the fake codex shim asserts on
    startup that $CODEX_HOME/config.toml exists and parses)
  - codex_toml_contains_declared_servers (parsed TOML round-trips back to
    the declared dict)
  - run_log_records_mcp_line             (run.log includes the
    `mcp_servers: ...` summary line)
  - outcome_advances_workflow            (the run reaches `end`)

Run from the project root:

    python3 tests/test_mcp_e2e_fake_codex.py
"""

from __future__ import annotations

import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import tomllib
import traceback
from pathlib import Path

_PROJECT_ROOT = Path(__file__).resolve().parent.parent


def _write_fake_codex(bin_dir: Path, capture_path: Path) -> Path:
    bin_dir.mkdir(parents=True, exist_ok=True)
    shim = bin_dir / "codex"
    shim.write_text(f"""#!{sys.executable}
import json, os, sys

home = os.environ.get('CODEX_HOME', '')
record = {{'argv': sys.argv[1:], 'CODEX_HOME': home,
           'config_toml_exists': False}}
if home:
    cfg = os.path.join(home, 'config.toml')
    record['config_toml_exists'] = os.path.isfile(cfg)
    if record['config_toml_exists']:
        with open(cfg) as f:
            record['config_toml'] = f.read()

# Find the outcome path embedded in the prompt argument. codex args look like:
#   exec --json --skip-git-repo-check ... --cd <dir> [--model M] <prompt>
# The prompt is the last positional arg (or follows `resume <tid>`).
prompt = sys.argv[-1] if sys.argv else ''
out_path = None
marker = 'write the slug of the next step to:'
idx = prompt.find(marker)
if idx != -1:
    tail = prompt[idx + len(marker):].lstrip()
    line_end = tail.find('\\n')
    out_path = tail[:line_end].strip() if line_end != -1 else tail.strip()
record['outcome_path'] = out_path

with open({str(capture_path)!r}, 'w') as f:
    json.dump(record, f, indent=2)

# Emit a fake `thread.started` so the codex runner sees a thread id.
sys.stdout.write(json.dumps({{
    'type': 'thread.started', 'thread_id': 'thr_fake_e2e'}}) + '\\n')
if out_path:
    with open(out_path, 'w') as f:
        f.write('end\\n')
sys.exit(0)
""")
    mode = shim.stat().st_mode
    shim.chmod(mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return shim


def _populate_auth_bank(home: Path) -> None:
    """Create a minimal openai slot so magnetize_accounts can pick one."""
    bank = home / "auth-bank" / "openai" / "fake"
    bank.mkdir(parents=True, exist_ok=True)
    (bank / "auth.json").write_text("{}\n")


def _write_workflow(path: Path, mcp: dict) -> None:
    path.write_text(json.dumps({
        "goal": "g", "start_step": "s",
        "steps": {"s": {
            "agent": "codex", "prompt": "go do the thing",
            "next_steps": ["end"],
            "mcp_servers": mcp,
        }},
    }))


def _run_tenacious(home: Path, bin_dir: Path, wf_path: Path) -> tuple[int, str, str]:
    env = os.environ.copy()
    env["TENACIOUS_HOME"] = str(home)
    env["PATH"] = f"{bin_dir}:{env.get('PATH', '')}"
    r = subprocess.run(
        [sys.executable, "-m", "tenacious", str(wf_path)],
        cwd=str(_PROJECT_ROOT), env=env,
        capture_output=True, text=True, timeout=60,
    )
    return r.returncode, r.stdout, r.stderr


def _latest_run(home: Path) -> Path:
    runs = home / "runs"
    entries = sorted(p for p in runs.iterdir() if p.is_dir())
    return entries[-1]


SERVERS = {
    "fs": {
        "command": "/usr/bin/echo",
        "args": ["one", "two"],
        "env": {"K1": "V1"},
    },
}


def _setup() -> tuple[Path, Path, Path, Path, Path]:
    d = Path(tempfile.mkdtemp(prefix="tnc-e2e-codex-"))
    home = d / "home"
    bin_dir = d / "bin"
    home.mkdir()
    capture = d / "codex-args.json"
    _write_fake_codex(bin_dir, capture)
    _populate_auth_bank(home)
    wf = d / "wf.json"
    _write_workflow(wf, SERVERS)
    return d, home, bin_dir, wf, capture


def _go() -> dict:
    d, home, bin_dir, wf, capture = _setup()
    rc, out, err = _run_tenacious(home, bin_dir, wf)
    return {"d": d, "home": home, "wf": wf, "capture": capture,
            "rc": rc, "out": out, "err": err,
            "run_root": _latest_run(home)}


def s_tenacious_writes_codex_config_toml() -> None:
    ctx = _go()
    try:
        assert ctx["rc"] == 0, (ctx["rc"], ctx["err"])
        cap = json.loads(ctx["capture"].read_text())
        assert cap["config_toml_exists"], cap
        # Profile dir on disk also has the file.
        cfg = ctx["run_root"] / "profiles" / "s" / "config.toml"
        assert cfg.exists(), cfg
    finally:
        shutil.rmtree(ctx["d"], ignore_errors=True)


def s_codex_toml_contains_declared_servers() -> None:
    ctx = _go()
    try:
        cfg = ctx["run_root"] / "profiles" / "s" / "config.toml"
        parsed = tomllib.loads(cfg.read_text())
        srv = parsed["mcp_servers"]["fs"]
        assert srv["command"] == "/usr/bin/echo", parsed
        assert srv["args"] == ["one", "two"], parsed
        assert srv["env"] == {"K1": "V1"}, parsed
    finally:
        shutil.rmtree(ctx["d"], ignore_errors=True)


def s_run_log_records_mcp_line() -> None:
    ctx = _go()
    try:
        log = (ctx["run_root"] / "run.log").read_text()
        assert "mcp_servers: 1 stdio (fs)" in log, log
    finally:
        shutil.rmtree(ctx["d"], ignore_errors=True)


def s_outcome_advances_workflow() -> None:
    ctx = _go()
    try:
        log = (ctx["run_root"] / "run.log").read_text()
        assert "workflow complete (end)" in log, log
    finally:
        shutil.rmtree(ctx["d"], ignore_errors=True)


SCENARIOS = [
    ("tenacious_writes_codex_config_toml",
     s_tenacious_writes_codex_config_toml),
    ("codex_toml_contains_declared_servers",
     s_codex_toml_contains_declared_servers),
    ("run_log_records_mcp_line", s_run_log_records_mcp_line),
    ("outcome_advances_workflow", s_outcome_advances_workflow),
]


def main() -> int:
    for name, fn in SCENARIOS:
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            print(f"FAIL {name}: {e}")
            traceback.print_exc()
            return 1
        print(f"PASS {name}")
    print(f"ALL PASS ({len(SCENARIOS)} scenarios)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
