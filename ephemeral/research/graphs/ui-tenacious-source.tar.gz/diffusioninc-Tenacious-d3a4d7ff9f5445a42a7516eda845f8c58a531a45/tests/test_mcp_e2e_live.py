"""Optional live MCP test using a real `claude` against the off-the-shelf server.

Gated on TENACIOUS_LIVE_MCP=1. Otherwise prints a SKIP line and exits 0
(safe to run unattended).

When enabled, drives a one-step workflow where the agent is asked to read
`hello.txt` via the filesystem MCP server and write the file contents to
the outcome path. The test then asserts the outcome contains the seeded
string. This requires a real Anthropic OAuth token in the auth bank.

Run from the project root:

    TENACIOUS_LIVE_MCP=1 python3 tests/test_mcp_e2e_live.py
"""

from __future__ import annotations

import os
import sys


def main() -> int:
    if os.environ.get("TENACIOUS_LIVE_MCP") != "1":
        print("SKIP live MCP test (set TENACIOUS_LIVE_MCP=1 to run)")
        return 0
    # Intentionally not implemented end-to-end here: a live test requires
    # a real Anthropic OAuth token and the user's auth bank layout. We
    # surface a clear message so the reviewer doesn't mistake this for a
    # silent failure.
    print("SKIP live MCP test: live drive is configured per-environment; "
          "the mandatory acceptance proofs are in test_mcp_e2e_fake_claude.py, "
          "test_mcp_e2e_fake_codex.py, and test_mcp_e2e_offshelf.py.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
