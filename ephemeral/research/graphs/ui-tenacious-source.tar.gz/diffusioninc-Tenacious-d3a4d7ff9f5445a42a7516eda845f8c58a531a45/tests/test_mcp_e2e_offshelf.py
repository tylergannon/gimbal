"""End-to-end acceptance test for the chosen off-the-shelf MCP server.

The chosen server is `@modelcontextprotocol/server-filesystem`, invoked as
`npx -y @modelcontextprotocol/server-filesystem <allowed-dir>`. Two
scenarios:

  - tenacious_materializes_offshelf_server — runs `python -m tenacious`
    against a workflow JSON declaring the off-the-shelf server, then
    asserts the claude profile dir contains the expected mcp-servers.json
    payload AND the orchestrator passed --mcp-config / --strict-mcp-config
    to the (fake) claude shim. Uses the fake-claude shim from
    test_mcp_e2e_fake_claude so we can run unattended without real
    Anthropic credentials.

  - offshelf_server_starts_and_initializes — spawns
    `npx -y @modelcontextprotocol/server-filesystem <sandbox>` directly
    from the test, performs an MCP `initialize` JSON-RPC handshake over
    stdio, and asserts the server answers with a sensible protocolVersion.
    This verifies the chosen server actually works as an MCP stdio server
    in this environment.

If `npx` is not on PATH, the script prints a single SKIP line and exits 0.

Run from the project root:

    python3 tests/test_mcp_e2e_offshelf.py
"""

from __future__ import annotations

import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import traceback
from pathlib import Path

_PROJECT_ROOT = Path(__file__).resolve().parent.parent


def _have_npx() -> bool:
    return shutil.which("npx") is not None


def _npx_path() -> str:
    p = shutil.which("npx")
    if p is None:
        raise RuntimeError("npx not found on PATH")
    return p


def _write_fake_claude(bin_dir: Path, capture_path: Path) -> Path:
    bin_dir.mkdir(parents=True, exist_ok=True)
    shim = bin_dir / "claude"
    shim.write_text(f"""#!{sys.executable}
import json, os, sys
record = {{'argv': sys.argv[1:]}}
mcp_path = None
for i, a in enumerate(sys.argv):
    if a == '--mcp-config' and i + 1 < len(sys.argv):
        mcp_path = sys.argv[i + 1]
        break
if mcp_path:
    with open(mcp_path) as f:
        record['mcp_payload'] = json.load(f)
out_path = None
for i, a in enumerate(sys.argv):
    if a == '-p' and i + 1 < len(sys.argv):
        body = sys.argv[i + 1]
        marker = 'write the slug of the next step to:'
        idx = body.find(marker)
        if idx != -1:
            tail = body[idx + len(marker):].lstrip()
            le = tail.find('\\n')
            out_path = tail[:le].strip() if le != -1 else tail.strip()
        break
with open({str(capture_path)!r}, 'w') as f:
    json.dump(record, f, indent=2)
if out_path:
    with open(out_path, 'w') as f:
        f.write('end\\n')
sys.exit(0)
""")
    mode = shim.stat().st_mode
    shim.chmod(mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return shim


def _populate_auth_bank(home: Path) -> None:
    bank = home / "auth-bank" / "anthropic" / "fake"
    bank.mkdir(parents=True, exist_ok=True)
    (bank / "slot.txt").write_text("fake-token\n")


def s_tenacious_materializes_offshelf_server() -> None:
    d = Path(tempfile.mkdtemp(prefix="tnc-e2e-offshelf-mat-"))
    try:
        home = d / "home"
        bin_dir = d / "bin"
        home.mkdir()
        capture = d / "claude-args.json"
        _write_fake_claude(bin_dir, capture)
        _populate_auth_bank(home)

        sandbox = d / "sandbox"
        sandbox.mkdir()
        (sandbox / "hello.txt").write_text("hello from mcp\n")

        wf = d / "wf.json"
        wf.write_text(json.dumps({
            "goal": "g", "start_step": "s",
            "steps": {"s": {
                "agent": "claude", "prompt": "use the MCP server",
                "next_steps": ["end"],
                "mcp_servers": {
                    "fs": {
                        "command": _npx_path(),
                        "args": ["-y",
                                 "@modelcontextprotocol/server-filesystem",
                                 str(sandbox)],
                    },
                },
            }},
        }))

        env = os.environ.copy()
        env["TENACIOUS_HOME"] = str(home)
        env["PATH"] = f"{bin_dir}:{env.get('PATH', '')}"
        r = subprocess.run(
            [sys.executable, "-m", "tenacious", str(wf)],
            cwd=str(_PROJECT_ROOT), env=env,
            capture_output=True, text=True, timeout=60,
        )
        assert r.returncode == 0, (r.returncode, r.stderr, r.stdout)

        cap = json.loads(capture.read_text())
        argv = cap["argv"]
        assert "--mcp-config" in argv, argv
        assert "--strict-mcp-config" in argv, argv
        payload = cap["mcp_payload"]
        fs = payload["mcpServers"]["fs"]
        assert fs["command"] == _npx_path(), fs
        assert fs["args"][0] == "-y", fs
        assert "@modelcontextprotocol/server-filesystem" in fs["args"], fs
        assert str(sandbox) in fs["args"], fs

        # Profile dir confirms the same.
        runs = sorted(p for p in (home / "runs").iterdir() if p.is_dir())
        profile = runs[-1] / "profiles" / "s" / "mcp-servers.json"
        assert profile.exists(), profile

        log = (runs[-1] / "run.log").read_text()
        assert "mcp_servers: 1 stdio (fs)" in log, log
    finally:
        shutil.rmtree(d, ignore_errors=True)


def s_offshelf_server_starts_and_initializes() -> None:
    """Spawn the real MCP filesystem server and run an `initialize` RPC.

    Times out generously to allow `npx` to download the package on its
    first run, but the response itself is small once the server is up.
    """
    d = Path(tempfile.mkdtemp(prefix="tnc-mcp-offshelf-init-"))
    try:
        sandbox = d / "sandbox"
        sandbox.mkdir()
        (sandbox / "hello.txt").write_text("hello from mcp\n")

        proc = subprocess.Popen(
            [_npx_path(), "-y", "@modelcontextprotocol/server-filesystem",
             str(sandbox)],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, bufsize=1,
        )
        try:
            init = {
                "jsonrpc": "2.0", "id": 1, "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {"name": "tenacious-mcp-test",
                                   "version": "0.1.0"},
                },
            }
            proc.stdin.write(json.dumps(init) + "\n")
            proc.stdin.flush()

            import select
            deadline_total = 120.0  # generous for npx first-fetch
            deadline = deadline_total
            response = None
            buffered = ""
            t_start = __import__("time").time()
            while True:
                remaining = deadline - (__import__("time").time() - t_start)
                if remaining <= 0:
                    raise AssertionError(
                        "no initialize response within "
                        f"{deadline_total}s; stderr tail: "
                        f"{proc.stderr.read(2000) if proc.stderr else ''!r}")
                rlist, _, _ = select.select([proc.stdout], [], [],
                                            min(2.0, remaining))
                if not rlist:
                    continue
                chunk = proc.stdout.readline()
                if not chunk:
                    raise AssertionError(
                        "server closed stdout before responding; "
                        f"stderr: {proc.stderr.read(2000)!r}")
                buffered += chunk
                # Servers may emit log lines before the JSON response. Try
                # to parse each complete line.
                for line in buffered.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if isinstance(obj, dict) and obj.get("id") == 1:
                        response = obj
                        break
                if response is not None:
                    break
            assert "result" in response, response
            result = response["result"]
            assert "protocolVersion" in result, result
            assert "capabilities" in result, result
        finally:
            try:
                proc.stdin.close()
            except Exception:
                pass
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=5)
    finally:
        shutil.rmtree(d, ignore_errors=True)


SCENARIOS = [
    ("tenacious_materializes_offshelf_server",
     s_tenacious_materializes_offshelf_server),
    ("offshelf_server_starts_and_initializes",
     s_offshelf_server_starts_and_initializes),
]


def main() -> int:
    if not _have_npx():
        print("SKIP off-the-shelf MCP E2E (npx not found)")
        return 0
    for name, fn in SCENARIOS:
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            print(f"FAIL {name}: {e}")
            traceback.print_exc()
            return 1
        print(f"PASS {name}")
    print(f"ALL PASS ({len(SCENARIOS)} scenarios)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
