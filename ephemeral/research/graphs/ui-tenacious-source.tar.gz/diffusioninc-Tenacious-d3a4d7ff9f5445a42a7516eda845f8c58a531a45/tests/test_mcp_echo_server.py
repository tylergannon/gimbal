"""Drive the in-repo echo MCP fixture over stdio and verify framing/tools.

Stdlib only. Spawns the fixture as a subprocess with stdio pipes and
exchanges newline-delimited JSON-RPC 2.0 messages, then asserts the
expected handshake/tools behavior. Used to validate the fixture itself
(so the orchestrator E2E tests can rely on it without surprises) and
indirectly to confirm the NDJSON framing we describe in the docs is
correct.

Run from the project root:

    python3 tests/test_mcp_echo_server.py
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import traceback
from pathlib import Path


_PROJECT_ROOT = Path(__file__).resolve().parent.parent
_FIXTURE = _PROJECT_ROOT / "tests" / "_mcp_servers" / "echo_server.py"


class EchoClient:
    """Minimal NDJSON JSON-RPC client tied to a spawned echo_server.py."""

    def __init__(self, env: dict[str, str] | None = None):
        env_ = os.environ.copy()
        if env:
            env_.update(env)
        self.proc = subprocess.Popen(
            [sys.executable, str(_FIXTURE)],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, env=env_, text=True, bufsize=1,
        )
        self._next_id = 1

    def call(self, method: str, params: dict | None = None,
             req_id: int | str | None = None) -> dict:
        if req_id is None:
            req_id = self._next_id
            self._next_id += 1
        msg = {"jsonrpc": "2.0", "id": req_id, "method": method}
        if params is not None:
            msg["params"] = params
        self.proc.stdin.write(json.dumps(msg) + "\n")
        self.proc.stdin.flush()
        line = self.proc.stdout.readline()
        if not line:
            raise RuntimeError(
                f"server closed stdout; stderr={self.proc.stderr.read()!r}")
        return json.loads(line)

    def send_raw(self, raw: str) -> None:
        self.proc.stdin.write(raw)
        self.proc.stdin.flush()

    def close(self) -> None:
        try:
            self.proc.stdin.close()
        except Exception:
            pass
        try:
            self.proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self.proc.kill()
            self.proc.wait(timeout=5)


def s_initialize_returns_protocol_version() -> None:
    c = EchoClient()
    try:
        resp = c.call("initialize", {"protocolVersion": "2024-11-05",
                                     "capabilities": {}})
        assert resp.get("id") == 1, resp
        result = resp.get("result")
        assert isinstance(result, dict), resp
        assert result.get("protocolVersion") == "2024-11-05", result
        assert "capabilities" in result, result
    finally:
        c.close()


def s_tools_list_has_echo() -> None:
    c = EchoClient()
    try:
        c.call("initialize", {"protocolVersion": "2024-11-05",
                              "capabilities": {}})
        resp = c.call("tools/list")
        tools = resp["result"]["tools"]
        names = [t["name"] for t in tools]
        assert "echo" in names, names
    finally:
        c.close()


def s_tools_call_echo_roundtrip() -> None:
    c = EchoClient()
    try:
        c.call("initialize", {"protocolVersion": "2024-11-05",
                              "capabilities": {}})
        resp = c.call("tools/call",
                      {"name": "echo", "arguments": {"text": "hello"}})
        content = resp["result"]["content"]
        assert content[0]["text"] == "hello", content
    finally:
        c.close()


def s_tools_call_echo_with_prefix_env() -> None:
    c = EchoClient(env={"ECHO_PREFIX": "PFX:"})
    try:
        c.call("initialize", {"protocolVersion": "2024-11-05",
                              "capabilities": {}})
        resp = c.call("tools/call",
                      {"name": "echo", "arguments": {"text": "world"}})
        text = resp["result"]["content"][0]["text"]
        assert text == "PFX:world", text
    finally:
        c.close()


def s_unknown_method_returns_error() -> None:
    c = EchoClient()
    try:
        resp = c.call("does/not/exist", {})
        err = resp.get("error")
        assert err and err.get("code") == -32601, resp
    finally:
        c.close()


def s_bad_json_does_not_crash() -> None:
    c = EchoClient()
    try:
        # Send a malformed line, then a valid request. The server must
        # swallow the garbage and still answer the valid one.
        c.send_raw("not-json\n")
        resp = c.call("initialize", {"protocolVersion": "2024-11-05",
                                     "capabilities": {}})
        assert "result" in resp, resp
    finally:
        c.close()


SCENARIOS = [
    ("initialize_returns_protocol_version",
     s_initialize_returns_protocol_version),
    ("tools_list_has_echo", s_tools_list_has_echo),
    ("tools_call_echo_roundtrip", s_tools_call_echo_roundtrip),
    ("tools_call_echo_with_prefix_env", s_tools_call_echo_with_prefix_env),
    ("unknown_method_returns_error", s_unknown_method_returns_error),
    ("bad_json_does_not_crash", s_bad_json_does_not_crash),
]


def main() -> int:
    for name, fn in SCENARIOS:
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            print(f"FAIL {name}: {e}")
            traceback.print_exc()
            return 1
        print(f"PASS {name}")
    print(f"ALL PASS ({len(SCENARIOS)} scenarios)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
