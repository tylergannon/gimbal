"""Acceptance test for round 3: every step in every shipped workflow
inherits the asset-before-outcome ordering rule via the orchestrator
contract block.

Loads 6step.yaml and iterative.yaml, builds a minimal in-memory Run,
and asserts that both render_prompt() and render_continuation_prompt()
include the new WRITE ORDER semantic markers - covering the persistence
concept, the asset-write-failure clause, and the question-path ordering
tokens - for every step.

Markers are deliberately chosen to be small, stable substrings so that
harmless prose changes do not break the test, while still proving the
required semantics. Per the round-3 plan:

  - 'outcome.txt'   - the file the rule is about
  - 'LAST'          - the ordering anchor
  - 'fully written' - the persistence concept (assets flushed first)
  - 'do NOT write'  - the asset-write-failure clause
  - 'question.txt'  - question-path ordering target
  - "'question'"    - the literal outcome value used on the question path

Stdlib only. Sibling style to tests/test_sigint_clean_exit.py.
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

_THIS = Path(__file__).resolve()
_PROJECT_ROOT = _THIS.parent.parent

if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from tenacious.orchestrator import (  # noqa: E402
    Run,
    Workflow,
    render_continuation_prompt,
    render_prompt,
)

_WORKFLOW_FILES = ("6step.yaml", "iterative.yaml")

# Semantic markers - see module docstring.
_REQUIRED_MARKERS = (
    "outcome.txt",
    "LAST",
    "fully written",
    "do NOT write",
    "question.txt",
    "'question'",
)


def _fail(detail: str) -> int:
    print(f"FAIL outcome_last: {detail}")
    return 1


def _make_run(workflow: Workflow, tmpdir: Path) -> Run:
    assets = tmpdir / "assets"
    profiles = tmpdir / "profiles"
    assets.mkdir(parents=True, exist_ok=True)
    profiles.mkdir(parents=True, exist_ok=True)
    return Run(
        slug="outcome-last-test",
        root=tmpdir,
        workflow=workflow,
        project_dir=tmpdir,
    )


def _check_prompt(label: str, rendered: str) -> str | None:
    for marker in _REQUIRED_MARKERS:
        if marker not in rendered:
            return (
                f"{label}: rendered prompt missing required marker "
                f"{marker!r}"
            )
    return None


def _part_first_visit_prompts() -> int:
    for wf_name in _WORKFLOW_FILES:
        wf_path = _PROJECT_ROOT / "workflows" / wf_name
        if not wf_path.is_file():
            return _fail(f"workflow file missing: {wf_path}")
        wf = Workflow.load(wf_path)
        with tempfile.TemporaryDirectory() as td_str:
            td = Path(td_str)
            run = _make_run(wf, td)
            for slug, step in wf.steps.items():
                sd = run.step_dir(slug, 1)
                sd.mkdir(parents=True, exist_ok=True)
                rendered = render_prompt(step, run, sd)
                err = _check_prompt(
                    f"first-visit {wf_name}:{slug}", rendered
                )
                if err is not None:
                    return _fail(err)
    return 0


def _part_continuation_prompts() -> int:
    for wf_name in _WORKFLOW_FILES:
        wf = Workflow.load(_PROJECT_ROOT / "workflows" / wf_name)
        with tempfile.TemporaryDirectory() as td_str:
            td = Path(td_str)
            run = _make_run(wf, td)
            for slug, step in wf.steps.items():
                sd = run.step_dir(slug, 2)
                sd.mkdir(parents=True, exist_ok=True)
                rendered = render_continuation_prompt(
                    step, run, sd,
                    question="placeholder question?",
                    answer="placeholder answer",
                )
                err = _check_prompt(
                    f"continuation {wf_name}:{slug}", rendered
                )
                if err is not None:
                    return _fail(err)
                if "placeholder question?" not in rendered:
                    return _fail(
                        f"continuation {wf_name}:{slug}: rendered "
                        f"prompt did not contain the supplied question "
                        f"text"
                    )
    return 0


def main() -> int:
    for part in (_part_first_visit_prompts, _part_continuation_prompts):
        rc = part()
        if rc != 0:
            return rc
    print("PASS outcome_last")
    return 0


if __name__ == "__main__":
    sys.exit(main())
