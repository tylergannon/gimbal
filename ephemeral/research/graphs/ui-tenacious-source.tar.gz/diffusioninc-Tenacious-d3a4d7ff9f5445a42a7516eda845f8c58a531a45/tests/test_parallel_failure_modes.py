"""In-process unit tests of the three substep-failure detection branches.

Stdlib only. No real `claude` is spawned: AGENT_RUNNERS is patched to a
stub that writes exactly the outcome/exit pattern each scenario needs.
Exercises:
  1. non-zero exit (even with a valid '__substep_done__' outcome)
  2. missing outcome.txt
  3. outcome.txt contents != sentinel
  4. cancelled siblings are NOT reported as the originating failure

Run from the project root:

    python3 tests/test_parallel_failure_modes.py
"""

from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
import threading
import traceback
import time
from contextlib import contextmanager
from pathlib import Path

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import tenacious.orchestrator as o  # noqa: E402


class Patcher:
    def __init__(self) -> None:
        self._saved: list[tuple[object, str, object]] = []

    def set(self, obj, attr, value):
        self._saved.append((obj, attr, getattr(obj, attr)))
        setattr(obj, attr, value)

    def undo(self) -> None:
        for obj, attr, value in reversed(self._saved):
            setattr(obj, attr, value)
        self._saved.clear()


@contextmanager
def home_env():
    d = Path(tempfile.mkdtemp(prefix="tnc-pfm-"))
    prev = os.environ.get("TENACIOUS_HOME")
    os.environ["TENACIOUS_HOME"] = str(d)
    (d / "proj").mkdir(parents=True, exist_ok=True)
    try:
        yield d
    finally:
        if prev is None:
            os.environ.pop("TENACIOUS_HOME", None)
        else:
            os.environ["TENACIOUS_HOME"] = prev
        shutil.rmtree(d, ignore_errors=True)


def _composite_wf(home: Path) -> dict:
    return {
        "goal": "g",
        "project_dir": str(home / "proj"),
        "start_step": "fan",
        "steps": {
            "fan": {
                "parallel": True,
                "next_steps": ["join"],
                "substeps": {
                    "a": {"agent": "fake", "prompt": "p"},
                    "b": {"agent": "fake", "prompt": "p"},
                    "c": {"agent": "fake", "prompt": "p"},
                },
            },
            "join": {
                "agent": "fake",
                "prompt": "p",
                "next_steps": ["end"],
            },
        },
    }


def _build_run(home: Path) -> tuple[o.Run, o.Step]:
    wfp = home / "wf.json"
    wfp.write_text(json.dumps(_composite_wf(home)))
    wf = o.Workflow.load(wfp)
    root = home / "runs" / "r1"
    (root / "assets").mkdir(parents=True)
    return (
        o.Run(slug="r1", root=root, workflow=wf,
              project_dir=home / "proj"),
        wf.steps["fan"],
    )


def _make_runner(plan: dict[str, dict]):
    """plan[sub_slug] = {'outcome': str|None, 'exit': int, 'delay': float}."""

    def runner(step, run, visit, step_dir, prompt, should_continue,
               composite_parent=None, cancel_event=None):
        spec = plan[step.slug]
        delay = spec.get("delay", 0.0)
        if delay > 0:
            deadline = time.time() + delay
            while time.time() < deadline:
                if cancel_event is not None and cancel_event.is_set():
                    return {"exit": -15, "stdout": "", "stderr": "cancelled",
                            "cancelled": True}
                time.sleep(0.02)
        oc = spec.get("outcome")
        if oc is not None:
            (step_dir / "outcome.txt").write_text(oc)
        return {"exit": spec["exit"], "stdout": "", "stderr": ""}

    return runner


def nonzero_exit_with_valid_outcome_still_fails() -> None:
    p = Patcher()
    try:
        with home_env() as home:
            run, fan = _build_run(home)
            plan = {
                "a": {"outcome": o.SUBSTEP_DONE_SENTINEL, "exit": 0},
                "b": {"outcome": o.SUBSTEP_DONE_SENTINEL, "exit": 7},
                "c": {"outcome": o.SUBSTEP_DONE_SENTINEL, "exit": 0,
                      "delay": 0.3},
            }
            p.set(o, "AGENT_RUNNERS", {"fake": _make_runner(plan)})
            try:
                o.execute_composite(fan, "fan", run)
            except RuntimeError as e:
                assert "fan" in str(e) and "b " in str(e) \
                    and "non-zero exit 7" in str(e), str(e)
            else:
                raise AssertionError(
                    "execute_composite did not raise on non-zero exit")
            meta = json.loads(
                (run.root / "fan" / "001" / "meta.json").read_text())
            assert meta["failed_substep"] == "b", meta
            assert not (run.root / "fan" / "001" / "outcome.txt").exists(), (
                "parent outcome.txt should not exist on failure")
    finally:
        p.undo()


def missing_outcome_after_grace_fails() -> None:
    p = Patcher()
    try:
        with home_env() as home:
            run, fan = _build_run(home)
            plan = {
                "a": {"outcome": o.SUBSTEP_DONE_SENTINEL, "exit": 0},
                "b": {"outcome": None, "exit": 0},   # exit 0, no outcome
                "c": {"outcome": o.SUBSTEP_DONE_SENTINEL, "exit": 0,
                      "delay": 0.3},
            }
            p.set(o, "AGENT_RUNNERS", {"fake": _make_runner(plan)})
            try:
                o.execute_composite(fan, "fan", run)
            except RuntimeError as e:
                assert "missing outcome.txt after grace" in str(e), str(e)
            else:
                raise AssertionError(
                    "execute_composite did not raise on missing outcome")
            meta = json.loads(
                (run.root / "fan" / "001" / "meta.json").read_text())
            assert meta["failed_substep"] == "b", meta
    finally:
        p.undo()


def outcome_not_sentinel_fails() -> None:
    p = Patcher()
    try:
        with home_env() as home:
            run, fan = _build_run(home)
            plan = {
                "a": {"outcome": o.SUBSTEP_DONE_SENTINEL, "exit": 0},
                "b": {"outcome": "NOPE", "exit": 0},
                "c": {"outcome": o.SUBSTEP_DONE_SENTINEL, "exit": 0,
                      "delay": 0.3},
            }
            p.set(o, "AGENT_RUNNERS", {"fake": _make_runner(plan)})
            try:
                o.execute_composite(fan, "fan", run)
            except RuntimeError as e:
                assert "'NOPE'" in str(e) and "!= sentinel" in str(e), str(e)
            else:
                raise AssertionError(
                    "execute_composite did not raise on wrong outcome")
            meta = json.loads(
                (run.root / "fan" / "001" / "meta.json").read_text())
            assert meta["failed_substep"] == "b", meta
    finally:
        p.undo()


def sibling_cancellation_does_not_count_as_root_failure() -> None:
    p = Patcher()
    try:
        with home_env() as home:
            run, fan = _build_run(home)
            plan = {
                # 'b' fails immediately; 'a' and 'c' sleep long enough that
                # the cancel_event will be set before they finish.
                "a": {"outcome": o.SUBSTEP_DONE_SENTINEL, "exit": 0,
                      "delay": 5.0},
                "b": {"outcome": "NOPE", "exit": 0},
                "c": {"outcome": o.SUBSTEP_DONE_SENTINEL, "exit": 0,
                      "delay": 5.0},
            }
            p.set(o, "AGENT_RUNNERS", {"fake": _make_runner(plan)})
            try:
                o.execute_composite(fan, "fan", run)
            except RuntimeError as e:
                msg = str(e)
                # The originating failure must be 'b', not 'a' or 'c'.
                assert " b " in msg, (
                    f"originating failure should be substep 'b': {msg}")
                assert "'NOPE'" in msg, msg
            else:
                raise AssertionError("did not raise on sibling cancellation")
            for sib in ("a", "c"):
                meta = json.loads(
                    (run.root / "fan" / "001" / sib / "001"
                     / "meta.json").read_text())
                assert meta["cancelled"] is True, (sib, meta)
    finally:
        p.undo()


SCENARIOS = [
    ("nonzero_exit_with_valid_outcome_still_fails",
     nonzero_exit_with_valid_outcome_still_fails),
    ("missing_outcome_after_grace_fails",
     missing_outcome_after_grace_fails),
    ("outcome_not_sentinel_fails", outcome_not_sentinel_fails),
    ("sibling_cancellation_does_not_count_as_root_failure",
     sibling_cancellation_does_not_count_as_root_failure),
]


def main() -> int:
    for name, fn in SCENARIOS:
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            print(f"FAIL {name}: {e}")
            traceback.print_exc()
            return 1
        print(f"PASS {name}")
    print(f"ALL PASS ({len(SCENARIOS)} scenarios)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
