"""Parallel substep — load-time schema validation.

Stdlib only. Hermetic: pure `Workflow.load(...)` assertions; no `claude`,
no run dirs. Each scenario loads a malformed fixture and asserts the
raised `ValueError`'s message contains the exact substring documented
in the plan.

Run from the project root:

    python3 tests/test_parallel_load_errors.py
"""

from __future__ import annotations

import os
import sys
import traceback
from pathlib import Path

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from tenacious.orchestrator import Workflow  # noqa: E402

_FIX = Path(_PROJECT_ROOT) / "tests" / "fixtures"


def _expect_load_error(fixture: str, needle: str) -> None:
    path = _FIX / fixture
    try:
        Workflow.load(path)
    except ValueError as e:
        msg = str(e)
        assert needle in msg, (
            f"expected substring not in error.\n"
            f"  expected substring: {needle!r}\n"
            f"  actual message:     {msg!r}"
        )
        return
    raise AssertionError(f"{fixture} loaded without raising ValueError")


def bad_parent_agent() -> None:
    _expect_load_error(
        "parallel-bad-parent-agent.json",
        "step research-multi: a parallel composite step must not declare "
        "its own 'agent' field",
    )


def bad_parent_prompt() -> None:
    _expect_load_error(
        "parallel-bad-parent-prompt.json",
        "step research-multi: a parallel composite step must not declare "
        "its own 'prompt' field",
    )


def bad_parent_multi_next() -> None:
    _expect_load_error(
        "parallel-bad-parent-multi-next.json",
        "step research-multi: a parallel composite step must declare "
        "exactly one next_steps entry, got 2",
    )


def bad_empty_substeps() -> None:
    _expect_load_error(
        "parallel-bad-empty-substeps.json",
        "step research-multi: a parallel composite step must declare a "
        "non-empty substeps map",
    )


def bad_parent_extra_field() -> None:
    _expect_load_error(
        "parallel-bad-parent-extra-field.json",
        "step research-multi: a parallel composite step must not declare "
        "'model' (composites have no agent/prompt of their own)",
    )


def bad_substep_next() -> None:
    _expect_load_error(
        "parallel-bad-substep-next.json",
        "step research-multi.find-facts: substep must not declare "
        "'next_steps'",
    )


def bad_substep_parallel() -> None:
    _expect_load_error(
        "parallel-bad-substep-parallel.json",
        "step research-multi.find-facts: substep must not declare 'parallel'",
    )


def bad_substep_questions() -> None:
    _expect_load_error(
        "parallel-bad-substep-questions.json",
        "step research-multi.find-facts: substep must not declare "
        "'questions: true' (substeps cannot interact with the user this round)",
    )


def bad_substep_unknown_key() -> None:
    _expect_load_error(
        "parallel-bad-substep-unknown-key.json",
        "step research-multi.find-facts: substep declares unknown field "
        "'foo'; allowed fields are agent, asset_slugs, assets, context, "
        "mcp_servers, model, prompt",
    )


SCENARIOS = [
    ("bad_parent_agent", bad_parent_agent),
    ("bad_parent_prompt", bad_parent_prompt),
    ("bad_parent_multi_next", bad_parent_multi_next),
    ("bad_empty_substeps", bad_empty_substeps),
    ("bad_parent_extra_field", bad_parent_extra_field),
    ("bad_substep_next", bad_substep_next),
    ("bad_substep_parallel", bad_substep_parallel),
    ("bad_substep_questions", bad_substep_questions),
    ("bad_substep_unknown_key", bad_substep_unknown_key),
]


def main() -> int:
    for name, fn in SCENARIOS:
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            print(f"FAIL {name}: {e}")
            traceback.print_exc()
            return 1
        print(f"PASS {name}")
    print(f"ALL PASS ({len(SCENARIOS)} scenarios)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
