"""Parallel substep — red `FYI:` warning behavior at load and runtime.

Stdlib only. Hermetic: no claude is invoked; the load-time warning is
exercised via `_emit_parallel_load_warnings` directly, the runtime
warning via `_emit_runtime_parallel_warning` against an in-process
`Run`. The "emitted exactly once per entry-point" scenario is a
subprocess scenario that drives `execute_workflow` end-to-end on a
fake-agent fixture so no real `claude` is reached, then counts the
load-time line in stdout.

Run from the project root:

    python3 tests/test_parallel_warnings.py
"""

from __future__ import annotations

import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import traceback
from contextlib import contextmanager
from pathlib import Path

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import tenacious.orchestrator as o  # noqa: E402
from tenacious import term_color as tc  # noqa: E402


@contextmanager
def env(**kwargs):
    saved: dict[str, str | None] = {}
    for k, v in kwargs.items():
        saved[k] = os.environ.get(k)
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    try:
        yield
    finally:
        for k, v in saved.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


class _TtyStream(io.StringIO):
    """A StringIO that reports as a TTY for color_enabled()."""

    def isatty(self) -> bool:
        return True


_RESEARCH_MULTI = Path(_PROJECT_ROOT) / "research-multi.json"


def load_warning_plain_text_without_color() -> None:
    with env(NO_COLOR="1", TENACIOUS_COLOR=None):
        buf = _TtyStream()
        wf = o.Workflow.load(_RESEARCH_MULTI)
        o._emit_parallel_load_warnings(wf, buf)
        out = buf.getvalue()
        assert "\x1b[" not in out, f"ANSI bytes present: {out!r}"
        expected = (
            "FYI: workflow declares 1 parallel composite step(s): "
            "research-multi (substeps: find-anecdotes, find-facts, "
            "find-predictions). Each invocation will draw 3x from the "
            "auth bank."
        )
        assert expected in out, f"missing expected line: {out!r}"


def load_warning_colored_with_tenacious_color() -> None:
    with env(NO_COLOR=None, TENACIOUS_COLOR="1"):
        buf = _TtyStream()
        wf = o.Workflow.load(_RESEARCH_MULTI)
        o._emit_parallel_load_warnings(wf, buf)
        out = buf.getvalue()
        assert "\x1b[1m\x1b[31mFYI: workflow declares 1 parallel " \
            "composite step(s):" in out, f"missing bold-red prefix: {out!r}"


def load_warning_no_color_wins() -> None:
    with env(NO_COLOR="1", TENACIOUS_COLOR="1"):
        buf = _TtyStream()
        wf = o.Workflow.load(_RESEARCH_MULTI)
        o._emit_parallel_load_warnings(wf, buf)
        out = buf.getvalue()
        assert "\x1b[" not in out, (
            f"NO_COLOR=1 lost to TENACIOUS_COLOR=1: {out!r}"
        )
        assert "FYI: workflow declares 1 parallel composite step(s):" in \
            out, f"missing plain prefix: {out!r}"


def _fake_workflow_dict(home: Path) -> dict:
    return {
        "goal": "g",
        "project_dir": str(home / "proj"),
        "start_step": "fan",
        "steps": {
            "fan": {
                "parallel": True,
                "next_steps": ["join"],
                "substeps": {
                    "a": {"agent": "fake", "prompt": "p"},
                    "b": {"agent": "fake", "prompt": "p"},
                    "c": {"agent": "fake", "prompt": "p"},
                },
            },
            "join": {
                "agent": "fake",
                "prompt": "p",
                "next_steps": ["end"],
            },
        },
    }


def load_warning_emitted_once() -> None:
    # Drive execute_workflow in a subprocess that monkey-patches
    # AGENT_RUNNERS to a no-claude fake. Count the load-time line in
    # stdout — must be exactly 1.
    home = Path(tempfile.mkdtemp(prefix="tnc-warn-once-"))
    try:
        (home / "proj").mkdir()
        wfp = home / "wf.json"
        wfp.write_text(json.dumps(_fake_workflow_dict(home)))

        driver = f"""
import os, sys
sys.path.insert(0, {_PROJECT_ROOT!r})
import tenacious.orchestrator as o
def fake_runner(step, run, visit, step_dir, prompt, should_continue,
                composite_parent=None, cancel_event=None):
    if step.slug in ('a','b','c'):
        (step_dir / 'outcome.txt').write_text(o.SUBSTEP_DONE_SENTINEL)
    else:
        nxt = step.next_steps[0] if step.next_steps else 'end'
        (step_dir / 'outcome.txt').write_text(nxt)
    return {{'exit': 0, 'stdout': '', 'stderr': ''}}
o.AGENT_RUNNERS = {{'fake': fake_runner}}
o._magnetize_accounts = lambda slug, wf, **_kw: {{}}
o.execute_workflow(__import__('pathlib').Path({str(wfp)!r}))
"""
        env_subp = os.environ.copy()
        env_subp["TENACIOUS_HOME"] = str(home / "tnc")
        env_subp["NO_COLOR"] = "1"
        env_subp.pop("TENACIOUS_COLOR", None)
        env_subp["PYTHONPATH"] = (
            f"{_PROJECT_ROOT}{os.pathsep}{env_subp.get('PYTHONPATH','')}"
        )
        out = subprocess.run(
            [sys.executable, "-c", driver],
            capture_output=True, text=True, env=env_subp, timeout=120,
        )
        assert out.returncode == 0, (
            f"subprocess failed rc={out.returncode}\n"
            f"stdout:\n{out.stdout}\nstderr:\n{out.stderr}"
        )
        count = out.stdout.count("FYI: workflow declares ")
        assert count == 1, (
            f"expected exactly 1 load-time FYI; got {count}\n"
            f"stdout:\n{out.stdout}"
        )
    finally:
        shutil.rmtree(home, ignore_errors=True)


def _build_run_with_composite(tmp: Path) -> tuple[o.Run, o.Step]:
    wf_dict = _fake_workflow_dict(tmp)
    wfp = tmp / "wf.json"
    wfp.write_text(json.dumps(wf_dict))
    wf = o.Workflow.load(wfp)
    root = tmp / "runroot"
    (root / "assets").mkdir(parents=True)
    run = o.Run(slug="r", root=root, workflow=wf,
                project_dir=tmp / "proj")
    return run, wf.steps["fan"]


def runtime_fyi_colored_on_tty() -> None:
    tmp = Path(tempfile.mkdtemp(prefix="tnc-warn-rt-"))
    try:
        with env(NO_COLOR=None, TENACIOUS_COLOR="1"):
            run, fan = _build_run_with_composite(tmp)
            buf = _TtyStream()
            saved_stdout = sys.stdout
            sys.stdout = buf
            try:
                o._emit_runtime_parallel_warning(run, "fan", fan)
            finally:
                sys.stdout = saved_stdout
            out = buf.getvalue()
            assert "\x1b[1m\x1b[31mFYI: launching parallel composite fan" \
                in out, f"missing bold-red runtime FYI: {out!r}"
            # Plain-text copy in run.log (no ANSI ever in the file).
            log_text = (run.root / "run.log").read_text()
            assert "FYI: launching parallel composite fan with 3 substep" \
                in log_text, f"run.log missing line: {log_text!r}"
            assert "\x1b[" not in log_text, (
                f"run.log unexpectedly contains ANSI: {log_text!r}"
            )
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def runtime_fyi_plain_under_no_color() -> None:
    tmp = Path(tempfile.mkdtemp(prefix="tnc-warn-rt-nc-"))
    try:
        with env(NO_COLOR="1", TENACIOUS_COLOR=None):
            run, fan = _build_run_with_composite(tmp)
            buf = _TtyStream()
            saved_stdout = sys.stdout
            sys.stdout = buf
            try:
                o._emit_runtime_parallel_warning(run, "fan", fan)
            finally:
                sys.stdout = saved_stdout
            out = buf.getvalue()
            assert "\x1b[" not in out, (
                f"NO_COLOR=1 lost: {out!r}"
            )
            assert "FYI: launching parallel composite fan with 3 substep" \
                in out, f"missing plain runtime FYI: {out!r}"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


SCENARIOS = [
    ("load_warning_plain_text_without_color",
     load_warning_plain_text_without_color),
    ("load_warning_colored_with_tenacious_color",
     load_warning_colored_with_tenacious_color),
    ("load_warning_no_color_wins", load_warning_no_color_wins),
    ("load_warning_emitted_once", load_warning_emitted_once),
    ("runtime_fyi_colored_on_tty", runtime_fyi_colored_on_tty),
    ("runtime_fyi_plain_under_no_color", runtime_fyi_plain_under_no_color),
]


def main() -> int:
    for name, fn in SCENARIOS:
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            print(f"FAIL {name}: {e}")
            traceback.print_exc()
            return 1
        print(f"PASS {name}")
    print(f"ALL PASS ({len(SCENARIOS)} scenarios)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
