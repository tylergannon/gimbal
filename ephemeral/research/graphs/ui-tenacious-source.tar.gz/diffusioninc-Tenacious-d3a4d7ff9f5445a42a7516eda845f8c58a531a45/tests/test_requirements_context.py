"""Bug 2 (Round 2): requirements step `context` must be "empty".

Stdlib only. Creates its own temp dirs. Drives the real `execute_step`
with a scripted fake "agent" runner.

  1. the shipped 6step.yaml sets steps.requirements.context == "empty";
  2. the in-round question -> answer continuation loop is unaffected by
     context="empty" (first visit fresh, continuation visit continued);
  3. re-entering the same context="empty" step (a later round's first
     requirements visit) is FRESH, not a stale-session resume — the
     precise interference leaving it "continue" caused.

Run from the project root:

    .venv/bin/python tests/test_requirements_context.py

Prints `PASS <scenario>` per scenario then `ALL PASS (<n> scenarios)`;
exits 0 if all pass, 1 with `FAIL <scenario>: <detail>` otherwise.
"""

from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
import traceback
from contextlib import contextmanager
from pathlib import Path

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import tenacious.orchestrator as o  # noqa: E402


class Patcher:
    def __init__(self):
        self._saved = []

    def set(self, obj, attr, value):
        self._saved.append((obj, attr, getattr(obj, attr)))
        setattr(obj, attr, value)

    def undo(self):
        for obj, attr, value in reversed(self._saved):
            setattr(obj, attr, value)
        self._saved.clear()


@contextmanager
def temp_run():
    d = tempfile.mkdtemp(prefix="tnc-reqctx-")
    try:
        root = Path(d) / "run"
        proj = Path(d) / "proj"
        (root / "assets").mkdir(parents=True)
        (root / "profiles").mkdir(parents=True)
        proj.mkdir(parents=True)
        wf = o.Workflow(goal="g", start_step="requirements", steps={})
        run = o.Run(slug="reqrun", root=root, workflow=wf,
                    project_dir=proj, accounts={})
        yield run, Path(d)
    finally:
        shutil.rmtree(d, ignore_errors=True)


def scripted_runner(actions):
    state = {"i": 0}

    def runner(step, run, visit, step_dir, prompt, should_continue):
        idx = min(state["i"], len(actions) - 1)
        state["i"] += 1
        rc = actions[idx](step_dir)
        return {"exit": rc, "stdout": f"v{visit}", "stderr": ""}
    return runner


def a_question(qtext):
    def _f(sd):
        (sd / "outcome.txt").write_text("question")
        (sd / "question.txt").write_text(qtext)
        return 0
    return _f


def a_write(value):
    def _f(sd):
        (sd / "outcome.txt").write_text(value)
        return 0
    return _f


def _meta(run, slug, visit):
    return json.loads(
        (run.root / slug / f"{visit:03d}" / "meta.json").read_text())


def s_sixstep_requirements_context_empty():
    wf = o.Workflow.load(
        Path(_PROJECT_ROOT) / "workflows" / "6step.yaml",
        goal_override="X")
    ctx = wf.steps["requirements"].context
    assert ctx == "empty", (
        f"6step.yaml steps.requirements.context is {ctx!r}, want 'empty'")


def s_questions_loop_unaffected_with_empty_context():
    p = Patcher()
    d = tempfile.mkdtemp(prefix="tnc-reqctx-q-")
    try:
        answers_file = Path(d) / "answers.txt"
        answers_file.write_text("ANSWER-ONE\n")
        ans = o.AnswerSource(answers_file)
        p.set(o, "AGENT_RUNNERS",
              {"fake": scripted_runner([a_question("Q?"),
                                        a_write("plan")])})
        with temp_run() as (run, _d):
            step = o.Step(slug="requirements", agent="fake",
                          prompt="ask {goal}", next_steps=["plan"],
                          questions=True, context="empty")
            out = o.execute_step(step, run, ans)
            assert out == "plan", f"outcome {out!r} != 'plan'"
            m1 = _meta(run, "requirements", 1)
            assert m1["continued"] is False, (
                f"question visit 1 must be fresh: {m1}")
            m2 = _meta(run, "requirements", 2)
            assert m2["continued"] is True, (
                f"continuation visit 2 must be continued: {m2}")
            ans_file = run.root / "requirements" / "001" / "answer.txt"
            assert ans_file.is_file(), "answer.txt not written in question dir"
            assert ans_file.read_text().strip() == "ANSWER-ONE", (
                ans_file.read_text())
    finally:
        p.undo()
        shutil.rmtree(d, ignore_errors=True)


def s_reentry_first_visit_is_fresh():
    p = Patcher()
    try:
        p.set(o, "AGENT_RUNNERS",
              {"fake": scripted_runner([a_write("plan")])})
        with temp_run() as (run, _d):
            step = o.Step(slug="requirements", agent="fake",
                          prompt="p {goal}", next_steps=["plan"],
                          questions=True, context="empty")
            out1 = o.execute_step(step, run, o.AnswerSource(None))
            assert out1 == "plan", out1
            # A later round re-enters the same requirements step on the
            # same Run: its first visit (#2 overall) must be FRESH.
            out2 = o.execute_step(step, run, o.AnswerSource(None))
            assert out2 == "plan", out2
            m2 = _meta(run, "requirements", 2)
            assert m2["continued"] is False, (
                f"re-entry first visit must be fresh (would be a stale "
                f"cross-round session resume if context were 'continue'): "
                f"{m2}")
    finally:
        p.undo()


SCENARIOS = [
    ("sixstep_requirements_context_empty",
     s_sixstep_requirements_context_empty),
    ("questions_loop_unaffected_with_empty_context",
     s_questions_loop_unaffected_with_empty_context),
    ("reentry_first_visit_is_fresh", s_reentry_first_visit_is_fresh),
]


def main() -> int:
    for name, fn in SCENARIOS:
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            print(f"FAIL {name}: {e}")
            traceback.print_exc()
            return 1
        print(f"PASS {name}")
    print(f"ALL PASS ({len(SCENARIOS)} scenarios)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
