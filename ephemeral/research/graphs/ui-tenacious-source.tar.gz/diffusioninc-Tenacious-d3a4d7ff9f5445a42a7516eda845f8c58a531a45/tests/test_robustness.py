"""Verification harness for the four orchestrator robustness fixes.

Stdlib only. Creates its own temp dirs. Does not need the auth bank, real
`codex`/`claude` binaries, or network. Drives the *real* shared step-visit
path (`_run_step_visit` -> runner -> `_supervise` -> `_kill_process_group`)
with a fake "agent" that is a short `python -c` program.

Run from the project root:

    .venv/bin/python tests/test_robustness.py

Prints `PASS <scenario>` per scenario, then `ALL PASS (<n> scenarios)`.
Exits 0 if all pass; 1 with `FAIL <scenario>: <detail>` on first failure.
"""

from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import traceback
from contextlib import contextmanager
from pathlib import Path

# Make `tenacious` importable when run as `python tests/test_robustness.py`.
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import tenacious.orchestrator as o  # noqa: E402

# Rebind the supervision constants to small values so scenarios run fast.
# This is in-process test acceleration, NOT user-facing configuration:
# scenario `constants_are_hardcoded_defaults` proves the shipped defaults in
# a clean subprocess.
o.OUTCOME_POLL_INTERVAL_SECONDS = 0.05
o.OUTCOME_GRACE_SECONDS = 0.5
o.PROCESS_GROUP_KILL_ESCALATION_SECONDS = 1.0
o.PROCESS_GROUP_POLL_INTERVAL_SECONDS = 0.05


# ----- helpers ---------------------------------------------------------------

class Patcher:
    """Save/restore monkeypatched attributes."""

    def __init__(self):
        self._saved = []

    def set(self, obj, attr, value):
        self._saved.append((obj, attr, getattr(obj, attr)))
        setattr(obj, attr, value)

    def undo(self):
        for obj, attr, value in reversed(self._saved):
            setattr(obj, attr, value)
        self._saved.clear()


@contextmanager
def temp_run():
    """Yield a real Run rooted in a fresh temp dir."""
    d = tempfile.mkdtemp(prefix="tnc-test-")
    try:
        root = Path(d) / "run"
        proj = Path(d) / "proj"
        root.mkdir(parents=True)
        proj.mkdir(parents=True)
        wf = o.Workflow(goal="g", start_step="s", steps={})
        run = o.Run(slug="testrun", root=root, workflow=wf, project_dir=proj,
                    accounts={"openai": "acct", "anthropic": "acct"})
        yield run, Path(d)
    finally:
        shutil.rmtree(d, ignore_errors=True)


def wait_dead(pid: int, timeout: float = 6.0) -> bool:
    """True if `pid` is gone within `timeout`."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return True
        except PermissionError:
            return False  # exists but not ours
        time.sleep(0.05)
    try:
        os.kill(pid, 0)
        return False
    except ProcessLookupError:
        return True


def make_fake_runner(child_code: str, env_for=None):
    """A runner that calls the REAL _supervise with a python -c fake agent."""
    def fake_runner(step, run, visit, step_dir, prompt, should_continue):
        env = os.environ.copy()
        env["TEST_OUTCOME"] = str(step_dir / "outcome.txt")
        if env_for is not None:
            env.update(env_for(step, run, visit, step_dir))
        cmd = [sys.executable, "-c", child_code]
        return o._supervise(cmd, env=env, cwd=str(run.project_dir),
                            outcome_path=step_dir / "outcome.txt",
                            run=run, label=step.slug)
    return fake_runner


def mkstep(slug="s", agent="fake", next_steps=("code_review",),
           questions=False, context="empty"):
    return o.Step(slug=slug, agent=agent, prompt="p",
                  next_steps=list(next_steps), questions=questions,
                  context=context)


PID_PREAMBLE = (
    "import os as _os\n"
    "_pf=_os.environ.get('TEST_PIDFILE')\n"
    "if _pf:\n"
    "    open(_pf,'w').write(str(_os.getpid()))\n"
)


# ----- scenarios -------------------------------------------------------------

def s_clean_exit():
    child = ("import os\n"
             "with open(os.environ['TEST_OUTCOME'],'w') as f:\n"
             "    f.write('code_review\\n')\n")
    p = Patcher()
    try:
        p.set(o, "AGENT_RUNNERS", {"fake": make_fake_runner(child)})
        with temp_run() as (run, _d):
            t0 = time.time()
            outcome, sd = o._run_step_visit(mkstep(), run, 1, "prompt", False)
            dt = time.time() - t0
            assert outcome == "code_review", outcome
            meta = json.loads((sd / "meta.json").read_text())
            assert meta["exit"] == 0, meta
            assert dt < 5.0, f"too slow: {dt:.2f}s"
    finally:
        p.undo()


def s_hang_after_outcome():
    child = (PID_PREAMBLE +
             "import os,time\n"
             "with open(os.environ['TEST_OUTCOME'],'w') as f:\n"
             "    f.write('code_review\\n')\n"
             "time.sleep(10000)\n")
    p = Patcher()
    try:
        p.set(o, "AGENT_RUNNERS", {"fake": make_fake_runner(child)})
        with temp_run() as (run, d):
            pidfile = d / "leader.pid"

            def env_for(step, run, visit, step_dir):
                return {"TEST_PIDFILE": str(pidfile)}

            p.set(o, "AGENT_RUNNERS",
                  {"fake": make_fake_runner(child, env_for)})
            t0 = time.time()
            outcome, _sd = o._run_step_visit(mkstep(), run, 1, "prompt", False)
            dt = time.time() - t0
            assert outcome == "code_review", outcome
            assert dt < 5.0, f"did not advance promptly: {dt:.2f}s"
            pid = int(pidfile.read_text().strip())
            assert wait_dead(pid), f"agent pid {pid} still alive"
    finally:
        p.undo()


def s_nonzero_exit_with_outcome():
    exit1 = ("import os,sys\n"
             "with open(os.environ['TEST_OUTCOME'],'w') as f:\n"
             "    f.write('code_review\\n')\n"
             "sys.exit(1)\n")
    sigself = ("import os,signal\n"
               "with open(os.environ['TEST_OUTCOME'],'w') as f:\n"
               "    f.write('code_review\\n')\n"
               "os.kill(os.getpid(), signal.SIGTERM)\n")
    p = Patcher()
    try:
        p.set(o, "AGENT_RUNNERS", {"fake": make_fake_runner(exit1)})
        with temp_run() as (run, _d):
            outcome, sd = o._run_step_visit(mkstep(), run, 1, "prompt", False)
            assert outcome == "code_review", outcome
            meta = json.loads((sd / "meta.json").read_text())
            assert meta["exit"] != 0, "expected non-zero recorded exit"
        p.set(o, "AGENT_RUNNERS", {"fake": make_fake_runner(sigself)})
        with temp_run() as (run, _d):
            outcome, sd = o._run_step_visit(mkstep(), run, 1, "prompt", False)
            assert outcome == "code_review", outcome
            meta = json.loads((sd / "meta.json").read_text())
            assert meta["exit"] != 0, f"expected negative exit, got {meta}"
    finally:
        p.undo()


def s_no_outcome_failure():
    child = ("import sys\n"
             "sys.stderr.write('STDERR_MARKER_XYZ\\n')\n"
             "sys.stderr.flush()\n")
    p = Patcher()
    try:
        p.set(o, "AGENT_RUNNERS", {"fake": make_fake_runner(child)})
        with temp_run() as (run, _d):
            try:
                o._run_step_visit(mkstep(), run, 1, "prompt", False)
            except RuntimeError as e:
                msg = str(e)
                assert "no valid outcome.txt" in msg, msg
                assert "STDERR_MARKER_XYZ" in msg, "stderr tail not surfaced"
            else:
                raise AssertionError("expected RuntimeError, none raised")
    finally:
        p.undo()


def s_empty_outcome_failure():
    child = ("import os\n"
             "with open(os.environ['TEST_OUTCOME'],'w') as f:\n"
             "    f.write('   \\n\\t \\n')\n")
    p = Patcher()
    try:
        p.set(o, "AGENT_RUNNERS", {"fake": make_fake_runner(child)})
        with temp_run() as (run, _d):
            try:
                o._run_step_visit(mkstep(), run, 1, "prompt", False)
            except RuntimeError as e:
                assert "no valid outcome.txt" in str(e), str(e)
            else:
                raise AssertionError("whitespace outcome treated as valid")
    finally:
        p.undo()


def s_orphan_child_killed_via_escalation():
    gc_code = ("import os,signal,time\n"
               "signal.signal(signal.SIGTERM, signal.SIG_IGN)\n"
               "open(os.environ['TEST_GC_PIDFILE'],'w')"
               ".write(str(os.getpid()))\n"
               "time.sleep(10000)\n")
    leader = (
        "import os,sys,signal,time,subprocess\n"
        "signal.signal(signal.SIGTERM, signal.SIG_IGN)\n"
        "_pf=os.environ.get('TEST_PIDFILE')\n"
        "if _pf:\n"
        "    open(_pf,'w').write(str(os.getpid()))\n"
        "GC=" + json.dumps(gc_code) + "\n"
        "subprocess.Popen([sys.executable,'-c',GC], env=os.environ.copy())\n"
        "with open(os.environ['TEST_OUTCOME'],'w') as f:\n"
        "    f.write('code_review\\n')\n"
        "time.sleep(10000)\n"
    )
    p = Patcher()
    try:
        with temp_run() as (run, d):
            leader_pidfile = d / "leader.pid"
            gc_pidfile = d / "gc.pid"

            def env_for(step, run, visit, step_dir):
                return {"TEST_PIDFILE": str(leader_pidfile),
                        "TEST_GC_PIDFILE": str(gc_pidfile)}

            p.set(o, "AGENT_RUNNERS",
                  {"fake": make_fake_runner(leader, env_for)})
            t0 = time.time()
            outcome, _sd = o._run_step_visit(mkstep(), run, 1, "prompt", False)
            dt = time.time() - t0
            assert outcome == "code_review", outcome
            assert dt < 10.0, f"escalation took too long: {dt:.2f}s"
            lpid = int(leader_pidfile.read_text().strip())
            # gc writes its pid early; give it a beat if needed.
            deadline = time.time() + 3.0
            while not gc_pidfile.exists() and time.time() < deadline:
                time.sleep(0.05)
            gpid = int(gc_pidfile.read_text().strip())
            assert wait_dead(lpid), f"SIGTERM-ignoring leader {lpid} alive"
            assert wait_dead(gpid), (
                f"orphan child {gpid} survived: group-wide SIGKILL "
                f"escalation did not reap it")
    finally:
        p.undo()


def s_end_to_end():
    child = ("import os\n"
             "q=os.environ.get('TEST_QUESTION_PATH')\n"
             "if q:\n"
             "    open(q,'w').write(os.environ.get('TEST_QUESTION_TEXT','q?'))\n"
             "with open(os.environ['TEST_OUTCOME'],'w') as f:\n"
             "    f.write(os.environ['TEST_OUTCOME_VALUE'])\n")

    def env_for(step, run, visit, step_dir):
        e = {}
        if step.slug == "a" and visit == 1:
            e["TEST_QUESTION_PATH"] = str(step_dir / "question.txt")
            e["TEST_QUESTION_TEXT"] = "Need a decision?"
            e["TEST_OUTCOME_VALUE"] = "question\n"
        elif step.slug == "a":
            e["TEST_OUTCOME_VALUE"] = "b\n"
        else:
            e["TEST_OUTCOME_VALUE"] = "end\n"
        return e

    p = Patcher()
    d = tempfile.mkdtemp(prefix="tnc-e2e-")
    try:
        home = Path(d) / "home"
        proj = Path(d) / "proj"
        home.mkdir(parents=True)
        proj.mkdir(parents=True)
        wf_path = Path(d) / "wf.json"
        wf_path.write_text(json.dumps({
            "goal": "g",
            "project_dir": str(proj),
            "start_step": "a",
            "steps": {
                "a": {"agent": "fake", "prompt": "pa",
                      "next_steps": ["b"], "questions": True,
                      "context": "continue"},
                "b": {"agent": "fake", "prompt": "pb",
                      "next_steps": ["end"]},
            },
        }))
        answers = Path(d) / "answers.txt"
        answers.write_text("the user answer\n")

        prev_home = os.environ.get("TENACIOUS_HOME")
        os.environ["TENACIOUS_HOME"] = str(home)
        p.set(o, "_magnetize_accounts", lambda slug, wf, **_kw: {})
        p.set(o, "AGENT_RUNNERS", {"fake": make_fake_runner(child, env_for)})

        try:
            run = o.execute_workflow(wf_path, answers_path=answers)
        finally:
            if prev_home is None:
                os.environ.pop("TENACIOUS_HOME", None)
            else:
                os.environ["TENACIOUS_HOME"] = prev_home
        log = (run.root / "run.log").read_text()
        assert "workflow complete (end)" in log, "workflow did not finish"
        assert run.visit_counts.get("a") == 2, (
            f"question continuation did not happen: {run.visit_counts}")
        assert run.visit_counts.get("b") == 1, run.visit_counts
    finally:
        p.undo()
        shutil.rmtree(d, ignore_errors=True)


def s_constants_are_hardcoded_defaults():
    code = (
        "import os\n"
        "os.environ['TENACIOUS_OUTCOME_GRACE_SECONDS']='1'\n"
        "os.environ['TENACIOUS_OUTCOME_POLL_INTERVAL_SECONDS']='1'\n"
        "os.environ['TENACIOUS_GRACE']='1'\n"
        "import tenacious.orchestrator as o\n"
        "print(o.OUTCOME_GRACE_SECONDS, o.OUTCOME_POLL_INTERVAL_SECONDS)\n"
    )
    r = subprocess.run([sys.executable, "-c", code], cwd=_PROJECT_ROOT,
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    assert r.stdout.strip() == "600.0 2.0", (
        f"shipped defaults changed or env-configurable: {r.stdout!r}")


def s_runner_codex_uses_supervise():
    import inspect
    src = inspect.getsource(o.run_codex)
    assert "_supervise" in src, "run_codex does not call _supervise"
    assert "subprocess.run" not in src, "run_codex still uses subprocess.run"

    p = Patcher()
    d = tempfile.mkdtemp(prefix="tnc-codex-")
    try:
        root = Path(d) / "run"
        proj = Path(d) / "proj"
        root.mkdir(parents=True)
        proj.mkdir(parents=True)
        wf = o.Workflow(goal="g", start_step="s", steps={})
        run = o.Run(slug="r", root=root, workflow=wf, project_dir=proj,
                    accounts={"openai": "acct"})
        step = mkstep(slug="code", agent="codex")
        step_dir = run.step_dir("code", 1)
        step_dir.mkdir(parents=True)
        outcome_path = step_dir / "outcome.txt"

        tid_marker = "thr_test123"
        jline = json.dumps(
            {"type": "thread.started", "thread_id": tid_marker})
        child = ("import sys\n"
                 "sys.stdout.write(%s + '\\n')\n" % json.dumps(jline) +
                 "sys.stdout.flush()\n"
                 "with open(%s,'w') as f:\n" % json.dumps(str(outcome_path)) +
                 "    f.write('code_review\\n')\n")

        real_popen = subprocess.Popen

        def fake_popen(cmd, **kw):
            return real_popen([sys.executable, "-c", child], **kw)

        slot = Path(d) / "slot.json"
        slot.write_text("{}")

        @contextmanager
        def fake_lease(provider, account, timeout=120.0, exclude=frozenset()):
            yield slot

        copies = []
        real_copy = shutil.copy

        def rec_copy(a, b):
            copies.append((str(a), str(b)))
            return real_copy(a, b)

        real_sup = o._supervise
        captured = []

        def spy_sup(cmd, **kw):
            captured.append(kw)
            return real_sup(cmd, **kw)

        p.set(o.subprocess, "Popen", fake_popen)
        p.set(o.authbank, "lease", fake_lease)
        p.set(o.authbank, "writeback", lambda prov: True)
        p.set(o.shutil, "copy", rec_copy)
        p.set(o, "_supervise", spy_sup)

        result = o.run_codex(step, run, 1, step_dir, "the prompt", False)

        assert captured, "real _supervise was not entered by run_codex"
        for k in ("exit", "stdout", "stderr", "thread_id"):
            assert k in result, f"missing key {k} in {result}"
        assert result["thread_id"] == tid_marker, result
        tid_file = run.profile_dir("code") / "thread_id.txt"
        assert tid_file.read_text().strip() == tid_marker, "thread id unwritten"
        auth_target = run.profile_dir("code") / "auth.json"
        assert any(s == str(auth_target) and dd == str(slot)
                   for s, dd in copies), (
            f"codex writeback copy not observed: {copies}")
    finally:
        p.undo()
        shutil.rmtree(d, ignore_errors=True)


def s_runner_claude_uses_supervise():
    import inspect
    src = inspect.getsource(o.run_claude)
    assert "_supervise" in src, "run_claude does not call _supervise"
    assert "subprocess.run" not in src, "run_claude still uses subprocess.run"

    p = Patcher()
    d = tempfile.mkdtemp(prefix="tnc-claude-")
    try:
        root = Path(d) / "run"
        proj = Path(d) / "proj"
        root.mkdir(parents=True)
        proj.mkdir(parents=True)
        wf = o.Workflow(goal="g", start_step="s", steps={})
        run = o.Run(slug="r", root=root, workflow=wf, project_dir=proj,
                    accounts={"anthropic": "acct"})
        step = mkstep(slug="code", agent="claude")
        step_dir = run.step_dir("code", 1)
        step_dir.mkdir(parents=True)
        outcome_path = step_dir / "outcome.txt"

        child = ("with open(%s,'w') as f:\n" % json.dumps(str(outcome_path)) +
                 "    f.write('code_review\\n')\n")

        real_popen = subprocess.Popen

        def fake_popen(cmd, **kw):
            return real_popen([sys.executable, "-c", child], **kw)

        slot = Path(d) / "slot.txt"
        slot.write_text("oauth-token-xyz")

        @contextmanager
        def fake_lease(provider, account, timeout=120.0):
            yield slot

        real_sup = o._supervise
        captured = []

        def spy_sup(cmd, **kw):
            captured.append(kw)
            return real_sup(cmd, **kw)

        p.set(o.subprocess, "Popen", fake_popen)
        p.set(o.authbank, "lease", fake_lease)
        p.set(o, "_supervise", spy_sup)

        result = o.run_claude(step, run, 1, step_dir, "the prompt", False)

        assert captured, "real _supervise was not entered by run_claude"
        assert captured[-1].get("cwd") == str(run.project_dir), (
            f"cwd not preserved: {captured[-1].get('cwd')!r} "
            f"!= {str(run.project_dir)!r}")
        for k in ("exit", "stdout", "stderr"):
            assert k in result, f"missing key {k} in {result}"
    finally:
        p.undo()
        shutil.rmtree(d, ignore_errors=True)


SCENARIOS = [
    ("clean_exit", s_clean_exit),
    ("hang_after_outcome", s_hang_after_outcome),
    ("nonzero_exit_with_outcome", s_nonzero_exit_with_outcome),
    ("no_outcome_failure", s_no_outcome_failure),
    ("empty_outcome_failure", s_empty_outcome_failure),
    ("orphan_child_killed_via_escalation",
     s_orphan_child_killed_via_escalation),
    ("end_to_end", s_end_to_end),
    ("constants_are_hardcoded_defaults", s_constants_are_hardcoded_defaults),
    ("runner_codex_uses_supervise", s_runner_codex_uses_supervise),
    ("runner_claude_uses_supervise", s_runner_claude_uses_supervise),
]


def main() -> int:
    for name, fn in SCENARIOS:
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            print(f"FAIL {name}: {e}")
            traceback.print_exc()
            return 1
        print(f"PASS {name}")
    print(f"ALL PASS ({len(SCENARIOS)} scenarios)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
