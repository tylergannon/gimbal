"""Acceptance test for round 1: pressing Ctrl-C while the Tenacious
orchestrator is running produces a clean exit (no Python traceback on
stderr, exit code 130). Stdlib-only; matches the conventions of
tests/test_robustness.py and tests/run_all.py.

Six parts:

  Part A  - entrypoint plumbing smoke check. For each of the two ways the
            orchestrator is launched (`python -m tenacious` and
            `python -m tenacious.orchestrator`), spawn `<launch> --help` as
            a subprocess and assert clean exit + argparse `usage:` line +
            no traceback. Proves both module entrypoints resolve and
            dispatch into main() without import-time errors.

  Part B  - wrapper-mode SIGINT clean-exit check. Spawn a tiny wrapper
            that imports tenacious.orchestrator, stubs execute_workflow
            with a sleep, and calls sys.exit(main(...)). Send SIGINT
            once, wait for exit, assert returncode == 130, no traceback /
            KeyboardInterrupt text on stderr, `Interrupted.` line present.

  Part C  - real `python -m tenacious` under SIGINT. Stubs are injected
            via a sitecustomize.py PYTHONPATH shim rather than a wrapper
            script. Same assertions as Part B.

  Part D  - same as Part C but launches `python -m tenacious.orchestrator`.

  Part E  - `--resume RUN_ID` SIGINT. Proves the outer except
            KeyboardInterrupt also catches interrupts raised from the
            --resume code path.

  Part F  - child-process teardown survives the interrupt. The
            sitecustomize stub spawns a real grandchild in its own
            process session before sleeping, registers a finally-block
            cleanup that mirrors what the orchestrator's existing
            _drive_run/_supervise finally blocks do, then sleeps. After
            SIGINT, the test asserts the grandchild is gone — proving the
            normal finally/atexit cleanup paths still run on the SIGINT
            exit path.
"""

from __future__ import annotations

import os
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path

_THIS = Path(__file__).resolve()
_PROJECT_ROOT = _THIS.parent.parent

_TRACEBACK_MARKER = b"Traceback (most recent call last):"
_KEYBOARD_INT_MARKER = b"KeyboardInterrupt"
_INTERRUPTED_MARKER = b"Interrupted."


def _env_with_project_on_path(extra_first: str | None = None) -> dict[str, str]:
    env = os.environ.copy()
    py_path = env.get("PYTHONPATH", "")
    parts = []
    if extra_first:
        parts.append(extra_first)
    parts.append(str(_PROJECT_ROOT))
    if py_path:
        parts.append(py_path)
    env["PYTHONPATH"] = os.pathsep.join(parts)
    return env


def _fail(detail: str) -> int:
    print(f"FAIL sigint_clean_exit: {detail}")
    return 1


# ---------------------------------------------------------------------------
# Part A: --help smoke for both module entrypoints
# ---------------------------------------------------------------------------


def _part_a_help_for(module: str) -> str | None:
    proc = subprocess.run(
        [sys.executable, "-m", module, "--help"],
        cwd=str(_PROJECT_ROOT),
        env=_env_with_project_on_path(),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=30,
    )
    if proc.returncode != 0:
        return (
            f"`python -m {module} --help` exited with "
            f"{proc.returncode}; stderr={proc.stderr!r}"
        )
    if _TRACEBACK_MARKER in proc.stderr:
        return (
            f"`python -m {module} --help` stderr contains a traceback: "
            f"{proc.stderr!r}"
        )
    if b"usage:" not in proc.stdout:
        return (
            f"`python -m {module} --help` stdout missing argparse "
            f"`usage:` line; stdout={proc.stdout!r}"
        )
    return None


def _part_a() -> int:
    for module in ("tenacious", "tenacious.orchestrator"):
        err = _part_a_help_for(module)
        if err is not None:
            return _fail(err)
    return 0


# ---------------------------------------------------------------------------
# Part B: wrapper-mode SIGINT (legacy in-process shim via a wrapper script)
# ---------------------------------------------------------------------------


_WRAPPER_SOURCE = r"""
import sys
from pathlib import Path

sys.path.insert(0, {project_root!r})

import tenacious.orchestrator as o

def _sleep_forever(*args, **kwargs):
    import time
    while True:
        time.sleep(60)

o.execute_workflow = _sleep_forever
if hasattr(o, "resume_workflow"):
    o.resume_workflow = _sleep_forever

# Mirror the real __main__ shape: sys.exit(main(argv)).
sys.exit(o.main(sys.argv[1:]))
"""


def _spawn_session(cmd: list[str], env: dict[str, str]) -> subprocess.Popen:
    popen_kwargs: dict = dict(
        cwd=str(_PROJECT_ROOT),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if hasattr(os, "setsid"):
        popen_kwargs["preexec_fn"] = os.setsid
    return subprocess.Popen(cmd, **popen_kwargs)


def _sigint_and_collect(
    proc: subprocess.Popen, *, label: str
) -> tuple[int, bytes, bytes] | str:
    """Send SIGINT, wait up to 10s, return (rc, stdout, stderr) on success
    or an error description string on failure."""
    try:
        proc.send_signal(signal.SIGINT)
    except ProcessLookupError:
        pass
    try:
        out, err = proc.communicate(timeout=10)
    except subprocess.TimeoutExpired:
        proc.kill()
        try:
            out, err = proc.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            out, err = b"", b""
        return (
            f"{label}: child did not exit within 10s of SIGINT; "
            f"killed; stdout={out!r}; stderr={err!r}"
        )
    return proc.returncode, out, err


def _assert_clean_sigint(
    rc: int, out: bytes, err: bytes, *, label: str
) -> str | None:
    if rc != 130:
        return (
            f"{label}: expected returncode 130, got {rc}; "
            f"stdout={out!r}; stderr={err!r}"
        )
    if _TRACEBACK_MARKER in err:
        return f"{label}: stderr contains a Python traceback: stderr={err!r}"
    if _KEYBOARD_INT_MARKER in err:
        return f"{label}: stderr contains 'KeyboardInterrupt' text: stderr={err!r}"
    if _INTERRUPTED_MARKER not in err:
        return (
            f"{label}: stderr missing expected 'Interrupted.' line; "
            f"stderr={err!r}"
        )
    return None


def _wait_for_alive_then_sigint(
    proc: subprocess.Popen,
    *,
    sentinel: Path | None,
    label: str,
    sentinel_timeout: float = 5.0,
) -> str | None:
    """Wait for the child to reach the sleep stub (either via a sentinel
    file or via an "is still alive" timeout), then send a single SIGINT
    and assert the clean-exit triple. Returns None on success or an error
    description on failure."""
    if sentinel is not None:
        deadline = time.monotonic() + sentinel_timeout
        while time.monotonic() < deadline:
            if proc.poll() is not None:
                out, err = proc.communicate(timeout=5)
                return (
                    f"{label}: child exited before sentinel appeared "
                    f"(rc={proc.returncode}); stdout={out!r}; stderr={err!r}"
                )
            if sentinel.exists():
                break
            time.sleep(0.05)
        else:
            try:
                proc.kill()
                out, err = proc.communicate(timeout=5)
            except Exception:
                out, err = b"", b""
            return (
                f"{label}: sentinel {sentinel} never appeared within "
                f"{sentinel_timeout}s; stdout={out!r}; stderr={err!r}"
            )
    else:
        time.sleep(0.5)
        if proc.poll() is not None:
            out, err = proc.communicate(timeout=5)
            return (
                f"{label}: child exited before SIGINT (rc={proc.returncode}); "
                f"stdout={out!r}; stderr={err!r}"
            )

    result = _sigint_and_collect(proc, label=label)
    if isinstance(result, str):
        return result
    rc, out, err = result
    return _assert_clean_sigint(rc, out, err, label=label)


def _part_b() -> int:
    with tempfile.TemporaryDirectory() as tmpdir:
        wrapper_path = Path(tmpdir) / "_sigint_wrapper.py"
        wrapper_path.write_text(
            _WRAPPER_SOURCE.format(project_root=str(_PROJECT_ROOT))
        )
        placeholder_workflow = str(Path(tmpdir) / "placeholder.json")

        proc = _spawn_session(
            [sys.executable, str(wrapper_path), placeholder_workflow],
            _env_with_project_on_path(),
        )
        try:
            err_desc = _wait_for_alive_then_sigint(
                proc, sentinel=None, label="part B"
            )
            if err_desc is not None:
                return _fail(err_desc)
        finally:
            if proc.poll() is None:
                try:
                    proc.kill()
                except Exception:
                    pass
                try:
                    proc.communicate(timeout=5)
                except Exception:
                    pass
    return 0


# ---------------------------------------------------------------------------
# sitecustomize PYTHONPATH shim — shared by Parts C, D, E, F
# ---------------------------------------------------------------------------


# The shim installs a meta_path finder that intercepts source loading of
# `tenacious.orchestrator` and injects a sleep-forever stub for
# execute_workflow / resume_workflow right before the
# `if __name__ == "__main__":` block.
#
# We have to do this via source-injection (rather than a simple `import
# tenacious.orchestrator as o; o.execute_workflow = stub` monkeypatch)
# because `python -m tenacious.orchestrator` makes runpy *re-execute* the
# orchestrator file in a fresh `__main__` namespace, which would bypass
# any patches applied to the already-imported `tenacious.orchestrator`
# module. Source-injection works uniformly for `python -m tenacious`,
# `python -m tenacious.orchestrator`, and ordinary `import` callers.
#
# The stub:
#   - touches SIGINT_TEST_SENTINEL so the test can deterministically wait
#     for the orchestrator to actually be inside the stub.
#   - if SIGINT_TEST_GRANDCHILD_PIDFILE is set, spawns a real grandchild
#     in its own POSIX session, records its PID, and registers a
#     try/finally cleanup that SIGTERMs it — mirroring how the real
#     orchestrator's _drive_run/_supervise finally-block teardown reaps
#     children. The grandchild's own session means SIGINT to the
#     orchestrator's group cannot reach it; only the stub's finally
#     can clean it up.
_SITECUSTOMIZE_SOURCE = r'''
import importlib.machinery
import importlib.util
import os
import sys


_INJECTION = b"""

def _sigint_test_sleep_stub(*args, **kwargs):
    import os
    import signal
    import subprocess
    import sys
    import time
    sentinel = os.environ.get("SIGINT_TEST_SENTINEL")
    grandchild_pidfile = os.environ.get("SIGINT_TEST_GRANDCHILD_PIDFILE")
    proc = None
    if grandchild_pidfile:
        proc = subprocess.Popen(
            [
                sys.executable,
                "-c",
                "import os, sys, time\\n"
                "sys.stdout.write(str(os.getpid()) + chr(10))\\n"
                "sys.stdout.flush()\\n"
                "time.sleep(600)\\n",
            ],
            stdout=subprocess.PIPE,
            start_new_session=True,
        )
        try:
            pid_line = proc.stdout.readline().strip()
            grandchild_pid = int(pid_line)
            with open(grandchild_pidfile, "w") as f:
                f.write(str(grandchild_pid) + chr(10))
        except Exception:
            pass
    if sentinel:
        try:
            with open(sentinel, "w") as f:
                f.write("ready" + chr(10))
        except Exception:
            pass
    try:
        while True:
            time.sleep(60)
    finally:
        if proc is not None:
            try:
                os.kill(proc.pid, signal.SIGTERM)
            except Exception:
                pass

execute_workflow = _sigint_test_sleep_stub
resume_workflow = _sigint_test_sleep_stub

"""


class _PatchedOrchestratorLoader(importlib.machinery.SourceFileLoader):
    def get_code(self, fullname):
        source_bytes = self.get_data(self.path)
        # Inject right before the `if __name__ == "__main__":` block so
        # that our rebinding runs AFTER the real execute_workflow /
        # resume_workflow definitions but BEFORE main() is called.
        marker = b"\nif __name__ =="
        idx = source_bytes.rfind(marker)
        if idx == -1:
            new_source = source_bytes + _INJECTION
        else:
            new_source = source_bytes[:idx] + _INJECTION + source_bytes[idx:]
        return compile(
            new_source, self.path, "exec", dont_inherit=True, optimize=-1
        )


class _OrchestratorFinder:
    def find_spec(self, name, path, target=None):
        if name != "tenacious.orchestrator":
            return None
        try:
            import tenacious  # noqa: F401
        except Exception as exc:
            sys.stderr.write(
                "sigint-test sitecustomize: tenacious import failed: "
                + repr(exc) + chr(10)
            )
            return None
        pkg_dir = None
        f = getattr(tenacious, "__file__", None)
        if f:
            pkg_dir = os.path.dirname(f)
        if not pkg_dir:
            pp = getattr(tenacious, "__path__", None)
            if pp:
                pkg_dir = list(pp)[0]
        if not pkg_dir:
            return None
        src = os.path.join(pkg_dir, "orchestrator.py")
        if not os.path.isfile(src):
            return None
        loader = _PatchedOrchestratorLoader(name, src)
        return importlib.util.spec_from_loader(name, loader, origin=src)


sys.meta_path.insert(0, _OrchestratorFinder())
'''


def _write_sitecustomize(tmpdir: Path) -> Path:
    path = tmpdir / "sitecustomize.py"
    path.write_text(_SITECUSTOMIZE_SOURCE)
    return path


def _shim_env(tmpdir: Path, *, sentinel: Path, grandchild_pidfile: Path | None = None) -> dict[str, str]:
    env = _env_with_project_on_path(extra_first=str(tmpdir))
    env["SIGINT_TEST_SENTINEL"] = str(sentinel)
    if grandchild_pidfile is not None:
        env["SIGINT_TEST_GRANDCHILD_PIDFILE"] = str(grandchild_pidfile)
    # Make sure the user-site sitecustomize, if any, doesn't preempt ours
    # in unexpected environments.
    env.pop("PYTHONNOUSERSITE", None)
    return env


# ---------------------------------------------------------------------------
# Parts C & D: real `python -m tenacious{,.orchestrator}` under SIGINT
# ---------------------------------------------------------------------------


def _module_launch_part(module: str, label: str) -> int:
    with tempfile.TemporaryDirectory() as tmpdir_str:
        tmpdir = Path(tmpdir_str)
        _write_sitecustomize(tmpdir)
        sentinel = tmpdir / "sentinel"
        placeholder = str(tmpdir / "placeholder.json")
        env = _shim_env(tmpdir, sentinel=sentinel)

        proc = _spawn_session(
            [sys.executable, "-m", module, placeholder], env
        )
        try:
            err_desc = _wait_for_alive_then_sigint(
                proc, sentinel=sentinel, label=label
            )
            if err_desc is not None:
                return _fail(err_desc)
        finally:
            if proc.poll() is None:
                try:
                    proc.kill()
                except Exception:
                    pass
                try:
                    proc.communicate(timeout=5)
                except Exception:
                    pass
    return 0


def _part_c() -> int:
    return _module_launch_part("tenacious", "part C")


def _part_d() -> int:
    return _module_launch_part("tenacious.orchestrator", "part D")


# ---------------------------------------------------------------------------
# Part E: --resume SIGINT
# ---------------------------------------------------------------------------


def _part_e() -> int:
    with tempfile.TemporaryDirectory() as tmpdir_str:
        tmpdir = Path(tmpdir_str)
        _write_sitecustomize(tmpdir)
        sentinel = tmpdir / "sentinel"
        env = _shim_env(tmpdir, sentinel=sentinel)

        # Use the orchestrator entrypoint with --resume + a fake run id.
        # The sitecustomize stub replaces resume_workflow with the same
        # sleep stub, so SIGINT must be caught by the outer except in
        # main().
        proc = _spawn_session(
            [
                sys.executable,
                "-m",
                "tenacious.orchestrator",
                "--resume",
                "definitely-not-a-real-run-id",
            ],
            env,
        )
        try:
            err_desc = _wait_for_alive_then_sigint(
                proc, sentinel=sentinel, label="part E"
            )
            if err_desc is not None:
                return _fail(err_desc)
        finally:
            if proc.poll() is None:
                try:
                    proc.kill()
                except Exception:
                    pass
                try:
                    proc.communicate(timeout=5)
                except Exception:
                    pass
    return 0


# ---------------------------------------------------------------------------
# Part F: child-process teardown survives the interrupt
# ---------------------------------------------------------------------------


def _proc_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _part_f() -> int:
    if not hasattr(os, "setsid"):
        # POSIX-only check; skip cleanly on non-POSIX systems.
        return 0

    with tempfile.TemporaryDirectory() as tmpdir_str:
        tmpdir = Path(tmpdir_str)
        _write_sitecustomize(tmpdir)
        sentinel = tmpdir / "sentinel"
        pidfile = tmpdir / "grandchild.pid"
        placeholder = str(tmpdir / "placeholder.json")
        env = _shim_env(tmpdir, sentinel=sentinel, grandchild_pidfile=pidfile)

        grandchild_pid: int | None = None
        proc = _spawn_session(
            [sys.executable, "-m", "tenacious", placeholder], env
        )
        try:
            # Wait for the sentinel (the stub has spawned the grandchild,
            # written its PID to disk, and is now sleeping).
            err_desc = _wait_for_alive_then_sigint(
                proc,
                sentinel=sentinel,
                label="part F",
                sentinel_timeout=7.0,
            )
            if err_desc is not None:
                # Try to capture the grandchild pid for the cleanup phase.
                if pidfile.exists():
                    try:
                        grandchild_pid = int(pidfile.read_text().strip())
                    except Exception:
                        grandchild_pid = None
                return _fail(err_desc)

            if not pidfile.exists():
                return _fail(
                    "part F: grandchild PID file was never written; "
                    "stub did not run as expected"
                )
            try:
                grandchild_pid = int(pidfile.read_text().strip())
            except Exception as exc:
                return _fail(
                    f"part F: could not parse grandchild PID file: {exc!r}"
                )

            # Grace window: the orchestrator has exited (130) by now,
            # which means the stub's `finally` block ran SIGTERM on the
            # grandchild before sys.exit returned. Allow up to ~3s for
                # the kernel to reap it.
            grace_deadline = time.monotonic() + 3.0
            while time.monotonic() < grace_deadline:
                if not _proc_alive(grandchild_pid):
                    break
                time.sleep(0.05)
            else:
                return _fail(
                    f"part F: grandchild pid {grandchild_pid} still alive "
                    f"3s after orchestrator exited — teardown did not run"
                )
        finally:
            if proc.poll() is None:
                try:
                    proc.kill()
                except Exception:
                    pass
                try:
                    proc.communicate(timeout=5)
                except Exception:
                    pass
            # Belt-and-braces: do not leak grandchildren even if the test
            # failed before its own clean-exit checks ran.
            if grandchild_pid is not None and _proc_alive(grandchild_pid):
                try:
                    os.kill(grandchild_pid, signal.SIGKILL)
                except Exception:
                    pass
    return 0


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------


def main() -> int:
    for part in (_part_a, _part_b, _part_c, _part_d, _part_e, _part_f):
        rc = part()
        if rc != 0:
            return rc
    print("PASS sigint_clean_exit")
    return 0


if __name__ == "__main__":
    sys.exit(main())
