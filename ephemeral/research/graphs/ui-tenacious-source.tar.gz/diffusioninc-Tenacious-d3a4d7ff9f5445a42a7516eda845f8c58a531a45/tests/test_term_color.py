"""Unit tests for tenacious.term_color (round-2 colored output, G-1/G-2).

Stdlib only. Imports `tenacious.term_color` directly; no Tenacious globals
are touched. Tests that mutate env vars do so via `env()` which restores
the prior values on exit so scenarios never bleed into each other.

Run from the project root:

    python3 tests/test_term_color.py

Prints `PASS <scenario>` per scenario, then `ALL PASS (<n> scenarios)`.
Exits 0 on success; 1 with `FAIL <scenario>: <detail>` on first failure.
"""

from __future__ import annotations

import os
import sys
import traceback
from contextlib import contextmanager

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from tenacious import term_color as tc  # noqa: E402


# ----- helpers ---------------------------------------------------------------

class _FakeStream:
    """Minimal stdout/stderr stub with a settable isatty()."""

    def __init__(self, is_tty: bool):
        self._is_tty = is_tty

    def isatty(self) -> bool:
        return self._is_tty


@contextmanager
def env(**kwargs):
    """Set env vars for the duration of the block; restore on exit.

    A value of None deletes the var. The function saves the prior values
    (or absence) and restores them faithfully — even if a scenario raises.
    """
    saved: dict[str, str | None] = {}
    for k, v in kwargs.items():
        saved[k] = os.environ.get(k)
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    try:
        yield
    finally:
        for k, v in saved.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


def expect(cond: bool, detail: str) -> None:
    if not cond:
        raise AssertionError(detail)


# ----- scenarios -------------------------------------------------------------

def enabled_when_tty_and_no_disable_envs() -> None:
    with env(NO_COLOR=None, TENACIOUS_COLOR=None):
        expect(tc.color_enabled(_FakeStream(True)) is True,
               "expected True for TTY with no env overrides")


def disabled_when_not_a_tty() -> None:
    with env(NO_COLOR=None, TENACIOUS_COLOR=None):
        expect(tc.color_enabled(_FakeStream(False)) is False,
               "expected False on a non-tty stream")


def disabled_by_NO_COLOR_envvar() -> None:
    with env(NO_COLOR="1", TENACIOUS_COLOR=None):
        expect(tc.color_enabled(_FakeStream(True)) is False,
               "NO_COLOR=1 should disable even on a TTY")


def disabled_by_TENACIOUS_COLOR_zero() -> None:
    with env(NO_COLOR=None, TENACIOUS_COLOR="0"):
        expect(tc.color_enabled(_FakeStream(True)) is False,
               "TENACIOUS_COLOR=0 should disable even on a TTY")


def force_enabled_by_TENACIOUS_COLOR_one_on_non_tty() -> None:
    with env(NO_COLOR=None, TENACIOUS_COLOR="1"):
        expect(tc.color_enabled(_FakeStream(False)) is True,
               "TENACIOUS_COLOR=1 should force-enable on a non-TTY")


def NO_COLOR_overrides_TENACIOUS_COLOR_one() -> None:
    with env(NO_COLOR="1", TENACIOUS_COLOR="1"):
        expect(tc.color_enabled(_FakeStream(True)) is False,
               "NO_COLOR must win over TENACIOUS_COLOR=1 (single rule)")


def colorize_dims_leading_timestamp() -> None:
    out = tc.colorize_log_line("[2026-05-21T10:11:12] hello", enabled=True)
    expect(out.startswith(f"{tc.DIM}[2026-05-21T10:11:12]{tc.RESET} "),
           f"timestamp not dimmed: {out!r}")
    expect(out.endswith("hello"), f"trailing 'hello' not preserved: {out!r}")
    expect(tc.DIM not in out[len(tc.DIM)+len("[2026-05-21T10:11:12]")+len(tc.RESET)+1:],
           f"'hello' was inadvertently dimmed: {out!r}")


def colorize_paints_health_monitor_magenta() -> None:
    line = "[2026-05-21T10:11:12]   [health_monitor] tick 3 (agent=claude)"
    out = tc.colorize_log_line(line, enabled=True)
    wrapped = f"{tc.MAGENTA}[health_monitor]{tc.RESET}"
    expect(wrapped in out,
           f"[health_monitor] not wrapped in magenta: {out!r}")


def colorize_paints_known_stepname_cyan() -> None:
    line = "[2026-05-21T10:11:12]   [code] valid outcome.txt detected"
    out = tc.colorize_log_line(line, known_steps={"code"}, enabled=True)
    wrapped = f"{tc.CYAN}[code]{tc.RESET}"
    expect(wrapped in out,
           f"[code] not wrapped in cyan: {out!r}")


def colorize_does_not_paint_unknown_bracket() -> None:
    line = "[2026-05-21T10:11:12]   answer: '[whatever]'"
    out = tc.colorize_log_line(line, known_steps={"code"}, enabled=True)
    expect(f"{tc.CYAN}[whatever]" not in out
           and f"{tc.MAGENTA}[whatever]" not in out,
           f"unknown bracket was colorized: {out!r}")


def colorize_paints_claude_cmd_blue() -> None:
    line = "[2026-05-21T10:11:12]   claude cmd: ...anthropic/foo/cc1.txt"
    out = tc.colorize_log_line(line, enabled=True)
    wrapped = f"{tc.BLUE}claude cmd:{tc.RESET}"
    expect(wrapped in out,
           f"'claude cmd:' not wrapped in blue: {out!r}")


def colorize_paints_codex_cmd_blue() -> None:
    line = "[2026-05-21T10:11:12]   codex cmd: ...openai/foo/cc1.txt"
    out = tc.colorize_log_line(line, enabled=True)
    wrapped = f"{tc.BLUE}codex cmd:{tc.RESET}"
    expect(wrapped in out,
           f"'codex cmd:' not wrapped in blue: {out!r}")


def colorize_paints_exited_zero_green() -> None:
    line = "[2026-05-21T10:11:12]   exited 0 in 1.2s"
    out = tc.colorize_log_line(line, enabled=True)
    wrapped = f"{tc.GREEN}exited 0{tc.RESET}"
    expect(wrapped in out,
           f"'exited 0' not wrapped in green: {out!r}")


def colorize_paints_exited_nonzero_red() -> None:
    for n in ("137", "-15", "1"):
        line = f"[2026-05-21T10:11:12]   exited {n} in 1.2s"
        out = tc.colorize_log_line(line, enabled=True)
        wrapped = f"{tc.RED}exited {n}{tc.RESET}"
        expect(wrapped in out,
               f"'exited {n}' not wrapped in red: {out!r}")


def colorize_multi_line_handles_each_line() -> None:
    line = (
        "[2026-05-21T10:11:12] ===== SESSION HEALTH UPDATE (tick 4) =====\n"
        "- foo\n"
        "[2026-05-21T10:11:13] ===== END SESSION HEALTH UPDATE ====="
    )
    out = tc.colorize_log_line(line, enabled=True)
    parts = out.split("\n")
    expect(len(parts) == 3, f"expected 3 lines, got {len(parts)}: {out!r}")
    expect(parts[0].startswith(f"{tc.DIM}[2026-05-21T10:11:12]{tc.RESET} "),
           f"line 1 timestamp not dimmed: {parts[0]!r}")
    expect(parts[2].startswith(f"{tc.DIM}[2026-05-21T10:11:13]{tc.RESET} "),
           f"line 3 timestamp not dimmed: {parts[2]!r}")
    expect(parts[1] == "- foo",
           f"plain body line was modified: {parts[1]!r}")


def banner_step_is_bold_cyan() -> None:
    out = tc.banner("step code visit 1", "step", enabled=True)
    expect(out == f"{tc.BOLD}{tc.CYAN}step code visit 1{tc.RESET}",
           f"banner step shape wrong: {out!r}")


def banner_question_is_bold_yellow() -> None:
    out = tc.banner("[Question from agent]", "question", enabled=True)
    expect(out == f"{tc.BOLD}{tc.YELLOW}[Question from agent]{tc.RESET}",
           f"banner question shape wrong: {out!r}")


def banner_health_is_bold_magenta() -> None:
    out = tc.banner("===== SESSION HEALTH UPDATE (tick 4) =====",
                    "health", enabled=True)
    expect(out == (f"{tc.BOLD}{tc.MAGENTA}"
                   f"===== SESSION HEALTH UPDATE (tick 4) ====={tc.RESET}"),
           f"banner health shape wrong: {out!r}")


def banner_invalid_role_raises() -> None:
    try:
        tc.banner("x", "nope", enabled=True)
    except ValueError:
        return
    raise AssertionError("banner('x', 'nope') did not raise ValueError")


def dim_helper_wraps_in_dim_reset() -> None:
    out = tc.dim("--- type your answer below ---", enabled=True)
    expect(out == f"{tc.DIM}--- type your answer below ---{tc.RESET}",
           f"dim shape wrong: {out!r}")


def all_helpers_return_input_unchanged_when_disabled() -> None:
    s_log = "[2026-05-21T10:11:12]   [code] valid outcome.txt detected"
    s_banner = "step code visit 1"
    s_dim = "footer"
    expect(tc.colorize_log_line(s_log, known_steps={"code"}, enabled=False)
           == s_log, "colorize_log_line altered input when disabled")
    expect(tc.banner(s_banner, "step", enabled=False) == s_banner,
           "banner altered input when disabled")
    expect(tc.dim(s_dim, enabled=False) == s_dim,
           "dim altered input when disabled")


def step_boundary_line_gets_both_dim_ts_and_bold_cyan_body() -> None:
    line = "[2026-05-21T10:11:12] step code visit 1 (agent=claude, context=fresh)"
    out = tc.colorize_log_line(line, known_steps={"code"}, enabled=True)
    expect(out.startswith(f"{tc.DIM}[2026-05-21T10:11:12]{tc.RESET} "),
           f"timestamp not dimmed: {out!r}")
    body_wrapped = (
        f"{tc.BOLD}{tc.CYAN}"
        f"step code visit 1 (agent=claude, context=fresh){tc.RESET}"
    )
    expect(body_wrapped in out,
           f"step boundary body not bold cyan: {out!r}")


def health_banner_header_line_gets_bold_magenta() -> None:
    line = "[2026-05-21T10:11:12] ===== SESSION HEALTH UPDATE (tick 4) ====="
    out = tc.colorize_log_line(line, enabled=True)
    body_wrapped = (
        f"{tc.BOLD}{tc.MAGENTA}"
        f"===== SESSION HEALTH UPDATE (tick 4) ====={tc.RESET}"
    )
    expect(body_wrapped in out,
           f"health header body not bold magenta: {out!r}")
    # And the END line.
    line2 = "[2026-05-21T10:11:12] ===== END SESSION HEALTH UPDATE ====="
    out2 = tc.colorize_log_line(line2, enabled=True)
    body_wrapped2 = (
        f"{tc.BOLD}{tc.MAGENTA}"
        f"===== END SESSION HEALTH UPDATE ====={tc.RESET}"
    )
    expect(body_wrapped2 in out2,
           f"health END body not bold magenta: {out2!r}")


def color_enabled_recomputes_each_call() -> None:
    """No caching — flipping env vars between calls changes the answer."""
    s = _FakeStream(True)
    with env(NO_COLOR=None, TENACIOUS_COLOR=None):
        expect(tc.color_enabled(s) is True, "expected True initially")
    with env(NO_COLOR="1", TENACIOUS_COLOR=None):
        expect(tc.color_enabled(s) is False,
               "expected False after setting NO_COLOR")
    with env(NO_COLOR=None, TENACIOUS_COLOR=None):
        expect(tc.color_enabled(s) is True,
               "expected True after clearing NO_COLOR (cache bleed?)")


# ----- runner ----------------------------------------------------------------

_SCENARIOS = [
    enabled_when_tty_and_no_disable_envs,
    disabled_when_not_a_tty,
    disabled_by_NO_COLOR_envvar,
    disabled_by_TENACIOUS_COLOR_zero,
    force_enabled_by_TENACIOUS_COLOR_one_on_non_tty,
    NO_COLOR_overrides_TENACIOUS_COLOR_one,
    colorize_dims_leading_timestamp,
    colorize_paints_health_monitor_magenta,
    colorize_paints_known_stepname_cyan,
    colorize_does_not_paint_unknown_bracket,
    colorize_paints_claude_cmd_blue,
    colorize_paints_codex_cmd_blue,
    colorize_paints_exited_zero_green,
    colorize_paints_exited_nonzero_red,
    colorize_multi_line_handles_each_line,
    banner_step_is_bold_cyan,
    banner_question_is_bold_yellow,
    banner_health_is_bold_magenta,
    banner_invalid_role_raises,
    dim_helper_wraps_in_dim_reset,
    all_helpers_return_input_unchanged_when_disabled,
    step_boundary_line_gets_both_dim_ts_and_bold_cyan_body,
    health_banner_header_line_gets_bold_magenta,
    color_enabled_recomputes_each_call,
]


def main() -> int:
    for scn in _SCENARIOS:
        try:
            scn()
        except AssertionError as e:
            print(f"FAIL {scn.__name__}: {e}")
            return 1
        except Exception:
            traceback.print_exc()
            print(f"FAIL {scn.__name__}: unexpected exception")
            return 1
        print(f"PASS {scn.__name__}")
    print(f"ALL PASS ({len(_SCENARIOS)} scenarios)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
