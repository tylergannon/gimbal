"""End-to-end test for round-2 colored output (G-4).

Spawns `python -m tenacious` against a tiny fake-agent workflow (same
shim recipe as `tests/test_mcp_e2e_fake_claude.py`) with stdout piped to
a file so we can scan the captured bytes for ANSI escape sequences.

Scenarios:

  - tenacious_stdout_piped_to_file_has_no_ansi  — default invocation,
    stdout pipe is non-tty -> ZERO `\\x1b[` in captured stdout AND in
    `<run_root>/run.log`. Also confirms the run reaches `workflow
    complete (end)` so the wiring did not break the happy path.
  - tenacious_run_log_file_has_no_ansi          — independent assertion.
  - tenacious_stdout_force_enabled_has_ansi     — `TENACIOUS_COLOR=1`
    => AT LEAST one `\\x1b[` in captured stdout, none in run.log.
  - tenacious_NO_COLOR_overrides_TENACIOUS_COLOR_one — both env vars
    set => stdout has zero `\\x1b[`. Locks in the single precedence
    rule end-to-end. Future changes must not flip this.

Run from the project root:

    python3 tests/test_term_color_e2e.py
"""

from __future__ import annotations

import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import traceback
from pathlib import Path


_PROJECT_ROOT = Path(__file__).resolve().parent.parent


def _write_fake_claude(bin_dir: Path) -> None:
    bin_dir.mkdir(parents=True, exist_ok=True)
    shim = bin_dir / "claude"
    shim.write_text(f"""#!{sys.executable}
import os, sys, json
# Pluck the orchestrator's outcome.txt path out of the rendered prompt.
out_path = None
for i, a in enumerate(sys.argv):
    if a == '-p' and i + 1 < len(sys.argv):
        body = sys.argv[i + 1]
        marker = 'write the slug of the next step to:'
        idx = body.find(marker)
        if idx != -1:
            tail = body[idx + len(marker):].lstrip()
            line_end = tail.find('\\n')
            out_path = tail[:line_end].strip() if line_end != -1 else tail.strip()
        break
if out_path:
    with open(out_path, 'w') as f:
        f.write('end\\n')
sys.stdout.write(json.dumps({{'type': 'result', 'subtype': 'success',
                              'result': 'ok'}}) + '\\n')
sys.exit(0)
""")
    shim.chmod(shim.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def _populate_auth_bank(home: Path) -> None:
    bank = home / "auth-bank" / "anthropic" / "fake"
    bank.mkdir(parents=True, exist_ok=True)
    (bank / "slot.txt").write_text("fake-token\n")


def _write_workflow(path: Path) -> None:
    path.write_text(json.dumps({
        "goal": "g", "start_step": "s",
        "steps": {"s": {
            "agent": "claude", "prompt": "go do the thing",
            "next_steps": ["end"],
        }},
    }))


def _run_tenacious(home: Path, bin_dir: Path, wf_path: Path,
                   extra_env: dict[str, str] | None = None
                   ) -> tuple[int, str, str]:
    env = os.environ.copy()
    env["TENACIOUS_HOME"] = str(home)
    env["PATH"] = f"{bin_dir}:{env.get('PATH', '')}"
    # Default: scrub any TENACIOUS_COLOR / NO_COLOR inherited from the
    # outer shell so each scenario starts from a clean slate. Scenarios
    # then explicitly opt-in via `extra_env`.
    env.pop("TENACIOUS_COLOR", None)
    env.pop("NO_COLOR", None)
    if extra_env:
        env.update(extra_env)
    r = subprocess.run(
        [sys.executable, "-m", "tenacious", str(wf_path)],
        cwd=str(_PROJECT_ROOT), env=env,
        capture_output=True, text=True, timeout=60,
    )
    return r.returncode, r.stdout, r.stderr


def _latest_run(home: Path) -> Path:
    runs = home / "runs"
    entries = sorted(p for p in runs.iterdir() if p.is_dir())
    if not entries:
        raise AssertionError(f"no runs created under {runs}")
    return entries[-1]


def _setup() -> tuple[Path, Path, Path, Path]:
    d = Path(tempfile.mkdtemp(prefix="tnc-e2e-tc-"))
    home = d / "home"
    bin_dir = d / "bin"
    home.mkdir()
    _write_fake_claude(bin_dir)
    _populate_auth_bank(home)
    wf = d / "wf.json"
    _write_workflow(wf)
    return d, home, bin_dir, wf


def tenacious_stdout_piped_to_file_has_no_ansi() -> None:
    d, home, bin_dir, wf = _setup()
    try:
        rc, out, err = _run_tenacious(home, bin_dir, wf)
        assert rc == 0, (rc, err, out)
        assert "\x1b[" not in out, (
            f"captured stdout (pipe, no env) contained ANSI: {out!r}")
        assert "workflow complete (end)" in out, (
            f"workflow did not reach end:\n{out!r}\nSTDERR:\n{err!r}")
        run_root = _latest_run(home)
        log = (run_root / "run.log").read_text()
        assert "\x1b[" not in log, f"run.log contained ANSI: {log!r}"
    finally:
        shutil.rmtree(d, ignore_errors=True)


def tenacious_run_log_file_has_no_ansi() -> None:
    """Independent of stdout: read `run.log` directly and verify."""
    d, home, bin_dir, wf = _setup()
    try:
        rc, _out, _err = _run_tenacious(
            home, bin_dir, wf, extra_env={"TENACIOUS_COLOR": "1"})
        assert rc == 0, rc
        run_root = _latest_run(home)
        log = (run_root / "run.log").read_text()
        assert "\x1b[" not in log, (
            f"run.log under TENACIOUS_COLOR=1 still contained ANSI: "
            f"{log!r}")
    finally:
        shutil.rmtree(d, ignore_errors=True)


def tenacious_stdout_force_enabled_has_ansi() -> None:
    d, home, bin_dir, wf = _setup()
    try:
        rc, out, err = _run_tenacious(
            home, bin_dir, wf, extra_env={"TENACIOUS_COLOR": "1"})
        assert rc == 0, (rc, err, out)
        assert "\x1b[" in out, (
            f"TENACIOUS_COLOR=1 produced no ANSI on captured stdout: "
            f"{out!r}")
    finally:
        shutil.rmtree(d, ignore_errors=True)


def tenacious_NO_COLOR_overrides_TENACIOUS_COLOR_one() -> None:
    """Locks in the single env-precedence rule: NO_COLOR always wins.

    Future maintainers: this assertion is intentional. If you have a
    use case that needs colors to survive NO_COLOR, do NOT silently
    invert the rule — it would break consumers of the no-color.org
    convention. Add a new env var instead.
    """
    d, home, bin_dir, wf = _setup()
    try:
        rc, out, _err = _run_tenacious(
            home, bin_dir, wf,
            extra_env={"TENACIOUS_COLOR": "1", "NO_COLOR": "1"})
        assert rc == 0, rc
        assert "\x1b[" not in out, (
            f"NO_COLOR did not override TENACIOUS_COLOR=1 (regression!): "
            f"{out!r}")
    finally:
        shutil.rmtree(d, ignore_errors=True)


SCENARIOS = [
    ("tenacious_stdout_piped_to_file_has_no_ansi",
     tenacious_stdout_piped_to_file_has_no_ansi),
    ("tenacious_run_log_file_has_no_ansi",
     tenacious_run_log_file_has_no_ansi),
    ("tenacious_stdout_force_enabled_has_ansi",
     tenacious_stdout_force_enabled_has_ansi),
    ("tenacious_NO_COLOR_overrides_TENACIOUS_COLOR_one",
     tenacious_NO_COLOR_overrides_TENACIOUS_COLOR_one),
]


def main() -> int:
    for name, fn in SCENARIOS:
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            print(f"FAIL {name}: {e}")
            traceback.print_exc()
            return 1
        print(f"PASS {name}")
    print(f"ALL PASS ({len(SCENARIOS)} scenarios)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
