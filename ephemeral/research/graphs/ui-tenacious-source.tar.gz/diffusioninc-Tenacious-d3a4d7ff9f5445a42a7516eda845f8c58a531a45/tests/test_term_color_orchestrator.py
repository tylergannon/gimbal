"""Orchestrator-level wiring tests for round-2 colored terminal output (G-3).

Stdlib only. Imports `tenacious.orchestrator` and `tenacious.term_color`
and exercises the in-process wiring without spawning a subprocess. Pty
fixtures degrade to SKIP cleanly when unavailable.

Run from the project root:

    python3 tests/test_term_color_orchestrator.py

Prints `PASS <scenario>` or `SKIP <scenario>: <reason>` per scenario,
then `ALL PASS (<n> scenarios)`. Exits 0 on success.
"""

from __future__ import annotations

import io
import os
import shutil
import sys
import tempfile
import traceback
from contextlib import contextmanager
from pathlib import Path

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import tenacious.orchestrator as o  # noqa: E402
from tenacious import term_color as tc  # noqa: E402


# ----- helpers ---------------------------------------------------------------

class _TtyStringIO(io.StringIO):
    """A StringIO that lies about being a TTY (or not), per construction."""

    def __init__(self, is_tty: bool):
        super().__init__()
        self._is_tty = is_tty

    def isatty(self) -> bool:
        return self._is_tty


@contextmanager
def env(**kwargs):
    saved: dict[str, str | None] = {}
    for k, v in kwargs.items():
        saved[k] = os.environ.get(k)
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    try:
        yield
    finally:
        for k, v in saved.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


@contextmanager
def temp_run(step_slugs=("code",)):
    """Construct a real Run with a tiny in-memory workflow."""
    d = tempfile.mkdtemp(prefix="tnc-tc-")
    try:
        root = Path(d) / "run"
        proj = Path(d) / "proj"
        (root / "assets").mkdir(parents=True)
        proj.mkdir(parents=True)
        steps = {}
        for slug in step_slugs:
            steps[slug] = o.Step(
                slug=slug, agent="fake", prompt="p",
                next_steps=["end"], context="empty",
            )
        wf = o.Workflow(goal="g", start_step=step_slugs[0], steps=steps)
        run = o.Run(slug="tcrun", root=root, workflow=wf, project_dir=proj,
                    accounts={})
        yield run
    finally:
        shutil.rmtree(d, ignore_errors=True)


@contextmanager
def captured_stdout(is_tty: bool):
    """Swap sys.stdout for a captured stream with a known is_tty flag."""
    buf = _TtyStringIO(is_tty)
    saved = sys.stdout
    sys.stdout = buf
    try:
        yield buf
    finally:
        sys.stdout = saved


def expect(cond: bool, detail: str) -> None:
    if not cond:
        raise AssertionError(detail)


def _strip_ansi(s: str) -> str:
    """Strip CSI escape sequences for plain-text comparison."""
    import re
    return re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", s)


# ----- scenarios -------------------------------------------------------------

def run_log_to_tty_emits_ansi_for_step_boundary() -> None:
    with env(NO_COLOR=None, TENACIOUS_COLOR="1"), temp_run() as run, \
            captured_stdout(is_tty=True) as out:
        run.log("step code visit 1 (agent=claude, context=fresh)")
        captured = out.getvalue()
        file_text = run.log_path.read_text()
    expect("\x1b[" in captured,
           f"expected ANSI in stdout, got: {captured!r}")
    expect(f"{tc.BOLD}{tc.CYAN}step code visit 1 "
           f"(agent=claude, context=fresh){tc.RESET}" in captured,
           f"step boundary body not bold-cyan: {captured!r}")
    expect("\x1b[" not in file_text,
           f"run.log file should never contain ANSI: {file_text!r}")


def run_log_to_nontty_emits_no_ansi() -> None:
    with env(NO_COLOR=None, TENACIOUS_COLOR=None), temp_run() as run, \
            captured_stdout(is_tty=False) as out:
        run.log("step code visit 1 (agent=claude, context=fresh)")
    captured = out.getvalue()
    expect("\x1b[" not in captured,
           f"expected NO ANSI on non-TTY stdout: {captured!r}")


def run_log_health_monitor_prefix_magenta() -> None:
    with env(NO_COLOR=None, TENACIOUS_COLOR="1"), temp_run() as run, \
            captured_stdout(is_tty=True) as out:
        run.log("  [health_monitor] tick 3 (agent=claude)")
    captured = out.getvalue()
    expect(f"{tc.MAGENTA}[health_monitor]{tc.RESET}" in captured,
           f"[health_monitor] not wrapped magenta: {captured!r}")


def run_log_known_stepname_prefix_cyan() -> None:
    with env(NO_COLOR=None, TENACIOUS_COLOR="1"), temp_run() as run, \
            captured_stdout(is_tty=True) as out:
        run.log("  [code] valid outcome.txt detected while agent still running")
    captured = out.getvalue()
    expect(f"{tc.CYAN}[code]{tc.RESET}" in captured,
           f"[code] not wrapped cyan: {captured!r}")


def run_log_unknown_stepname_prefix_uncolored() -> None:
    with env(NO_COLOR=None, TENACIOUS_COLOR="1"), temp_run() as run, \
            captured_stdout(is_tty=True) as out:
        # [no_such_step] is not in the workflow's step set.
        run.log("  [no_such_step] surprise log line")
    captured = out.getvalue()
    expect(f"{tc.CYAN}[no_such_step]" not in captured
           and f"{tc.MAGENTA}[no_such_step]" not in captured,
           f"unknown bracket was colorized: {captured!r}")


def run_log_health_banner_multi_line_colors_both_wrappers() -> None:
    with env(NO_COLOR=None, TENACIOUS_COLOR="1"), temp_run() as run, \
            captured_stdout(is_tty=True) as out:
        banner = (
            "===== SESSION HEALTH UPDATE (tick 4) =====\n"
            "- body line\n"
            "[2026-05-21T10:11:13] ===== END SESSION HEALTH UPDATE ====="
        )
        run.log_monitor(banner)
    captured = out.getvalue()
    # Header line: bold magenta around the ===== ... ===== payload.
    expect(f"{tc.BOLD}{tc.MAGENTA}===== SESSION HEALTH UPDATE (tick 4) "
           f"====={tc.RESET}" in captured,
           f"header banner not bold magenta: {captured!r}")
    # END line: same.
    expect(f"{tc.BOLD}{tc.MAGENTA}===== END SESSION HEALTH UPDATE "
           f"====={tc.RESET}" in captured,
           f"END banner not bold magenta: {captured!r}")
    # Body line untouched.
    expect("- body line" in captured
           and f"{tc.MAGENTA}- body line" not in captured
           and f"{tc.BOLD}- body line" not in captured,
           f"body line was modified: {captured!r}")


def run_log_file_is_byte_identical_to_pre_color() -> None:
    """Same `Run.log(...)` text emitted with color on vs off — file
    contents must be byte-identical."""
    text = (
        "step code visit 1 (agent=claude, context=fresh)",
        "  [health_monitor] tick 3 (agent=claude)",
        "  claude cmd: ...anthropic/acct/slot.txt ... (prompt len=10B)",
        "  exited 0 in 1.2s",
        "  exited 137 in 9.0s",
    )
    with env(NO_COLOR=None, TENACIOUS_COLOR="1"), temp_run() as run_on, \
            captured_stdout(is_tty=True):
        for t in text:
            run_on.log(t)
        a = run_on.log_path.read_text()
    with env(NO_COLOR="1", TENACIOUS_COLOR=None), temp_run() as run_off, \
            captured_stdout(is_tty=False):
        for t in text:
            run_off.log(t)
        b = run_off.log_path.read_text()
    # Strip timestamps so we compare just the message content.
    import re
    norm = re.compile(r"\[\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\] ")
    a2 = norm.sub("[TS] ", a)
    b2 = norm.sub("[TS] ", b)
    expect(a2 == b2, f"file contents diverged:\n  on:  {a2!r}\n  off: {b2!r}")
    expect("\x1b[" not in a,
           f"run.log under color-on contained ANSI: {a!r}")


def resume_terminal_replays_colored_strings() -> None:
    with env(NO_COLOR=None, TENACIOUS_COLOR="1"), temp_run() as run, \
            captured_stdout(is_tty=True) as out:
        run.suspend_terminal()
        run.log("step code visit 1 (agent=claude, context=fresh)")
        # Nothing on stdout yet — it's buffered.
        mid = out.getvalue()
        expect(mid == "",
               f"expected empty stdout while suspended, got: {mid!r}")
        run.resume_terminal()
    captured = out.getvalue()
    expect("\x1b[" in captured,
           f"resumed buffer must contain colored bytes: {captured!r}")
    expect(f"{tc.BOLD}{tc.CYAN}step code visit 1 "
           f"(agent=claude, context=fresh){tc.RESET}" in captured,
           f"resumed text missing step-banner styling: {captured!r}")


# ----- raw editor (pty) ------------------------------------------------------

def _pty_pair():
    """Allocate a master/slave pty pair; return (master_fd, slave_fd) or
    None if pty support is unavailable on this platform."""
    try:
        import pty as _pty
    except ImportError:
        return None
    try:
        m, s = _pty.openpty()
    except OSError:
        return None
    return m, s


def raw_editor_banner_colors_question_header_and_dims_footer() -> None:
    pair = _pty_pair()
    if pair is None:
        raise _Skip("pty unavailable on this platform")
    m, s = pair
    try:
        with env(NO_COLOR=None, TENACIOUS_COLOR="1"):
            ed = o._RawLineEditor(m, s, "Pick a color?")
            ed._term_width = lambda: 80
            text = ed._banner()
        # Header row: bold yellow wrap.
        expect(f"{tc.BOLD}{tc.YELLOW}[Question from agent]{tc.RESET}"
               in text,
               f"header not wrapped bold yellow: {text!r}")
        # Footer rows: at least one DIM-RESET wrapper.
        expect(f"{tc.DIM}--- type your answer below ---{tc.RESET}" in text,
               f"footer marker not dimmed: {text!r}")
        # The question body itself is not colored.
        expect("Pick a color?" in text
               and f"{tc.YELLOW}Pick a color?" not in text
               and f"{tc.DIM}Pick a color?" not in text,
               f"question body was modified: {text!r}")
    finally:
        os.close(m)
        os.close(s)


def raw_editor_banner_narrow_terminal_keeps_styling() -> None:
    pair = _pty_pair()
    if pair is None:
        raise _Skip("pty unavailable on this platform")
    m, s = pair
    try:
        with env(NO_COLOR=None, TENACIOUS_COLOR="1"):
            ed = o._RawLineEditor(m, s, "Pick a color?")
            # Narrow width forces both header and footer to wrap.
            ed._term_width = lambda: 10
            text = ed._banner()
        # Header text "[Question from agent]" is 20 chars at width 10 ->
        # at least two physical rows; EVERY row must carry bold-yellow.
        rows_with_styling = text.count(f"{tc.BOLD}{tc.YELLOW}")
        expect(rows_with_styling >= 2,
               f"header rows missing bold-yellow at narrow width: "
               f"{text!r} (got {rows_with_styling})")
        # Plain (non-colored) "[Question from agent]" must NOT appear
        # spanning a single line — proves wrap happened.
        plain = _strip_ansi(text)
        expect("[Question from agent]" not in plain.replace("\r", ""),
               f"header did not wrap at width 10: plain={plain!r}")
        # Every plain footer row appears dimmed in the actual text — pick
        # the marker line and confirm each of its wrapped rows is dimmed.
        # At width 10, "--- type your answer below ---" wraps to multiple
        # rows; we just assert at least 2 dim wrappers in total.
        dim_count = text.count(tc.DIM)
        expect(dim_count >= 2,
               f"expected >=2 dim wrappers at narrow width, got "
               f"{dim_count}: {text!r}")
    finally:
        os.close(m)
        os.close(s)


def stderr_fallback_question_block_colored_when_stderr_is_tty() -> None:
    text = o._format_question_block_for_stderr(
        "Pick a color?", enabled=True)
    expect(f"{tc.BOLD}{tc.YELLOW}[Question from agent]{tc.RESET}" in text,
           f"header not bold-yellow in stderr fallback: {text!r}")
    expect(f"{tc.DIM}(no interactive terminal" in text
           and f"paste supported){tc.RESET}" in text,
           f"help footer not dimmed in stderr fallback: {text!r}")
    # And the disabled variant returns plain bytes.
    text_off = o._format_question_block_for_stderr(
        "Pick a color?", enabled=False)
    expect("\x1b[" not in text_off,
           f"stderr fallback with enabled=False contained ANSI: "
           f"{text_off!r}")
    expect("[Question from agent]" in text_off
           and "Pick a color?" in text_off,
           f"stderr fallback (off) missing required text: {text_off!r}")


# ----- runner ----------------------------------------------------------------

class _Skip(Exception):
    pass


_SCENARIOS = [
    run_log_to_tty_emits_ansi_for_step_boundary,
    run_log_to_nontty_emits_no_ansi,
    run_log_health_monitor_prefix_magenta,
    run_log_known_stepname_prefix_cyan,
    run_log_unknown_stepname_prefix_uncolored,
    run_log_health_banner_multi_line_colors_both_wrappers,
    run_log_file_is_byte_identical_to_pre_color,
    resume_terminal_replays_colored_strings,
    raw_editor_banner_colors_question_header_and_dims_footer,
    raw_editor_banner_narrow_terminal_keeps_styling,
    stderr_fallback_question_block_colored_when_stderr_is_tty,
]


def main() -> int:
    passed = 0
    skipped = 0
    for scn in _SCENARIOS:
        try:
            scn()
        except _Skip as s:
            print(f"SKIP {scn.__name__}: {s}")
            skipped += 1
            continue
        except AssertionError as e:
            print(f"FAIL {scn.__name__}: {e}")
            return 1
        except Exception:
            traceback.print_exc()
            print(f"FAIL {scn.__name__}: unexpected exception")
            return 1
        print(f"PASS {scn.__name__}")
        passed += 1
    if skipped:
        print(f"ALL PASS ({passed} scenarios, {skipped} skipped)")
    else:
        print(f"ALL PASS ({passed} scenarios)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
