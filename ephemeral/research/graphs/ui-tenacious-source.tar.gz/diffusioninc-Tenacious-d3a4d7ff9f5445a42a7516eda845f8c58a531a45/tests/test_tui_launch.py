"""Verification that the interactive TUI launch path never crashes.

Guards the round-0001 code-feedback critical finding: a `_curses.error`
from `curses.curs_set()` / `curses.wrapper` startup must NOT escape as a
Python traceback with a non-zero exit. The requirements mandate a clear
message and a clean exit there.

Each case launches `python -m tenacious.viewer` (no surface flag) under a
real pseudo-terminal so `sys.stdout.isatty()` is True and the TUI path is
taken. We then feed `q` and assert the process:

  * exits 0, AND
  * never prints a Python traceback,

whether it entered the curses TUI and quit on `q`, or printed the
fallback message because the terminal cannot support curses.

TERM variants exercised:
  * unset            -> initscr()/wrapper startup typically fails
                        (run_tui `except curses.error` fallback path)
  * "dumb"           -> initscr() succeeds but curs_set() returns ERR
                        (the exact reported regression; now guarded)
  * "xterm-256color" -> normal full-screen TUI; `q` quits cleanly

Run directly:  python3 tests/test_tui_launch.py
Exit 0 = all pass; non-zero = a failure (message on stderr).
"""

from __future__ import annotations

import os
import pty
import select
import struct
import subprocess
import sys
import termios
import time

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

_failures: list[str] = []


def _set_winsize(fd: int, rows: int, cols: int) -> None:
    try:
        import fcntl
        fcntl.ioctl(fd, termios.TIOCSWINSZ,
                    struct.pack("HHHH", rows, cols, 0, 0))
    except Exception:
        pass


def _launch(term, timeout: float = 20.0):
    """Run the viewer under a pty with the given TERM; feed `q`.

    Returns (returncode, decoded_output).
    """
    master, slave = pty.openpty()
    _set_winsize(slave, 40, 120)

    env = dict(os.environ)
    if term is None:
        env.pop("TERM", None)
    else:
        env["TERM"] = term

    proc = subprocess.Popen(
        [sys.executable, "-m", "tenacious.viewer"],
        cwd=REPO, env=env,
        stdin=slave, stdout=slave, stderr=slave,
        close_fds=True,
    )
    os.close(slave)

    out = bytearray()
    sent = False
    deadline = time.time() + timeout
    while True:
        if proc.poll() is not None:
            break
        if time.time() > deadline:
            proc.kill()
            proc.wait(timeout=5)
            try:
                os.close(master)
            except OSError:
                pass
            raise AssertionError(
                f"viewer did not exit within {timeout}s (TERM={term!r}); "
                f"output:\n{bytes(out).decode(errors='replace')}")
        try:
            r, _, _ = select.select([master], [], [], 0.2)
            if r:
                chunk = os.read(master, 4096)
                if chunk:
                    out += chunk
        except OSError:
            # Slave side closed (process exited / fallback path).
            break
        if not sent:
            # Let curses attempt initialization, then send the quit key.
            # Harmless if the process already printed a fallback and is
            # exiting: the write may raise OSError which we swallow.
            time.sleep(0.5)
            try:
                os.write(master, b"q")
            except OSError:
                pass
            sent = True

    # Drain any remaining buffered output.
    try:
        while True:
            r, _, _ = select.select([master], [], [], 0.1)
            if not r:
                break
            chunk = os.read(master, 4096)
            if not chunk:
                break
            out += chunk
    except OSError:
        pass
    try:
        os.close(master)
    except OSError:
        pass

    rc = proc.wait(timeout=5)
    return rc, bytes(out).decode(errors="replace")


def _check(term) -> None:
    label = f"TERM={term!r}"
    try:
        rc, output = _launch(term)
    except AssertionError as e:
        _failures.append(f"{label}: {e}")
        print(f"  FAIL: {label}: {e}")
        return

    has_tb = "Traceback (most recent call last)" in output
    if rc == 0 and not has_tb:
        print(f"  ok: {label}: exit 0, no traceback")
        return

    detail = []
    if rc != 0:
        detail.append(f"exit={rc}")
    if has_tb:
        detail.append("traceback present")
    msg = (f"{label}: {', '.join(detail)}; output:\n"
           f"{output}")
    _failures.append(msg)
    print(f"  FAIL: {msg}")


def main() -> int:
    print("tui launch checks (pty):")
    for term in (None, "dumb", "xterm-256color"):
        _check(term)
    if _failures:
        sys.stderr.write(f"\n{len(_failures)} failure(s):\n")
        for f in _failures:
            sys.stderr.write(f"  - {f}\n")
        return 1
    print("\nALL TUI-LAUNCH CHECKS PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
