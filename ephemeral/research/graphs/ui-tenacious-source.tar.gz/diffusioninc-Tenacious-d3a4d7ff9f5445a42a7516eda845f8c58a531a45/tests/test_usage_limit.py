"""Verification harness for usage-limit detection (round 1).

Stdlib only. Creates its own temp dirs. Does not need the auth bank,
real agent binaries, or network. Exercises both the standalone detector
helpers and the end-to-end `execute_step` integration when an agent's
captured stdout/stderr matches a known usage-limit signature.

Run from the project root:

    .venv/bin/python tests/test_usage_limit.py

Prints `PASS <scenario>` per scenario, then `ALL PASS (<n> scenarios)`.
Exits 0 if all pass; 1 with `FAIL <scenario>: <detail>` on first failure.
"""

from __future__ import annotations

import os
import shutil
import sys
import tempfile
import traceback
from contextlib import contextmanager
from pathlib import Path

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import tenacious.orchestrator as o  # noqa: E402


_FIXTURES = Path(_PROJECT_ROOT) / "tests" / "fixtures"


# ----- helpers ---------------------------------------------------------------

class Patcher:
    def __init__(self):
        self._saved = []

    def set(self, obj, attr, value):
        self._saved.append((obj, attr, getattr(obj, attr)))
        setattr(obj, attr, value)

    def undo(self):
        for obj, attr, value in reversed(self._saved):
            setattr(obj, attr, value)
        self._saved.clear()


@contextmanager
def temp_run(goal="GOALTEXT-MARKER"):
    d = tempfile.mkdtemp(prefix="tnc-usage-")
    try:
        root = Path(d) / "run"
        proj = Path(d) / "proj"
        (root / "assets").mkdir(parents=True)
        (root / "profiles").mkdir(parents=True)
        proj.mkdir(parents=True)
        wf = o.Workflow(goal=goal, start_step="s", steps={})
        run = o.Run(slug="usagerun", root=root, workflow=wf,
                    project_dir=proj, accounts={})
        yield run, Path(d)
    finally:
        shutil.rmtree(d, ignore_errors=True)


def mkstep_codex(slug="s", next_steps=("code_review",)):
    return o.Step(slug=slug, agent="codex", prompt="do {goal} now",
                  next_steps=list(next_steps), questions=False,
                  context="empty")


def stdout_runner(stdout_text="", stderr_text="STDERR_TAIL_MARKER",
                  exit_code=1):
    def runner(step, run, visit, step_dir, prompt, should_continue):
        return {"exit": exit_code, "stdout": stdout_text,
                "stderr": stderr_text}
    return runner


def _log(run):
    return (run.root / "run.log").read_text()


def _read_fixture(name):
    return (_FIXTURES / name).read_text()


# ----- scenarios -------------------------------------------------------------

def s_detector_codex_stdout_positive():
    text = _read_fixture("usage_limit_codex.jsonl")
    matched, reset = o._detect_usage_limit("codex", text, "")
    assert matched is True, (matched, reset)
    assert reset == "12:19 AM", repr(reset)


def s_detector_codex_stderr_positive():
    text = _read_fixture("usage_limit_codex.jsonl")
    matched, reset = o._detect_usage_limit("codex", "", text)
    assert matched is True, (matched, reset)
    assert reset == "12:19 AM", repr(reset)


def s_detector_codex_stdout_takes_precedence():
    stdout_text = _read_fixture("usage_limit_codex.jsonl")  # reset 12:19 AM
    stderr_text = (
        '{"type":"thread.started","thread_id":"x"}\n'
        '{"type":"turn.started"}\n'
        '{"type":"turn.failed","error":{"message":"You\'ve hit your usage '
        'limit. try again at 09:42 PM."}}\n'
    )
    matched, reset = o._detect_usage_limit("codex", stdout_text, stderr_text)
    assert matched is True, (matched, reset)
    assert reset == "12:19 AM", repr(reset)


def s_detector_codex_negative_control():
    text = _read_fixture("no_usage_limit_codex.jsonl")
    a = o._detect_usage_limit("codex", text, "")
    b = o._detect_usage_limit("codex", "", text)
    assert a == (False, None), a
    assert b == (False, None), b


def s_detector_codex_no_reset_time():
    text = (
        '{"type":"thread.started","thread_id":"x"}\n'
        '{"type":"turn.started"}\n'
        '{"type":"turn.failed","error":{"message":"You\'ve hit your usage '
        'limit. Upgrade to Pro or purchase credits."}}\n'
    )
    matched, reset = o._detect_usage_limit("codex", text, "")
    assert matched is True, (matched, reset)
    assert reset is None, repr(reset)


def s_format_tag():
    a = o._format_usage_limit_tag("codex", "12:19 AM")
    b = o._format_usage_limit_tag("codex", None)
    assert a == "usage_limited (codex, reset~12:19 AM)", repr(a)
    assert b == "usage_limited (codex)", repr(b)


def s_integration_retry_log_tagged():
    p = Patcher()
    try:
        usage_stdout = _read_fixture("usage_limit_codex.jsonl")
        p.set(o, "AGENT_RUNNERS", {"codex": stdout_runner(
            stdout_text=usage_stdout, stderr_text="", exit_code=1)})
        with temp_run() as (run, _d):
            step = mkstep_codex()
            raised = None
            try:
                o.execute_step(step, run, o.AnswerSource(None))
            except RuntimeError as e:
                raised = e
            assert raised is not None, "expected RuntimeError"
            msg = str(raised)
            assert msg.startswith(
                "usage_limited (codex, reset~12:19 AM): "), msg
            assert "no valid outcome.txt" in msg, msg
            assert msg.endswith("(after 2 retries)"), msg
            log = _log(run)
            assert ("retry 1/2: usage_limited (codex, reset~12:19 AM)"
                    in log), log
            assert ("retry 2/2: usage_limited (codex, reset~12:19 AM)"
                    in log), log
            assert "retry 1/2: no_outcome" not in log, log
            assert "retry 2/2: no_outcome" not in log, log
    finally:
        p.undo()


def s_integration_non_usage_limit_unchanged():
    p = Patcher()
    try:
        p.set(o, "AGENT_RUNNERS", {"codex": stdout_runner(
            stdout_text="", stderr_text="", exit_code=0)})
        with temp_run() as (run, _d):
            step = mkstep_codex()
            raised = None
            try:
                o.execute_step(step, run, o.AnswerSource(None))
            except RuntimeError as e:
                raised = e
            assert raised is not None, "expected RuntimeError"
            msg = str(raised)
            assert "usage_limited" not in msg, msg
            assert "no valid outcome.txt" in msg, msg
            assert msg.endswith("(after 2 retries)"), msg
            log = _log(run)
            assert "retry 1/2: no_outcome" in log, log
            assert "retry 2/2: no_outcome" in log, log
            assert "usage_limited" not in log, log
    finally:
        p.undo()


SCENARIOS = [
    ("s_detector_codex_stdout_positive", s_detector_codex_stdout_positive),
    ("s_detector_codex_stderr_positive", s_detector_codex_stderr_positive),
    ("s_detector_codex_stdout_takes_precedence",
     s_detector_codex_stdout_takes_precedence),
    ("s_detector_codex_negative_control", s_detector_codex_negative_control),
    ("s_detector_codex_no_reset_time", s_detector_codex_no_reset_time),
    ("s_format_tag", s_format_tag),
    ("s_integration_retry_log_tagged", s_integration_retry_log_tagged),
    ("s_integration_non_usage_limit_unchanged",
     s_integration_non_usage_limit_unchanged),
]


def main() -> int:
    for name, fn in SCENARIOS:
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            print(f"FAIL {name}: {e}")
            traceback.print_exc()
            return 1
        print(f"PASS {name}")
    print(f"ALL PASS ({len(SCENARIOS)} scenarios)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
