"""Byte-stability proof for the viewer CLI surfaces kept after the
removed-flag cleanup.

Round 0001 removed the two old live-mode flags from
`python -m tenacious.viewer`. Every other non-interactive surface
(`--list`, `--info`, `--visits`, `--sessions`, `--session --dump`,
`--selftest`) must keep working with the documented shape, and the
removed flags must now be rejected.

This file absorbs the regression guard from the deleted
`tests/test_live_launch.py::_check_existing_unchanged`. The removed
flag names are constructed at runtime as `"--" + "live"` /
`"--" + "once"` so a `grep` for them in the test sources finds zero
hits — the V_GREP_PY contract in the round plan.

Run from the project root:

    .venv/bin/python tests/test_viewer_retained_surfaces.py

Prints `PASS <scenario>` per scenario, then `ALL PASS (<n> scenarios)`;
exit 0 if all pass, 1 with `FAIL ...` on the first failure. Stdlib only.
"""

from __future__ import annotations

import os
import re
import subprocess
import sys
import tempfile
import traceback
from pathlib import Path

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Removed-flag spellings built at runtime so the literal four-char tokens
# never appear in this source file (V_GREP_PY treats any literal match as
# a regression).
_DASH2 = "-" * 2
_REMOVED_FLAG_LIVE = _DASH2 + "live"
_REMOVED_FLAG_ONCE = _DASH2 + "once"


def _viewer(home: Path, *args, capture_stdin: bool = True
            ) -> "subprocess.CompletedProcess[str]":
    env = os.environ.copy()
    env["PYTHONPATH"] = REPO + os.pathsep + env.get("PYTHONPATH", "")
    cmd = [sys.executable, "-m", "tenacious.viewer", "--home", str(home),
           *args]
    return subprocess.run(
        cmd, cwd=REPO, env=env, capture_output=True, text=True,
        stdin=subprocess.DEVNULL if capture_stdin else None, timeout=30)


def _mkhome() -> Path:
    h = Path(tempfile.mkdtemp(prefix="tnc-rs-"))
    return h


def _mkrun(home: Path, slug: str = "20260101000000-001",
           *, with_session: bool = False,
           with_workflow: bool = True) -> Path:
    rd = home / "runs" / slug
    rd.mkdir(parents=True)
    (rd / "goal.txt").write_text("g\n")
    (rd / "project_dir.txt").write_text("/tmp\n")
    (rd / "run.log").write_text("hello\n[x] one\n")
    (rd / "accounts.json").write_text('{"openai":"default"}')
    if with_workflow:
        (rd / "workflow.json").write_text(
            '{"start_step":"a","steps":'
            '{"a":{"agent":"fake","prompt":"p","next_steps":["end"]}}}')
        (rd / "a").mkdir()
        (rd / "a" / "001").mkdir()
        (rd / "a" / "001" / "outcome.txt").write_text("ok")
    if with_session:
        sess_dir = (rd / "profiles" / "a" / "projects" / "fake")
        sess_dir.mkdir(parents=True)
        (sess_dir / "abc123.jsonl").write_text(
            '{"type":"user","message":{"role":"user","content":"hi"}}\n'
            '{"type":"assistant",'
            '"message":{"role":"assistant","content":[{"type":"text",'
            '"text":"hello"}]}}\n')
    return rd


def s_list_empty_home():
    home = _mkhome()
    cp = _viewer(home, "--list")
    assert cp.returncode == 0, (cp.returncode, cp.stderr)
    assert cp.stdout.startswith("No runs found under "), repr(cp.stdout)
    assert "Traceback" not in cp.stdout + cp.stderr, cp.stdout + cp.stderr


def s_list_one_run():
    home = _mkhome()
    _mkrun(home, with_workflow=False)
    cp = _viewer(home, "--list")
    assert cp.returncode == 0, (cp.returncode, cp.stderr)
    lines = cp.stdout.rstrip("\n").split("\n")
    assert len(lines) == 1, lines
    fields = lines[0].split("\t")
    assert len(fields) == 5, (len(fields), fields)
    # slug, started_at, last_activity, project_dir, goal
    assert fields[0] == "20260101000000-001", fields
    assert fields[3] == "/tmp", fields


def s_info_one_run():
    home = _mkhome()
    rd = _mkrun(home)
    cp = _viewer(home, "--run", "20260101000000-001", "--info")
    assert cp.returncode == 0, (cp.returncode, cp.stderr)
    out = cp.stdout
    expected_in_order = [
        "run: 20260101000000-001",
        "started: ",
        "last_activity: ",
        "project_dir: /tmp",
        "accounts: ",
        "goal:",
    ]
    idx = 0
    for needle in expected_in_order:
        i = out.find(needle, idx)
        assert i >= 0, (needle, out)
        idx = i + len(needle)
    assert "--- run.log (tail) ---" in out, out


def s_visits_and_sessions_shape():
    home = _mkhome()
    _mkrun(home, with_session=True)
    cp_v = _viewer(home, "--run", "20260101000000-001", "--step", "a",
                   "--visits")
    assert cp_v.returncode == 0, (cp_v.returncode, cp_v.stderr)
    line = cp_v.stdout.rstrip("\n").split("\n")[0]
    # "#NNN\tquestion=…\toutcome=…\tmtime=…"
    assert re.match(
        r"^#\d{3}\tquestion=[yn]\toutcome=.*\tmtime=.*$", line), repr(line)

    cp_s = _viewer(home, "--run", "20260101000000-001", "--step", "a",
                   "--sessions")
    assert cp_s.returncode == 0, (cp_s.returncode, cp_s.stderr)
    sline = cp_s.stdout.rstrip("\n").split("\n")[0]
    # "i\tkind\tmtime\tsize\tlines\tpath"
    parts = sline.split("\t")
    assert len(parts) == 6, (len(parts), parts)
    assert parts[0] == "0", parts
    assert parts[1] in ("claude", "codex"), parts


def s_session_dump():
    home = _mkhome()
    _mkrun(home, with_session=True)
    cp = _viewer(home, "--run", "20260101000000-001", "--step", "a",
                 "--session", "abc123.jsonl", "--dump")
    assert cp.returncode == 0, (cp.returncode, cp.stderr)
    assert len(cp.stdout) > 0, "dump should produce some output"
    assert "Traceback" not in cp.stdout + cp.stderr, cp.stdout + cp.stderr


def s_selftest():
    home = _mkhome()
    _mkrun(home, with_session=True)
    cp = _viewer(home, "--selftest")
    assert cp.returncode == 0, (cp.returncode, cp.stderr)
    line = cp.stdout.rstrip("\n").split("\n")[-1]
    assert re.match(
        r"^selftest: \d+ runs, \d+ sessions, \d+ parsed OK, \d+ errors$",
        line), repr(line)


def s_bare_non_tty():
    """Bare invocation with stdout redirected (no tty): documented fall
    through to --list, never opens curses, never hangs."""
    home = _mkhome()
    cp = _viewer(home)  # stdin already DEVNULL'd; stdout is a pipe
    assert cp.returncode == 0, (cp.returncode, cp.stderr)
    assert cp.stdout.startswith("No runs found under "), repr(cp.stdout)


def s_removed_flags_rejected():
    """The flag names removed in round 0001 must be rejected by argparse.

    Flag spellings are constructed at runtime via `"-" * 2 + <name>` so
    the literal four-character tokens are absent from this file.
    """
    home = _mkhome()
    cp1 = _viewer(home, _REMOVED_FLAG_LIVE)
    assert cp1.returncode == 2, (cp1.returncode, cp1.stderr)
    assert "unrecognized arguments" in cp1.stderr, cp1.stderr
    assert _REMOVED_FLAG_LIVE in cp1.stderr, cp1.stderr
    cp2 = _viewer(home, _REMOVED_FLAG_ONCE)
    assert cp2.returncode == 2, (cp2.returncode, cp2.stderr)
    assert "unrecognized arguments" in cp2.stderr, cp2.stderr
    assert _REMOVED_FLAG_ONCE in cp2.stderr, cp2.stderr


SCENARIOS = [
    ("list_empty_home", s_list_empty_home),
    ("list_one_run", s_list_one_run),
    ("info_one_run", s_info_one_run),
    ("visits_and_sessions_shape", s_visits_and_sessions_shape),
    ("session_dump", s_session_dump),
    ("selftest", s_selftest),
    ("bare_non_tty", s_bare_non_tty),
    ("removed_flags_rejected", s_removed_flags_rejected),
]


def main() -> int:
    for name, fn in SCENARIOS:
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            print(f"FAIL {name}: {e}")
            traceback.print_exc()
            return 1
        print(f"PASS {name}")
    print(f"ALL PASS ({len(SCENARIOS)} scenarios)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
