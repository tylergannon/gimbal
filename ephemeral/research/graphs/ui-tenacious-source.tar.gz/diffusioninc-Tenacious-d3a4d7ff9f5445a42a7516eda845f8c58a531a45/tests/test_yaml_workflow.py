"""YAML workflow loader tests.

Validates that Workflow.load accepts `.yaml`/`.yml` workflow files via
PyYAML and produces an in-memory Workflow byte-identical (in observable
schema fields) to loading the equivalent JSON. Also checks the error
path when PyYAML is missing and when the document is malformed.

Stdlib only, except PyYAML (which is a declared dependency for YAML
workflows; the test skips with PASS-N/A if it isn't installed, so JSON-
only environments still run the test suite cleanly).

Run from the project root:

    .venv/bin/python tests/test_yaml_workflow.py
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import tenacious.orchestrator as o  # noqa: E402


FAILS: list[str] = []


def _ok(name: str) -> None:
    print(f"PASS {name}")


def _fail(name: str, detail: str) -> None:
    FAILS.append(f"{name}: {detail}")
    print(f"FAIL {name}: {detail}")


def _check(name: str, cond: bool, detail: str) -> None:
    if cond:
        _ok(name)
    else:
        _fail(name, detail)


def _workflow_equal(a: o.Workflow, b: o.Workflow) -> tuple[bool, str]:
    if a.goal != b.goal:
        return False, f"goal differs: {a.goal!r} vs {b.goal!r}"
    if a.start_step != b.start_step:
        return False, f"start_step differs: {a.start_step!r} vs {b.start_step!r}"
    if a.base_prompt != b.base_prompt:
        return False, "base_prompt differs"
    if a.project_dir != b.project_dir:
        return False, f"project_dir differs: {a.project_dir!r} vs {b.project_dir!r}"
    if a.health_monitor_step != b.health_monitor_step:
        return False, "health_monitor_step differs"
    if a.health_monitor_interval_seconds != b.health_monitor_interval_seconds:
        return False, "health_monitor_interval_seconds differs"
    if set(a.steps) != set(b.steps):
        return False, f"step slugs differ: {set(a.steps)} vs {set(b.steps)}"
    for slug, sa in a.steps.items():
        sb = b.steps[slug]
        for field in ("agent", "prompt", "context", "questions", "model",
                      "next_steps", "asset_slugs", "assets"):
            va = getattr(sa, field)
            vb = getattr(sb, field)
            if va != vb:
                return False, f"step {slug!r} field {field} differs"
    return True, ""


def main() -> int:
    try:
        import yaml  # noqa: F401
    except ImportError:
        print("PASS yaml-skipped (PyYAML not installed; nothing to test)")
        return 0

    # --- Scenario 1: equivalent YAML and JSON load to equivalent workflows.
    json_doc = {
        "goal": "demo goal",
        "project_dir": "/tmp/proj",
        "start_step": "a",
        "base_prompt": "shared\nrules\n",
        "steps": {
            "a": {
                "agent": "claude",
                "model": "claude-opus-4-7",
                "prompt": "step a prompt {goal}",
                "next_steps": ["b"],
                "asset_slugs": [],
                "context": "empty",
            },
            "b": {
                "agent": "codex",
                "prompt": "step b prompt {goal}",
                "next_steps": ["end"],
                "asset_slugs": ["foo.md"],
                "context": "empty",
                "questions": False,
            },
        },
    }
    yaml_text = """\
goal: demo goal
project_dir: /tmp/proj
start_step: a
base_prompt: |
  shared
  rules
steps:
  a:
    agent: claude
    model: claude-opus-4-7
    prompt: "step a prompt {goal}"
    next_steps: [b]
    asset_slugs: []
    context: empty
  b:
    agent: codex
    prompt: "step b prompt {goal}"
    next_steps: [end]
    asset_slugs:
      - foo.md
    context: empty
    questions: false
"""

    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        jp = td / "wf.json"
        yp = td / "wf.yaml"
        ymlp = td / "wf.yml"
        jp.write_text(json.dumps(json_doc))
        yp.write_text(yaml_text)
        ymlp.write_text(yaml_text)

        wf_json = o.Workflow.load(jp)
        wf_yaml = o.Workflow.load(yp)
        wf_yml = o.Workflow.load(ymlp)

        ok, why = _workflow_equal(wf_json, wf_yaml)
        _check("yaml-equivalent-to-json", ok, why)
        ok2, why2 = _workflow_equal(wf_json, wf_yml)
        _check("yml-extension-also-works", ok2, why2)

        # --- Scenario 2: top-level non-mapping document is rejected.
        bad = td / "bad.yaml"
        bad.write_text("- just\n- a\n- list\n")
        try:
            o.Workflow.load(bad)
            _fail("yaml-non-mapping-rejected", "expected ValueError, got none")
        except ValueError as e:
            _check("yaml-non-mapping-rejected",
                   "must be a top-level mapping" in str(e),
                   f"unexpected message: {e}")

        # --- Scenario 3: invariants for the three shipped YAML workflows
        # (6step.yaml, iterative.yaml, 6step-goal-only.yaml).
        full_steps = {"requirements", "plan", "plan_eval", "plan_update",
                      "code", "code_review", "health_monitor"}
        goal_only_steps = full_steps - {"requirements"}
        full_assets = {
            "requirements":   ["requirements"],
            "plan":           ["plan"],
            "plan_eval":      ["plan-feedback"],
            "plan_update":    ["plan-revised"],
            "code":           ["code-notes"],
            "code_review":    ["status-update", "code-feedback"],
            "health_monitor": [],
        }
        goal_only_assets = {k: v for k, v in full_assets.items()
                            if k != "requirements"}
        invariants = [
            ("6step.yaml",           "requirements", full_steps,      full_assets),
            ("iterative.yaml",       "requirements", full_steps,      full_assets),
            ("6step-goal-only.yaml", "plan",         goal_only_steps, goal_only_assets),
        ]
        for src_name, want_start, want_steps, want_assets in invariants:
            src = Path(_PROJECT_ROOT) / "workflows" / src_name
            wf = o.Workflow.load(src, goal_override="X")
            if wf.start_step != want_start:
                _fail(f"shipped-yaml-{src_name}",
                      f"start_step={wf.start_step!r}, want {want_start!r}")
                continue
            if set(wf.steps) != want_steps:
                _fail(f"shipped-yaml-{src_name}",
                      f"steps={set(wf.steps)}, want {want_steps}")
                continue
            bad_assets = None
            for slug, want in want_assets.items():
                got = list(wf.steps[slug].assets)
                if got != want:
                    bad_assets = (slug, got, want)
                    break
            if bad_assets is not None:
                slug, got, want = bad_assets
                _fail(f"shipped-yaml-{src_name}",
                      f"{slug}.assets={got}, want {want}")
                continue
            edges = [("plan", "plan_eval"), ("plan_eval", "plan_update"),
                     ("plan_update", "code"), ("code", "code_review")]
            bad_edge = None
            for src_slug, want_dst in edges:
                if want_dst not in wf.steps[src_slug].next_steps:
                    bad_edge = (src_slug, want_dst,
                                list(wf.steps[src_slug].next_steps))
                    break
            if bad_edge is not None:
                src_slug, want_dst, got = bad_edge
                _fail(f"shipped-yaml-{src_name}",
                      f"{src_slug}.next_steps={got}, missing {want_dst!r}")
                continue
            _ok(f"shipped-yaml-{src_name}")

    if FAILS:
        print(f"\nFAILED ({len(FAILS)}):")
        for f in FAILS:
            print(f"  {f}")
        return 1
    print(f"\nALL PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
